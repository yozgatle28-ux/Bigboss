package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * Kuralları cihazın uygulama içi depolama alanında rules.json olarak
 * saklar. Kod yazmaya gerek kalmadan editörden eklenen her kural
 * buraya kaydolur ve uygulama her açıldığında buradan okunur.
 */
object RuleStorage {

    private const val FILE_NAME = "rules.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<RuleDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<RuleDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    fun save(context: Context, rules: List<RuleDefinition>) {
        val file = MacroScope.file(context, FILE_NAME)
        file.writeText(gson.toJson(rules))
    }

    fun addRule(context: Context, rule: RuleDefinition) {
        val rules = load(context)
        rules.add(rule)
        save(context, rules)
    }

    /** Aynı id varsa günceller, yoksa ekler. Kural editörü hem "yeni" hem "düzenle" için bunu kullanır. */
    fun upsert(context: Context, rule: RuleDefinition) {
        val rules = load(context)
        val idx = rules.indexOfFirst { it.id == rule.id }
        if (idx >= 0) rules[idx] = rule else rules.add(rule)
        save(context, rules)
    }

    fun deleteRule(context: Context, ruleId: String) {
        val rules = load(context)
        val removed = rules.filter { it.id == ruleId }
        rules.removeAll { it.id == ruleId }
        save(context, rules)
        removed.forEach { rule ->
            rule.alternatives.forEach { alt -> TemplateStorage.delete(alt.templatePath) }
        }
    }

    /** Macrorify'daki "Move Selected Up/Down": listedeki sırayı değiştirir (organizasyon amaçlı). */
    fun moveUp(context: Context, ruleId: String) {
        val rules = load(context)
        val idx = rules.indexOfFirst { it.id == ruleId }
        if (idx > 0) {
            val tmp = rules[idx - 1]; rules[idx - 1] = rules[idx]; rules[idx] = tmp
            save(context, rules)
        }
    }

    fun moveDown(context: Context, ruleId: String) {
        val rules = load(context)
        val idx = rules.indexOfFirst { it.id == ruleId }
        if (idx in 0 until rules.size - 1) {
            val tmp = rules[idx + 1]; rules[idx + 1] = rules[idx]; rules[idx] = tmp
            save(context, rules)
        }
    }
}
