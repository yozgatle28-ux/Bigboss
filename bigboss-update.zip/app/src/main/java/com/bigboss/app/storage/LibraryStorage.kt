package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * "library.json" içinde kaydedilmiş renk/resimleri tutar. Kural editöründe
 * her seferinde yeniden çizmek yerine buradan seçip tekrar kullanabilirsin.
 */
object LibraryStorage {

    private const val FILE_NAME = "library.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<LibraryItem> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<LibraryItem>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    fun save(context: Context, items: List<LibraryItem>) {
        val file = MacroScope.file(context, FILE_NAME)
        file.writeText(gson.toJson(items))
    }

    fun add(context: Context, item: LibraryItem) {
        val items = load(context)
        items.add(item)
        save(context, items)
    }

    /** Var olan bir öğeyi (aynı id) günceller, yoksa yeni ekler — sırasını KORUR (add'in aksine). */
    fun upsert(context: Context, item: LibraryItem) {
        val items = load(context)
        val idx = items.indexOfFirst { it.id == item.id }
        if (idx >= 0) items[idx] = item else items.add(item)
        save(context, items)
    }

    fun delete(context: Context, id: String) {
        val items = load(context)
        val removed = items.filter { it.id == id }
        items.removeAll { it.id == id }
        save(context, items)
        removed.forEach { TemplateStorage.delete(it.templatePath) }
    }
}
