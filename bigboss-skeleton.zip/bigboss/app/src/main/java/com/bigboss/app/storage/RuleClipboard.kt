package com.bigboss.app.storage

/**
 * Macrorify'ın Ana Akış listesindeki "Copy Selected / Cut Selected /
 * Paste Copied-Cut" işlevlerinin karşılığı. Sadece bellekte tutulur
 * (uygulama kapanınca sıfırlanır) — bir kuralı kopyalayıp/kesip başka
 * bir yere (ya da aynı yere tekrar) yapıştırmanı sağlar.
 */
object RuleClipboard {
    private var copied: RuleDefinition? = null

    fun copy(rule: RuleDefinition) {
        copied = rule.copy(alternatives = rule.alternatives.map { it.copy() }.toMutableList())
    }

    fun hasContent(): Boolean = copied != null

    fun peekName(): String? = copied?.name

    /** Panodaki kuralı YENİ bir id ile döner (aynı kuralı birden çok kez yapıştırabilirsin). */
    fun pasteAsNew(): RuleDefinition? {
        val src = copied ?: return null
        return src.copy(
            id = java.util.UUID.randomUUID().toString(),
            alternatives = src.alternatives.map { it.copy() }.toMutableList()
        )
    }

    fun clear() { copied = null }
}
