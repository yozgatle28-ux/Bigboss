package com.bigboss.app.storage

import android.content.Context
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Rule

/**
 * Motoru (RuleEngine) her yerde AYNI şekilde kurmak için merkezi yer.
 * Ana Akış kurallarının yanına, her etkin Action Group için bir
 * "kapı kuralı" (gate rule) ekler — bu kural sadece kapı koşulunu
 * kontrol eder, doğruysa grubun içindeki taramaları (Fonksiyon çağırma
 * mekanizmasıyla) tetikler. Kapı yanlışsa, gruptaki taramalar HİÇ
 * kontrol edilmez — performans kazancı burada.
 */
object EngineAssembler {

    fun buildRules(context: Context): List<Rule> {
        val mainRules = RuleDefinitionMapper.toRules(RuleStorage.load(context))
        val groups = ActionGroupStorage.load(context).filter { it.enabled && it.gate != null }
        val gateRules = groups.map { group ->
            val gateDef = RuleDefinition(
                id = "group-gate-${group.id}",
                name = "📦 ${group.name}",
                alternatives = mutableListOf(group.gate!!),
                timeoutMs = group.gateCooldownMs
            )
            Rule(
                id = gateDef.id,
                name = gateDef.name,
                condition = RuleDefinitionMapper.toCondition(gateDef),
                thenAction = Action.CallFunction(group.id, 1),
                cooldownMs = group.gateCooldownMs,
                enabled = true,
                negate = false,
                loopMode = "ALWAYS"
            )
        }
        return mainRules + gateRules
    }

    /** Function çağırma mekanizmasını, hem Fonksiyonlar hem Action Group'lar için ortak kullanır. */
    fun buildFunctionsProvider(context: Context): (String) -> List<Rule> = { id ->
        FunctionStorage.load(context).find { it.id == id }?.let { RuleDefinitionMapper.toRules(it.rules) }
            ?: ActionGroupStorage.load(context).find { it.id == id }?.let { RuleDefinitionMapper.toRules(it.rules) }
            ?: emptyList()
    }

    /** Botu çalıştıran RuleEngine'e en güncel kural+fonksiyon listesini yükler. */
    fun refresh(context: Context) {
        val engine = com.bigboss.app.service.ScreenCaptureService.ruleEngine ?: return
        engine.setRules(buildRules(context))
        engine.setFunctionsProvider(buildFunctionsProvider(context))
    }
}
