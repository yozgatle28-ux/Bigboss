package com.bigboss.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bigboss.app.databinding.ItemScriptBinding
import com.bigboss.app.storage.ScriptDefinition

class ScriptsAdapter(
    private val onOpen: (ScriptDefinition) -> Unit,
    private val onDelete: (ScriptDefinition) -> Unit
) : RecyclerView.Adapter<ScriptsAdapter.ScriptViewHolder>() {

    private val items = mutableListOf<ScriptDefinition>()

    fun submitList(newItems: List<ScriptDefinition>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class ScriptViewHolder(val binding: ItemScriptBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScriptViewHolder {
        val binding = ItemScriptBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ScriptViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ScriptViewHolder, position: Int) {
        val script = items[position]
        holder.binding.tvScriptName.text = "🖥️ ${script.name}"
        holder.binding.root.setOnClickListener { onOpen(script) }
        holder.binding.btnDeleteScript.setOnClickListener { onDelete(script) }
    }

    override fun getItemCount(): Int = items.size
}
