package com.bigboss.app.storage

/**
 * Macrorify'ın "EMScript" fikrinden ilham alan, JavaScript tabanlı
 * (Rhino motoruyla çalışan) kod parçası. Değişken, if/else, döngü,
 * fonksiyon, sınıf — hepsi gerçek JS söz dizimiyle yazılabilir.
 * BigBoss'a özel köprü fonksiyonları (tap, swipe, findColor, vb.)
 * için README'deki "Kod Sistemi (Script)" bölümüne bak.
 */
data class ScriptDefinition(
    val id: String,
    var name: String,
    var code: String = "// Örnek:\nlog(\"Merhaba BigBoss\")\n"
)
