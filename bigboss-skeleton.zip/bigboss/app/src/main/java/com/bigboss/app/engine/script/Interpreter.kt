package com.bigboss.app.engine.script

class RuntimeErrorScript(message: String) : Exception(message)
private class ReturnSignal(val value: Any?) : RuntimeException(null, null, false, false)
private object BreakSignal : RuntimeException(null, null, false, false)
private object ContinueSignal : RuntimeException(null, null, false, false)

class Environment(val parent: Environment?) {
    private val values = HashMap<String, Any?>()

    fun define(name: String, value: Any?) { values[name] = value }

    fun get(name: String): Any? {
        if (values.containsKey(name)) return values[name]
        parent?.let { return it.get(name) }
        throw RuntimeErrorScript("Tanımsız değişken: $name")
    }

    fun assign(name: String, value: Any?) {
        if (values.containsKey(name)) { values[name] = value; return }
        if (parent != null) { parent.assign(name, value); return }
        // Bilinmeyen isimlere atama yapılırsa global kapsamda otomatik tanımla (JS benzeri kolaylık)
        values[name] = value
    }
}

interface Callable {
    fun call(interp: Interpreter, args: List<Any?>): Any?
    val arity: Int get() = -1 // -1 = esnek
}

class NativeFunction(val name: String, private val fn: (List<Any?>) -> Any?) : Callable {
    override fun call(interp: Interpreter, args: List<Any?>): Any? = fn(args)
}

class NativeNamespace(val name: String, val methods: Map<String, NativeFunction>)

class EMFunction(
    val paramNames: List<String>,
    val body: List<Stmt>,
    val closure: Environment,
    val name: String = "",
    val boundThis: EMInstance? = null
) : Callable {
    fun bind(instance: EMInstance): EMFunction = EMFunction(paramNames, body, closure, name, instance)

    override fun call(interp: Interpreter, args: List<Any?>): Any? {
        val env = Environment(closure)
        paramNames.forEachIndexed { i, p -> env.define(p, args.getOrNull(i)) }
        if (boundThis != null) env.define("this", boundThis)
        return try {
            interp.executeBlock(body, env)
            null
        } catch (r: ReturnSignal) {
            r.value
        }
    }
}

class EMClass(
    val name: String,
    val fieldNames: List<String>,
    val methods: Map<String, EMFunction>,
    val staticMethods: Map<String, EMFunction>,
    val staticFields: Environment
) {
    fun instantiate(interp: Interpreter, args: List<Any?>): EMInstance {
        val instance = EMInstance(this)
        fieldNames.forEach { instance.fields[it] = null }
        methods["init"]?.bind(instance)?.call(interp, args)
        return instance
    }
}

class EMInstance(val klass: EMClass) {
    val fields = HashMap<String, Any?>()

    fun get(name: String): Any? {
        if (fields.containsKey(name)) return fields[name]
        klass.methods[name]?.let { return it.bind(this) }
        throw RuntimeErrorScript("${klass.name} nesnesinde '$name' yok")
    }

    fun set(name: String, value: Any?) { fields[name] = value }
}

/** BigScript kodunu çalıştıran ağaç-gezici (tree-walking) yorumlayıcı. */
class Interpreter(val context: ScriptContext) {
    val globals = Environment(null)
    private var environment = globals

    init {
        ScriptBridge.install(globals, context)
    }

    fun run(program: List<Stmt>) {
        try {
            for (stmt in program) execute(stmt)
        } catch (r: ReturnSignal) { /* en üst seviyede return -> yoksay */ }
    }

    fun callGlobalFunction(name: String, args: List<Any?> = emptyList()): Any? {
        val fn = globals.get(name)
        if (fn is Callable) return fn.call(this, args)
        throw RuntimeErrorScript("'$name' bir fonksiyon değil")
    }

    fun hasGlobal(name: String): Boolean = try { globals.get(name); true } catch (e: Exception) { false }

    // ---- statement çalıştırma ----

    private fun execute(stmt: Stmt) {
        when (stmt) {
            is Stmt.ExprStmt -> evaluate(stmt.expr)
            is Stmt.VarDecl -> environment.define(stmt.name, stmt.init?.let { evaluate(it) })
            is Stmt.Block -> executeBlock(stmt.stmts, Environment(environment))
            is Stmt.If -> {
                if (truthy(evaluate(stmt.cond))) execute(stmt.thenB)
                else stmt.elseB?.let { execute(it) }
            }
            is Stmt.While -> {
                while (truthy(evaluate(stmt.cond))) {
                    try { execute(stmt.body) } catch (b: BreakSignal) { break } catch (c: ContinueSignal) { }
                }
            }
            is Stmt.DoWhile -> {
                do {
                    try { execute(stmt.body) } catch (b: BreakSignal) { break } catch (c: ContinueSignal) { }
                } while (truthy(evaluate(stmt.cond)))
            }
            is Stmt.For -> {
                val loopEnv = Environment(environment)
                val prev = environment
                environment = loopEnv
                try {
                    stmt.init?.let { execute(it) }
                    while (stmt.cond == null || truthy(evaluate(stmt.cond))) {
                        try { execute(stmt.body) } catch (b: BreakSignal) { break } catch (c: ContinueSignal) { }
                        stmt.step?.let { execute(it) }
                    }
                } finally { environment = prev }
            }
            is Stmt.ForEach -> {
                val iterable = evaluate(stmt.iterable)
                val items: List<Any?> = when (iterable) {
                    is MutableList<*> -> iterable
                    else -> throw RuntimeErrorScript("foreach sadece dizi üzerinde çalışır")
                }
                for (item in items) {
                    val loopEnv = Environment(environment)
                    loopEnv.define(stmt.varName, item)
                    val prev = environment
                    environment = loopEnv
                    try {
                        try { execute(stmt.body) } catch (b: BreakSignal) { throw b }
                    } catch (c: ContinueSignal) {
                    } catch (b: BreakSignal) {
                        environment = prev; break
                    } finally { environment = prev }
                }
            }
            is Stmt.FunDecl -> environment.define(stmt.name, EMFunction(stmt.params, stmt.body, environment, stmt.name))
            is Stmt.ClassDecl -> {
                val methods = stmt.methods.associate { it.name to EMFunction(it.params, it.body, environment, it.name) }
                val staticMethods = stmt.staticMethods.associate { it.name to EMFunction(it.params, it.body, environment, it.name) }
                val staticEnv = Environment(environment)
                stmt.staticFields.forEach { (n, init) -> staticEnv.define(n, init?.let { evaluate(it) }) }
                val klass = EMClass(stmt.name, stmt.fields, methods, staticMethods, staticEnv)
                environment.define(stmt.name, klass)
            }
            is Stmt.Return -> throw ReturnSignal(stmt.value?.let { evaluate(it) })
            Stmt.Break -> throw BreakSignal
            Stmt.Continue -> throw ContinueSignal
        }
    }

    fun executeBlock(stmts: List<Stmt>, env: Environment): Any? {
        val previous = environment
        environment = env
        try {
            for (s in stmts) execute(s)
        } finally {
            environment = previous
        }
        return null
    }

    // ---- ifade değerlendirme ----

    private fun evaluate(expr: Expr): Any? = when (expr) {
        is Expr.Literal -> expr.value
        is Expr.VarRef -> environment.get(expr.name)
        is Expr.Assign -> evaluate(expr.value).also { environment.assign(expr.name, it) }
        is Expr.Unary -> {
            val v = evaluate(expr.right)
            when (expr.op) {
                "-" -> -(asNumber(v))
                "!" -> !truthy(v)
                else -> throw RuntimeErrorScript("Bilinmeyen tekli operatör ${expr.op}")
            }
        }
        is Expr.Binary -> evalBinary(expr)
        is Expr.Logical -> {
            val left = evaluate(expr.left)
            if (expr.op == "||") { if (truthy(left)) left else evaluate(expr.right) }
            else { if (!truthy(left)) left else evaluate(expr.right) }
        }
        is Expr.Ternary -> if (truthy(evaluate(expr.cond))) evaluate(expr.thenE) else evaluate(expr.elseE)
        is Expr.Call -> evalCall(expr)
        is Expr.Get -> evalGet(expr)
        is Expr.SetProp -> {
            val obj = evaluate(expr.obj)
            val value = evaluate(expr.value)
            when (obj) {
                is EMInstance -> obj.set(expr.name, value)
                else -> throw RuntimeErrorScript("'${expr.name}' bu nesneye atanamaz")
            }
            value
        }
        is Expr.Index -> {
            val target = evaluate(expr.target)
            val idx = evaluate(expr.index)
            when (target) {
                is MutableList<*> -> target.getOrNull(asNumber(idx).toInt())
                is String -> target.getOrNull(asNumber(idx).toInt())?.toString()
                else -> throw RuntimeErrorScript("İndeksleme desteklenmiyor")
            }
        }
        is Expr.IndexSet -> {
            val target = evaluate(expr.target)
            val idx = asNumber(evaluate(expr.index)).toInt()
            val value = evaluate(expr.value)
            @Suppress("UNCHECKED_CAST")
            when (target) {
                is MutableList<Any?> -> {
                    while (target.size <= idx) target.add(null)
                    target[idx] = value
                }
                else -> throw RuntimeErrorScript("İndeksle atama desteklenmiyor")
            }
            value
        }
        is Expr.ArrayLit -> expr.items.map { evaluate(it) }.toMutableList()
        is Expr.FunctionExpr -> EMFunction(expr.params, expr.body, environment)
        Expr.ThisExpr -> environment.get("this")
        is Expr.New -> {
            val klass = environment.get(expr.className)
            if (klass !is EMClass) throw RuntimeErrorScript("${expr.className} bir sınıf değil")
            klass.instantiate(this, expr.args.map { evaluate(it) })
        }
    }

    private fun evalBinary(expr: Expr.Binary): Any? {
        val l = evaluate(expr.left)
        val r = evaluate(expr.right)
        return when (expr.op) {
            "+" -> if (l is String || r is String) stringify(l) + stringify(r) else asNumber(l) + asNumber(r)
            "-" -> asNumber(l) - asNumber(r)
            "*" -> asNumber(l) * asNumber(r)
            "/" -> asNumber(l) / asNumber(r)
            "%" -> asNumber(l) % asNumber(r)
            "==" -> l == r
            "!=" -> l != r
            "<" -> asNumber(l) < asNumber(r)
            ">" -> asNumber(l) > asNumber(r)
            "<=" -> asNumber(l) <= asNumber(r)
            ">=" -> asNumber(l) >= asNumber(r)
            else -> throw RuntimeErrorScript("Bilinmeyen operatör ${expr.op}")
        }
    }

    private fun evalCall(expr: Expr.Call): Any? {
        val args = expr.args.map { evaluate(it) }
        // metot çağrısı: obj.method(args)
        if (expr.callee is Expr.Get) {
            val objExpr = expr.callee.obj
            val obj = evaluate(objExpr)
            return when (obj) {
                is NativeNamespace -> {
                    val fn = obj.methods[expr.callee.name] ?: throw RuntimeErrorScript("${obj.name}.${expr.callee.name} yok")
                    fn.call(this, args)
                }
                is EMInstance -> {
                    val member = obj.get(expr.callee.name)
                    if (member is Callable) member.call(this, args)
                    else throw RuntimeErrorScript("${expr.callee.name} çağrılabilir değil")
                }
                is EMClass -> {
                    val fn = obj.staticMethods[expr.callee.name] ?: throw RuntimeErrorScript("${obj.name}.${expr.callee.name} yok")
                    fn.call(this, args)
                }
                is MutableList<*> -> {
                    @Suppress("UNCHECKED_CAST") val list = obj as MutableList<Any?>
                    when (expr.callee.name) {
                        "push" -> { list.add(args.getOrNull(0)); list.size.toDouble() }
                        "size" -> list.size.toDouble()
                        else -> throw RuntimeErrorScript("Dizi metodu yok: ${expr.callee.name}")
                    }
                }
                else -> throw RuntimeErrorScript("Metot çağrılamıyor: ${expr.callee.name}")
            }
        }
        val callee = evaluate(expr.callee)
        if (callee is Callable) return callee.call(this, args)
        throw RuntimeErrorScript("Çağrılabilir değil")
    }

    private fun evalGet(expr: Expr.Get): Any? {
        val obj = evaluate(expr.obj)
        return when (obj) {
            is EMInstance -> obj.get(expr.name)
            is EMClass -> {
                if (expr.name == "name") obj.name
                else try { obj.staticFields.get(expr.name) } catch (e: Exception) {
                    obj.staticMethods[expr.name] ?: throw RuntimeErrorScript("${obj.name}.${expr.name} yok")
                }
            }
            is MutableList<*> -> when (expr.name) {
                "size" -> obj.size.toDouble()
                else -> throw RuntimeErrorScript("Dizi özelliği yok: ${expr.name}")
            }
            is String -> when (expr.name) {
                "length" -> obj.length.toDouble()
                else -> throw RuntimeErrorScript("String özelliği yok: ${expr.name}")
            }
            is NativeNamespace -> obj.methods[expr.name] ?: throw RuntimeErrorScript("${obj.name}.${expr.name} yok")
            else -> throw RuntimeErrorScript("'.${expr.name}' bu değere uygulanamaz")
        }
    }

    companion object {
        fun truthy(v: Any?): Boolean = when (v) { null -> false; is Boolean -> v; else -> true }
        fun asNumber(v: Any?): Double = when (v) {
            is Double -> v
            is Int -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: throw RuntimeErrorScript("Sayıya çevrilemedi: $v")
            is Boolean -> if (v) 1.0 else 0.0
            else -> throw RuntimeErrorScript("Sayı bekleniyordu")
        }
        fun stringify(v: Any?): String = when (v) {
            null -> "null"
            is Double -> if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
            is MutableList<*> -> "[" + v.joinToString(", ") { stringify(it) } + "]"
            else -> v.toString()
        }
    }
}
