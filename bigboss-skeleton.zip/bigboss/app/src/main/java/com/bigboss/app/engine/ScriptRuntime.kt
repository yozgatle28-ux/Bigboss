package com.bigboss.app.engine

/**
 * ScriptEngine, Context'e ihtiyaç duyduğu için (Function/VariableStore
 * köprüleri) Condition/Action seviyesinde doğrudan oluşturulamıyor.
 * Bunun yerine EditModeActivity/PlayModeActivity botu başlatırken bir
 * ScriptEngine kurup buraya atıyor; Condition.Script gibi sınıflar
 * buradan erişiyor.
 */
object ScriptRuntime {
    var engine: ScriptEngine? = null
}
