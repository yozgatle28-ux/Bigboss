package com.bigboss.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityScriptEditorBinding
import com.bigboss.app.engine.ScriptRuntime
import com.bigboss.app.storage.ScriptDefinition
import com.bigboss.app.storage.ScriptStorage
import java.util.UUID

/**
 * Bir Script'i (JavaScript, Rhino motoruyla) yazıp test edip kaydettiğin
 * ekran. "▶️ Test Et", çalışan ScriptRuntime.engine varsa (Edit/Play Mode
 * aktifse) script'i GERÇEKTEN çalıştırır — Edit Mode'daysa tap()/swipe()
 * çağrıları otomatik olarak engellenir (güvenlik), sadece log()/findColor()
 * gibi salt-okunur şeyler çalışır.
 */
class ScriptEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SCRIPT_ID = "script_id"
    }

    private lateinit var binding: ActivityScriptEditorBinding
    private var scriptId: String = UUID.randomUUID().toString()
    private var isNew = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScriptEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val editId = intent.getStringExtra(EXTRA_SCRIPT_ID)
        if (editId != null) {
            val existing = ScriptStorage.load(this).find { it.id == editId }
            if (existing != null) {
                scriptId = existing.id
                isNew = false
                binding.etScriptName.setText(existing.name)
                binding.etScriptCode.setText(existing.code)
            }
        }
        if (binding.etScriptCode.text.isNullOrBlank()) {
            binding.etScriptCode.setText(
                "// ==== Basit fonksiyonlar ====\n" +
                "// tap(x, y, {repeat, hold, delay, random})\n" +
                "// swipe(x1, y1, x2, y2, {duration, holdStart, holdEnd, delay, random})\n" +
                "// swipePath([{x,y,hold}, {x,y,hold}, ...], sureHer)  -- çok noktalı kaydırma\n" +
                "// wait(ms)\n" +
                "// back() | home() | recents() | notifications() | quickSettings()\n" +
                "// getVar(ad) | setVar(ad, deger)                -- oyun-içi sayaç\n" +
                "// getGlobalVar(ad) | setGlobalVar(ad, deger)     -- kalıcı Değişkenler\n" +
                "// colorAt(x, y) | randomInt(min, max)\n" +
                "// findColor(x,y,w,h,\"#RRGGBB\",minSkor) | findImage(x,y,w,h,\"kütüphaneAdi\",minSkor) | findText(x,y,w,h,\"metin\")\n" +
                "// callFunction(\"fonksiyonAdi\", tekrar) | runScript(\"scriptAdi\") | log(mesaj)\n" +
                "//\n" +
                "// ==== Region nesnesi (daha güçlü, EMScript'teki Region sınıfı gibi) ====\n" +
                "// var r = Region(x, y, w, h)\n" +
                "// r.findColor(\"#RRGGBB\", minSkor) | r.findImage(\"kütüphaneAdi\", minSkor) | r.findText(\"metin\")\n" +
                "// r.findImageMatch(\"kütüphaneAdi\", minSkor)  -> {found, x, y, score} ya da null\n" +
                "// r.tap({hold}) | r.center() -> {x, y}\n\n" +
                "log(\"Merhaba BigBoss\")\n\n" +
                "var dusman = Region(100, 200, 300, 300)\n" +
                "var m = dusman.findImageMatch(\"dusman\", 0.8)\n" +
                "if (m) {\n" +
                "    tap(m.x, m.y, {hold: 80})\n" +
                "    setVar(\"vurus\", getVar(\"vurus\") + 1)\n" +
                "}\n"
            )
        }

        binding.btnTestScript.setOnClickListener { testScript() }
        binding.btnSaveScript.setOnClickListener { saveScript() }
        binding.btnDeleteScriptEditor.setOnClickListener { deleteScript() }
    }

    private fun testScript() {
        val engine = ScriptRuntime.engine
        if (engine == null) {
            binding.tvScriptOutput.text = "⚠️ Şu an çalışan bir motor yok — önce Edit Mode veya Play Mode'u başlat."
            return
        }
        val code = binding.etScriptCode.text.toString()
        val error = engine.run(code)
        binding.tvScriptOutput.text = if (error != null) "❌ Hata: $error" else "✅ Çalıştı. (Logcat'te \"BigBossScript\" etiketiyle log() çıktılarını görebilirsin.)"
        Toast.makeText(this, if (error != null) "Script hata verdi" else "Script çalıştı", Toast.LENGTH_SHORT).show()
    }

    private fun saveScript() {
        val name = binding.etScriptName.text.toString().ifBlank { "İsimsiz script" }
        val code = binding.etScriptCode.text.toString()
        ScriptStorage.upsert(this, ScriptDefinition(scriptId, name, code))
        isNew = false
        Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun deleteScript() {
        if (isNew) { finish(); return }
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage("Bu script'i silmek istediğine emin misin?")
            .setPositiveButton("Sil") { _, _ ->
                ScriptStorage.delete(this, scriptId)
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
