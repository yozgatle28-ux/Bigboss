package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Macrorify'daki "Action Result" koşulunun temeli: bir kuralın en son
 * ne zaman tetiklendiğini tutar. Böylece "B kuralı, A kuralı yakın
 * zamanda tetiklendiyse çalışsın" gibi SIRA gerektiren senaryolar,
 * paralel/reaktif motorda da mümkün olur — gerçek bir "sıra" olmadan.
 */
object ActionResultRegistry {
    private val lastFiredAt = ConcurrentHashMap<String, Long>()

    fun markFired(ruleId: String) {
        lastFiredAt[ruleId] = System.currentTimeMillis()
    }

    fun firedWithin(ruleId: String, withinMs: Long): Boolean {
        val t = lastFiredAt[ruleId] ?: return false
        return System.currentTimeMillis() - t <= withinMs
    }

    fun lastFiredAt(ruleId: String): Long? = lastFiredAt[ruleId]

    fun reset() = lastFiredAt.clear()
}
