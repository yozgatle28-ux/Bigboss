package com.bigboss.app.storage

/**
 * "BAŞARILI OLUNCA" / "BULUNAMAZSA" sekmelerinde eklenen SIRALI
 * adımlardan biri. Bir RuleDefinition'ın `extraSteps` listesi, bu
 * adımların sırayla (tek seferde, art arda) çalıştırılmasını temsil eder.
 */
data class ActionStep(
    /** "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT" */
    var type: String,
    var x: Int = 0,
    var y: Int = 0,
    var x2: Int = 0,
    var y2: Int = 0,
    var waitMs: Long = 500,
    var repeat: Int = 1,
    var functionId: String? = null,
    var variableName: String = "",
    var variableDelta: Int = 1,
    var scriptId: String? = null,
    var scriptCode: String? = null
)
