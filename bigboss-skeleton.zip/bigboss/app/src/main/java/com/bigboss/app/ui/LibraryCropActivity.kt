package com.bigboss.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityLibraryCropBinding
import com.bigboss.app.storage.LibraryStorage
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kütüphanede zaten kayıtlı bir resmi PİKSEL HASSASİYETİYLE yeniden
 * kırpar. Hem sürükleyerek (görsel) hem de X/Y/Genişlik/Yükseklik
 * kutularına tam sayı yazarak (kesin) ayarlanabilir — ikisi birbirini
 * canlı günceller.
 */
class LibraryCropActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LIBRARY_ITEM_ID = "library_item_id"
    }

    private lateinit var binding: ActivityLibraryCropBinding
    private lateinit var original: Bitmap
    private lateinit var itemId: String
    private lateinit var path: String

    private lateinit var cropBox: View
    private lateinit var handle: View
    private var suppressFieldSync = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLibraryCropBinding.inflate(layoutInflater)
        setContentView(binding.root)

        itemId = intent.getStringExtra(EXTRA_LIBRARY_ITEM_ID) ?: run { finish(); return }
        val item = LibraryStorage.load(this).find { it.id == itemId }
        val p = item?.templatePath
        if (item == null || p.isNullOrBlank()) {
            Toast.makeText(this, "Görsel bulunamadı", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        path = p
        val bmp = BitmapFactory.decodeFile(path)
        if (bmp == null) {
            Toast.makeText(this, "Görsel okunamadı", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        original = bmp
        binding.ivImage.setImageBitmap(original)

        // Kırpma kutusu ve tutamacı, resmin üstüne kod ile ekleniyor
        cropBox = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#332196F3"))
                setStroke(6, Color.parseColor("#2196F3"))
            }
        }
        handle = View(this).apply { setBackgroundColor(Color.WHITE) }
        binding.imageContainer.addView(cropBox)
        binding.imageContainer.addView(handle, android.widget.FrameLayout.LayoutParams(36, 36))

        binding.ivImage.post { initCropBoxToFullImage() }

        setupDrag()
        setupFieldSync()

        binding.btnCancelCrop.setOnClickListener { finish() }
        binding.btnApplyCrop.setOnClickListener { applyCrop() }
    }

    /** ImageView içindeki GERÇEK görüntü alanının (fitCenter boşluklarını hariç tutarak) sınırlarını hesaplar. */
    private fun imageDisplayRect(): FloatArray {
        val iv = binding.ivImage
        val viewW = iv.width.toFloat(); val viewH = iv.height.toFloat()
        val bmpW = original.width.toFloat(); val bmpH = original.height.toFloat()
        val scale = min(viewW / bmpW, viewH / bmpH)
        val dispW = bmpW * scale; val dispH = bmpH * scale
        val left = (viewW - dispW) / 2f
        val top = (viewH - dispH) / 2f
        return floatArrayOf(left, top, dispW, dispH, scale)
    }

    private fun initCropBoxToFullImage() {
        val (left, top, dispW, dispH, _) = imageDisplayRect()
        cropBox.x = left; cropBox.y = top
        cropBox.layoutParams = cropBox.layoutParams?.apply {
            width = dispW.toInt(); height = dispH.toInt()
        } ?: android.widget.FrameLayout.LayoutParams(dispW.toInt(), dispH.toInt())
        cropBox.requestLayout()
        positionHandle()
        syncFieldsFromBox()
    }

    private fun positionHandle() {
        handle.x = cropBox.x + cropBox.width - 18f
        handle.y = cropBox.y + cropBox.height - 18f
    }

    private fun setupDrag() {
        var downRawX = 0f; var downRawY = 0f
        var boxStartX = 0f; var boxStartY = 0f

        cropBox.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    boxStartX = cropBox.x; boxStartY = cropBox.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX; val dy = event.rawY - downRawY
                    val (left, top, dispW, dispH, _) = imageDisplayRect()
                    val maxX = left + dispW - cropBox.width
                    val maxY = top + dispH - cropBox.height
                    cropBox.x = (boxStartX + dx).coerceIn(left, max(left, maxX))
                    cropBox.y = (boxStartY + dy).coerceIn(top, max(top, maxY))
                    positionHandle()
                    syncFieldsFromBox()
                }
            }
            true
        }

        handle.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val (left, top, dispW, dispH, _) = imageDisplayRect()
                val minSize = 20f
                val newW = (event.rawX - cropBox.x).coerceIn(minSize, left + dispW - cropBox.x)
                val newH = (event.rawY - cropBox.y).coerceIn(minSize, top + dispH - cropBox.y)
                cropBox.layoutParams = cropBox.layoutParams.apply {
                    width = newW.toInt(); height = newH.toInt()
                }
                cropBox.requestLayout()
                positionHandle()
                syncFieldsFromBox()
            }
            true
        }
    }

    /** Sürükleme kutusundan -> X/Y/W/H kutularına (piksel cinsinden gerçek koordinat). */
    private fun syncFieldsFromBox() {
        if (suppressFieldSync) return
        val (left, top, _, _, scale) = imageDisplayRect()
        val px = ((cropBox.x - left) / scale).toInt().coerceAtLeast(0)
        val py = ((cropBox.y - top) / scale).toInt().coerceAtLeast(0)
        val pw = (cropBox.width / scale).toInt().coerceAtLeast(1)
        val ph = (cropBox.height / scale).toInt().coerceAtLeast(1)
        suppressFieldSync = true
        binding.etX.setText(px.toString())
        binding.etY.setText(py.toString())
        binding.etW.setText(pw.toString())
        binding.etH.setText(ph.toString())
        suppressFieldSync = false
    }

    /** X/Y/W/H kutularından -> sürükleme kutusuna (kullanıcı elle tam sayı yazarsa). */
    private fun setupFieldSync() {
        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { syncBoxFromFields() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        binding.etX.addTextChangedListener(watcher)
        binding.etY.addTextChangedListener(watcher)
        binding.etW.addTextChangedListener(watcher)
        binding.etH.addTextChangedListener(watcher)
    }

    private fun syncBoxFromFields() {
        if (suppressFieldSync) return
        val (left, top, dispW, dispH, scale) = imageDisplayRect()
        val px = binding.etX.text.toString().toIntOrNull() ?: return
        val py = binding.etY.text.toString().toIntOrNull() ?: return
        val pw = binding.etW.text.toString().toIntOrNull() ?: return
        val ph = binding.etH.text.toString().toIntOrNull() ?: return
        if (pw <= 0 || ph <= 0) return

        suppressFieldSync = true
        cropBox.x = left + px * scale
        cropBox.y = top + py * scale
        cropBox.layoutParams = cropBox.layoutParams.apply {
            width = (pw * scale).toInt().coerceAtLeast(1)
            height = (ph * scale).toInt().coerceAtLeast(1)
        }
        cropBox.requestLayout()
        positionHandle()
        suppressFieldSync = false
    }

    private fun applyCrop() {
        val px = binding.etX.text.toString().toIntOrNull() ?: 0
        val py = binding.etY.text.toString().toIntOrNull() ?: 0
        val pw = binding.etW.text.toString().toIntOrNull() ?: original.width
        val ph = binding.etH.text.toString().toIntOrNull() ?: original.height

        val safeX = px.coerceIn(0, original.width - 1)
        val safeY = py.coerceIn(0, original.height - 1)
        val safeW = pw.coerceIn(1, original.width - safeX)
        val safeH = ph.coerceIn(1, original.height - safeY)

        try {
            val cropped = Bitmap.createBitmap(original, safeX, safeY, safeW, safeH)
            FileOutputStream(path).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Kırpıldı ve kaydedildi (${safeW}x${safeH}px)", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
