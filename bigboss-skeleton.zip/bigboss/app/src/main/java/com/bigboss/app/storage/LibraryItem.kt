package com.bigboss.app.storage

/**
 * Kütüphaneye kaydedilmiş, tekrar tekrar farklı kurallarda çağrılabilecek
 * bir renk ya da resim (Macrorify'daki "Manage Images" / kaydedilmiş
 * Template fikri).
 */
data class LibraryItem(
    val id: String,
    var name: String,
    /** "COLOR" ya da "IMAGE" */
    var kind: String,
    /** kind = "COLOR" için renk (Int, ARGB) */
    var color: Int = 0,
    /** kind = "IMAGE" için kaydedilmiş PNG dosya yolu */
    var templatePath: String? = null
)
