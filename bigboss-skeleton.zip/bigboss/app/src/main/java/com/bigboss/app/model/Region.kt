package com.bigboss.app.model

/**
 * Ekran üzerinde izlenecek dikdörtgen bölge.
 * Koordinatlar cihazın gerçek piksel çözünürlüğüne göredir (sol üst köşe = 0,0).
 */
data class Region(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
) {
    val centerX: Int get() = x + width / 2
    val centerY: Int get() = y + height / 2
}
