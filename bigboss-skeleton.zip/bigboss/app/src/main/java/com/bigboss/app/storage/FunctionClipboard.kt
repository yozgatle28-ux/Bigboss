package com.bigboss.app.storage

/** "f{} Fonksiyonlar" sayfasındaki Kopyala/Kes/Yapıştır için — RuleClipboard'ın Fonksiyon karşılığı. */
object FunctionClipboard {
    private var copied: FunctionDefinition? = null

    fun copy(fn: FunctionDefinition) {
        copied = fn.copy(rules = fn.rules.map { it.copy() }.toMutableList())
    }

    fun hasContent(): Boolean = copied != null
    fun peekName(): String? = copied?.name

    fun pasteAsNew(): FunctionDefinition? {
        val src = copied ?: return null
        return src.copy(
            id = java.util.UUID.randomUUID().toString(),
            rules = src.rules.map { it.copy() }.toMutableList()
        )
    }
}
