package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Macrorify'daki "Variables" fikrinin basitleştirilmiş hâli: isimli,
 * sayısal (Int) global değişkenler. Örn. "kaç kere tıkladım", "kaç tur
 * geçti" gibi sayaçlar tutmak için.
 *
 * Not: Sadece uygulama açıkken bellekte tutulur (bot her yeniden
 * başlatıldığında sıfırlanır). Kalıcı olması gerekirse SharedPreferences'a
 * taşınabilir.
 */
object VariableStore {
    private val vars = ConcurrentHashMap<String, Int>()

    fun get(name: String): Int = vars[name] ?: 0
    fun set(name: String, value: Int) { vars[name] = value }
    fun increment(name: String, delta: Int) { vars[name] = get(name) + delta }
    fun getAll(): Map<String, Int> = vars.toMap()
    fun reset(name: String) { vars[name] = 0 }
    fun resetAll() { vars.clear() }
}
