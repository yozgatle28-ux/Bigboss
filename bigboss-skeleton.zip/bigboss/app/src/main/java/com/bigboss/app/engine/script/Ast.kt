package com.bigboss.app.engine.script

sealed class Expr {
    data class Literal(val value: Any?) : Expr()
    data class VarRef(val name: String) : Expr()
    data class Assign(val name: String, val value: Expr) : Expr()
    data class Binary(val left: Expr, val op: String, val right: Expr) : Expr()
    data class Logical(val left: Expr, val op: String, val right: Expr) : Expr()
    data class Unary(val op: String, val right: Expr) : Expr()
    data class Call(val callee: Expr, val args: List<Expr>) : Expr()
    data class Get(val obj: Expr, val name: String) : Expr()
    data class SetProp(val obj: Expr, val name: String, val value: Expr) : Expr()
    data class Index(val target: Expr, val index: Expr) : Expr()
    data class IndexSet(val target: Expr, val index: Expr, val value: Expr) : Expr()
    data class ArrayLit(val items: List<Expr>) : Expr()
    data class Ternary(val cond: Expr, val thenE: Expr, val elseE: Expr) : Expr()
    data class FunctionExpr(val params: List<String>, val body: List<Stmt>) : Expr()
    object ThisExpr : Expr()
    data class New(val className: String, val args: List<Expr>) : Expr()
}

sealed class Stmt {
    data class ExprStmt(val expr: Expr) : Stmt()
    data class VarDecl(val name: String, val init: Expr?) : Stmt()
    data class Block(val stmts: List<Stmt>) : Stmt()
    data class If(val cond: Expr, val thenB: Stmt, val elseB: Stmt?) : Stmt()
    data class While(val cond: Expr, val body: Stmt) : Stmt()
    data class DoWhile(val body: Stmt, val cond: Expr) : Stmt()
    data class For(val init: Stmt?, val cond: Expr?, val step: Stmt?, val body: Stmt) : Stmt()
    data class ForEach(val varName: String, val iterable: Expr, val body: Stmt) : Stmt()
    data class FunDecl(val name: String, val params: List<String>, val body: List<Stmt>) : Stmt()
    data class ClassDecl(
        val name: String,
        val fields: List<String>,
        val methods: List<FunDecl>,
        val staticMethods: List<FunDecl>,
        val staticFields: List<Pair<String, Expr?>>
    ) : Stmt()
    data class Return(val value: Expr?) : Stmt()
    object Break : Stmt()
    object Continue : Stmt()
}
