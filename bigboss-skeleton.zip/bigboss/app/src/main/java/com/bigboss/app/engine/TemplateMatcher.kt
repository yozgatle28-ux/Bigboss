package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Görüntü tanıma köprüsü. Şu an iskelet aşamasında olduğu için gerçek
 * eşleştirme yapmıyor — OpenCV modülü projeye eklendiğinde burası
 * Imgproc.matchTemplate(...) çağrısıyla doldurulacak.
 *
 * Kurulum adımları için bkz. README.md -> "OpenCV kurulumu".
 */
object TemplateMatcher {

    /**
     * @param frame Anlık ekran görüntüsü
     * @param region Aranacak bölge (performans için tüm ekranı değil, alt bölgeyi tara)
     * @param templateAssetName assets/templates/ altındaki referans görsel dosya adı
     * @param threshold 0.0-1.0 arası benzerlik eşiği
     */
    fun matches(
        frame: Bitmap,
        region: Region,
        templateAssetName: String,
        threshold: Double
    ): Boolean {
        // TODO: OpenCV entegrasyonu:
        // 1) frame'i region'a göre crop et (Bitmap.createBitmap)
        // 2) Mat'e çevir (Utils.bitmapToMat)
        // 3) assets/templates/$templateAssetName dosyasını yükle
        // 4) Imgproc.matchTemplate(...) ile karşılaştır
        // 5) Sonuç skorunu threshold ile kıyasla
        throw NotImplementedError(
            "TemplateMatcher henüz OpenCV'ye bağlanmadı. README.md'deki kurulum adımlarını tamamla."
        )
    }
}
