package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** "global_variables.json" içinde Hold/Delay gibi alanların bağlanabileceği kalıcı değişkenleri saklar. */
object GlobalVariableStorage {

    private const val FILE_NAME = "global_variables.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<GlobalVariableDefinition> {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<GlobalVariableDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, vars: List<GlobalVariableDefinition>) {
        File(context.filesDir, FILE_NAME).writeText(gson.toJson(vars))
    }

    fun upsert(context: Context, variable: GlobalVariableDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == variable.id }
        if (idx >= 0) all[idx] = variable else all.add(variable)
        save(context, all)
    }

    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    /** İsme göre DEĞERİ okur — bir Hold/Delay alanı bir değişkene bağlıysa bunu kullanır. Bulunamazsa null. */
    fun valueOf(context: Context, name: String?): Long? {
        if (name.isNullOrBlank()) return null
        return load(context).find { it.name == name }?.value
    }
}
