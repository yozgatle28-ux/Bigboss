package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit

/**
 * Macrorify'daki "Text Recognition" özelliğinin karşılığı: bir bölgede
 * belirli bir kelime/metnin geçip geçmediğini ML Kit'in cihaz-üstü OCR'ı
 * ile arar. İnternet gerekmez (Google Play Services üzerinden bir kere
 * model indirildikten sonra), ama cihazda Play Services olması gerekir.
 *
 * ÖNEMLİ: Bu fonksiyon bloklayan (senkron) bir çağrı yapar
 * (Tasks.await), bu yüzden ANA THREAD'DE ÇAĞRILMAMALI. ScreenCaptureService
 * artık frame'leri arka plan thread'inde işliyor, orada güvenlidir.
 */
object TextMatcher {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    fun contains(frame: Bitmap, region: Region, expectedText: String): Float {
        if (expectedText.isBlank()) return 0f
        val cropped = safeCrop(frame, region) ?: return 0f
        return try {
            val image = InputImage.fromBitmap(cropped, 0)
            val result = Tasks.await(recognizer.process(image), 3, TimeUnit.SECONDS)
            val found = result.text.contains(expectedText, ignoreCase = true)
            if (found) 1f else 0f
        } catch (e: Exception) {
            0f
        }
    }

    private fun safeCrop(frame: Bitmap, region: Region): Bitmap? {
        val x = region.x.coerceIn(0, frame.width - 1)
        val y = region.y.coerceIn(0, frame.height - 1)
        val w = region.width.coerceAtMost(frame.width - x)
        val h = region.height.coerceAtMost(frame.height - y)
        if (w <= 0 || h <= 0) return null
        return Bitmap.createBitmap(frame, x, y, w, h)
    }
}
