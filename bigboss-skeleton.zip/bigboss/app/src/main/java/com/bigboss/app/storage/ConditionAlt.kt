package com.bigboss.app.storage

/**
 * Bir kuralın koşul kısmında birden fazla ALTERNATİF olabilir
 * (Macrorify'daki "Multi Detection" -> "One Detection Success" mantığı):
 * "bu bölgede BU renk YA DA BU resim YA DA BU yazı varsa" gibi.
 * Bir kuralda genelde tek bir alternatif olur; birden fazlaysa (extraConditions ile)
 * VE/VEYA (and/or) mantığıyla birleştirilir.
 *
 * Macrorify'ın "Conditional" özelliğine göre GENİŞLETİLDİ: artık ekran taramasından
 * BAĞIMSIZ mantıksal koşullar da bir alternatif olabilir:
 *  - "VARIABLE": bir değişkenin değerini bir sayıyla karşılaştır (örn. tur >= 10)
 *  - "CUSTOM": herhangi bir JavaScript ifadesi (true/false döner)
 * Bu iki tip için bölge (x/y/w/h), renk, resim, metin, minScore alanları KULLANILMAZ.
 */
data class ConditionAlt(
    /** "COLOR", "IMAGE", "TEXT", "VARIABLE" ya da "CUSTOM" */
    var conditionKind: String = "COLOR",
    var x: Int = 0,
    var y: Int = 0,
    var width: Int = 1,
    var height: Int = 1,
    var color: Int = 0,
    /** conditionKind = "IMAGE" için kaydedilmiş şablon PNG dosya yolu */
    var templatePath: String? = null,
    /** conditionKind = "TEXT" için aranacak kelime/metin */
    var expectedText: String? = null,
    /** 0-100 arası minimum eşleşme skoru */
    var minScore: Int = 85,
    /** conditionKind = "TEXT" için: büyük/küçük harf duyarlı karşılaştırma. */
    var textCaseSensitive: Boolean = false,
    /** conditionKind = "TEXT" için: sadece bu karakterlere izin ver (OCR düzeltmesi). Boşsa devre dışı. */
    var textWhitelist: String = "",
    /** conditionKind = "TEXT" için: bu karakterleri okunan metinden çıkar. Boşsa devre dışı. */
    var textBlacklist: String = "",

    // ---- Macrorify "Conditional" koşul tipleri (ekran taramasından bağımsız) ----
    /** conditionKind = "VARIABLE" için: karşılaştırılacak değişkenin adı (oyun-içi sayaç / VariableStore). */
    var variableName: String = "",
    /** conditionKind = "VARIABLE" için karşılaştırma operatörü: ">=", "<=", "==", "!=", ">", "<" */
    var variableOp: String = ">=",
    /** conditionKind = "VARIABLE" için karşılaştırılacak sabit sayı değeri. */
    var compareValue: Int = 0,
    /** conditionKind = "CUSTOM" için: true/false dönmesi beklenen JavaScript ifadesi (örn. getVar("can") < 30). */
    var customCode: String = ""
)
