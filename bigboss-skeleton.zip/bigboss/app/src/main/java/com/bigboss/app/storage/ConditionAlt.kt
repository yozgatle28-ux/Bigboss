package com.bigboss.app.storage

/**
 * Bir kuralın koşul kısmında birden fazla ALTERNATİF olabilir
 * (Macrorify'daki "Multi Detection" -> "One Detection Success" mantığı):
 * "bu bölgede BU renk YA DA BU resim YA DA BU yazı varsa" gibi.
 * Bir kuralda genelde tek bir alternatif olur; birden fazlaysa VEYA (OR)
 * mantığıyla birleştirilir.
 */
data class ConditionAlt(
    /** "COLOR", "IMAGE" ya da "TEXT" */
    var conditionKind: String = "COLOR",
    var x: Int = 0,
    var y: Int = 0,
    var width: Int = 1,
    var height: Int = 1,
    var color: Int = 0,
    /** conditionKind = "IMAGE" için kaydedilmiş şablon PNG dosya yolu */
    var templatePath: String? = null,
    /** conditionKind = "TEXT" için aranacak kelime/metin */
    var expectedText: String? = null,
    /** 0-100 arası minimum eşleşme skoru */
    var minScore: Int = 85
)
