package com.bigboss.app.storage

/**
 * "Değişkenler" — bekleme süresi (Hold/Delay) gibi sayısal alanların
 * SABİT bir değer yerine buraya BAĞLANABİLMESİNİ sağlar. 20 farklı
 * kuralın Hold'u bu değişkene bağlıysa, buradaki değeri TEK YERDEN
 * değiştirince hepsi otomatik güncellenir — tek tek gezmene gerek kalmaz.
 *
 * NOT: Bu, script'lerdeki VariableStore (oyun-içi sayaç, oturum bazlı,
 * sıfırlanır) ile KARIŞTIRILMAMALI — bu KALICI, kullanıcı tanımlı bir
 * "ayar sabiti" listesi.
 */
data class GlobalVariableDefinition(
    val id: String,
    var name: String,
    var value: Long = 0
)
