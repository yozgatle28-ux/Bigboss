package com.bigboss.app.engine.script

class Parser(private val tokens: List<Token>) {
    private var pos = 0

    fun parseProgram(): List<Stmt> {
        val stmts = mutableListOf<Stmt>()
        while (!isAtEnd()) stmts.add(declaration())
        return stmts
    }

    // ---- yardımcılar ----
    private fun peek() = tokens[pos]
    private fun previous() = tokens[pos - 1]
    private fun isAtEnd() = peek().type == TokType.EOF
    private fun check(type: TokType) = !isAtEnd() && peek().type == type
    private fun advance(): Token { if (!isAtEnd()) pos++; return previous() }
    private fun match(vararg types: TokType): Boolean {
        for (t in types) if (check(t)) { advance(); return true }
        return false
    }
    private fun expect(type: TokType, msg: String): Token {
        if (check(type)) return advance()
        throw ScriptSyntaxError("Satır ${peek().line}: $msg (bulunan: '${peek().text}')")
    }

    // ---- bildirimler ----
    private fun declaration(): Stmt {
        if (match(TokType.CLASS)) return classDecl()
        if (match(TokType.FUN)) return funDecl()
        if (match(TokType.VAR)) return varDeclStmt()
        return statement()
    }

    private fun classDecl(): Stmt {
        val name = expect(TokType.IDENT, "sınıf adı bekleniyordu").text
        expect(TokType.LBRACE, "'{' bekleniyordu")
        val fields = mutableListOf<String>()
        val methods = mutableListOf<Stmt.FunDecl>()
        val staticMethods = mutableListOf<Stmt.FunDecl>()
        val staticFields = mutableListOf<Pair<String, Expr?>>()

        while (!check(TokType.RBRACE) && !isAtEnd()) {
            val isStatic = match(TokType.STATIC)
            val memberName = expect(TokType.IDENT, "üye adı bekleniyordu").text
            if (check(TokType.LPAREN)) {
                val params = paramList()
                val body = blockBody()
                if (isStatic) staticMethods.add(Stmt.FunDecl(memberName, params, body))
                else methods.add(Stmt.FunDecl(memberName, params, body))
            } else {
                var init: Expr? = null
                if (match(TokType.ASSIGN)) init = expression()
                match(TokType.SEMI)
                if (isStatic) staticFields.add(memberName to init) else fields.add(memberName)
            }
        }
        expect(TokType.RBRACE, "'}' bekleniyordu (class sonu)")
        return Stmt.ClassDecl(name, fields, methods, staticMethods, staticFields)
    }

    private fun funDecl(): Stmt.FunDecl {
        val name = expect(TokType.IDENT, "fonksiyon adı bekleniyordu").text
        val params = paramList()
        val body = blockBody()
        return Stmt.FunDecl(name, params, body)
    }

    private fun paramList(): List<String> {
        expect(TokType.LPAREN, "'(' bekleniyordu")
        val params = mutableListOf<String>()
        if (!check(TokType.RPAREN)) {
            do { params.add(expect(TokType.IDENT, "parametre adı bekleniyordu").text) } while (match(TokType.COMMA))
        }
        expect(TokType.RPAREN, "')' bekleniyordu")
        return params
    }

    private fun blockBody(): List<Stmt> {
        expect(TokType.LBRACE, "'{' bekleniyordu")
        val stmts = mutableListOf<Stmt>()
        while (!check(TokType.RBRACE) && !isAtEnd()) stmts.add(declaration())
        expect(TokType.RBRACE, "'}' bekleniyordu")
        return stmts
    }

    private fun varDeclStmt(): Stmt {
        val name = expect(TokType.IDENT, "değişken adı bekleniyordu").text
        var init: Expr? = null
        if (match(TokType.ASSIGN)) init = expression()
        match(TokType.SEMI)
        return Stmt.VarDecl(name, init)
    }

    // ---- ifadeler (statement) ----
    private fun statement(): Stmt {
        if (check(TokType.LBRACE)) return Stmt.Block(blockBody())
        if (match(TokType.IF)) return ifStmt()
        if (match(TokType.WHILE)) return whileStmt()
        if (match(TokType.DO)) return doWhileStmt()
        if (match(TokType.FOR)) return forStmt()
        if (match(TokType.RETURN)) {
            val value = if (!check(TokType.SEMI) && !check(TokType.RBRACE)) expression() else null
            match(TokType.SEMI)
            return Stmt.Return(value)
        }
        if (match(TokType.BREAK)) { match(TokType.SEMI); return Stmt.Break }
        if (match(TokType.CONTINUE)) { match(TokType.SEMI); return Stmt.Continue }
        val expr = expression()
        match(TokType.SEMI)
        return Stmt.ExprStmt(expr)
    }

    private fun ifStmt(): Stmt {
        expect(TokType.LPAREN, "'(' bekleniyordu")
        val cond = expression()
        expect(TokType.RPAREN, "')' bekleniyordu")
        val thenB = statement()
        var elseB: Stmt? = null
        if (match(TokType.ELSE)) elseB = statement()
        return Stmt.If(cond, thenB, elseB)
    }

    private fun whileStmt(): Stmt {
        expect(TokType.LPAREN, "'(' bekleniyordu")
        val cond = expression()
        expect(TokType.RPAREN, "')' bekleniyordu")
        return Stmt.While(cond, statement())
    }

    private fun doWhileStmt(): Stmt {
        val body = statement()
        expect(TokType.WHILE, "'while' bekleniyordu")
        expect(TokType.LPAREN, "'(' bekleniyordu")
        val cond = expression()
        expect(TokType.RPAREN, "')' bekleniyordu")
        match(TokType.SEMI)
        return Stmt.DoWhile(body, cond)
    }

    private fun forStmt(): Stmt {
        expect(TokType.LPAREN, "'(' bekleniyordu")
        // foreach: for (var x : iterable)
        if (check(TokType.VAR)) {
            val save = pos
            advance()
            val name = expect(TokType.IDENT, "değişken adı bekleniyordu").text
            if (match(TokType.COLON)) {
                val iterable = expression()
                expect(TokType.RPAREN, "')' bekleniyordu")
                return Stmt.ForEach(name, iterable, statement())
            }
            pos = save // klasik for'a geri dön
        }
        val init: Stmt? = when {
            match(TokType.SEMI) -> null
            check(TokType.VAR) -> { advance(); varDeclStmt() }
            else -> { val e = expression(); match(TokType.SEMI); Stmt.ExprStmt(e) }
        }
        val cond = if (!check(TokType.SEMI)) expression() else null
        expect(TokType.SEMI, "';' bekleniyordu")
        val step = if (!check(TokType.RPAREN)) Stmt.ExprStmt(expression()) else null
        expect(TokType.RPAREN, "')' bekleniyordu")
        return Stmt.For(init, cond, step, statement())
    }

    // ---- ifade (expression) precedence zinciri ----
    private fun expression(): Expr = assignment()

    private fun assignment(): Expr {
        val expr = ternary()
        if (match(TokType.ASSIGN)) {
            val value = assignment()
            return when (expr) {
                is Expr.VarRef -> Expr.Assign(expr.name, value)
                is Expr.Get -> Expr.SetProp(expr.obj, expr.name, value)
                is Expr.Index -> Expr.IndexSet(expr.target, expr.index, value)
                else -> throw ScriptSyntaxError("Geçersiz atama hedefi")
            }
        }
        return expr
    }

    private fun ternary(): Expr {
        val cond = or()
        if (match(TokType.QUESTION)) {
            val thenE = expression()
            expect(TokType.COLON, "':' bekleniyordu")
            val elseE = expression()
            return Expr.Ternary(cond, thenE, elseE)
        }
        return cond
    }

    private fun or(): Expr {
        var expr = and()
        while (match(TokType.OR)) expr = Expr.Logical(expr, "||", and())
        return expr
    }

    private fun and(): Expr {
        var expr = equality()
        while (match(TokType.AND)) expr = Expr.Logical(expr, "&&", equality())
        return expr
    }

    private fun equality(): Expr {
        var expr = comparison()
        while (check(TokType.EQEQ) || check(TokType.BANGEQ)) {
            val op = advance().text
            expr = Expr.Binary(expr, op, comparison())
        }
        return expr
    }

    private fun comparison(): Expr {
        var expr = term()
        while (check(TokType.LT) || check(TokType.GT) || check(TokType.LE) || check(TokType.GE)) {
            val op = advance().text
            expr = Expr.Binary(expr, op, term())
        }
        return expr
    }

    private fun term(): Expr {
        var expr = factor()
        while (check(TokType.PLUS) || check(TokType.MINUS)) {
            val op = advance().text
            expr = Expr.Binary(expr, op, factor())
        }
        return expr
    }

    private fun factor(): Expr {
        var expr = unary()
        while (check(TokType.STAR) || check(TokType.SLASH) || check(TokType.PERCENT)) {
            val op = advance().text
            expr = Expr.Binary(expr, op, unary())
        }
        return expr
    }

    private fun unary(): Expr {
        if (check(TokType.BANG) || check(TokType.MINUS)) {
            val op = advance().text
            return Expr.Unary(op, unary())
        }
        return callExpr()
    }

    private fun callExpr(): Expr {
        var expr = primary()
        while (true) {
            expr = when {
                match(TokType.LPAREN) -> {
                    val args = mutableListOf<Expr>()
                    if (!check(TokType.RPAREN)) {
                        do { args.add(expression()) } while (match(TokType.COMMA))
                    }
                    expect(TokType.RPAREN, "')' bekleniyordu")
                    Expr.Call(expr, args)
                }
                match(TokType.DOT) -> {
                    val name = expect(TokType.IDENT, "üye adı bekleniyordu").text
                    Expr.Get(expr, name)
                }
                match(TokType.LBRACKET) -> {
                    val idx = expression()
                    expect(TokType.RBRACKET, "']' bekleniyordu")
                    Expr.Index(expr, idx)
                }
                else -> break
            }
        }
        return expr
    }

    private fun primary(): Expr {
        if (match(TokType.NUMBER)) return Expr.Literal(previous().literal)
        if (match(TokType.STRING)) return Expr.Literal(previous().literal)
        if (match(TokType.TRUE)) return Expr.Literal(true)
        if (match(TokType.FALSE)) return Expr.Literal(false)
        if (match(TokType.NULL)) return Expr.Literal(null)
        if (match(TokType.THIS)) return Expr.ThisExpr
        if (match(TokType.NEW)) {
            val className = expect(TokType.IDENT, "sınıf adı bekleniyordu").text
            expect(TokType.LPAREN, "'(' bekleniyordu")
            val args = mutableListOf<Expr>()
            if (!check(TokType.RPAREN)) {
                do { args.add(expression()) } while (match(TokType.COMMA))
            }
            expect(TokType.RPAREN, "')' bekleniyordu")
            return Expr.New(className, args)
        }
        if (match(TokType.FUN)) {
            val params = paramList()
            val body = blockBody()
            return Expr.FunctionExpr(params, body)
        }
        if (match(TokType.LBRACKET)) {
            val items = mutableListOf<Expr>()
            if (!check(TokType.RBRACKET)) {
                do { items.add(expression()) } while (match(TokType.COMMA))
            }
            expect(TokType.RBRACKET, "']' bekleniyordu")
            return Expr.ArrayLit(items)
        }
        if (match(TokType.LPAREN)) {
            val expr = expression()
            expect(TokType.RPAREN, "')' bekleniyordu")
            return expr
        }
        if (check(TokType.IDENT)) {
            val name = advance().text
            // kısa lambda: x => expr
            if (match(TokType.ARROW)) {
                val body = listOf<Stmt>(Stmt.Return(expression()))
                return Expr.FunctionExpr(listOf(name), body)
            }
            return Expr.VarRef(name)
        }
        throw ScriptSyntaxError("Satır ${peek().line}: beklenmeyen '${peek().text}'")
    }
}
