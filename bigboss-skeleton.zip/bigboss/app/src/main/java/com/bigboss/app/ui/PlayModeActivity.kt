package com.bigboss.app.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityPlayModeBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

/**
 * PLAY MODE: sistemin GERÇEKTEN çalıştığı, hiçbir düzenleme/müdahale
 * imkanı olmayan ekran. Açılır açılmaz izin ister, botu çalışır hâlde
 * (paused = false) başlatır. Tek kontrol: durdurma.
 */
class PlayModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayModeBinding
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)
        binding.btnStopPlay.setOnClickListener { stopAndReturn() }

        if (BigBossAccessibilityService.instance == null) {
            binding.tvPlayStatus.text = "⚠️ Erişilebilirlik servisi kapalı!\nAyarlar > Erişilebilirlik'ten BigBoss'u aç."
            return
        }

        if (ScreenCaptureService.ruleEngine != null && ScreenCaptureService.latestFrame != null) {
            // Zaten çalışıyor olabilir (örn. Edit Mode'dan geçiş) — motoru unpause et, overlay'i PLAY moduna al.
            startEngineUnpaused()
            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "PLAY")
            })
            finish()
        } else {
            requestScreenCapturePermission()
        }
    }

    private fun requestScreenCapturePermission() {
        binding.tvPlayStatus.text = "Ekran kaydı izni isteniyor..."
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            val executor = BigBossAccessibilityService.instance
            if (executor == null) {
                binding.tvPlayStatus.text = "⚠️ Erişilebilirlik servisi kapalı!"
                return
            }
            // ÖNEMLİ: RuleEngine'e SABİT bir instance değil, her execute() çağrısında
            // GÜNCEL BigBossAccessibilityService.instance'a bakan bir sarmalayıcı veriyoruz —
            // servis herhangi bir sebeple yeniden bağlanırsa bile komutlar çalışmaya devam etsin.
            val liveExecutor = object : com.bigboss.app.engine.ActionExecutor {
                override fun execute(action: com.bigboss.app.engine.Action) {
                    BigBossAccessibilityService.instance?.execute(action)
                }
            }
            val ruleEngine = RuleEngine(liveExecutor)
            ruleEngine.setRules(com.bigboss.app.storage.EngineAssembler.buildRules(this))
            ruleEngine.setFunctionsProvider(com.bigboss.app.storage.EngineAssembler.buildFunctionsProvider(this))
            ScreenCaptureService.ruleEngine = ruleEngine

            com.bigboss.app.engine.ScriptRuntime.engine = com.bigboss.app.engine.ScriptEngine(
                executor = liveExecutor,
                frameProvider = { ScreenCaptureService.latestFrame },
                functionByName = { name ->
                    FunctionStorage.load(this).find { it.name == name }
                        ?.let { RuleDefinitionMapper.toRules(it.rules) } ?: emptyList()
                },
                runRuleList = { rulesToRun, frame -> ruleEngine.evaluateRulesOnce(rulesToRun, frame) },
                pausedProvider = { ruleEngine.paused },
                libraryLookup = { name -> com.bigboss.app.storage.LibraryStorage.load(this).find { it.name == name }?.templatePath },
                scriptLookup = { name -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.name == name }?.code }
            ).also { engine ->
                engine.globalVarLookup = { name -> com.bigboss.app.storage.GlobalVariableStorage.valueOf(this, name) }
                engine.globalVarSetter = { name, value ->
                    val vars = com.bigboss.app.storage.GlobalVariableStorage.load(this)
                    val existing = vars.find { it.name == name }
                    if (existing != null) { existing.value = value; com.bigboss.app.storage.GlobalVariableStorage.upsert(this, existing) }
                    else com.bigboss.app.storage.GlobalVariableStorage.upsert(this, com.bigboss.app.storage.GlobalVariableDefinition(java.util.UUID.randomUUID().toString(), name, value))
                }
            }

            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "PLAY")
            })
            val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(captureIntent)
            startEngineUnpaused()
            // Kritik: hemen kapanıyoruz — kullanıcı istediği uygulamaya geçebilir.
            finish()
        } else if (requestCode == REQUEST_CODE_CAPTURE) {
            binding.tvPlayStatus.text = "İzin verilmedi, PLAY MODE başlatılamadı."
        }
    }

    private fun startEngineUnpaused() {
        ScreenCaptureService.ruleEngine?.paused = false
        binding.tvPlayStatus.text = "▶️ ÇALIŞIYOR — sisteme müdahale kapalı"
    }

    private fun stopAndReturn() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        finish()
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 51
    }
}
