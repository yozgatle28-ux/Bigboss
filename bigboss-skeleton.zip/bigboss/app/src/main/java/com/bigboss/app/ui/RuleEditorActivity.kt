package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kod yazmadan kural oluşturma/düzenleme ekranı (Macrorify tarzı):
 *  1) Donmuş ekran görüntüsü üzerinde SÜRÜKLEYEREK bir bölge (Region) çizersin
 *  2) Renk mi Resim mi (Template) aranacağını seçersin
 *  3) Tap mi Swipe mi olacağını seçip nokta(lar)a dokunursun
 *  4) İsim, Min Score (%) ve arama süresi (timeout, ms) girip kaydedersin
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
    }

    private lateinit var binding: ActivityRuleEditorBinding

    private enum class Step { DRAW_REGION, CHOOSE_CONDITION_KIND, CHOOSE_ACTION_TYPE, PICK_TAP, PICK_SWIPE_START, PICK_SWIPE_END, DONE }
    private var step = Step.DRAW_REGION
    private var conditionKind = "COLOR"
    private var actionType = "TAP"

    // Bitmap (gerçek ekran) koordinatlarında saklanan değerler
    private var condX = 0; private var condY = 0; private var condW = 1; private var condH = 1
    private var condColor = Color.BLACK
    private var templatePath: String? = null
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0

    private var dragStartViewX = 0f
    private var dragStartViewY = 0f

    private lateinit var frame: Bitmap
    private var existingRule: RuleDefinition? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)

        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            existingRule = RuleStorage.load(this).find { it.id == editId }
            if (existingRule != null) {
                binding.tvInstruction.text =
                    "\"${existingRule!!.name}\" kuralını düzenliyorsun — yeni bölge/nokta çiz"
            }
        }

        binding.ivScreenshot.setOnTouchListener { _, event -> handleTouch(event); true }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnNext.setOnClickListener { onNextPressed() }

        binding.btnCondColor.setOnClickListener {
            conditionKind = "COLOR"
            condColor = averageColor(frame, condX, condY, condW, condH)
            templatePath = null
            binding.conditionKindChooser.visibility = View.GONE
            binding.tvInstruction.text = "2/3: Aksiyon tipini seç"
            binding.actionTypeChooser.visibility = View.VISIBLE
            step = Step.CHOOSE_ACTION_TYPE
        }
        binding.btnCondImage.setOnClickListener {
            conditionKind = "IMAGE"
            val cropped = safeCropRegion(frame, condX, condY, condW, condH)
            if (cropped == null) {
                Toast.makeText(this, "Bölge çok küçük/geçersiz, tekrar çiz", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            templatePath = TemplateStorage.save(this, cropped)
            binding.conditionKindChooser.visibility = View.GONE
            binding.tvInstruction.text = "2/3: Aksiyon tipini seç"
            binding.actionTypeChooser.visibility = View.VISIBLE
            step = Step.CHOOSE_ACTION_TYPE
        }

        binding.btnActionTap.setOnClickListener {
            actionType = "TAP"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "3/3: Dokunulacak (tap) noktaya dokun"
            step = Step.PICK_TAP
        }
        binding.btnActionSwipe.setOnClickListener {
            actionType = "SWIPE"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "3/3: Kaydırmanın BAŞLANGIÇ noktasına dokun"
            step = Step.PICK_SWIPE_START
        }
    }

    private fun handleTouch(event: MotionEvent) {
        when (step) {
            Step.DRAW_REGION -> handleDrawRegion(event)
            Step.PICK_TAP -> if (event.action == MotionEvent.ACTION_DOWN) handlePickTap(event)
            Step.PICK_SWIPE_START -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeStart(event)
            Step.PICK_SWIPE_END -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeEnd(event)
            else -> {}
        }
    }

    // ---- Adım 1: bölge çizimi ----

    private fun handleDrawRegion(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartViewX = event.x
                dragStartViewY = event.y
                binding.regionBox.visibility = View.VISIBLE
                updateRegionBoxView(event.x, event.y, event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> updateRegionBoxView(dragStartViewX, dragStartViewY, event.x, event.y)
            MotionEvent.ACTION_UP -> finalizeRegion(dragStartViewX, dragStartViewY, event.x, event.y)
        }
    }

    private fun updateRegionBoxView(x1: Float, y1: Float, x2: Float, y2: Float) {
        val left = min(x1, x2); val top = min(y1, y2)
        val w = max(abs(x2 - x1), 4f); val h = max(abs(y2 - y1), 4f)
        binding.regionBox.x = left
        binding.regionBox.y = top
        binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
            width = w.toInt(); height = h.toInt()
        }
        binding.regionBox.requestLayout()
    }

    private fun finalizeRegion(x1: Float, y1: Float, x2: Float, y2: Float) {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        val leftView = min(x1, x2); val topView = min(y1, y2)
        val rightView = max(x1, x2); val bottomView = max(y1, y2)

        condX = (leftView * scaleX).toInt().coerceIn(0, frame.width - 1)
        condY = (topView * scaleY).toInt().coerceIn(0, frame.height - 1)
        condW = ((rightView - leftView) * scaleX).toInt().coerceAtLeast(4)
        condH = ((bottomView - topView) * scaleY).toInt().coerceAtLeast(4)

        binding.tvInstruction.text = "Bu alanda ne aranacak?"
        binding.conditionKindChooser.visibility = View.VISIBLE
        step = Step.CHOOSE_CONDITION_KIND
    }

    private fun averageColor(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Int {
        var r = 0L; var g = 0L; var b = 0L; var count = 0L
        val step = 4
        val right = (x + w).coerceAtMost(bitmap.width)
        val bottom = (y + h).coerceAtMost(bitmap.height)
        var yy = y
        while (yy < bottom) {
            var xx = x
            while (xx < right) {
                val px = bitmap.getPixel(xx, yy)
                r += (px shr 16) and 0xFF; g += (px shr 8) and 0xFF; b += px and 0xFF
                count++
                xx += step
            }
            yy += step
        }
        if (count == 0L) return Color.BLACK
        return Color.rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
    }

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    // ---- Adım 3: aksiyon noktaları ----

    private fun handlePickTap(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun handlePickSwipeStart(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Şimdi kaydırmanın BİTİŞ noktasına dokun"
        step = Step.PICK_SWIPE_END
    }

    private fun handlePickSwipeEnd(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX2 = bx; actionY2 = by
        placeMarker(binding.markerActionEnd, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun viewToBitmap(x: Float, y: Float): Pair<Int, Int> {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (y * scaleY).toInt().coerceIn(0, frame.height - 1)
        return bx to by
    }

    private fun placeMarker(marker: View, x: Float, y: Float) {
        marker.visibility = View.VISIBLE
        marker.x = x - marker.width / 2f
        marker.y = y - marker.height / 2f
    }

    private fun onNextPressed() {
        if (step != Step.DONE) return
        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
            setText(existingRule?.name ?: "")
        }
        container.addView(nameInput)

        val kindSummary = TextView(this).apply {
            text = if (conditionKind == "IMAGE") "Koşul: 🖼️ Resim eşleşmesi" else "Koşul: 🎨 Renk eşleşmesi"
        }
        container.addView(kindSummary)

        val actionSummary = TextView(this).apply {
            text = if (actionType == "SWIPE")
                "Aksiyon: ↔ Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
            else
                "Aksiyon: 👆 Dokunma ($actionX,$actionY)"
        }
        container.addView(actionSummary)

        val defaultMinScore = existingRule?.minScore ?: 85
        val minScoreLabel = TextView(this).apply { text = "Min Score: %$defaultMinScore" }
        container.addView(minScoreLabel)
        val minScoreSeek = SeekBar(this).apply {
            max = 100
            progress = defaultMinScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    minScoreLabel.text = "Min Score: %$value"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(minScoreSeek)

        val timeoutLabel = TextView(this).apply {
            text = "Arama süresi (ms) — bu koşulu en fazla ne kadar arasın. -1 = sınırsız:"
            setPadding(0, 24, 0, 0)
        }
        container.addView(timeoutLabel)
        val timeoutInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.timeoutMs ?: 3000L).toString())
        }
        container.addView(timeoutInput)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"
            isChecked = existingRule?.enabled ?: true
        }
        container.addView(enabledCheck)

        AlertDialog.Builder(this)
            .setTitle(if (existingRule != null) "Kuralı güncelle" else "Kuralı kaydet")
            .setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val timeout = timeoutInput.text.toString().toLongOrNull() ?: 3000L
                val def = RuleDefinition(
                    id = existingRule?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    conditionKind = conditionKind,
                    condX = condX, condY = condY, condWidth = condW, condHeight = condH,
                    condColor = condColor,
                    templatePath = templatePath,
                    minScore = minScoreSeek.progress,
                    timeoutMs = timeout,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2
                )
                // Düzenleme modunda eski şablon dosyası artık kullanılmıyorsa temizle
                if (existingRule?.conditionKind == "IMAGE" && existingRule?.templatePath != templatePath) {
                    TemplateStorage.delete(existingRule?.templatePath)
                }
                RuleStorage.upsert(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
