package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify tarzı ÇOKLU ALAN kural editörü — artık her alan KENDİ İÇİNDE
 * TAM bir kural (General + Action + On Success + Loop sekmeleri).
 *
 * Akış:
 *  1) "➕ Alan Ekle" ile ekrana bir arama alanı (region) düşürürsün,
 *     sürükleyip/boyutlandırırsın.
 *  2) Alana dokununca 4 sekmeli bir ayar penceresi açılır:
 *     GENEL (ne aranacak) | AKSİYON (ne yapılacak) |
 *     BAŞARILI OLUNCA (ek aksiyonlar) | TEKRAR (bekleme/ters mantık/değişken)
 *  3) O pencerede "Kaydet"e basınca o alan HEMEN kendi kuralı olarak
 *     kaydolur — ayrı bir "genel kaydet" adımına gerek yok.
 *  4) Basılı tutunca 🙈 Gizle / 🗑 Sil menüsü açılır.
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
        const val EXTRA_FUNCTION_ID = "function_id"
        private const val DEFAULT_SIZE_DP = 130f
        private const val HANDLE_SIZE_DP = 22f
        private const val TAP_SLOP_PX = 18f
        private const val TAP_MAX_MS = 350L
        private const val LONG_PRESS_MS = 500L
        private const val LIVE_REFRESH_MS = 400L
    }

    private lateinit var binding: ActivityRuleEditorBinding
    private lateinit var frame: Bitmap
    private var functionScopeId: String? = null
    private val density get() = resources.displayMetrics.density
    private val liveRefreshHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var liveRefreshRunning = false
    private val liveRefreshRunnable = object : Runnable {
        override fun run() {
            val latest = ScreenCaptureService.latestFrame
            if (latest != null) {
                frame = latest
                binding.ivScreenshot.setImageBitmap(latest)
            }
            if (liveRefreshRunning) liveRefreshHandler.postDelayed(this, LIVE_REFRESH_MS)
        }
    }

    /** Bir "aksiyon": tap / swipe / fonksiyon çağrısı. On Success listesinde kullanılır. */
    private data class ExtraAction(
        val type: String, // "TAP" | "CALL_FUNCTION"
        var x: Int = 0, var y: Int = 0,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1
    )

    /** Ekranda duran bir alan — ARTIK KENDİ İÇİNDE TAM BİR KURAL. */
    private inner class PendingRegion(val id: String, val box: View, val handle: View, val label: TextView) {
        var configured = false
        var existingRuleId: String? = null

        // GENEL
        var name = ""
        var groupName = ""
        var conditionKind = "COLOR" // COLOR | IMAGE | TEXT
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText: String = ""
        var minScore = 90

        // AKSİYON (birincil)
        var actionType = "TAP" // TAP | SWIPE | CALL_FUNCTION
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName: String = ""
        var callFunctionRepeat = 1

        // BAŞARILI OLUNCA (ek aksiyonlar)
        val extraActions = mutableListOf<ExtraAction>()

        // TEKRAR / İleri seviye
        var cooldownMs: Long = 300
        var negate = false
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
    }

    private val regions = mutableListOf<PendingRegion>()
    private var regionCounter = 0

    /** Ekrana dokunarak nokta/renk seçme sırasında ne bekleniyor. */
    private sealed class PendingPick {
        data class ColorPick(val region: PendingRegion) : PendingPick()
        data class ActionPoint(val region: PendingRegion, val target: String) : PendingPick() // TAP | SWIPE_START | SWIPE_END | EXTRA_TAP
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex: Int = -1 // EXTRA_TAP için hangi extraAction düzenleniyor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)
        binding.ivScreenshot.setOnTouchListener { _, event -> handleScreenshotTouch(event); true }

        binding.btnAddRegion.setOnClickListener { addRegion() }
        binding.btnCancelEdit.setOnClickListener { finish() }

        functionScopeId = intent.getStringExtra(EXTRA_FUNCTION_ID)
        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            val existing = if (functionScopeId != null) {
                FunctionStorage.load(this).find { it.id == functionScopeId }?.rules?.find { it.id == editId }
            } else {
                RuleStorage.load(this).find { it.id == editId }
            }
            existing?.let { restoreRegionForEdit(it) }
        }
        updateInstruction()
    }

    override fun onResume() {
        super.onResume()
        liveRefreshRunning = true
        liveRefreshHandler.post(liveRefreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        liveRefreshRunning = false
        liveRefreshHandler.removeCallbacks(liveRefreshRunnable)
    }

    private fun updateInstruction() {
        val configured = regions.count { it.configured }
        binding.tvInstruction.text = "Alanlar: ${regions.size} ($configured kaydedildi) — bir alana dokunarak ayarla"
    }

    // ==================== ALAN (region) OLUŞTURMA / SÜRÜKLEME ====================

    private fun addRegion(initialXPx: Float? = null, initialYPx: Float? = null, initialWPx: Float? = null, initialHPx: Float? = null): PendingRegion {
        val id = "r${regionCounter++}"
        val defaultSizePx = DEFAULT_SIZE_DP * density
        val offset = (regionCounter % 6) * 24f * density

        val box = View(this).apply { background = borderDrawable(Color.parseColor("#2196F3")) }
        val handle = View(this).apply {
            setBackgroundColor(Color.WHITE)
            layoutParams = squareParams((HANDLE_SIZE_DP * density).toInt())
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }

        binding.root.addView(box, squareParams(defaultSizePx.toInt()))
        binding.root.addView(handle)
        binding.root.addView(label)

        val region = PendingRegion(id, box, handle, label)
        box.x = initialXPx ?: (60f * density + offset)
        box.y = initialYPx ?: (220f * density + offset)
        box.layoutParams = box.layoutParams.apply {
            width = (initialWPx ?: defaultSizePx).toInt()
            height = (initialHPx ?: defaultSizePx).toInt()
        }
        box.requestLayout()
        positionHandleAndLabel(region)

        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var boxStartX = 0f; var boxStartY = 0f
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    boxStartX = box.x; boxStartY = box.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, LONG_PRESS_MS)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX; val dy = event.rawY - downRawY
                    if (abs(dx) > TAP_SLOP_PX || abs(dy) > TAP_SLOP_PX) longPressHandler.removeCallbacks(longPressRunnable)
                    val maxX = (binding.ivScreenshot.width - box.width).toFloat().coerceAtLeast(0f)
                    val maxY = (binding.ivScreenshot.height - box.height).toFloat().coerceAtLeast(0f)
                    box.x = (boxStartX + dx).coerceIn(0f, maxX)
                    box.y = (boxStartY + dy).coerceIn(0f, maxY)
                    positionHandleAndLabel(region)
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < TAP_SLOP_PX && dt < TAP_MAX_MS) openRegionConfigDialog(region, "GENERAL")
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handle.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSizePx = 40f * density
                val newW = (event.rawX - box.x).coerceAtLeast(minSizePx)
                val newH = (event.rawY - box.y).coerceAtLeast(minSizePx)
                val maxW = binding.ivScreenshot.width - box.x
                val maxH = binding.ivScreenshot.height - box.y
                box.layoutParams = box.layoutParams.apply {
                    width = newW.coerceAtMost(maxW).toInt()
                    height = newH.coerceAtMost(maxH).toInt()
                }
                box.requestLayout()
                positionHandleAndLabel(region)
            }
            true
        }

        regions.add(region)
        updateInstruction()
        return region
    }

    private fun squareParams(sizePx: Int) = android.widget.FrameLayout.LayoutParams(sizePx, sizePx)

    private fun borderDrawable(color: Int, strokeDp: Float = 2.5f): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((strokeDp * density).toInt(), color)
        }
    }

    private fun positionHandleAndLabel(region: PendingRegion) {
        val handleHalf = (HANDLE_SIZE_DP * density) / 2f
        region.handle.x = region.box.x + region.box.width - handleHalf
        region.handle.y = region.box.y + region.box.height - handleHalf
        region.label.x = region.box.x
        region.label.y = (region.box.y - 28f * density).coerceAtLeast(0f)
    }

    private fun openHideDeleteMenu(region: PendingRegion) {
        AlertDialog.Builder(this)
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) hideRegion(region) else removeRegion(region)
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun hideRegion(region: PendingRegion) {
        region.box.visibility = View.GONE; region.handle.visibility = View.GONE; region.label.visibility = View.GONE
        Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
    }

    private fun removeRegion(region: PendingRegion) {
        binding.root.removeView(region.box); binding.root.removeView(region.handle); binding.root.removeView(region.label)
        region.existingRuleId?.let { ruleId ->
            val fnId = functionScopeId
            if (fnId != null) FunctionStorage.deleteRuleFromFunction(this, fnId, ruleId) else RuleStorage.deleteRule(this, ruleId)
        }
        regions.remove(region)
        updateInstruction()
    }

    private fun regionBitmapRect(region: PendingRegion): IntArray {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val x = (region.box.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val y = (region.box.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val w = (region.box.width * scaleX).toInt().coerceAtLeast(4)
        val h = (region.box.height * scaleY).toInt().coerceAtLeast(4)
        return intArrayOf(x, y, w, h)
    }

    private fun viewToBitmapPoint(x: Float, y: Float): Pair<Int, Int> {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        return (x * scaleX).toInt().coerceIn(0, frame.width - 1) to (y * scaleY).toInt().coerceIn(0, frame.height - 1)
    }

    // ==================== EKRANA DOKUNARAK NOKTA/RENK SEÇME ====================

    private fun handleScreenshotTouch(event: MotionEvent) {
        val pick = pendingPick ?: return
        if (event.action != MotionEvent.ACTION_DOWN) return
        val (bx, by) = viewToBitmapPoint(event.x, event.y)

        when (pick) {
            is PendingPick.ColorPick -> {
                val exactColor = frame.getPixel(bx, by)
                pendingPick = null
                showColorConfirm(pick.region, exactColor)
            }
            is PendingPick.ActionPoint -> {
                pendingPick = null
                val region = pick.region
                when (pick.target) {
                    "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
                    "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
                    "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
                    "EXTRA_TAP" -> {
                        if (pendingExtraActionIndex in region.extraActions.indices) {
                            region.extraActions[pendingExtraActionIndex].x = bx
                            region.extraActions[pendingExtraActionIndex].y = by
                        }
                    }
                }
                openRegionConfigDialog(region, "ACTION")
            }
        }
    }

    private fun showColorConfirm(region: PendingRegion, exactColor: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and exactColor)
        val swatch = View(this).apply { setBackgroundColor(exactColor) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@RuleEditorActivity).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        AlertDialog.Builder(this)
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = exactColor
                openRegionConfigDialog(region, "GENERAL")
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region, "GENERAL") }
            .show()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: PendingRegion, initialTab: String) {
        val ctx = this
        var currentTab = initialTab

        val tabBar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val tabGeneral = Button(ctx).apply { text = "GENEL" }
        val tabAction = Button(ctx).apply { text = "AKSİYON" }
        val tabSuccess = Button(ctx).apply { text = "BAŞARILI OLUNCA" }
        val tabLoop = Button(ctx).apply { text = "TEKRAR" }
        listOf(tabGeneral, tabAction, tabSuccess, tabLoop).forEach {
            it.textSize = 10f
            tabBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 0)
        }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(tabBar)
            addView(content)
        }
        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        val dialog = AlertDialog.Builder(ctx)
            .setView(scroll)
            .setPositiveButton("💾 Kaydet", null)
            .setNeutralButton("🗑 Sil Bu Alanı", null)
            .setNegativeButton("Kapat", null)
            .create()

        fun highlightTabs() {
            listOf(tabGeneral to "GENERAL", tabAction to "ACTION", tabSuccess to "SUCCESS", tabLoop to "LOOP").forEach { (btn, key) ->
                btn.setTextColor(if (key == currentTab) Color.parseColor("#2196F3") else Color.DKGRAY)
            }
        }

        fun renderTab() {
            content.removeAllViews()
            when (currentTab) {
                "GENERAL" -> buildGeneralTab(region, content, dialog)
                "ACTION" -> buildActionTab(region, content, dialog)
                "SUCCESS" -> buildSuccessTab(region, content, dialog)
                "LOOP" -> buildLoopTab(region, content)
            }
            highlightTabs()
        }

        tabGeneral.setOnClickListener { currentTab = "GENERAL"; renderTab() }
        tabAction.setOnClickListener { currentTab = "ACTION"; renderTab() }
        tabSuccess.setOnClickListener { currentTab = "SUCCESS"; renderTab() }
        tabLoop.setOnClickListener { currentTab = "LOOP"; renderTab() }

        dialog.setOnShowListener {
            renderTab()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (saveRegionAsRule(region)) dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                openHideDeleteMenu(region)
            }
        }
        dialog.show()
    }

    // ---- GENEL sekmesi ----

    private fun buildGeneralTab(region: PendingRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Kural adı (örn. HP düşükse potion iç)"; setText(region.name) }
        nameInput.doAfterTextChangedSimple { region.name = it }
        content.addView(nameInput)

        val groupInput = EditText(ctx).apply { hint = "Grup adı (isteğe bağlı)"; setText(region.groupName) }
        groupInput.doAfterTextChangedSimple { region.groupName = it }
        content.addView(groupInput)

        content.addView(TextView(ctx).apply {
            text = "Bu alanda ne aranacak?"
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 4)
        })

        val radioGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.VERTICAL }
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk"; id = 1 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR)"; id = 3 }
        listOf(rbColor, rbImage, rbText).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; else -> 1 })
        content.addView(radioGroup)

        val subSection = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(subSection)

        fun renderSub() {
            subSection.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    subSection.addView(TextView(ctx).apply { text = "Kırpma önizlemesi:" })
                    val (px, py, pw, ph) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                    val preview = safeCropRegion(frame, px, py, pw, ph)
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    if (preview != null) iv.setImageBitmap(preview)
                    subSection.addView(iv)
                    val btnRecrop = Button(ctx).apply { text = "🔄 Bu alandan yeniden kırp" }
                    btnRecrop.setOnClickListener {
                        val (px2, py2, pw2, ph2) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                        val cropped = safeCropRegion(frame, px2, py2, pw2, ph2)
                        if (cropped != null) {
                            region.conditionTemplatePath = TemplateStorage.save(ctx, cropped)
                            Toast.makeText(ctx, "Şablon güncellendi", Toast.LENGTH_SHORT).show()
                        }
                    }
                    subSection.addView(btnRecrop)
                    val btnLibrary = Button(ctx).apply { text = "📚 Kütüphaneden Seç" }
                    btnLibrary.setOnClickListener { pickFromLibrary(region) { renderSub() } }
                    subSection.addView(btnLibrary)

                    val scoreLabel = TextView(ctx).apply { text = "Min Skor: %${region.minScore}" }
                    val scoreSeek = SeekBar(ctx).apply {
                        max = 100; progress = region.minScore
                        setOnSeekBarChangeListener(simpleSeek { v -> region.minScore = v; scoreLabel.text = "Min Skor: %$v" })
                    }
                    subSection.addView(scoreLabel); subSection.addView(scoreSeek)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.doAfterTextChangedSimple { region.conditionText = it }
                    subSection.addView(input)
                }
                else -> { // COLOR
                    val row = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.CENTER_VERTICAL
                    }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply {
                        text = String.format(" #%06X", 0xFFFFFF and region.conditionColor)
                    })
                    subSection.addView(row)

                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener {
                        pendingPick = PendingPick.ColorPick(region)
                        Toast.makeText(ctx, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    }
                    subSection.addView(btnPick)

                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.doAfterTextChangedSimple { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) {
                            region.conditionColor = parsed
                            swatch.setBackgroundColor(parsed)
                        }
                    }
                    subSection.addView(hexInput)

                    val scoreLabel = TextView(ctx).apply { text = "Min Skor: %${region.minScore}" }
                    val scoreSeek = SeekBar(ctx).apply {
                        max = 100; progress = region.minScore
                        setOnSeekBarChangeListener(simpleSeek { v -> region.minScore = v; scoreLabel.text = "Min Skor: %$v" })
                    }
                    subSection.addView(scoreLabel); subSection.addView(scoreSeek)
                }
            }
        }
        renderSub()

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; else -> "COLOR" }
            renderSub()
        }
    }

    private fun pickFromLibrary(region: PendingRegion, onDone: () -> Unit) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Seç")
            .setItems(labels) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") {
                    region.conditionKind = "IMAGE"
                    region.conditionTemplatePath = item.templatePath
                } else {
                    region.conditionKind = "COLOR"
                    region.conditionColor = item.color
                }
                onDone()
            }
            .show()
    }

    // ---- AKSİYON sekmesi ----

    private fun buildActionTab(region: PendingRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val radioGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.VERTICAL }
        val rbTap = android.widget.RadioButton(ctx).apply { text = "👆 Dokunma"; id = 1 }
        val rbSwipe = android.widget.RadioButton(ctx).apply { text = "👉 Kaydırma"; id = 2 }
        val rbFunc = android.widget.RadioButton(ctx).apply { text = "🔧 Fonksiyon Çağır"; id = 3 }
        listOf(rbTap, rbSwipe, rbFunc).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.actionType) { "SWIPE" -> 2; "CALL_FUNCTION" -> 3; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.actionType) {
                "SWIPE" -> {
                    sub.addView(TextView(ctx).apply { text = "Başlangıç: (${region.actionX}, ${region.actionY})" })
                    val btnStart = Button(ctx).apply { text = "📍 Başlangıç Noktasını Seç" }
                    btnStart.setOnClickListener {
                        pendingPick = PendingPick.ActionPoint(region, "SWIPE_START")
                        Toast.makeText(ctx, "Kaydırmanın BAŞLANGIÇ noktasına dokun", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    }
                    sub.addView(btnStart)
                    sub.addView(TextView(ctx).apply { text = "Bitiş: (${region.actionX2}, ${region.actionY2})" })
                    val btnEnd = Button(ctx).apply { text = "📍 Bitiş Noktasını Seç" }
                    btnEnd.setOnClickListener {
                        pendingPick = PendingPick.ActionPoint(region, "SWIPE_END")
                        Toast.makeText(ctx, "Kaydırmanın BİTİŞ noktasına dokun", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    }
                    sub.addView(btnEnd)
                }
                "CALL_FUNCTION" -> {
                    sub.addView(TextView(ctx).apply {
                        text = if (region.callFunctionName.isNotBlank()) "Seçili: f{} ${region.callFunctionName}" else "Henüz fonksiyon seçilmedi"
                    })
                    val btnPick = Button(ctx).apply { text = "🔧 Fonksiyon Seç / Oluştur" }
                    btnPick.setOnClickListener { pickOrCreateFunction(region) { renderSub() } }
                    sub.addView(btnPick)
                    val repeatInput = EditText(ctx).apply {
                        hint = "Kaç kere çalışsın"
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.callFunctionRepeat.toString())
                    }
                    repeatInput.doAfterTextChangedSimple { region.callFunctionRepeat = it.toIntOrNull() ?: 1 }
                    sub.addView(repeatInput)
                }
                else -> { // TAP
                    sub.addView(TextView(ctx).apply { text = "Nokta: (${region.actionX}, ${region.actionY})" })
                    val btnPick = Button(ctx).apply { text = "📍 Dokunulacak Noktayı Seç" }
                    btnPick.setOnClickListener {
                        pendingPick = PendingPick.ActionPoint(region, "TAP")
                        Toast.makeText(ctx, "Dokunulacak noktaya dokun", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    }
                    sub.addView(btnPick)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.actionType = when (checkedId) { 2 -> "SWIPE"; 3 -> "CALL_FUNCTION"; else -> "TAP" }
            renderSub()
        }
    }

    private fun pickOrCreateFunction(region: PendingRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        AlertDialog.Builder(this)
            .setItems(options.toTypedArray()) { _, index ->
                if (index == 0) {
                    val input = EditText(this).apply { hint = "Fonksiyon adı" }
                    AlertDialog.Builder(this)
                        .setTitle("Yeni Fonksiyon")
                        .setView(input)
                        .setPositiveButton("Oluştur") { _, _ ->
                            val name = input.text.toString().ifBlank { "fonksiyon" }
                            val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                            FunctionStorage.upsert(this, fn)
                            region.callFunctionId = fn.id; region.callFunctionName = fn.name
                            onDone()
                        }
                        .show()
                } else {
                    val fn = functions[index - 1]
                    region.callFunctionId = fn.id; region.callFunctionName = fn.name
                    onDone()
                }
            }
            .show()
    }

    // ---- BAŞARILI OLUNCA sekmesi ----

    private fun buildSuccessTab(region: PendingRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        content.addView(TextView(ctx).apply {
            text = "Birincil aksiyon çalıştıktan HEMEN SONRA, ek olarak yapılacaklar:"
            textSize = 12f
        })

        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(list)

        fun renderList() {
            list.removeAllViews()
            region.extraActions.forEachIndexed { index, extra ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(0, 4, 0, 4)
                }
                val desc = if (extra.type == "CALL_FUNCTION") "🔧 f{} ${extra.functionName} x${extra.repeat}"
                    else "👆 Dokun (${extra.x},${extra.y})"
                row.addView(TextView(ctx).apply {
                    text = desc
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                btnRemove.setOnClickListener { region.extraActions.removeAt(index); renderList() }
                row.addView(btnRemove)
                list.addView(row)
            }
        }
        renderList()

        val btnAdd = Button(ctx).apply { text = "+ Ekle" }
        btnAdd.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setItems(arrayOf("👆 Dokunma Ekle", "🔧 Fonksiyon Çağırma Ekle")) { _, index ->
                    if (index == 0) {
                        region.extraActions.add(ExtraAction("TAP"))
                        pendingExtraActionIndex = region.extraActions.size - 1
                        pendingPick = PendingPick.ActionPoint(region, "EXTRA_TAP")
                        Toast.makeText(ctx, "Ek dokunma noktasına dokun", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    } else {
                        val functions = FunctionStorage.load(ctx)
                        val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                        opts.addAll(functions.map { "f{} ${it.name}" })
                        AlertDialog.Builder(ctx)
                            .setItems(opts.toTypedArray()) { _, idx2 ->
                                if (idx2 == 0) {
                                    val input = EditText(ctx).apply { hint = "Fonksiyon adı" }
                                    AlertDialog.Builder(ctx)
                                        .setTitle("Yeni Fonksiyon")
                                        .setView(input)
                                        .setPositiveButton("Oluştur") { _, _ ->
                                            val name = input.text.toString().ifBlank { "fonksiyon" }
                                            val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                                            FunctionStorage.upsert(ctx, fn)
                                            region.extraActions.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                            renderList()
                                        }
                                        .show()
                                } else {
                                    val fn = functions[idx2 - 1]
                                    region.extraActions.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                    renderList()
                                }
                            }
                            .show()
                    }
                }
                .show()
        }
        content.addView(btnAdd)
    }

    // ---- TEKRAR (Loop) sekmesi ----

    private fun buildLoopTab(region: PendingRegion, content: LinearLayout) {
        val ctx = this
        content.addView(TextView(ctx).apply {
            text = "Bekleme süresi (ms) — tetiklendikten sonra tekrar tetiklenmeden önce en az ne kadar beklesin:"
            textSize = 12f
        })
        val cooldownInput = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(region.cooldownMs.toString())
        }
        cooldownInput.doAfterTextChangedSimple { region.cooldownMs = it.toLongOrNull() ?: 300 }
        content.addView(cooldownInput)

        val negateCheck = CheckBox(ctx).apply {
            text = "⏳ Ters mantık: koşul KAYBOLDUĞUNDA tetikle (Not Appear)"
            isChecked = region.negate
        }
        negateCheck.setOnCheckedChangeListener { _, checked -> region.negate = checked }
        content.addView(negateCheck)

        content.addView(TextView(ctx).apply {
            text = "İsteğe bağlı: Değişken/Sayaç"
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 0)
        })
        val incName = EditText(ctx).apply { hint = "Tetiklenince artırılacak sayaç adı"; setText(region.incrementVariableName ?: "") }
        incName.doAfterTextChangedSimple { region.incrementVariableName = it.ifBlank { null } }
        content.addView(incName)
        val incDelta = EditText(ctx).apply {
            hint = "Ne kadar artırılsın"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(region.incrementVariableDelta.toString())
        }
        incDelta.doAfterTextChangedSimple { region.incrementVariableDelta = it.toIntOrNull() ?: 1 }
        content.addView(incDelta)

        val reqName = EditText(ctx).apply { hint = "Ek şart: bu sayaç adı"; setText(region.requireVariableName ?: "") }
        reqName.doAfterTextChangedSimple { region.requireVariableName = it.ifBlank { null } }
        content.addView(reqName)
        val reqOp = EditText(ctx).apply { hint = ">=, <=, ==, >, <"; setText(region.requireVariableOp) }
        reqOp.doAfterTextChangedSimple { region.requireVariableOp = it.ifBlank { ">=" } }
        content.addView(reqOp)
        val reqVal = EditText(ctx).apply {
            hint = "Karşılaştırılacak sayı"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(region.requireVariableValue.toString())
        }
        reqVal.doAfterTextChangedSimple { region.requireVariableValue = it.toIntOrNull() ?: 0 }
        content.addView(reqVal)
    }

    // ==================== KAYDET ====================

    private fun saveRegionAsRule(region: PendingRegion): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show()
            return false
        }
        val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
        val mainAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) {
                    Toast.makeText(this, "Resim seçilmedi (Genel sekmesi)", Toast.LENGTH_LONG).show()
                    return false
                }
                ConditionAlt("IMAGE", rx, ry, rw, rh, templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) {
                    Toast.makeText(this, "Aranacak metin boş (Genel sekmesi)", Toast.LENGTH_LONG).show()
                    return false
                }
                ConditionAlt("TEXT", rx, ry, rw, rh, expectedText = region.conditionText)
            }
            else -> ConditionAlt("COLOR", rx, ry, rw, rh, color = region.conditionColor, minScore = region.minScore)
        }

        val name = region.name.ifBlank { "İsimsiz kural" }

        // Birincil kural
        val def = RuleDefinition(
            id = region.existingRuleId ?: UUID.randomUUID().toString(),
            name = name,
            enabled = true,
            groupName = region.groupName.ifBlank { null },
            alternatives = mutableListOf(mainAlt),
            timeoutMs = region.cooldownMs,
            negateCondition = region.negate,
            requireVariableName = region.requireVariableName,
            requireVariableOp = region.requireVariableOp,
            requireVariableValue = region.requireVariableValue,
            actionType = region.actionType,
            actionX = region.actionX, actionY = region.actionY,
            actionX2 = region.actionX2, actionY2 = region.actionY2,
            callFunctionId = region.callFunctionId,
            callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName,
            incrementVariableDelta = region.incrementVariableDelta
        )

        val fnScope = functionScopeId
        if (fnScope != null) FunctionStorage.upsertRuleInFunction(this, fnScope, def) else RuleStorage.upsert(this, def)
        region.existingRuleId = def.id

        // "Başarılı olunca" ek aksiyonları AYRI kurallar olarak kaydet — Action Result koşuluyla
        // birincil kuralın hemen ardından tetiklensinler.
        region.extraActions.forEachIndexed { index, extra ->
            val extraDef = RuleDefinition(
                id = UUID.randomUUID().toString(),
                name = "$name → ek aksiyon ${index + 1}",
                enabled = true,
                groupName = region.groupName.ifBlank { null },
                alternatives = mutableListOf(mainAlt), // aynı koşulu paylaşır
                timeoutMs = region.cooldownMs,
                negateCondition = region.negate,
                requireVariableName = null,
                actionType = extra.type,
                actionX = extra.x, actionY = extra.y,
                callFunctionId = extra.functionId,
                callFunctionRepeat = extra.repeat
            )
            if (fnScope != null) FunctionStorage.upsertRuleInFunction(this, fnScope, extraDef) else RuleStorage.upsert(this, extraDef)
        }

        region.configured = true
        applyRegionVisual(region)
        updateInstruction()
        Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun applyRegionVisual(region: PendingRegion) {
        val color = when (region.actionType) {
            "SWIPE" -> Color.parseColor("#1F6FEB")
            "CALL_FUNCTION" -> Color.parseColor("#FFA500")
            else -> Color.parseColor("#00C853")
        }
        region.box.background = borderDrawable(color)
        val kindIcon = when (region.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
        region.label.text = "$kindIcon ${region.name.ifBlank { "?" }}"
    }

    // ==================== DÜZENLEME MODUNDA GERİ YÜKLEME ====================

    private fun restoreRegionForEdit(rule: RuleDefinition) {
        binding.ivScreenshot.post {
            val alt = rule.alternatives.firstOrNull() ?: return@post
            val scaleX = frame.width.toFloat() / binding.ivScreenshot.width.toFloat()
            val scaleY = frame.height.toFloat() / binding.ivScreenshot.height.toFloat()
            val vx = alt.x / scaleX; val vy = alt.y / scaleY
            val vw = (alt.width / scaleX).coerceAtLeast(20f); val vh = (alt.height / scaleY).coerceAtLeast(20f)
            val region = addRegion(vx, vy, vw, vh)

            region.existingRuleId = rule.id
            region.name = rule.name
            region.groupName = rule.groupName ?: ""
            region.conditionKind = alt.conditionKind
            region.conditionColor = alt.color
            region.conditionTemplatePath = alt.templatePath
            region.conditionText = alt.expectedText ?: ""
            region.minScore = alt.minScore
            region.actionType = rule.actionType
            region.actionX = rule.actionX; region.actionY = rule.actionY
            region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
            region.callFunctionId = rule.callFunctionId
            region.callFunctionName = rule.callFunctionId?.let { id -> FunctionStorage.load(this).find { it.id == id }?.name } ?: ""
            region.callFunctionRepeat = rule.callFunctionRepeat
            region.cooldownMs = rule.timeoutMs
            region.negate = rule.negateCondition
            region.requireVariableName = rule.requireVariableName
            region.requireVariableOp = rule.requireVariableOp
            region.requireVariableValue = rule.requireVariableValue
            region.incrementVariableName = rule.incrementVariableName
            region.incrementVariableDelta = rule.incrementVariableDelta
            region.configured = true
            applyRegionVisual(region)
            updateInstruction()
        }
    }

    // ==================== YARDIMCI ====================

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) { onChange(value) }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }

    private fun EditText.doAfterTextChangedSimple(action: (String) -> Unit) {
        addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { action(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private data class Quad(val a: Int, val b: Int, val c: Int, val d: Int)
}
