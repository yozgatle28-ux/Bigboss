package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import java.util.UUID

/**
 * Kod yazmadan kural oluşturma ekranı (Macrorify tarzı):
 *  1) Donmuş ekran görüntüsü üzerinde koşul noktasına dokun -> renk otomatik okunur
 *  2) Aksiyon noktasına dokun -> "bu koşul doğruysa buraya dokun" demiş olursun
 *  3) İsim/ tolerans gir, kaydet.
 */
class RuleEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRuleEditorBinding

    private enum class Step { PICK_CONDITION, PICK_ACTION, DONE }
    private var step = Step.PICK_CONDITION

    private var condX = 0
    private var condY = 0
    private var condColor = Color.BLACK
    private var actionX = 0
    private var actionY = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        binding.ivScreenshot.setImageBitmap(frame)

        binding.ivScreenshot.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                handleTap(event, frame.width, frame.height, frame)
            }
            true
        }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnNext.setOnClickListener { onNextPressed() }
    }

    /** Görünüm (view) koordinatını, gerçek ekran görüntüsü (bitmap) koordinatına çevirir. */
    private fun handleTap(event: MotionEvent, bitmapWidth: Int, bitmapHeight: Int, frame: android.graphics.Bitmap) {
        val view = binding.ivScreenshot
        val scaleX = bitmapWidth.toFloat() / view.width.toFloat()
        val scaleY = bitmapHeight.toFloat() / view.height.toFloat()
        val bx = (event.x * scaleX).toInt().coerceIn(0, bitmapWidth - 1)
        val by = (event.y * scaleY).toInt().coerceIn(0, bitmapHeight - 1)

        when (step) {
            Step.PICK_CONDITION -> {
                condX = bx
                condY = by
                condColor = frame.getPixel(bx, by)
                placeMarker(binding.markerCondition, event.x, event.y)
                binding.tvInstruction.text =
                    "2/2: Aksiyon noktasına dokun (örn. potion/saldırı butonu)"
                binding.btnNext.visibility = android.view.View.VISIBLE
                binding.btnNext.text = "Devam"
                step = Step.PICK_ACTION
            }
            Step.PICK_ACTION -> {
                actionX = bx
                actionY = by
                placeMarker(binding.markerAction, event.x, event.y)
                binding.tvInstruction.text = "Hazır! Kaydetmek için devam et."
                binding.btnNext.text = "Kaydet"
                step = Step.DONE
            }
            Step.DONE -> {
                // Kullanıcı tekrar dokunursa aksiyon noktasını güncelle
                actionX = bx
                actionY = by
                placeMarker(binding.markerAction, event.x, event.y)
            }
        }
    }

    private fun placeMarker(marker: android.view.View, x: Float, y: Float) {
        marker.visibility = android.view.View.VISIBLE
        marker.x = x - marker.width / 2f
        marker.y = y - marker.height / 2f
    }

    private fun onNextPressed() {
        if (step != Step.DONE) return
        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply { hint = "Kural adı (örn. HP düşükse potion iç)" }
        container.addView(nameInput)

        val toleranceLabel = TextView(this).apply { text = "Renk toleransı: 24" }
        container.addView(toleranceLabel)
        val toleranceSeek = SeekBar(this).apply {
            max = 100
            progress = 24
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    toleranceLabel.text = "Renk toleransı: $value"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(toleranceSeek)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"
            isChecked = true
        }
        container.addView(enabledCheck)

        AlertDialog.Builder(this)
            .setTitle("Kuralı kaydet")
            .setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val def = RuleDefinition(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    condX = condX,
                    condY = condY,
                    condColor = condColor,
                    tolerance = toleranceSeek.progress,
                    actionX = actionX,
                    actionY = actionY
                )
                RuleStorage.addRule(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
