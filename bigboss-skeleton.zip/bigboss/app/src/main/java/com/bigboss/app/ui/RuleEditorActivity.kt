package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kod yazmadan kural oluşturma/düzenleme ekranı (Macrorify tarzı):
 *  1) Bölge çiz (ya da düzenlemede: mevcut bölgeyi sürükle/boyutlandır) -> Onayla
 *  2) Renk / HEX / Resim / Yazı / Kütüphane arasından seç, istersen VEYA
 *     alternatifi ekle
 *  3) Tap mi Swipe mi olacağını seçip nokta(lar)a dokun
 *  4) İsim, grup, süre, değişken ayarlarını girip kaydet
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
        private const val HANDLE_HALF_DP = 12f
    }

    private lateinit var binding: ActivityRuleEditorBinding

    private enum class Step { DRAW_REGION, ADJUST_REGION, CHOOSE_CONDITION_KIND, PICK_COLOR_POINT, CHOOSE_ACTION_TYPE, PICK_TAP, PICK_SWIPE_START, PICK_SWIPE_END, DONE }
    private var step = Step.DRAW_REGION
    private var actionType = "TAP"

    private val alternatives = mutableListOf<ConditionAlt>()

    private var condX = 0; private var condY = 0; private var condW = 1; private var condH = 1
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0

    private var dragStartViewX = 0f
    private var dragStartViewY = 0f
    private var boxDragStartX = 0f
    private var boxDragStartY = 0f

    private lateinit var frame: Bitmap
    private var existingRule: RuleDefinition? = null
    private val density get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)

        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            existingRule = RuleStorage.load(this).find { it.id == editId }
        }

        binding.ivScreenshot.setOnTouchListener { _, event -> handleScreenshotTouch(event); true }
        binding.regionBox.setOnTouchListener { _, event -> handleBoxDrag(event); true }
        binding.resizeHandle.setOnTouchListener { _, event -> handleResize(event); true }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnNext.setOnClickListener { onNextPressed() }
        binding.btnConfirmRegion.setOnClickListener { confirmRegion() }

        binding.btnCondColor.setOnClickListener {
            binding.conditionKindChooser.visibility = View.GONE
            binding.tvInstruction.text = "Bu bölgenin içinde, RENGİNİ almak istediğin TAM NOKTAYA dokun"
            step = Step.PICK_COLOR_POINT
        }
        binding.btnCondHex.setOnClickListener { showHexInputDialog() }
        binding.btnCondImage.setOnClickListener {
            val cropped = safeCropRegion(frame, condX, condY, condW, condH)
            if (cropped == null) {
                Toast.makeText(this, "Bölge çok küçük/geçersiz", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val path = TemplateStorage.save(this, cropped)
            showMinScoreDialog(80, "Resim için Min Score", true) { ms, libName ->
                alternatives.add(ConditionAlt("IMAGE", condX, condY, condW, condH, templatePath = path, minScore = ms))
                maybeSaveToLibrary(libName, "IMAGE", 0, path)
                askAddAnotherAlternative()
            }
        }
        binding.btnCondText.setOnClickListener {
            showTextInputDialog { text ->
                if (text.isBlank()) {
                    Toast.makeText(this, "Metin boş olamaz", Toast.LENGTH_SHORT).show()
                } else {
                    alternatives.add(ConditionAlt("TEXT", condX, condY, condW, condH, expectedText = text))
                    askAddAnotherAlternative()
                }
            }
        }
        binding.btnCondLibrary.setOnClickListener { showLibraryPickerDialog() }

        binding.btnActionTap.setOnClickListener {
            actionType = "TAP"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "Dokunulacak (tap) noktaya dokun"
            step = Step.PICK_TAP
        }
        binding.btnActionSwipe.setOnClickListener {
            actionType = "SWIPE"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "Kaydırmanın BAŞLANGIÇ noktasına dokun"
            step = Step.PICK_SWIPE_START
        }
        binding.btnActionWaitOnly.setOnClickListener {
            actionType = "WAIT"
            actionX = 0; actionY = 0
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
            binding.btnNext.visibility = View.VISIBLE
            binding.btnNext.text = "Devam"
            step = Step.DONE
        }

        val editingRule = existingRule
        if (editingRule != null && editingRule.alternatives.isNotEmpty()) {
            binding.tvInstruction.text = "\"${editingRule.name}\" düzenleniyor — alanı sürükle/boyutlandır, sonra Onayla'ya bas"
            initRegionBoxForEdit(editingRule.alternatives.first())
        }
    }

    // ---- Bölge: çizme, sürükleme, boyutlandırma ----

    private fun handleScreenshotTouch(event: MotionEvent) {
        when (step) {
            Step.DRAW_REGION -> handleDrawRegion(event)
            Step.PICK_COLOR_POINT -> if (event.action == MotionEvent.ACTION_DOWN) handlePickColorPoint(event)
            Step.PICK_TAP -> if (event.action == MotionEvent.ACTION_DOWN) handlePickTap(event)
            Step.PICK_SWIPE_START -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeStart(event)
            Step.PICK_SWIPE_END -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeEnd(event)
            else -> {}
        }
    }

    private fun handlePickColorPoint(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        val exactColor = frame.getPixel(bx, by)
        val hex = String.format("#%06X", 0xFFFFFF and exactColor)

        val swatch = View(this).apply {
            setBackgroundColor(exactColor)
            layoutParams = LinearLayout.LayoutParams(120, 120)
        }
        val hexLabel = TextView(this).apply {
            text = hex
            setPadding(0, 12, 0, 0)
        }
        val previewRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            addView(swatch)
        }
        val previewContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(previewRow)
            addView(hexLabel)
        }

        AlertDialog.Builder(this)
            .setTitle("Bu renk mi?")
            .setView(previewContainer)
            .setPositiveButton("Evet, bunu kullan") { _, _ ->
                showMinScoreDialog(95, "Renk için Min Score ($hex)", true) { ms, libName ->
                    alternatives.add(ConditionAlt("COLOR", condX, condY, condW, condH, color = exactColor, minScore = ms))
                    maybeSaveToLibrary(libName, "COLOR", exactColor, null)
                    askAddAnotherAlternative()
                }
            }
            .setNegativeButton("Tekrar dokun", null)
            .show()
    }

    private fun handleDrawRegion(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartViewX = event.x
                dragStartViewY = event.y
                binding.regionBox.visibility = View.VISIBLE
                setBoxRect(event.x, event.y, event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> setBoxRect(dragStartViewX, dragStartViewY, event.x, event.y)
            MotionEvent.ACTION_UP -> enterAdjustMode()
        }
    }

    private fun setBoxRect(x1: Float, y1: Float, x2: Float, y2: Float) {
        val left = min(x1, x2); val top = min(y1, y2)
        val w = max(abs(x2 - x1), 4f); val h = max(abs(y2 - y1), 4f)
        binding.regionBox.x = left
        binding.regionBox.y = top
        binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
            width = w.toInt(); height = h.toInt()
        }
        binding.regionBox.requestLayout()
        positionHandle()
    }

    private fun enterAdjustMode() {
        binding.tvInstruction.text = "İstersen sürükle / köşeden boyutlandır, sonra Onayla'ya bas"
        binding.resizeHandle.visibility = View.VISIBLE
        binding.btnConfirmRegion.visibility = View.VISIBLE
        positionHandle()
        step = Step.ADJUST_REGION
    }

    private fun initRegionBoxForEdit(alt: ConditionAlt) {
        binding.ivScreenshot.post {
            val scaleX = frame.width.toFloat() / binding.ivScreenshot.width.toFloat()
            val scaleY = frame.height.toFloat() / binding.ivScreenshot.height.toFloat()
            val viewX = alt.x / scaleX
            val viewY = alt.y / scaleY
            val viewW = (alt.width / scaleX).coerceAtLeast(8f)
            val viewH = (alt.height / scaleY).coerceAtLeast(8f)

            binding.regionBox.visibility = View.VISIBLE
            binding.regionBox.x = viewX
            binding.regionBox.y = viewY
            binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
                width = viewW.toInt(); height = viewH.toInt()
            }
            binding.regionBox.requestLayout()
            binding.resizeHandle.visibility = View.VISIBLE
            binding.btnConfirmRegion.visibility = View.VISIBLE
            positionHandle()
            step = Step.ADJUST_REGION
        }
    }

    private fun positionHandle() {
        val handleHalfPx = HANDLE_HALF_DP * density
        binding.resizeHandle.x = binding.regionBox.x + binding.regionBox.width - handleHalfPx
        binding.resizeHandle.y = binding.regionBox.y + binding.regionBox.height - handleHalfPx
    }

    private fun handleBoxDrag(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartViewX = event.rawX
                dragStartViewY = event.rawY
                boxDragStartX = binding.regionBox.x
                boxDragStartY = binding.regionBox.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - dragStartViewX
                val dy = event.rawY - dragStartViewY
                val maxX = (binding.ivScreenshot.width - binding.regionBox.width).toFloat().coerceAtLeast(0f)
                val maxY = (binding.ivScreenshot.height - binding.regionBox.height).toFloat().coerceAtLeast(0f)
                binding.regionBox.x = (boxDragStartX + dx).coerceIn(0f, maxX)
                binding.regionBox.y = (boxDragStartY + dy).coerceIn(0f, maxY)
                positionHandle()
            }
        }
    }

    private fun handleResize(event: MotionEvent) {
        if (event.action != MotionEvent.ACTION_MOVE && event.action != MotionEvent.ACTION_DOWN) return
        val minSizePx = 24f * density
        val newW = (event.rawX - binding.regionBox.x).coerceAtLeast(minSizePx)
        val newH = (event.rawY - binding.regionBox.y).coerceAtLeast(minSizePx)
        val maxW = (binding.ivScreenshot.width - binding.regionBox.x)
        val maxH = (binding.ivScreenshot.height - binding.regionBox.y)
        binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
            width = newW.coerceAtMost(maxW).toInt()
            height = newH.coerceAtMost(maxH).toInt()
        }
        binding.regionBox.requestLayout()
        positionHandle()
    }

    private fun confirmRegion() {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        condX = (binding.regionBox.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        condY = (binding.regionBox.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        condW = (binding.regionBox.width * scaleX).toInt().coerceAtLeast(4)
        condH = (binding.regionBox.height * scaleY).toInt().coerceAtLeast(4)

        binding.resizeHandle.visibility = View.GONE
        binding.btnConfirmRegion.visibility = View.GONE
        binding.tvInstruction.text = "Bu alanda ne aranacak?"
        binding.conditionKindChooser.visibility = View.VISIBLE
        step = Step.CHOOSE_CONDITION_KIND
    }

    // ---- Koşul tipi seçimi ----

    private fun askAddAnotherAlternative() {
        binding.regionBox.visibility = View.GONE
        AlertDialog.Builder(this)
            .setTitle("Alternatif ekle?")
            .setMessage("Bu koşula BAŞKA bir alternatif eklemek ister misin? (VEYA mantığı)\n\nŞu ana kadar: ${alternatives.size} alternatif")
            .setPositiveButton("Evet, ekle") { _, _ ->
                binding.tvInstruction.text = "Yeni alternatif için bir alan daha çiz"
                step = Step.DRAW_REGION
            }
            .setNegativeButton("Hayır, devam et") { _, _ ->
                binding.tvInstruction.text = "Aksiyon tipini seç"
                binding.actionTypeChooser.visibility = View.VISIBLE
                step = Step.CHOOSE_ACTION_TYPE
            }
            .setCancelable(false)
            .show()
    }

    private fun showHexInputDialog() {
        val input = EditText(this).apply {
            hint = "#RRGGBB (örn. #FF3B30)"
            setText("#")
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("HEX Renk Kodu Gir")
            .setView(container)
            .setPositiveButton("Tamam") { _, _ ->
                val hex = input.text.toString().trim()
                val parsed = try { Color.parseColor(hex) } catch (e: Exception) { null }
                if (parsed == null) {
                    Toast.makeText(this, "Geçersiz HEX kodu, tekrar dene (örn. #FF3B30)", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                showMinScoreDialog(95, "Renk için Min Score", true) { ms, libName ->
                    alternatives.add(ConditionAlt("COLOR", condX, condY, condW, condH, color = parsed, minScore = ms))
                    maybeSaveToLibrary(libName, "COLOR", parsed, null)
                    askAddAnotherAlternative()
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun showLibraryPickerDialog() {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) {
            Toast.makeText(this, "Kütüphane boş. Önce bir renk/resim kaydet.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kütüphaneden Seç")
            .setItems(labels) { _, index ->
                val item = items[index]
                val defaultScore = if (item.kind == "IMAGE") 80 else 90
                showMinScoreDialog(defaultScore, "Min Score", false) { ms, _ ->
                    val alt = if (item.kind == "IMAGE") {
                        ConditionAlt("IMAGE", condX, condY, condW, condH, templatePath = item.templatePath, minScore = ms)
                    } else {
                        ConditionAlt("COLOR", condX, condY, condW, condH, color = item.color, minScore = ms)
                    }
                    alternatives.add(alt)
                    askAddAnotherAlternative()
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun maybeSaveToLibrary(name: String?, kind: String, color: Int, templatePath: String?) {
        if (name.isNullOrBlank()) return
        LibraryStorage.add(this, LibraryItem(
            id = UUID.randomUUID().toString(),
            name = name,
            kind = kind,
            color = color,
            templatePath = templatePath
        ))
        Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
    }

    private fun showMinScoreDialog(default: Int, title: String, offerLibrarySave: Boolean, onConfirm: (Int, String?) -> Unit) {
        val label = TextView(this).apply { text = "$title: %$default" }
        val seek = SeekBar(this).apply {
            max = 100
            progress = default
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    label.text = "$title: %$value"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(label); addView(seek)
        }
        var libNameInput: EditText? = null
        if (offerLibrarySave) {
            val libLabel = TextView(this).apply {
                text = "Kütüphaneye de kaydetmek için isim ver (boş bırakabilirsin):"
                setPadding(0, 24, 0, 0)
            }
            libNameInput = EditText(this).apply { hint = "örn. Kırmızı HP Barı" }
            container.addView(libLabel)
            container.addView(libNameInput)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setPositiveButton("Tamam") { _, _ -> onConfirm(seek.progress, libNameInput?.text?.toString()) }
            .setCancelable(false)
            .show()
    }

    private fun showTextInputDialog(onConfirm: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Aranacak kelime/metin (örn. Devam)" }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Aranacak metni yaz")
            .setView(container)
            .setPositiveButton("Tamam") { _, _ -> onConfirm(input.text.toString()) }
            .setCancelable(false)
            .show()
    }

    private fun averageColor(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Int {
        var r = 0L; var g = 0L; var b = 0L; var count = 0L
        val step = 4
        val right = (x + w).coerceAtMost(bitmap.width)
        val bottom = (y + h).coerceAtMost(bitmap.height)
        var yy = y
        while (yy < bottom) {
            var xx = x
            while (xx < right) {
                val px = bitmap.getPixel(xx, yy)
                r += (px shr 16) and 0xFF; g += (px shr 8) and 0xFF; b += px and 0xFF
                count++
                xx += step
            }
            yy += step
        }
        if (count == 0L) return Color.BLACK
        return Color.rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
    }

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    // ---- Aksiyon noktaları ----

    private fun handlePickTap(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun handlePickSwipeStart(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Şimdi kaydırmanın BİTİŞ noktasına dokun"
        step = Step.PICK_SWIPE_END
    }

    private fun handlePickSwipeEnd(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX2 = bx; actionY2 = by
        placeMarker(binding.markerActionEnd, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun viewToBitmap(x: Float, y: Float): Pair<Int, Int> {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (y * scaleY).toInt().coerceIn(0, frame.height - 1)
        return bx to by
    }

    private fun placeMarker(marker: View, x: Float, y: Float) {
        marker.visibility = View.VISIBLE
        marker.x = x - marker.width / 2f
        marker.y = y - marker.height / 2f
    }

    private fun onNextPressed() {
        if (step != Step.DONE) return
        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
            setText(existingRule?.name ?: "")
        }
        container.addView(nameInput)

        val groupInput = EditText(this).apply {
            hint = "Grup adı (isteğe bağlı, örn. \"Savaş\", \"Toplama\")"
            setText(existingRule?.groupName ?: "")
        }
        container.addView(groupInput)

        val altSummary = TextView(this).apply {
            text = "Koşul: ${alternatives.size} alternatif (${alternatives.joinToString(", ") { it.conditionKind }})"
            setPadding(0, 16, 0, 0)
        }
        container.addView(altSummary)

        val actionSummary = TextView(this).apply {
            text = when (actionType) {
                "SWIPE" -> "Aksiyon: ↔ Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
                "WAIT" -> "Aksiyon: ⏳ Sadece bekle (dokunma/kaydırma yok)"
                else -> "Aksiyon: 👆 Dokunma ($actionX,$actionY)"
            }
        }
        container.addView(actionSummary)

        val timeoutLabel = TextView(this).apply {
            text = "Arama süresi (ms) — en fazla ne kadar arasın. -1 = sınırsız:"
            setPadding(0, 24, 0, 0)
        }
        container.addView(timeoutLabel)
        val timeoutInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.timeoutMs ?: 3000L).toString())
        }
        container.addView(timeoutInput)

        val varHeader = TextView(this).apply {
            text = "İsteğe bağlı: Değişken/Sayaç"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        container.addView(varHeader)

        val incVarNameInput = EditText(this).apply {
            hint = "Tetiklenince artırılacak sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.incrementVariableName ?: "")
        }
        container.addView(incVarNameInput)
        val incVarDeltaInput = EditText(this).apply {
            hint = "Ne kadar artırılsın (örn. 1, -1)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.incrementVariableDelta ?: 1).toString())
        }
        container.addView(incVarDeltaInput)

        val reqVarNameInput = EditText(this).apply {
            hint = "Ek şart: bu sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.requireVariableName ?: "")
        }
        container.addView(reqVarNameInput)
        val reqVarOpInput = EditText(this).apply {
            hint = "Karşılaştırma: >=, <=, ==, >, <  (örn. >=)"
            setText(existingRule?.requireVariableOp ?: ">=")
        }
        container.addView(reqVarOpInput)
        val reqVarValueInput = EditText(this).apply {
            hint = "Karşılaştırılacak sayı"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.requireVariableValue ?: 0).toString())
        }
        container.addView(reqVarValueInput)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"
            isChecked = existingRule?.enabled ?: true
            setPadding(0, 16, 0, 0)
        }
        container.addView(enabledCheck)

        val advHeader = TextView(this).apply {
            text = "İleri Seviye (Macrorify: Wait till vanish / Loop)"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        container.addView(advHeader)

        val negateCheck = CheckBox(this).apply {
            text = "⏳ Ters mantık: koşul KAYBOLUNCA tetikle (Wait till vanish)"
            isChecked = existingRule?.negateCondition ?: false
        }
        container.addView(negateCheck)

        val loopCheck = CheckBox(this).apply {
            text = "🔁 Eşleştikçe/eşleşmedikçe bu kuralda kal ve tekrar dene (Loop)"
            isChecked = (existingRule?.loopMode ?: "NONE") != "NONE"
        }
        container.addView(loopCheck)

        val maxLoopInput = EditText(this).apply {
            hint = "Maks tekrar sayısı (0 = sınırsız)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existingRule?.maxLoopCount ?: 0).toString())
        }
        container.addView(maxLoopInput)

        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle(if (existingRule != null) "Kuralı güncelle" else "Kuralı kaydet")
            .setView(scroll)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val timeout = timeoutInput.text.toString().toLongOrNull() ?: 3000L
                val def = RuleDefinition(
                    id = existingRule?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    groupName = groupInput.text.toString().ifBlank { null },
                    alternatives = alternatives.toMutableList(),
                    timeoutMs = timeout,
                    negateCondition = negateCheck.isChecked,
                    loopMode = if (loopCheck.isChecked) "WHILE_SUCCESS" else "NONE",
                    maxLoopCount = maxLoopInput.text.toString().toIntOrNull() ?: 0,
                    requireVariableName = reqVarNameInput.text.toString().ifBlank { null },
                    requireVariableOp = reqVarOpInput.text.toString().ifBlank { ">=" },
                    requireVariableValue = reqVarValueInput.text.toString().toIntOrNull() ?: 0,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2,
                    incrementVariableName = incVarNameInput.text.toString().ifBlank { null },
                    incrementVariableDelta = incVarDeltaInput.text.toString().toIntOrNull() ?: 1
                )
                RuleStorage.upsert(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
