package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kod yazmadan kural oluşturma ekranı (Macrorify tarzı):
 *  1) Donmuş ekran görüntüsü üzerinde SÜRÜKLEYEREK bir bölge çizersin
 *     -> o bölgenin ortalama rengi otomatik hesaplanır (koşul: "bu bölgede bu renk var mı")
 *  2) Tap mi Swipe mi olacağını seçersin
 *  3) Tap için tek noktaya, Swipe için başlangıç+bitiş noktasına dokunursun
 *  4) İsim/tolerans girip kaydedersin
 */
class RuleEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRuleEditorBinding

    private enum class Step { DRAW_REGION, CHOOSE_ACTION_TYPE, PICK_TAP, PICK_SWIPE_START, PICK_SWIPE_END, DONE }
    private var step = Step.DRAW_REGION
    private var actionType = "TAP"

    // Bitmap (gerçek ekran) koordinatlarında saklanan değerler
    private var condX = 0; private var condY = 0; private var condW = 1; private var condH = 1
    private var condColor = Color.BLACK
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0

    // View koordinatlarında sürükleme başlangıcı
    private var dragStartViewX = 0f
    private var dragStartViewY = 0f

    private lateinit var frame: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)

        binding.ivScreenshot.setOnTouchListener { _, event -> handleTouch(event); true }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnNext.setOnClickListener { onNextPressed() }

        binding.btnActionTap.setOnClickListener {
            actionType = "TAP"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "3/3: Dokunulacak (tap) noktaya dokun"
            step = Step.PICK_TAP
        }
        binding.btnActionSwipe.setOnClickListener {
            actionType = "SWIPE"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "3/3: Kaydırmanın BAŞLANGIÇ noktasına dokun"
            step = Step.PICK_SWIPE_START
        }
    }

    private fun handleTouch(event: MotionEvent) {
        when (step) {
            Step.DRAW_REGION -> handleDrawRegion(event)
            Step.PICK_TAP -> if (event.action == MotionEvent.ACTION_DOWN) handlePickTap(event)
            Step.PICK_SWIPE_START -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeStart(event)
            Step.PICK_SWIPE_END -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeEnd(event)
            else -> {}
        }
    }

    // ---- Adım 1: bölge çizimi ----

    private fun handleDrawRegion(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartViewX = event.x
                dragStartViewY = event.y
                binding.regionBox.visibility = View.VISIBLE
                updateRegionBoxView(event.x, event.y, event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> {
                updateRegionBoxView(dragStartViewX, dragStartViewY, event.x, event.y)
            }
            MotionEvent.ACTION_UP -> {
                finalizeRegion(dragStartViewX, dragStartViewY, event.x, event.y)
            }
        }
    }

    private fun updateRegionBoxView(x1: Float, y1: Float, x2: Float, y2: Float) {
        val left = min(x1, x2)
        val top = min(y1, y2)
        val w = max(abs(x2 - x1), 4f)
        val h = max(abs(y2 - y1), 4f)
        binding.regionBox.x = left
        binding.regionBox.y = top
        binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
            width = w.toInt()
            height = h.toInt()
        }
        binding.regionBox.requestLayout()
    }

    private fun finalizeRegion(x1: Float, y1: Float, x2: Float, y2: Float) {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        val leftView = min(x1, x2); val topView = min(y1, y2)
        val rightView = max(x1, x2); val bottomView = max(y1, y2)

        condX = (leftView * scaleX).toInt().coerceIn(0, frame.width - 1)
        condY = (topView * scaleY).toInt().coerceIn(0, frame.height - 1)
        condW = ((rightView - leftView) * scaleX).toInt().coerceAtLeast(4)
        condH = ((bottomView - topView) * scaleY).toInt().coerceAtLeast(4)

        condColor = averageColor(frame, condX, condY, condW, condH)

        binding.tvInstruction.text = "2/3: Aksiyon tipini seç"
        binding.actionTypeChooser.visibility = View.VISIBLE
        step = Step.CHOOSE_ACTION_TYPE
    }

    private fun averageColor(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Int {
        var r = 0L; var g = 0L; var b = 0L; var count = 0L
        val step = 4
        val right = (x + w).coerceAtMost(bitmap.width)
        val bottom = (y + h).coerceAtMost(bitmap.height)
        var yy = y
        while (yy < bottom) {
            var xx = x
            while (xx < right) {
                val px = bitmap.getPixel(xx, yy)
                r += (px shr 16) and 0xFF
                g += (px shr 8) and 0xFF
                b += px and 0xFF
                count++
                xx += step
            }
            yy += step
        }
        if (count == 0L) return Color.BLACK
        return Color.rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
    }

    // ---- Adım 3: aksiyon noktaları ----

    private fun handlePickTap(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Kaydet"
        step = Step.DONE
    }

    private fun handlePickSwipeStart(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Şimdi kaydırmanın BİTİŞ noktasına dokun"
        step = Step.PICK_SWIPE_END
    }

    private fun handlePickSwipeEnd(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX2 = bx; actionY2 = by
        placeMarker(binding.markerActionEnd, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Kaydet"
        step = Step.DONE
    }

    private fun viewToBitmap(x: Float, y: Float): Pair<Int, Int> {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (y * scaleY).toInt().coerceIn(0, frame.height - 1)
        return bx to by
    }

    private fun placeMarker(marker: View, x: Float, y: Float) {
        marker.visibility = View.VISIBLE
        marker.x = x - marker.width / 2f
        marker.y = y - marker.height / 2f
    }

    private fun onNextPressed() {
        if (step != Step.DONE) return
        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
        }
        container.addView(nameInput)

        val actionSummary = TextView(this).apply {
            text = if (actionType == "SWIPE")
                "Aksiyon: Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
            else
                "Aksiyon: Dokunma ($actionX,$actionY)"
        }
        container.addView(actionSummary)

        val toleranceLabel = TextView(this).apply { text = "Renk toleransı: 24" }
        container.addView(toleranceLabel)
        val toleranceSeek = SeekBar(this).apply {
            max = 100
            progress = 24
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    toleranceLabel.text = "Renk toleransı: $value"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(toleranceSeek)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"
            isChecked = true
        }
        container.addView(enabledCheck)

        AlertDialog.Builder(this)
            .setTitle("Kuralı kaydet")
            .setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val def = RuleDefinition(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    condX = condX, condY = condY, condWidth = condW, condHeight = condH,
                    condColor = condColor,
                    tolerance = toleranceSeek.progress,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2
                )
                RuleStorage.addRule(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
