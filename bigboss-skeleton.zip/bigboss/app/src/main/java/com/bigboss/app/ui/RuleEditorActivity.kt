package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify tarzı ÇOKLU ALAN (multi-region) kural editörü.
 *
 * Akış:
 *  1) "➕ Alan Ekle" ile ekrana istediğin kadar sürüklenebilir/boyutlandırılabilir
 *     kutu düşürebilirsin. Kutu eklendiğinde HİÇBİR menü açılmaz — sadece
 *     ekranda durur, başka alanlar da ekleyebilirsin.
 *  2) Bir alana DOKUNURSAN (sürüklemeden, kısa bir tıklama) o alan için
 *     bir menü açılır: "Arama Alanı Yap" (renk/HEX/resim/yazı/kütüphane)
 *     ya da "Dokunma/Kaydırma Noktası Yap" (aksiyon).
 *  3) Yeterli alan (en az 1 arama + 1 aksiyon) yapılandırıldığında
 *     "💾 Kaydet" ile kuralı tamamlarsın.
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
        const val EXTRA_FUNCTION_ID = "function_id"
        private const val DEFAULT_SIZE_DP = 130f
        private const val HANDLE_SIZE_DP = 22f
        private const val TAP_SLOP_PX = 18f
        private const val TAP_MAX_MS = 350L
    }

    private lateinit var binding: ActivityRuleEditorBinding
    private lateinit var frame: Bitmap
    private var existingRule: RuleDefinition? = null
    private var functionId: String? = null
    private val density get() = resources.displayMetrics.density

    /** Ekranda o an duran bir alan (bölge) ve o alanın rolü/durumu. */
    private inner class PendingRegion(val id: String, val box: View, val handle: View, val label: TextView) {
        var role: String = "UNSET" // UNSET, CONDITION, ACTION_TAP, ACTION_SWIPE_START, ACTION_SWIPE_END, ACTION_CALL_FUNCTION
        var conditionAlt: ConditionAlt? = null
        var callFunctionId: String? = null
        var callFunctionRepeat: Int = 1
    }

    private val regions = mutableListOf<PendingRegion>()
    private var regionCounter = 0
    private var pendingColorPickRegion: PendingRegion? = null

    // Kaydet'e basıldığında showSaveDialog()'un kullandığı toplanmış değerler
    private val alternatives = mutableListOf<ConditionAlt>()
    private var actionType = "TAP"
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0
    private var callFunctionId: String? = null
    private var callFunctionRepeat: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)
        binding.ivScreenshot.setOnTouchListener { _, event -> handleScreenshotTouch(event); true }

        binding.btnAddRegion.setOnClickListener { addRegion() }
        binding.btnCancelEdit.setOnClickListener { finish() }
        binding.btnSaveRule.setOnClickListener { onSavePressed() }

        functionId = intent.getStringExtra(EXTRA_FUNCTION_ID)

        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            existingRule = if (functionId != null) {
                FunctionStorage.load(this).find { it.id == functionId }?.rules?.find { it.id == editId }
            } else {
                RuleStorage.load(this).find { it.id == editId }
            }
            existingRule?.let { restoreRegionsForEdit(it) }
        }
        updateInstruction()
    }

    private fun updateInstruction() {
        val configured = regions.count { it.role != "UNSET" }
        binding.tvInstruction.text = "Alanlar: ${regions.size} (${configured} yapılandırıldı) — bir alana dokunarak ne arayacağını seç"
    }

    // ---- Alan (region) oluşturma ve düzenleme ----

    private fun addRegion(initialXPx: Float? = null, initialYPx: Float? = null, initialWPx: Float? = null, initialHPx: Float? = null): PendingRegion {
        val id = "r${regionCounter++}"
        val defaultSizePx = DEFAULT_SIZE_DP * density
        val offset = (regionCounter % 6) * 24f * density

        val box = View(this).apply {
            setBackgroundColor(Color.parseColor("#559E9E9E")) // UNSET = gri
        }
        val handle = View(this).apply {
            setBackgroundColor(Color.WHITE)
            layoutParams = FrameLayoutParamsSquare((HANDLE_SIZE_DP * density).toInt())
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }

        binding.root.addView(box, FrameLayoutParamsSquare(defaultSizePx.toInt()))
        binding.root.addView(handle)
        binding.root.addView(label)

        val region = PendingRegion(id, box, handle, label)

        box.x = initialXPx ?: (60f * density + offset)
        box.y = initialYPx ?: (220f * density + offset)
        box.layoutParams = box.layoutParams.apply {
            width = (initialWPx ?: defaultSizePx).toInt()
            height = (initialHPx ?: defaultSizePx).toInt()
        }
        box.requestLayout()
        positionHandleAndLabel(region)

        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var boxStartX = 0f; var boxStartY = 0f

        box.setOnTouchListener { _, event ->
            if (pendingColorPickRegion != null) return@setOnTouchListener false // renk seçimi sırasında dokunuşu ekrana bırak
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    boxStartX = box.x; boxStartY = box.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX; val dy = event.rawY - downRawY
                    val maxX = (binding.ivScreenshot.width - box.width).toFloat().coerceAtLeast(0f)
                    val maxY = (binding.ivScreenshot.height - box.height).toFloat().coerceAtLeast(0f)
                    box.x = (boxStartX + dx).coerceIn(0f, maxX)
                    box.y = (boxStartY + dy).coerceIn(0f, maxY)
                    positionHandleAndLabel(region)
                }
                MotionEvent.ACTION_UP -> {
                    val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                    val dt = System.currentTimeMillis() - downTime
                    if (dist < TAP_SLOP_PX && dt < TAP_MAX_MS) {
                        openRegionMenu(region)
                    }
                }
            }
            true
        }

        handle.setOnTouchListener { _, event ->
            if (pendingColorPickRegion != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSizePx = 40f * density
                val newW = (event.rawX - box.x).coerceAtLeast(minSizePx)
                val newH = (event.rawY - box.y).coerceAtLeast(minSizePx)
                val maxW = binding.ivScreenshot.width - box.x
                val maxH = binding.ivScreenshot.height - box.y
                box.layoutParams = box.layoutParams.apply {
                    width = newW.coerceAtMost(maxW).toInt()
                    height = newH.coerceAtMost(maxH).toInt()
                }
                box.requestLayout()
                positionHandleAndLabel(region)
            }
            true
        }

        regions.add(region)
        updateInstruction()
        return region
    }

    private fun FrameLayoutParamsSquare(sizePx: Int) =
        android.widget.FrameLayout.LayoutParams(sizePx, sizePx)

    private fun positionHandleAndLabel(region: PendingRegion) {
        val handleHalf = (HANDLE_SIZE_DP * density) / 2f
        region.handle.x = region.box.x + region.box.width - handleHalf
        region.handle.y = region.box.y + region.box.height - handleHalf
        region.label.x = region.box.x
        region.label.y = (region.box.y - 28f * density).coerceAtLeast(0f)
    }

    private fun removeRegion(region: PendingRegion) {
        binding.root.removeView(region.box)
        binding.root.removeView(region.handle)
        binding.root.removeView(region.label)
        if (region.conditionAlt?.templatePath != null) {
            // Kütüphaneye kaydedilmediyse, sadece bu kural için oluşturulmuş geçici şablonu temizle
        }
        regions.remove(region)
        updateInstruction()
    }

    // ---- Alana dokununca açılan menü ----

    private fun openRegionMenu(region: PendingRegion) {
        val options = mutableListOf("🔎 Arama Alanı Yap (Koşul)", "👆 Dokunma Noktası Yap", "👉 Kaydırma Başlangıcı Yap", "👉 Kaydırma Bitişi Yap", "🔧 Fonksiyon Çağır Yap", "🗑 Bu Alanı Sil")
        AlertDialog.Builder(this)
            .setTitle("Bu alan ne için?")
            .setItems(options.toTypedArray()) { _, index ->
                when (index) {
                    0 -> openConditionKindMenu(region)
                    1 -> setActionRole(region, "ACTION_TAP")
                    2 -> setActionRole(region, "ACTION_SWIPE_START")
                    3 -> setActionRole(region, "ACTION_SWIPE_END")
                    4 -> openCallFunctionMenu(region)
                    5 -> removeRegion(region)
                }
            }
            .show()
    }

    private fun openCallFunctionMenu(region: PendingRegion) {
        val functions = FunctionStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name} (${it.rules.size} kural)" })
        AlertDialog.Builder(this)
            .setTitle("Hangi fonksiyon çağrılsın?")
            .setItems(options.toTypedArray()) { _, index ->
                if (index == 0) {
                    createNewFunctionThenAssign(region)
                } else {
                    assignCallFunction(region, functions[index - 1])
                }
            }
            .show()
    }

    private fun createNewFunctionThenAssign(region: PendingRegion) {
        val input = EditText(this).apply { hint = "Fonksiyon adı (örn. doBattle)" }
        AlertDialog.Builder(this)
            .setTitle("Yeni Fonksiyon")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                val fn = com.bigboss.app.storage.FunctionDefinition(UUID.randomUUID().toString(), name)
                FunctionStorage.upsert(this, fn)
                assignCallFunction(region, fn)
                Toast.makeText(this, "Fonksiyon oluşturuldu: $name — içine kural eklemeyi unutma", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun assignCallFunction(region: PendingRegion, fn: com.bigboss.app.storage.FunctionDefinition) {
        val repeatInput = EditText(this).apply {
            hint = "Kaç kere çalışsın (1 = bir kere)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("1")
        }
        AlertDialog.Builder(this)
            .setTitle("f{} ${fn.name}")
            .setView(repeatInput)
            .setPositiveButton("Tamam") { _, _ ->
                setActionRole(region, "ACTION_CALL_FUNCTION")
                region.callFunctionId = fn.id
                region.callFunctionRepeat = repeatInput.text.toString().toIntOrNull() ?: 1
                region.label.text = "🔧 ${fn.name}"
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun setActionRole(region: PendingRegion, role: String) {
        // Tap/Swipe/Fonksiyon karışmasın: aksiyon rolündeki başka bir alan varsa sıfırla
        val actionRoles = setOf("ACTION_TAP", "ACTION_SWIPE_START", "ACTION_SWIPE_END", "ACTION_CALL_FUNCTION")
        val conflicting = if (role == "ACTION_SWIPE_START" || role == "ACTION_SWIPE_END") {
            regions.filter { it.role == "ACTION_TAP" || it.role == "ACTION_CALL_FUNCTION" || it.role == role }
        } else {
            regions.filter { it.role in actionRoles }
        }
        conflicting.filter { it.id != region.id }.forEach { resetRegionRole(it) }

        region.role = role
        region.conditionAlt = null
        val (color, text) = when (role) {
            "ACTION_TAP" -> Color.parseColor("#AAFF3B30") to "👆 Dokun"
            "ACTION_SWIPE_START" -> Color.parseColor("#AA1F6FEB") to "👉 Başlangıç"
            "ACTION_CALL_FUNCTION" -> Color.parseColor("#AAFFA500") to "🔧 Fonksiyon"
            else -> Color.parseColor("#AA6F1FEB") to "👉 Bitiş"
        }
        region.box.setBackgroundColor(color)
        region.label.text = text
        updateInstruction()
    }

    private fun resetRegionRole(region: PendingRegion) {
        region.role = "UNSET"
        region.conditionAlt = null
        region.callFunctionId = null
        region.callFunctionRepeat = 1
        region.box.setBackgroundColor(Color.parseColor("#559E9E9E"))
        region.label.text = "?"
    }

    private fun regionBitmapRect(region: PendingRegion): IntArray {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val x = (region.box.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val y = (region.box.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val w = (region.box.width * scaleX).toInt().coerceAtLeast(4)
        val h = (region.box.height * scaleY).toInt().coerceAtLeast(4)
        return intArrayOf(x, y, w, h)
    }

    // ---- Arama alanı: TEK, birleşik ayar penceresi (Macrorify'daki General panel gibi) ----

    private fun openConditionKindMenu(region: PendingRegion) {
        showConditionConfigDialog(region, preselectedKind = region.conditionAlt?.conditionKind ?: "COLOR")
    }

    private fun showConditionConfigDialog(
        region: PendingRegion,
        preselectedKind: String,
        pickedColor: Int? = null
    ) {
        val ctx = this
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 0)
        }

        root.addView(TextView(ctx).apply {
            text = "Bu alanda ne aranacak?"
            setTypeface(null, android.graphics.Typeface.BOLD)
            textSize = 15f
        })

        val radioGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.VERTICAL }
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk (ekrandan nokta seç)"; id = 1 }
        val rbHex = android.widget.RadioButton(ctx).apply { text = "# HEX renk kodu"; id = 2 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim (bu alanı kırp)"; id = 3 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR ile ara)"; id = 4 }
        val rbLibrary = android.widget.RadioButton(ctx).apply { text = "📚 Kütüphaneden seç"; id = 5 }
        listOf(rbColor, rbHex, rbImage, rbText, rbLibrary).forEach { radioGroup.addView(it) }
        root.addView(radioGroup)

        // Dinamik alt bölüm: seçime göre değişir
        val subSection = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 0)
        }
        root.addView(subSection)

        // --- Renk alt bölümü ---
        var currentColor = pickedColor ?: region.conditionAlt?.color ?: Color.BLACK
        val colorSwatch = View(ctx)
        val colorHexLabel = TextView(ctx)
        val btnPickPoint = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
        fun refreshColorPreview() {
            colorSwatch.setBackgroundColor(currentColor)
            colorHexLabel.text = String.format("#%06X", 0xFFFFFF and currentColor)
        }
        refreshColorPreview()

        // --- HEX alt bölümü ---
        val hexInput = EditText(ctx).apply {
            hint = "#RRGGBB (örn. #FF3B30)"
            setText(if (preselectedKind == "COLOR" && pickedColor == null && region.conditionAlt?.conditionKind == "COLOR")
                String.format("#%06X", 0xFFFFFF and (region.conditionAlt?.color ?: 0)) else "#")
        }

        // --- Resim alt bölümü ---
        val imagePreview = android.widget.ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(200, 200)
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }
        val (px, py, pw, ph) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
        val previewCrop = safeCropRegion(frame, px, py, pw, ph)
        if (previewCrop != null) imagePreview.setImageBitmap(previewCrop)

        // --- Yazı alt bölümü ---
        val textInput = EditText(ctx).apply {
            hint = "Aranacak kelime/metin (örn. Devam)"
            setText(region.conditionAlt?.expectedText ?: "")
        }

        // --- Kütüphane alt bölümü ---
        var selectedLibraryItem: LibraryItem? = null
        val libraryLabel = TextView(ctx).apply { text = "Henüz seçilmedi" }
        val btnPickLibrary = Button(ctx).apply {
            text = "📚 Kütüphaneden Seç"
            setOnClickListener {
                val items = LibraryStorage.load(ctx)
                if (items.isEmpty()) {
                    Toast.makeText(ctx, "Kütüphane boş", Toast.LENGTH_SHORT).show()
                } else {
                    val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
                    AlertDialog.Builder(ctx)
                        .setTitle("Seç")
                        .setItems(labels) { _, idx ->
                            selectedLibraryItem = items[idx]
                            libraryLabel.text = "Seçildi: ${items[idx].name}"
                        }
                        .show()
                }
            }
        }

        // --- Ortak: Min Score ---
        val minScoreLabel = TextView(ctx).apply { text = "Min Skor: %${region.conditionAlt?.minScore ?: 90}" }
        val minScoreSeek = SeekBar(ctx).apply {
            max = 100
            progress = region.conditionAlt?.minScore ?: 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) { minScoreLabel.text = "Min Skor: %$value" }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

        // --- Ortak: Kütüphaneye kaydet (isteğe bağlı isim) ---
        val libSaveLabel = TextView(ctx).apply { text = "Kütüphaneye de kaydetmek için isim ver (isteğe bağlı):" }
        val libSaveInput = EditText(ctx).apply { hint = "örn. Kırmızı HP Barı" }

        fun rebuildSubSection(kind: String) {
            subSection.removeAllViews()
            when (kind) {
                "COLOR" -> {
                    subSection.addView(btnPickPoint)
                    val row = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.CENTER_VERTICAL
                        setPadding(0, 12, 0, 0)
                        addView(colorSwatch, LinearLayout.LayoutParams(60, 60))
                        addView(colorHexLabel.apply { setPadding(16, 0, 0, 0) })
                    }
                    subSection.addView(row)
                    subSection.addView(minScoreLabel); subSection.addView(minScoreSeek)
                    subSection.addView(libSaveLabel); subSection.addView(libSaveInput)
                }
                "HEX" -> {
                    subSection.addView(hexInput)
                    subSection.addView(minScoreLabel); subSection.addView(minScoreSeek)
                    subSection.addView(libSaveLabel); subSection.addView(libSaveInput)
                }
                "IMAGE" -> {
                    subSection.addView(TextView(ctx).apply { text = "Bu alandan kırpılacak önizleme:" })
                    subSection.addView(imagePreview)
                    subSection.addView(minScoreLabel); subSection.addView(minScoreSeek)
                    subSection.addView(libSaveLabel); subSection.addView(libSaveInput)
                }
                "TEXT" -> {
                    subSection.addView(textInput)
                }
                "LIBRARY" -> {
                    subSection.addView(btnPickLibrary)
                    subSection.addView(libraryLabel)
                    subSection.addView(minScoreLabel); subSection.addView(minScoreSeek)
                }
            }
        }

        val initialRadio = when (preselectedKind) { "IMAGE" -> rbImage; "TEXT" -> rbText; else -> rbColor }
        radioGroup.check(initialRadio.id)
        rebuildSubSection(if (preselectedKind == "IMAGE") "IMAGE" else if (preselectedKind == "TEXT") "TEXT" else "COLOR")

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            rebuildSubSection(when (checkedId) { 2 -> "HEX"; 3 -> "IMAGE"; 4 -> "TEXT"; 5 -> "LIBRARY"; else -> "COLOR" })
        }

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        val dialog = AlertDialog.Builder(ctx)
            .setView(scroll)
            .setPositiveButton("✅ Uygula", null) // aşağıda manuel override ediyoruz (kapanmasın diye)
            .setNegativeButton("Vazgeç", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                when (radioGroup.checkedRadioButtonId) {
                    1 -> { // Renk
                        val alt = ConditionAlt("COLOR", px, py, pw, ph, color = currentColor, minScore = minScoreSeek.progress)
                        applyConditionToRegion(region, alt, "🎨")
                        maybeSaveToLibrary(libSaveInput.text.toString(), "COLOR", currentColor, null)
                        dialog.dismiss()
                    }
                    2 -> { // HEX
                        val parsed = try { Color.parseColor(hexInput.text.toString().trim()) } catch (e: Exception) { null }
                        if (parsed == null) {
                            Toast.makeText(ctx, "Geçersiz HEX kodu", Toast.LENGTH_SHORT).show()
                        } else {
                            val alt = ConditionAlt("COLOR", px, py, pw, ph, color = parsed, minScore = minScoreSeek.progress)
                            applyConditionToRegion(region, alt, "# HEX")
                            maybeSaveToLibrary(libSaveInput.text.toString(), "COLOR", parsed, null)
                            dialog.dismiss()
                        }
                    }
                    3 -> { // Resim
                        if (previewCrop == null) {
                            Toast.makeText(ctx, "Bölge çok küçük/geçersiz", Toast.LENGTH_SHORT).show()
                        } else {
                            val path = TemplateStorage.save(ctx, previewCrop)
                            val alt = ConditionAlt("IMAGE", px, py, pw, ph, templatePath = path, minScore = minScoreSeek.progress)
                            applyConditionToRegion(region, alt, "🖼️")
                            maybeSaveToLibrary(libSaveInput.text.toString(), "IMAGE", 0, path)
                            dialog.dismiss()
                        }
                    }
                    4 -> { // Yazı
                        val text = textInput.text.toString()
                        if (text.isBlank()) {
                            Toast.makeText(ctx, "Metin boş olamaz", Toast.LENGTH_SHORT).show()
                        } else {
                            val alt = ConditionAlt("TEXT", px, py, pw, ph, expectedText = text)
                            applyConditionToRegion(region, alt, "📝")
                            dialog.dismiss()
                        }
                    }
                    5 -> { // Kütüphane
                        val item = selectedLibraryItem
                        if (item == null) {
                            Toast.makeText(ctx, "Önce kütüphaneden bir öğe seç", Toast.LENGTH_SHORT).show()
                        } else {
                            val alt = if (item.kind == "IMAGE")
                                ConditionAlt("IMAGE", px, py, pw, ph, templatePath = item.templatePath, minScore = minScoreSeek.progress)
                            else
                                ConditionAlt("COLOR", px, py, pw, ph, color = item.color, minScore = minScoreSeek.progress)
                            applyConditionToRegion(region, alt, if (item.kind == "IMAGE") "🖼️📚" else "🎨📚")
                            dialog.dismiss()
                        }
                    }
                }
            }
        }

        btnPickPoint.setOnClickListener {
            dialog.dismiss()
            pendingColorPickRegion = region
            Toast.makeText(ctx, "Şimdi renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
        }

        dialog.show()
    }

    private fun handleScreenshotTouch(event: MotionEvent) {
        val pickRegion = pendingColorPickRegion ?: return
        if (event.action != MotionEvent.ACTION_DOWN) return
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (event.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (event.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val exactColor = frame.getPixel(bx, by)
        pendingColorPickRegion = null
        // Noktayı seçtikten sonra AYNI birleşik ayar penceresini, seçilen renkle önceden dolu tekrar aç
        showConditionConfigDialog(pickRegion, preselectedKind = "COLOR", pickedColor = exactColor)
    }

    private fun applyConditionToRegion(region: PendingRegion, alt: ConditionAlt, iconText: String) {
        region.role = "CONDITION"
        region.conditionAlt = alt
        region.box.setBackgroundColor(Color.parseColor("#5500FF00"))
        region.label.text = iconText
        updateInstruction()
    }

    private data class Quad(val a: Int, val b: Int, val c: Int, val d: Int)

    private fun maybeSaveToLibrary(name: String?, kind: String, color: Int, templatePath: String?) {
        if (name.isNullOrBlank()) return
        LibraryStorage.add(this, LibraryItem(UUID.randomUUID().toString(), name, kind, color, templatePath))
        Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
    }

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    // ---- Düzenleme modunda: mevcut kuralın alanlarını geri yükle ----

    private fun restoreRegionsForEdit(rule: RuleDefinition) {
        binding.ivScreenshot.post {
            val scaleX = frame.width.toFloat() / binding.ivScreenshot.width.toFloat()
            val scaleY = frame.height.toFloat() / binding.ivScreenshot.height.toFloat()

            rule.alternatives.forEach { alt ->
                val vx = alt.x / scaleX; val vy = alt.y / scaleY
                val vw = (alt.width / scaleX).coerceAtLeast(20f); val vh = (alt.height / scaleY).coerceAtLeast(20f)
                val region = addRegion(vx, vy, vw, vh)
                val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
                applyConditionToRegion(region, alt.copy(), icon)
            }

            val actionSizePx = 50f * density
            when (rule.actionType) {
                "SWIPE" -> {
                    val startRegion = addRegion(
                        rule.actionX / scaleX - actionSizePx / 2, rule.actionY / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(startRegion, "ACTION_SWIPE_START")
                    val endRegion = addRegion(
                        rule.actionX2 / scaleX - actionSizePx / 2, rule.actionY2 / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(endRegion, "ACTION_SWIPE_END")
                }
                "WAIT" -> { /* aksiyon noktası yok */ }
                "CALL_FUNCTION" -> {
                    val fnRegion = addRegion(
                        60f * density, 220f * density, actionSizePx, actionSizePx
                    )
                    setActionRole(fnRegion, "ACTION_CALL_FUNCTION")
                    fnRegion.callFunctionId = rule.callFunctionId
                    fnRegion.callFunctionRepeat = rule.callFunctionRepeat
                    val fnName = FunctionStorage.load(this@RuleEditorActivity).find { it.id == rule.callFunctionId }?.name ?: "?"
                    fnRegion.label.text = "🔧 $fnName"
                }
                else -> {
                    val tapRegion = addRegion(
                        rule.actionX / scaleX - actionSizePx / 2, rule.actionY / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(tapRegion, "ACTION_TAP")
                }
            }
            updateInstruction()
        }
    }

    // ---- Kaydet ----

    private fun onSavePressed() {
        val conditionRegions = regions.filter { it.role == "CONDITION" && it.conditionAlt != null }
        val tapRegion = regions.find { it.role == "ACTION_TAP" }
        val swipeStart = regions.find { it.role == "ACTION_SWIPE_START" }
        val swipeEnd = regions.find { it.role == "ACTION_SWIPE_END" }
        val callRegion = regions.find { it.role == "ACTION_CALL_FUNCTION" }

        if (conditionRegions.isEmpty()) {
            Toast.makeText(this, "En az bir arama alanı yapılandırmalısın (bir alana dokun)", Toast.LENGTH_LONG).show()
            return
        }
        if (tapRegion == null && callRegion == null && (swipeStart == null || swipeEnd == null)) {
            Toast.makeText(this, "Bir aksiyon (Dokunma / Kaydırma / Fonksiyon Çağır) ayarlamalısın", Toast.LENGTH_LONG).show()
            return
        }

        alternatives.clear()
        alternatives.addAll(conditionRegions.mapNotNull { it.conditionAlt })

        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        when {
            callRegion != null -> {
                actionType = "CALL_FUNCTION"
                callFunctionId = callRegion.callFunctionId
                callFunctionRepeat = callRegion.callFunctionRepeat
            }
            tapRegion != null -> {
                actionType = "TAP"
                actionX = ((tapRegion.box.x + tapRegion.box.width / 2f) * scaleX).toInt()
                actionY = ((tapRegion.box.y + tapRegion.box.height / 2f) * scaleY).toInt()
            }
            else -> {
                actionType = "SWIPE"
                actionX = ((swipeStart!!.box.x + swipeStart.box.width / 2f) * scaleX).toInt()
                actionY = ((swipeStart.box.y + swipeStart.box.height / 2f) * scaleY).toInt()
                actionX2 = ((swipeEnd!!.box.x + swipeEnd.box.width / 2f) * scaleX).toInt()
                actionY2 = ((swipeEnd.box.y + swipeEnd.box.height / 2f) * scaleY).toInt()
            }
        }

        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
            setText(existingRule?.name ?: "")
        }
        container.addView(nameInput)

        val groupInput = EditText(this).apply {
            hint = "Grup adı (isteğe bağlı, örn. \"Savaş\", \"Toplama\")"
            setText(existingRule?.groupName ?: "")
        }
        container.addView(groupInput)

        container.addView(TextView(this).apply {
            text = "Koşul: ${alternatives.size} alan (${alternatives.joinToString(", ") { it.conditionKind }})"
            setPadding(0, 16, 0, 0)
        })
        container.addView(TextView(this).apply {
            text = when (actionType) {
                "SWIPE" -> "Aksiyon: ↔ Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
                "CALL_FUNCTION" -> "Aksiyon: 🔧 Fonksiyon çağır (x$callFunctionRepeat)"
                else -> "Aksiyon: 👆 Dokunma ($actionX,$actionY)"
            }
        })

        container.addView(TextView(this).apply {
            text = "Arama süresi (ms) — en fazla ne kadar arasın. -1 = sınırsız:"
            setPadding(0, 24, 0, 0)
        })
        val timeoutInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.timeoutMs ?: 3000L).toString())
        }
        container.addView(timeoutInput)

        container.addView(TextView(this).apply {
            text = "İsteğe bağlı: Değişken/Sayaç"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val incVarNameInput = EditText(this).apply {
            hint = "Tetiklenince artırılacak sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.incrementVariableName ?: "")
        }
        container.addView(incVarNameInput)
        val incVarDeltaInput = EditText(this).apply {
            hint = "Ne kadar artırılsın (örn. 1, -1)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.incrementVariableDelta ?: 1).toString())
        }
        container.addView(incVarDeltaInput)
        val reqVarNameInput = EditText(this).apply {
            hint = "Ek şart: bu sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.requireVariableName ?: "")
        }
        container.addView(reqVarNameInput)
        val reqVarOpInput = EditText(this).apply {
            hint = "Karşılaştırma: >=, <=, ==, >, <  (örn. >=)"
            setText(existingRule?.requireVariableOp ?: ">=")
        }
        container.addView(reqVarOpInput)
        val reqVarValueInput = EditText(this).apply {
            hint = "Karşılaştırılacak sayı"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.requireVariableValue ?: 0).toString())
        }
        container.addView(reqVarValueInput)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"; isChecked = existingRule?.enabled ?: true
            setPadding(0, 16, 0, 0)
        }
        container.addView(enabledCheck)

        container.addView(TextView(this).apply {
            text = "İleri Seviye Ayarlar (kural kaybolunca tetikleme / tekrar etme)"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val negateCheck = CheckBox(this).apply {
            text = "⏳ Ters mantık: koşul bulunduğunda değil, KAYBOLDUĞUNDA tetikle"
            isChecked = existingRule?.negateCondition ?: false
        }
        container.addView(negateCheck)
        val loopCheck = CheckBox(this).apply {
            text = "🔁 Eşleştikçe/eşleşmedikçe bu kuralda kal ve tekrar dene"
            isChecked = (existingRule?.loopMode ?: "NONE") != "NONE"
        }
        container.addView(loopCheck)
        val maxLoopInput = EditText(this).apply {
            hint = "Maks tekrar sayısı (0 = sınırsız)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existingRule?.maxLoopCount ?: 0).toString())
        }
        container.addView(maxLoopInput)

        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle(if (existingRule != null) "Kuralı güncelle" else "Kuralı kaydet")
            .setView(scroll)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val timeout = timeoutInput.text.toString().toLongOrNull() ?: 3000L
                val def = RuleDefinition(
                    id = existingRule?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    groupName = groupInput.text.toString().ifBlank { null },
                    alternatives = alternatives.toMutableList(),
                    timeoutMs = timeout,
                    negateCondition = negateCheck.isChecked,
                    loopMode = if (loopCheck.isChecked) "WHILE_SUCCESS" else "NONE",
                    maxLoopCount = maxLoopInput.text.toString().toIntOrNull() ?: 0,
                    requireVariableName = reqVarNameInput.text.toString().ifBlank { null },
                    requireVariableOp = reqVarOpInput.text.toString().ifBlank { ">=" },
                    requireVariableValue = reqVarValueInput.text.toString().toIntOrNull() ?: 0,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2,
                    callFunctionId = callFunctionId,
                    callFunctionRepeat = callFunctionRepeat,
                    incrementVariableName = incVarNameInput.text.toString().ifBlank { null },
                    incrementVariableDelta = incVarDeltaInput.text.toString().toIntOrNull() ?: 1
                )
                val fnId = functionId
                if (fnId != null) {
                    FunctionStorage.upsertRuleInFunction(this, fnId, def)
                } else {
                    RuleStorage.upsert(this, def)
                }
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
