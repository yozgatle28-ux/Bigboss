package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kod yazmadan kural oluşturma/düzenleme ekranı (Macrorify tarzı):
 *  1) Donmuş ekran görüntüsü üzerinde SÜRÜKLEYEREK bir bölge (Region) çizersin
 *  2) Renk / Resim / Yazı arasından seçersin, gerekirse başka bir alternatif
 *     daha eklersin (VEYA mantığı -> Multi Detection)
 *  3) Tap mi Swipe mi olacağını seçip nokta(lar)a dokunursun
 *  4) İsim, grup, süre, isteğe bağlı sayaç/değişken ayarlarını girip kaydedersin
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
    }

    private lateinit var binding: ActivityRuleEditorBinding

    private enum class Step { DRAW_REGION, CHOOSE_CONDITION_KIND, CHOOSE_ACTION_TYPE, PICK_TAP, PICK_SWIPE_START, PICK_SWIPE_END, DONE }
    private var step = Step.DRAW_REGION
    private var actionType = "TAP"

    private val alternatives = mutableListOf<ConditionAlt>()

    // Şu an çizilmekte olan bölge (bitmap koordinatlarında)
    private var condX = 0; private var condY = 0; private var condW = 1; private var condH = 1
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0

    private var dragStartViewX = 0f
    private var dragStartViewY = 0f

    private lateinit var frame: Bitmap
    private var existingRule: RuleDefinition? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)

        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            existingRule = RuleStorage.load(this).find { it.id == editId }
            if (existingRule != null) {
                binding.tvInstruction.text =
                    "\"${existingRule!!.name}\" kuralını düzenliyorsun — yeni bölge/nokta çiz"
            }
        }

        binding.ivScreenshot.setOnTouchListener { _, event -> handleTouch(event); true }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnNext.setOnClickListener { onNextPressed() }

        binding.btnCondColor.setOnClickListener {
            val avgColor = averageColor(frame, condX, condY, condW, condH)
            showMinScoreDialog(85, "Renk için Min Score") { ms ->
                alternatives.add(ConditionAlt("COLOR", condX, condY, condW, condH, color = avgColor, minScore = ms))
                askAddAnotherAlternative()
            }
        }
        binding.btnCondImage.setOnClickListener {
            val cropped = safeCropRegion(frame, condX, condY, condW, condH)
            if (cropped == null) {
                Toast.makeText(this, "Bölge çok küçük/geçersiz, tekrar çiz", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val path = TemplateStorage.save(this, cropped)
            showMinScoreDialog(80, "Resim için Min Score") { ms ->
                alternatives.add(ConditionAlt("IMAGE", condX, condY, condW, condH, templatePath = path, minScore = ms))
                askAddAnotherAlternative()
            }
        }
        binding.btnCondText.setOnClickListener {
            showTextInputDialog { text ->
                if (text.isBlank()) {
                    Toast.makeText(this, "Metin boş olamaz", Toast.LENGTH_SHORT).show()
                } else {
                    alternatives.add(ConditionAlt("TEXT", condX, condY, condW, condH, expectedText = text))
                    askAddAnotherAlternative()
                }
            }
        }

        binding.btnActionTap.setOnClickListener {
            actionType = "TAP"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "Dokunulacak (tap) noktaya dokun"
            step = Step.PICK_TAP
        }
        binding.btnActionSwipe.setOnClickListener {
            actionType = "SWIPE"
            binding.actionTypeChooser.visibility = View.GONE
            binding.tvInstruction.text = "Kaydırmanın BAŞLANGIÇ noktasına dokun"
            step = Step.PICK_SWIPE_START
        }
    }

    private fun handleTouch(event: MotionEvent) {
        when (step) {
            Step.DRAW_REGION -> handleDrawRegion(event)
            Step.PICK_TAP -> if (event.action == MotionEvent.ACTION_DOWN) handlePickTap(event)
            Step.PICK_SWIPE_START -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeStart(event)
            Step.PICK_SWIPE_END -> if (event.action == MotionEvent.ACTION_DOWN) handlePickSwipeEnd(event)
            else -> {}
        }
    }

    // ---- Bölge çizimi ----

    private fun handleDrawRegion(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartViewX = event.x
                dragStartViewY = event.y
                binding.regionBox.visibility = View.VISIBLE
                updateRegionBoxView(event.x, event.y, event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> updateRegionBoxView(dragStartViewX, dragStartViewY, event.x, event.y)
            MotionEvent.ACTION_UP -> finalizeRegion(dragStartViewX, dragStartViewY, event.x, event.y)
        }
    }

    private fun updateRegionBoxView(x1: Float, y1: Float, x2: Float, y2: Float) {
        val left = min(x1, x2); val top = min(y1, y2)
        val w = max(abs(x2 - x1), 4f); val h = max(abs(y2 - y1), 4f)
        binding.regionBox.x = left
        binding.regionBox.y = top
        binding.regionBox.layoutParams = binding.regionBox.layoutParams.apply {
            width = w.toInt(); height = h.toInt()
        }
        binding.regionBox.requestLayout()
    }

    private fun finalizeRegion(x1: Float, y1: Float, x2: Float, y2: Float) {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        val leftView = min(x1, x2); val topView = min(y1, y2)
        val rightView = max(x1, x2); val bottomView = max(y1, y2)

        condX = (leftView * scaleX).toInt().coerceIn(0, frame.width - 1)
        condY = (topView * scaleY).toInt().coerceIn(0, frame.height - 1)
        condW = ((rightView - leftView) * scaleX).toInt().coerceAtLeast(4)
        condH = ((bottomView - topView) * scaleY).toInt().coerceAtLeast(4)

        binding.tvInstruction.text = "Bu alanda ne aranacak?"
        binding.conditionKindChooser.visibility = View.VISIBLE
        step = Step.CHOOSE_CONDITION_KIND
    }

    private fun askAddAnotherAlternative() {
        binding.regionBox.visibility = View.GONE
        AlertDialog.Builder(this)
            .setTitle("Alternatif ekle?")
            .setMessage("Bu koşula BAŞKA bir alternatif eklemek ister misin? (VEYA mantığı — hangisi bulunursa kural tetiklenir)\n\nŞu ana kadar: ${alternatives.size} alternatif")
            .setPositiveButton("Evet, ekle") { _, _ ->
                binding.tvInstruction.text = "Yeni alternatif için bir alan daha çiz"
                step = Step.DRAW_REGION
            }
            .setNegativeButton("Hayır, devam et") { _, _ ->
                binding.tvInstruction.text = "Aksiyon tipini seç"
                binding.actionTypeChooser.visibility = View.VISIBLE
                step = Step.CHOOSE_ACTION_TYPE
            }
            .setCancelable(false)
            .show()
    }

    private fun showMinScoreDialog(default: Int, title: String, onConfirm: (Int) -> Unit) {
        val label = TextView(this).apply { text = "$title: %$default" }
        val seek = SeekBar(this).apply {
            max = 100
            progress = default
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    label.text = "$title: %$value"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(label); addView(seek)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setPositiveButton("Tamam") { _, _ -> onConfirm(seek.progress) }
            .setCancelable(false)
            .show()
    }

    private fun showTextInputDialog(onConfirm: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Aranacak kelime/metin (örn. Devam)" }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Aranacak metni yaz")
            .setView(container)
            .setPositiveButton("Tamam") { _, _ -> onConfirm(input.text.toString()) }
            .setCancelable(false)
            .show()
    }

    private fun averageColor(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Int {
        var r = 0L; var g = 0L; var b = 0L; var count = 0L
        val step = 4
        val right = (x + w).coerceAtMost(bitmap.width)
        val bottom = (y + h).coerceAtMost(bitmap.height)
        var yy = y
        while (yy < bottom) {
            var xx = x
            while (xx < right) {
                val px = bitmap.getPixel(xx, yy)
                r += (px shr 16) and 0xFF; g += (px shr 8) and 0xFF; b += px and 0xFF
                count++
                xx += step
            }
            yy += step
        }
        if (count == 0L) return Color.BLACK
        return Color.rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
    }

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    // ---- Aksiyon noktaları ----

    private fun handlePickTap(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun handlePickSwipeStart(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX = bx; actionY = by
        placeMarker(binding.markerAction, event.x, event.y)
        binding.tvInstruction.text = "Şimdi kaydırmanın BİTİŞ noktasına dokun"
        step = Step.PICK_SWIPE_END
    }

    private fun handlePickSwipeEnd(event: MotionEvent) {
        val (bx, by) = viewToBitmap(event.x, event.y)
        actionX2 = bx; actionY2 = by
        placeMarker(binding.markerActionEnd, event.x, event.y)
        binding.tvInstruction.text = "Hazır! Kaydetmek için Devam'a bas."
        binding.btnNext.visibility = View.VISIBLE
        binding.btnNext.text = "Devam"
        step = Step.DONE
    }

    private fun viewToBitmap(x: Float, y: Float): Pair<Int, Int> {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (y * scaleY).toInt().coerceIn(0, frame.height - 1)
        return bx to by
    }

    private fun placeMarker(marker: View, x: Float, y: Float) {
        marker.visibility = View.VISIBLE
        marker.x = x - marker.width / 2f
        marker.y = y - marker.height / 2f
    }

    private fun onNextPressed() {
        if (step != Step.DONE) return
        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
            setText(existingRule?.name ?: "")
        }
        container.addView(nameInput)

        val groupInput = EditText(this).apply {
            hint = "Grup adı (isteğe bağlı, örn. \"Savaş\", \"Toplama\")"
            setText(existingRule?.groupName ?: "")
        }
        container.addView(groupInput)

        val altSummary = TextView(this).apply {
            text = "Koşul: ${alternatives.size} alternatif (${alternatives.joinToString(", ") { it.conditionKind }})"
            setPadding(0, 16, 0, 0)
        }
        container.addView(altSummary)

        val actionSummary = TextView(this).apply {
            text = if (actionType == "SWIPE")
                "Aksiyon: ↔ Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
            else
                "Aksiyon: 👆 Dokunma ($actionX,$actionY)"
        }
        container.addView(actionSummary)

        val timeoutLabel = TextView(this).apply {
            text = "Arama süresi (ms) — en fazla ne kadar arasın. -1 = sınırsız:"
            setPadding(0, 24, 0, 0)
        }
        container.addView(timeoutLabel)
        val timeoutInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.timeoutMs ?: 3000L).toString())
        }
        container.addView(timeoutInput)

        val varHeader = TextView(this).apply {
            text = "İsteğe bağlı: Değişken/Sayaç"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        container.addView(varHeader)

        val incVarNameInput = EditText(this).apply {
            hint = "Tetiklenince artırılacak sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.incrementVariableName ?: "")
        }
        container.addView(incVarNameInput)
        val incVarDeltaInput = EditText(this).apply {
            hint = "Ne kadar artırılsın (örn. 1, -1)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.incrementVariableDelta ?: 1).toString())
        }
        container.addView(incVarDeltaInput)

        val reqVarNameInput = EditText(this).apply {
            hint = "Ek şart: bu sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.requireVariableName ?: "")
        }
        container.addView(reqVarNameInput)
        val reqVarOpInput = EditText(this).apply {
            hint = "Karşılaştırma: >=, <=, ==, >, <  (örn. >=)"
            setText(existingRule?.requireVariableOp ?: ">=")
        }
        container.addView(reqVarOpInput)
        val reqVarValueInput = EditText(this).apply {
            hint = "Karşılaştırılacak sayı"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.requireVariableValue ?: 0).toString())
        }
        container.addView(reqVarValueInput)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"
            isChecked = existingRule?.enabled ?: true
            setPadding(0, 16, 0, 0)
        }
        container.addView(enabledCheck)

        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle(if (existingRule != null) "Kuralı güncelle" else "Kuralı kaydet")
            .setView(scroll)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val timeout = timeoutInput.text.toString().toLongOrNull() ?: 3000L
                val def = RuleDefinition(
                    id = existingRule?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    groupName = groupInput.text.toString().ifBlank { null },
                    alternatives = alternatives.toMutableList(),
                    timeoutMs = timeout,
                    requireVariableName = reqVarNameInput.text.toString().ifBlank { null },
                    requireVariableOp = reqVarOpInput.text.toString().ifBlank { ">=" },
                    requireVariableValue = reqVarValueInput.text.toString().toIntOrNull() ?: 0,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2,
                    incrementVariableName = incVarNameInput.text.toString().ifBlank { null },
                    incrementVariableDelta = incVarDeltaInput.text.toString().toIntOrNull() ?: 1
                )
                RuleStorage.upsert(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
