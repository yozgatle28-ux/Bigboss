package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityRuleEditorBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify tarzı ÇOKLU ALAN (multi-region) kural editörü.
 *
 * Akış:
 *  1) "➕ Alan Ekle" ile ekrana istediğin kadar sürüklenebilir/boyutlandırılabilir
 *     kutu düşürebilirsin. Kutu eklendiğinde HİÇBİR menü açılmaz — sadece
 *     ekranda durur, başka alanlar da ekleyebilirsin.
 *  2) Bir alana DOKUNURSAN (sürüklemeden, kısa bir tıklama) o alan için
 *     bir menü açılır: "Arama Alanı Yap" (renk/HEX/resim/yazı/kütüphane)
 *     ya da "Dokunma/Kaydırma Noktası Yap" (aksiyon).
 *  3) Yeterli alan (en az 1 arama + 1 aksiyon) yapılandırıldığında
 *     "💾 Kaydet" ile kuralı tamamlarsın.
 */
class RuleEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_RULE_ID = "edit_rule_id"
        private const val DEFAULT_SIZE_DP = 130f
        private const val HANDLE_SIZE_DP = 22f
        private const val TAP_SLOP_PX = 18f
        private const val TAP_MAX_MS = 350L
    }

    private lateinit var binding: ActivityRuleEditorBinding
    private lateinit var frame: Bitmap
    private var existingRule: RuleDefinition? = null
    private val density get() = resources.displayMetrics.density

    /** Ekranda o an duran bir alan (bölge) ve o alanın rolü/durumu. */
    private inner class PendingRegion(val id: String, val box: View, val handle: View, val label: TextView) {
        var role: String = "UNSET" // UNSET, CONDITION, ACTION_TAP, ACTION_SWIPE_START, ACTION_SWIPE_END
        var conditionAlt: ConditionAlt? = null
    }

    private val regions = mutableListOf<PendingRegion>()
    private var regionCounter = 0
    private var pendingColorPickRegion: PendingRegion? = null

    // Kaydet'e basıldığında showSaveDialog()'un kullandığı toplanmış değerler
    private val alternatives = mutableListOf<ConditionAlt>()
    private var actionType = "TAP"
    private var actionX = 0; private var actionY = 0
    private var actionX2 = 0; private var actionY2 = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRuleEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val capturedFrame = ScreenCaptureService.latestFrame
        if (capturedFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = capturedFrame
        binding.ivScreenshot.setImageBitmap(frame)
        binding.ivScreenshot.setOnTouchListener { _, event -> handleScreenshotTouch(event); true }

        binding.btnAddRegion.setOnClickListener { addRegion() }
        binding.btnCancelEdit.setOnClickListener { finish() }
        binding.btnSaveRule.setOnClickListener { onSavePressed() }

        val editId = intent.getStringExtra(EXTRA_EDIT_RULE_ID)
        if (editId != null) {
            existingRule = RuleStorage.load(this).find { it.id == editId }
            existingRule?.let { restoreRegionsForEdit(it) }
        }
        updateInstruction()
    }

    private fun updateInstruction() {
        val configured = regions.count { it.role != "UNSET" }
        binding.tvInstruction.text = "Alanlar: ${regions.size} (${configured} yapılandırıldı) — bir alana dokunarak ne arayacağını seç"
    }

    // ---- Alan (region) oluşturma ve düzenleme ----

    private fun addRegion(initialXPx: Float? = null, initialYPx: Float? = null, initialWPx: Float? = null, initialHPx: Float? = null): PendingRegion {
        val id = "r${regionCounter++}"
        val defaultSizePx = DEFAULT_SIZE_DP * density
        val offset = (regionCounter % 6) * 24f * density

        val box = View(this).apply {
            setBackgroundColor(Color.parseColor("#559E9E9E")) // UNSET = gri
        }
        val handle = View(this).apply {
            setBackgroundColor(Color.WHITE)
            layoutParams = FrameLayoutParamsSquare((HANDLE_SIZE_DP * density).toInt())
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }

        binding.root.addView(box, FrameLayoutParamsSquare(defaultSizePx.toInt()))
        binding.root.addView(handle)
        binding.root.addView(label)

        val region = PendingRegion(id, box, handle, label)

        box.x = initialXPx ?: (60f * density + offset)
        box.y = initialYPx ?: (220f * density + offset)
        box.layoutParams = box.layoutParams.apply {
            width = (initialWPx ?: defaultSizePx).toInt()
            height = (initialHPx ?: defaultSizePx).toInt()
        }
        box.requestLayout()
        positionHandleAndLabel(region)

        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var boxStartX = 0f; var boxStartY = 0f

        box.setOnTouchListener { _, event ->
            if (pendingColorPickRegion != null) return@setOnTouchListener false // renk seçimi sırasında dokunuşu ekrana bırak
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    boxStartX = box.x; boxStartY = box.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX; val dy = event.rawY - downRawY
                    val maxX = (binding.ivScreenshot.width - box.width).toFloat().coerceAtLeast(0f)
                    val maxY = (binding.ivScreenshot.height - box.height).toFloat().coerceAtLeast(0f)
                    box.x = (boxStartX + dx).coerceIn(0f, maxX)
                    box.y = (boxStartY + dy).coerceIn(0f, maxY)
                    positionHandleAndLabel(region)
                }
                MotionEvent.ACTION_UP -> {
                    val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                    val dt = System.currentTimeMillis() - downTime
                    if (dist < TAP_SLOP_PX && dt < TAP_MAX_MS) {
                        openRegionMenu(region)
                    }
                }
            }
            true
        }

        handle.setOnTouchListener { _, event ->
            if (pendingColorPickRegion != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSizePx = 40f * density
                val newW = (event.rawX - box.x).coerceAtLeast(minSizePx)
                val newH = (event.rawY - box.y).coerceAtLeast(minSizePx)
                val maxW = binding.ivScreenshot.width - box.x
                val maxH = binding.ivScreenshot.height - box.y
                box.layoutParams = box.layoutParams.apply {
                    width = newW.coerceAtMost(maxW).toInt()
                    height = newH.coerceAtMost(maxH).toInt()
                }
                box.requestLayout()
                positionHandleAndLabel(region)
            }
            true
        }

        regions.add(region)
        updateInstruction()
        return region
    }

    private fun FrameLayoutParamsSquare(sizePx: Int) =
        android.widget.FrameLayout.LayoutParams(sizePx, sizePx)

    private fun positionHandleAndLabel(region: PendingRegion) {
        val handleHalf = (HANDLE_SIZE_DP * density) / 2f
        region.handle.x = region.box.x + region.box.width - handleHalf
        region.handle.y = region.box.y + region.box.height - handleHalf
        region.label.x = region.box.x
        region.label.y = (region.box.y - 28f * density).coerceAtLeast(0f)
    }

    private fun removeRegion(region: PendingRegion) {
        binding.root.removeView(region.box)
        binding.root.removeView(region.handle)
        binding.root.removeView(region.label)
        if (region.conditionAlt?.templatePath != null) {
            // Kütüphaneye kaydedilmediyse, sadece bu kural için oluşturulmuş geçici şablonu temizle
        }
        regions.remove(region)
        updateInstruction()
    }

    // ---- Alana dokununca açılan menü ----

    private fun openRegionMenu(region: PendingRegion) {
        val options = mutableListOf("🔎 Arama Alanı Yap (Koşul)", "👆 Dokunma Noktası Yap", "👉 Kaydırma Başlangıcı Yap", "👉 Kaydırma Bitişi Yap", "🗑 Bu Alanı Sil")
        AlertDialog.Builder(this)
            .setTitle("Bu alan ne için?")
            .setItems(options.toTypedArray()) { _, index ->
                when (index) {
                    0 -> openConditionKindMenu(region)
                    1 -> setActionRole(region, "ACTION_TAP")
                    2 -> setActionRole(region, "ACTION_SWIPE_START")
                    3 -> setActionRole(region, "ACTION_SWIPE_END")
                    4 -> removeRegion(region)
                }
            }
            .show()
    }

    private fun setActionRole(region: PendingRegion, role: String) {
        // Tap ile Swipe karışmasın: aynı rolde başka bir alan varsa sıfırla
        val conflicting = when (role) {
            "ACTION_TAP" -> regions.filter { it.role == "ACTION_TAP" || it.role == "ACTION_SWIPE_START" || it.role == "ACTION_SWIPE_END" }
            else -> regions.filter { it.role == "ACTION_TAP" || it.role == role }
        }
        conflicting.filter { it.id != region.id }.forEach { resetRegionRole(it) }

        region.role = role
        region.conditionAlt = null
        val (color, text) = when (role) {
            "ACTION_TAP" -> Color.parseColor("#AAFF3B30") to "👆 Dokun"
            "ACTION_SWIPE_START" -> Color.parseColor("#AA1F6FEB") to "👉 Başlangıç"
            else -> Color.parseColor("#AA6F1FEB") to "👉 Bitiş"
        }
        region.box.setBackgroundColor(color)
        region.label.text = text
        updateInstruction()
    }

    private fun resetRegionRole(region: PendingRegion) {
        region.role = "UNSET"
        region.conditionAlt = null
        region.box.setBackgroundColor(Color.parseColor("#559E9E9E"))
        region.label.text = "?"
    }

    private fun regionBitmapRect(region: PendingRegion): IntArray {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val x = (region.box.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val y = (region.box.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val w = (region.box.width * scaleX).toInt().coerceAtLeast(4)
        val h = (region.box.height * scaleY).toInt().coerceAtLeast(4)
        return intArrayOf(x, y, w, h)
    }

    // ---- Arama alanı: renk / hex / resim / yazı / kütüphane ----

    private fun openConditionKindMenu(region: PendingRegion) {
        val options = arrayOf("🎨 Renk (Ekrandan Nokta Seç)", "# HEX Renk Gir", "🖼️ Resim Ara (Bu Alanı Kırp)", "📝 Yazı Ara (OCR)", "📚 Kütüphaneden Seç")
        AlertDialog.Builder(this)
            .setTitle("Bu alanda ne aranacak?")
            .setItems(options) { _, index ->
                when (index) {
                    0 -> startColorPointPick(region)
                    1 -> showHexInputDialog(region)
                    2 -> configureImageCondition(region)
                    3 -> showTextInputDialog(region)
                    4 -> showLibraryPickerDialog(region)
                }
            }
            .show()
    }

    private fun startColorPointPick(region: PendingRegion) {
        pendingColorPickRegion = region
        Toast.makeText(this, "Şimdi renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    private fun handleScreenshotTouch(event: MotionEvent) {
        val pickRegion = pendingColorPickRegion ?: return
        if (event.action != MotionEvent.ACTION_DOWN) return
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val bx = (event.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val by = (event.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val exactColor = frame.getPixel(bx, by)
        val hex = String.format("#%06X", 0xFFFFFF and exactColor)
        pendingColorPickRegion = null

        val swatch = View(this).apply { setBackgroundColor(exactColor) }
        val previewContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@RuleEditorActivity).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        AlertDialog.Builder(this)
            .setTitle("Bu renk mi?")
            .setView(previewContainer)
            .setPositiveButton("Evet, bunu kullan") { _, _ ->
                showMinScoreDialog(95, "Renk için Min Skor ($hex)", true) { ms, libName ->
                    val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                    val alt = ConditionAlt("COLOR", rx, ry, rw, rh, color = exactColor, minScore = ms)
                    applyConditionToRegion(region, alt, "🎨")
                    maybeSaveToLibrary(libName, "COLOR", exactColor, null)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun showHexInputDialog(region: PendingRegion) {
        val input = EditText(this).apply { hint = "#RRGGBB (örn. #FF3B30)"; setText("#") }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("HEX Renk Kodu Gir")
            .setView(container)
            .setPositiveButton("Tamam") { _, _ ->
                val hex = input.text.toString().trim()
                val parsed = try { Color.parseColor(hex) } catch (e: Exception) { null }
                if (parsed == null) {
                    Toast.makeText(this, "Geçersiz HEX kodu, tekrar dene", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                showMinScoreDialog(95, "Renk için Min Skor", true) { ms, libName ->
                    val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                    val alt = ConditionAlt("COLOR", rx, ry, rw, rh, color = parsed, minScore = ms)
                    applyConditionToRegion(region, alt, "# HEX")
                    maybeSaveToLibrary(libName, "COLOR", parsed, null)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun configureImageCondition(region: PendingRegion) {
        val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
        val cropped = safeCropRegion(frame, rx, ry, rw, rh)
        if (cropped == null) {
            Toast.makeText(this, "Bölge çok küçük/geçersiz", Toast.LENGTH_SHORT).show()
            return
        }
        val path = TemplateStorage.save(this, cropped)
        showMinScoreDialog(80, "Resim için Min Skor", true) { ms, libName ->
            val alt = ConditionAlt("IMAGE", rx, ry, rw, rh, templatePath = path, minScore = ms)
            applyConditionToRegion(region, alt, "🖼️")
            maybeSaveToLibrary(libName, "IMAGE", 0, path)
        }
    }

    private fun showTextInputDialog(region: PendingRegion) {
        val input = EditText(this).apply { hint = "Aranacak kelime/metin (örn. Devam)" }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Aranacak metni yaz")
            .setView(container)
            .setPositiveButton("Tamam") { _, _ ->
                val text = input.text.toString()
                if (text.isBlank()) {
                    Toast.makeText(this, "Metin boş olamaz", Toast.LENGTH_SHORT).show()
                } else {
                    val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                    val alt = ConditionAlt("TEXT", rx, ry, rw, rh, expectedText = text)
                    applyConditionToRegion(region, alt, "📝")
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun showLibraryPickerDialog(region: PendingRegion) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) {
            Toast.makeText(this, "Kütüphane boş. Önce bir renk/resim kaydet.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kütüphaneden Seç")
            .setItems(labels) { _, index ->
                val item = items[index]
                val defaultScore = if (item.kind == "IMAGE") 80 else 90
                showMinScoreDialog(defaultScore, "Min Skor", false) { ms, _ ->
                    val (rx, ry, rw, rh) = regionBitmapRect(region).let { Quad(it[0], it[1], it[2], it[3]) }
                    val alt = if (item.kind == "IMAGE") {
                        ConditionAlt("IMAGE", rx, ry, rw, rh, templatePath = item.templatePath, minScore = ms)
                    } else {
                        ConditionAlt("COLOR", rx, ry, rw, rh, color = item.color, minScore = ms)
                    }
                    applyConditionToRegion(region, alt, if (item.kind == "IMAGE") "🖼️📚" else "🎨📚")
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun applyConditionToRegion(region: PendingRegion, alt: ConditionAlt, iconText: String) {
        region.role = "CONDITION"
        region.conditionAlt = alt
        region.box.setBackgroundColor(Color.parseColor("#5500FF00"))
        region.label.text = iconText
        updateInstruction()
    }

    private data class Quad(val a: Int, val b: Int, val c: Int, val d: Int)

    private fun maybeSaveToLibrary(name: String?, kind: String, color: Int, templatePath: String?) {
        if (name.isNullOrBlank()) return
        LibraryStorage.add(this, LibraryItem(UUID.randomUUID().toString(), name, kind, color, templatePath))
        Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
    }

    private fun showMinScoreDialog(default: Int, title: String, offerLibrarySave: Boolean, onConfirm: (Int, String?) -> Unit) {
        val label = TextView(this).apply { text = "$title: %$default" }
        val seek = SeekBar(this).apply {
            max = 100
            progress = default
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) { label.text = "$title: %$value" }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(label); addView(seek)
        }
        var libNameInput: EditText? = null
        if (offerLibrarySave) {
            container.addView(TextView(this).apply {
                text = "Kütüphaneye de kaydetmek için isim ver (boş bırakabilirsin):"
                setPadding(0, 24, 0, 0)
            })
            libNameInput = EditText(this).apply { hint = "örn. Kırmızı HP Barı" }
            container.addView(libNameInput)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setPositiveButton("Tamam") { _, _ -> onConfirm(seek.progress, libNameInput?.text?.toString()) }
            .setCancelable(false)
            .show()
    }

    private fun safeCropRegion(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeW = w.coerceAtMost(bitmap.width - x)
        val safeH = h.coerceAtMost(bitmap.height - y)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, x, y, safeW, safeH)
    }

    // ---- Düzenleme modunda: mevcut kuralın alanlarını geri yükle ----

    private fun restoreRegionsForEdit(rule: RuleDefinition) {
        binding.ivScreenshot.post {
            val scaleX = frame.width.toFloat() / binding.ivScreenshot.width.toFloat()
            val scaleY = frame.height.toFloat() / binding.ivScreenshot.height.toFloat()

            rule.alternatives.forEach { alt ->
                val vx = alt.x / scaleX; val vy = alt.y / scaleY
                val vw = (alt.width / scaleX).coerceAtLeast(20f); val vh = (alt.height / scaleY).coerceAtLeast(20f)
                val region = addRegion(vx, vy, vw, vh)
                val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
                applyConditionToRegion(region, alt.copy(), icon)
            }

            val actionSizePx = 50f * density
            when (rule.actionType) {
                "SWIPE" -> {
                    val startRegion = addRegion(
                        rule.actionX / scaleX - actionSizePx / 2, rule.actionY / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(startRegion, "ACTION_SWIPE_START")
                    val endRegion = addRegion(
                        rule.actionX2 / scaleX - actionSizePx / 2, rule.actionY2 / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(endRegion, "ACTION_SWIPE_END")
                }
                "WAIT" -> { /* aksiyon noktası yok */ }
                else -> {
                    val tapRegion = addRegion(
                        rule.actionX / scaleX - actionSizePx / 2, rule.actionY / scaleY - actionSizePx / 2, actionSizePx, actionSizePx
                    )
                    setActionRole(tapRegion, "ACTION_TAP")
                }
            }
            updateInstruction()
        }
    }

    // ---- Kaydet ----

    private fun onSavePressed() {
        val conditionRegions = regions.filter { it.role == "CONDITION" && it.conditionAlt != null }
        val tapRegion = regions.find { it.role == "ACTION_TAP" }
        val swipeStart = regions.find { it.role == "ACTION_SWIPE_START" }
        val swipeEnd = regions.find { it.role == "ACTION_SWIPE_END" }

        if (conditionRegions.isEmpty()) {
            Toast.makeText(this, "En az bir arama alanı yapılandırmalısın (bir alana dokun)", Toast.LENGTH_LONG).show()
            return
        }
        if (tapRegion == null && (swipeStart == null || swipeEnd == null)) {
            Toast.makeText(this, "Bir aksiyon noktası (Dokunma) ya da Kaydırma Başlangıç+Bitiş ayarlamalısın", Toast.LENGTH_LONG).show()
            return
        }

        alternatives.clear()
        alternatives.addAll(conditionRegions.mapNotNull { it.conditionAlt })

        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()

        if (tapRegion != null) {
            actionType = "TAP"
            actionX = ((tapRegion.box.x + tapRegion.box.width / 2f) * scaleX).toInt()
            actionY = ((tapRegion.box.y + tapRegion.box.height / 2f) * scaleY).toInt()
        } else {
            actionType = "SWIPE"
            actionX = ((swipeStart!!.box.x + swipeStart.box.width / 2f) * scaleX).toInt()
            actionY = ((swipeStart.box.y + swipeStart.box.height / 2f) * scaleY).toInt()
            actionX2 = ((swipeEnd!!.box.x + swipeEnd.box.width / 2f) * scaleX).toInt()
            actionY2 = ((swipeEnd.box.y + swipeEnd.box.height / 2f) * scaleY).toInt()
        }

        showSaveDialog()
    }

    private fun showSaveDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val nameInput = EditText(this).apply {
            hint = "Kural adı (örn. HP düşükse potion iç)"
            setText(existingRule?.name ?: "")
        }
        container.addView(nameInput)

        val groupInput = EditText(this).apply {
            hint = "Grup adı (isteğe bağlı, örn. \"Savaş\", \"Toplama\")"
            setText(existingRule?.groupName ?: "")
        }
        container.addView(groupInput)

        container.addView(TextView(this).apply {
            text = "Koşul: ${alternatives.size} alan (${alternatives.joinToString(", ") { it.conditionKind }})"
            setPadding(0, 16, 0, 0)
        })
        container.addView(TextView(this).apply {
            text = when (actionType) {
                "SWIPE" -> "Aksiyon: ↔ Kaydırma ($actionX,$actionY) -> ($actionX2,$actionY2)"
                else -> "Aksiyon: 👆 Dokunma ($actionX,$actionY)"
            }
        })

        container.addView(TextView(this).apply {
            text = "Arama süresi (ms) — en fazla ne kadar arasın. -1 = sınırsız:"
            setPadding(0, 24, 0, 0)
        })
        val timeoutInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.timeoutMs ?: 3000L).toString())
        }
        container.addView(timeoutInput)

        container.addView(TextView(this).apply {
            text = "İsteğe bağlı: Değişken/Sayaç"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val incVarNameInput = EditText(this).apply {
            hint = "Tetiklenince artırılacak sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.incrementVariableName ?: "")
        }
        container.addView(incVarNameInput)
        val incVarDeltaInput = EditText(this).apply {
            hint = "Ne kadar artırılsın (örn. 1, -1)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.incrementVariableDelta ?: 1).toString())
        }
        container.addView(incVarDeltaInput)
        val reqVarNameInput = EditText(this).apply {
            hint = "Ek şart: bu sayaç adı (boş bırakabilirsin)"
            setText(existingRule?.requireVariableName ?: "")
        }
        container.addView(reqVarNameInput)
        val reqVarOpInput = EditText(this).apply {
            hint = "Karşılaştırma: >=, <=, ==, >, <  (örn. >=)"
            setText(existingRule?.requireVariableOp ?: ">=")
        }
        container.addView(reqVarOpInput)
        val reqVarValueInput = EditText(this).apply {
            hint = "Karşılaştırılacak sayı"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existingRule?.requireVariableValue ?: 0).toString())
        }
        container.addView(reqVarValueInput)

        val enabledCheck = CheckBox(this).apply {
            text = "Etkin"; isChecked = existingRule?.enabled ?: true
            setPadding(0, 16, 0, 0)
        }
        container.addView(enabledCheck)

        container.addView(TextView(this).apply {
            text = "İleri Seviye Ayarlar (kural kaybolunca tetikleme / tekrar etme)"
            setPadding(0, 24, 0, 0)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val negateCheck = CheckBox(this).apply {
            text = "⏳ Ters mantık: koşul bulunduğunda değil, KAYBOLDUĞUNDA tetikle"
            isChecked = existingRule?.negateCondition ?: false
        }
        container.addView(negateCheck)
        val loopCheck = CheckBox(this).apply {
            text = "🔁 Eşleştikçe/eşleşmedikçe bu kuralda kal ve tekrar dene"
            isChecked = (existingRule?.loopMode ?: "NONE") != "NONE"
        }
        container.addView(loopCheck)
        val maxLoopInput = EditText(this).apply {
            hint = "Maks tekrar sayısı (0 = sınırsız)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existingRule?.maxLoopCount ?: 0).toString())
        }
        container.addView(maxLoopInput)

        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle(if (existingRule != null) "Kuralı güncelle" else "Kuralı kaydet")
            .setView(scroll)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz kural" }
                val timeout = timeoutInput.text.toString().toLongOrNull() ?: 3000L
                val def = RuleDefinition(
                    id = existingRule?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    enabled = enabledCheck.isChecked,
                    groupName = groupInput.text.toString().ifBlank { null },
                    alternatives = alternatives.toMutableList(),
                    timeoutMs = timeout,
                    negateCondition = negateCheck.isChecked,
                    loopMode = if (loopCheck.isChecked) "WHILE_SUCCESS" else "NONE",
                    maxLoopCount = maxLoopInput.text.toString().toIntOrNull() ?: 0,
                    requireVariableName = reqVarNameInput.text.toString().ifBlank { null },
                    requireVariableOp = reqVarOpInput.text.toString().ifBlank { ">=" },
                    requireVariableValue = reqVarValueInput.text.toString().toIntOrNull() ?: 0,
                    actionType = actionType,
                    actionX = actionX, actionY = actionY,
                    actionX2 = actionX2, actionY2 = actionY2,
                    incrementVariableName = incVarNameInput.text.toString().ifBlank { null },
                    incrementVariableDelta = incVarDeltaInput.text.toString().toIntOrNull() ?: 1
                )
                RuleStorage.upsert(this, def)
                Toast.makeText(this, "Kural kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
