package com.bigboss.app.storage

/** Macrorify'daki "Swipe Point": bir kaydırma yolundaki tek bir nokta + o noktada bekleme süresi. */
data class SwipePointData(
    var x: Int = 0,
    var y: Int = 0,
    var holdMs: Long = 0
)
