package com.bigboss.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bigboss.app.databinding.ItemFunctionBinding
import com.bigboss.app.storage.FunctionDefinition

class FunctionsAdapter(
    private val onOpen: (FunctionDefinition) -> Unit,
    private val onDelete: (FunctionDefinition) -> Unit
) : RecyclerView.Adapter<FunctionsAdapter.FunctionViewHolder>() {

    private val items = mutableListOf<FunctionDefinition>()

    fun submitList(newItems: List<FunctionDefinition>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class FunctionViewHolder(val binding: ItemFunctionBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FunctionViewHolder {
        val binding = ItemFunctionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FunctionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FunctionViewHolder, position: Int) {
        val fn = items[position]
        holder.binding.tvFunctionName.text = "f{} ${fn.name}  (${fn.rules.size} kural)"
        holder.binding.root.setOnClickListener { onOpen(fn) }
        holder.binding.btnDeleteFunction.setOnClickListener { onDelete(fn) }
    }

    override fun getItemCount(): Int = items.size
}
