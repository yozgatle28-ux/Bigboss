package com.bigboss.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Macrorify'daki gibi TEK, kalıcı bir panel — her menü için ayrı bir
 * pop-up (AlertDialog) açmak yerine, AYNI pencere içinde "ekran"lar
 * arasında gezinir. Üstte HER ZAMAN "neredeyim" (breadcrumb) yazar,
 * bir "‹ Geri" butonu bir üst ekrana döner — hiçbir zaman kaybolmazsın.
 *
 * Kullanım:
 *   panel.push("🏠 Ana Akış") { content -> ... content.addView(...) ... }
 *   panel.push("✏️ Alan Ayarları") { content -> ... } // üstüne biner, breadcrumb: "Ana Akış › Alan Ayarları"
 *   panel.pop() // bir üst ekrana döner
 *   panel.close() // tamamen kapatır
 */
class PanelNavigator(private val context: Context, private val windowManager: WindowManager) {

    private data class Screen(val title: String, val build: (LinearLayout) -> Unit, val footer: ((LinearLayout) -> Unit)? = null)

    private val stack = mutableListOf<Screen>()
    private var windowView: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    private lateinit var breadcrumbScroll: HorizontalScrollView
    private lateinit var breadcrumbRow: LinearLayout
    private lateinit var backButton: Button
    private lateinit var closeButton: Button
    private lateinit var contentContainer: LinearLayout
    private lateinit var footerContainer: LinearLayout

    private val density get() = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    val isOpen: Boolean get() = windowView != null

    /** Yeni bir ekranı üste ekler (geri ile bir öncekine dönülebilir). */
    fun push(title: String, footer: ((LinearLayout) -> Unit)? = null, build: (LinearLayout) -> Unit) {
        stack.add(Screen(title, build, footer))
        if (windowView == null) buildWindow() else render()
    }

    /** Şu anki ekranı SIFIRLAYIP yeniden çizer (veri değiştiğinde liste güncellemek için). */
    fun refreshTop() {
        if (stack.isNotEmpty()) render()
    }

    /** En üstteki ekranı kaldırıp bir öncekine döner. Sadece 1 ekran kaldıysa kapatır. */
    fun pop() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            render()
        } else {
            close()
        }
    }

    fun close() {
        stack.clear()
        windowView?.let { try { windowManager.removeView(it) } catch (e: Exception) {} }
        windowView = null
    }

    private fun buildWindow() {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F7F7F7"))
                cornerRadius = dp(14).toFloat()
            }
            clipToOutline = true
        }

        val headerBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1F6FEB"))
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        backButton = Button(context).apply {
            text = "‹ Geri"
            textSize = 13f
            setOnClickListener { pop() }
        }
        breadcrumbScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        breadcrumbRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        breadcrumbScroll.addView(breadcrumbRow)
        closeButton = Button(context).apply {
            text = "✕"
            textSize = 13f
            setOnClickListener { close() }
        }
        headerBar.addView(backButton)
        headerBar.addView(breadcrumbScroll)
        headerBar.addView(closeButton)
        root.addView(headerBar)

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (context.resources.displayMetrics.heightPixels * 0.62).toInt()
            )
        }
        contentContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        scroll.addView(contentContainer)
        root.addView(scroll)

        footerContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(footerContainer)

        windowView = root
        params = WindowManager.LayoutParams(
            (context.resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        windowManager.addView(root, params)
        render()
    }

    private fun render() {
        if (windowView == null || stack.isEmpty()) return
        val current = stack.last()

        breadcrumbRow.removeAllViews()
        stack.forEachIndexed { i, screen ->
            val isLast = i == stack.size - 1
            breadcrumbRow.addView(TextView(context).apply {
                text = screen.title
                setTextColor(if (isLast) Color.WHITE else Color.parseColor("#CCE3F2FD"))
                textSize = if (isLast) 14f else 12f
                setPadding(dp(4), 0, dp(4), 0)
                if (!isLast) {
                    setOnClickListener {
                        while (stack.size > i + 1) stack.removeAt(stack.size - 1)
                        render()
                    }
                }
            })
            if (!isLast) {
                breadcrumbRow.addView(TextView(context).apply {
                    text = "›"; setTextColor(Color.parseColor("#88FFFFFF")); textSize = 12f
                })
            }
        }
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(View.FOCUS_RIGHT) }
        backButton.visibility = if (stack.size > 1) View.VISIBLE else View.GONE

        contentContainer.removeAllViews()
        current.build(contentContainer)

        footerContainer.removeAllViews()
        current.footer?.invoke(footerContainer)
        footerContainer.visibility = if (current.footer != null) View.VISIBLE else View.GONE
    }
}
