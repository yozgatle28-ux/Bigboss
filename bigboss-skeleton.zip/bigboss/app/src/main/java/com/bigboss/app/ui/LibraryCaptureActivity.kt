package com.bigboss.app.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityLibraryCaptureBinding
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * "📚 Kütüphanem" ekranındaki "📷 Ekrandan Kırp" ile açılır. Ekrandan
 * istediğin bir alanı sürükleyerek seçip, isim vererek doğrudan
 * kütüphaneye kaydetmeni sağlar — herhangi bir kural oluşturmadan.
 * Sonradan bu resmi, bir kuralın "GENEL" sekmesindeki
 * "📚 Kütüphaneden Seç" ile istediğin alan için çağırabilirsin.
 */
class LibraryCaptureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLibraryCaptureBinding
    private lateinit var frame: Bitmap
    private val density get() = resources.displayMetrics.density

    private var boxVisible = false
    private var dragStartX = 0f
    private var dragStartY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLibraryCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val captured = ScreenCaptureService.latestFrame
        if (captured == null) {
            Toast.makeText(this, "Ekran görüntüsü bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        frame = captured
        binding.ivScreenshot.setImageBitmap(frame)

        // Seçim kutusu: sade bir View, kod ile eklenip sürüklenerek çizilir
        val box = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#332196F3"))
                setStroke((2.5f * density).toInt(), Color.parseColor("#2196F3"))
            }
            visibility = View.GONE
        }
        binding.root.addView(box)

        binding.ivScreenshot.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.x; dragStartY = event.y
                    box.visibility = View.VISIBLE
                    setBoxRect(box, event.x, event.y, event.x, event.y)
                }
                MotionEvent.ACTION_MOVE -> setBoxRect(box, dragStartX, dragStartY, event.x, event.y)
                MotionEvent.ACTION_UP -> boxVisible = true
            }
            true
        }

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnCrop.setOnClickListener {
            if (!boxVisible) {
                Toast.makeText(this, "Önce ekranda bir alan seç (sürükle)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            cropAndSave(box)
        }
    }

    private fun setBoxRect(box: View, x1: Float, y1: Float, x2: Float, y2: Float) {
        val left = min(x1, x2); val top = min(y1, y2)
        val w = max(abs(x2 - x1), 8f); val h = max(abs(y2 - y1), 8f)
        box.x = left; box.y = top
        box.layoutParams = (box.layoutParams ?: android.widget.FrameLayout.LayoutParams(0, 0)).apply {
            width = w.toInt(); height = h.toInt()
        }
        box.requestLayout()
    }

    private fun cropAndSave(box: View) {
        val view = binding.ivScreenshot
        val scaleX = frame.width.toFloat() / view.width.toFloat()
        val scaleY = frame.height.toFloat() / view.height.toFloat()
        val x = (box.x * scaleX).toInt().coerceIn(0, frame.width - 1)
        val y = (box.y * scaleY).toInt().coerceIn(0, frame.height - 1)
        val w = (box.width * scaleX).toInt().coerceAtMost(frame.width - x)
        val h = (box.height * scaleY).toInt().coerceAtMost(frame.height - y)
        if (w < 4 || h < 4) {
            Toast.makeText(this, "Alan çok küçük", Toast.LENGTH_SHORT).show()
            return
        }
        val cropped = Bitmap.createBitmap(frame, x, y, w, h)

        val input = EditText(this).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
        AlertDialog.Builder(this)
            .setTitle("Bu resmi kaydet")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = input.text.toString().ifBlank { "İsimsiz görsel" }
                val path = TemplateStorage.save(this, cropped)
                LibraryStorage.add(this, LibraryItem(UUID.randomUUID().toString(), name, "IMAGE", 0, path))
                Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
