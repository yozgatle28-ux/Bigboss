package com.bigboss.app.storage

/**
 * Macrorify'daki "Function" fikri: isimlendirilmiş, tekrar tekrar
 * çağrılabilen ayrı bir komut dizisi. Ana akıştaki bir kuralın aksiyonu
 * "Fonksiyon Çağır" olduğunda, o fonksiyonun kuralları sırayla çalışır,
 * bitince (ya da tekrar sayısı dolunca) ana akışa geri dönülür.
 */
data class FunctionDefinition(
    val id: String,
    var name: String,
    var rules: MutableList<RuleDefinition> = mutableListOf()
)
