package com.bigboss.app.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityEditModeBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

/**
 * EDIT MODE artık TAM EKRAN bir sayfa DEĞİL — sadece izinleri alıp
 * "✏️ Düzenleme" overlay'ini başlatır, sonra HEMEN kapanır (finish).
 * Bundan sonra HER ŞEY o küçük overlay simgesinden yönetiliyor —
 * Macrorify'daki gibi, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 */
class EditModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditModeBinding
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditModeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        projectionManager = getSystemService(MediaProjectionManager::class.java)

        if (ScreenCaptureService.latestFrame != null) {
            // Zaten çalışıyor — sadece overlay'i EDIT moduna al ve çık.
            ScreenCaptureService.ruleEngine?.paused = true
            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "EDIT")
            })
            finish()
            return
        }

        binding.tvEditStatus.text = "Ekran kaydı izni isteniyor..."
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CODE_CAPTURE) return
        if (data == null) { finish(); return }

        // ÖNEMLİ: instance'ı burada bir DEĞİŞKENE alıp kapatmıyoruz — o an null olabilir
        // (erişilebilirlik servisi henüz bağlanmamış olabilir). Her execute() çağrısında
        // GÜNCEL BigBossAccessibilityService.instance'a bakıyoruz, böylece servis sonradan
        // bağlansa bile (ki genelde öyle olur) komutlar çalışmaya başlar.
        val ruleEngine = RuleEngine(object : com.bigboss.app.engine.ActionExecutor {
            override fun execute(action: com.bigboss.app.engine.Action) {
                BigBossAccessibilityService.instance?.execute(action)
            }
        })
        ruleEngine.paused = true // EDIT MODE: sisteme asla dokunulmaz
        ruleEngine.setRules(com.bigboss.app.storage.EngineAssembler.buildRules(this))
        ruleEngine.setFunctionsProvider(com.bigboss.app.storage.EngineAssembler.buildFunctionsProvider(this))
        ScreenCaptureService.ruleEngine = ruleEngine

        com.bigboss.app.engine.ScriptRuntime.engine = com.bigboss.app.engine.ScriptEngine(
            executor = object : com.bigboss.app.engine.ActionExecutor {
                override fun execute(action: com.bigboss.app.engine.Action) {
                    BigBossAccessibilityService.instance?.execute(action)
                }
            },
            frameProvider = { ScreenCaptureService.latestFrame },
            functionByName = { name ->
                FunctionStorage.load(this).find { it.name == name }
                    ?.let { RuleDefinitionMapper.toRules(it.rules) } ?: emptyList()
            },
            runRuleList = { rulesToRun, frame -> ruleEngine.evaluateRulesOnce(rulesToRun, frame) },
            pausedProvider = { true },
            libraryLookup = { name -> com.bigboss.app.storage.LibraryStorage.load(this).find { it.name == name }?.templatePath },
            scriptLookup = { name -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.name == name }?.code }
        ).also { engine ->
            engine.globalVarLookup = { name -> com.bigboss.app.storage.GlobalVariableStorage.valueOf(this, name) }
            engine.globalVarSetter = { name, value ->
                val vars = com.bigboss.app.storage.GlobalVariableStorage.load(this)
                val existing = vars.find { it.name == name }
                if (existing != null) { existing.value = value; com.bigboss.app.storage.GlobalVariableStorage.upsert(this, existing) }
                else com.bigboss.app.storage.GlobalVariableStorage.upsert(this, com.bigboss.app.storage.GlobalVariableDefinition(java.util.UUID.randomUUID().toString(), name, value))
            }
        }

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(captureIntent)

        startService(Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_MODE, "EDIT")
        })

        // Kritik: hemen kapanıyoruz. Kullanıcı artık istediği uygulamaya
        // geçebilir, küçük ✏️ simgeden tüm işlemleri yapabilir.
        finish()
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 61
    }
}
