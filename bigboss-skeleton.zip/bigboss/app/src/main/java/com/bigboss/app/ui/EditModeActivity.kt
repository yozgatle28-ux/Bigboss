package com.bigboss.app.ui

import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bigboss.app.databinding.ActivityEditModeBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID

/**
 * EDIT MODE: kural/fonksiyon ekleme, düzenleme, kütüphane yönetimi —
 * yapabileceğin HER ŞEY burada. Sisteme müdahale (gerçek dokunuş/kaydırma)
 * burada YAPILMAZ; sadece ekran görüntüsü akar (RuleEngine hep paused=true).
 * Çıkmak için "💾 Kaydet ve Çık" — onay ister.
 */
class EditModeActivity : AppCompatActivity() {

    private enum class Tab { MAIN_FLOW, FUNCTIONS, SCRIPTS }
    private var currentTab = Tab.MAIN_FLOW

    private lateinit var binding: ActivityEditModeBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var rulesAdapter: RulesAdapter
    private lateinit var functionsAdapter: FunctionsAdapter
    private lateinit var scriptsAdapter: ScriptsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)

        rulesAdapter = RulesAdapter(
            onToggle = { rule, checked -> onRuleToggled(rule, checked) },
            onDelete = { rule -> onRuleDeleted(rule) },
            onEdit = { rule -> openEditor(rule.id) },
            onTest = { rule -> testRule(rule) }
        )
        functionsAdapter = FunctionsAdapter(
            onOpen = { fn -> openFunction(fn) },
            onDelete = { fn -> deleteFunction(fn) }
        )
        scriptsAdapter = ScriptsAdapter(
            onOpen = { script -> openScript(script.id) },
            onDelete = { script ->
                com.bigboss.app.storage.ScriptStorage.delete(this, script.id)
                refreshCurrentList()
            }
        )

        binding.rvRules.layoutManager = LinearLayoutManager(this)
        binding.btnTabMain.setOnClickListener { switchTab(Tab.MAIN_FLOW) }
        binding.btnTabFunctions.setOnClickListener { switchTab(Tab.FUNCTIONS) }
        binding.btnTabScripts.setOnClickListener { switchTab(Tab.SCRIPTS) }
        binding.btnAddToTab.setOnClickListener { onAddPressed() }
        binding.btnLibrary.setOnClickListener { showLibraryDialog() }
        binding.btnSaveExit.setOnClickListener { confirmExit() }

        switchTab(Tab.MAIN_FLOW)
        ensureCaptureRunning()
    }

    override fun onResume() {
        super.onResume()
        refreshCurrentList()
    }

    private fun openScript(scriptId: String) {
        val intent = Intent(this, ScriptEditorActivity::class.java)
        intent.putExtra(ScriptEditorActivity.EXTRA_SCRIPT_ID, scriptId)
        startActivity(intent)
    }

    // ---- Ekran görüntüsünü Edit Mode için sessizce başlat (dokunuş YAPILMAZ, motor paused kalır) ----

    private fun ensureCaptureRunning() {
        if (ScreenCaptureService.latestFrame != null) {
            binding.tvEditStatus.text = "Hazır! Oyuna geçip ✏️ simgeden \"Alan Ekle\" ile kural ekleyebilirsin."
            ScreenCaptureService.ruleEngine?.paused = true
            return
        }
        if (BigBossAccessibilityService.instance == null) {
            binding.tvEditStatus.text = "⚠️ Erişilebilirlik servisi kapalı — yine de düzenleme yapabilirsin ama test/oynatma çalışmaz. Ayarlar > Erişilebilirlik'ten aç."
        }
        binding.tvEditStatus.text = "Ekran görüntüsü isteniyor..."
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            val executor = BigBossAccessibilityService.instance
            val ruleEngine = RuleEngine(object : com.bigboss.app.engine.ActionExecutor {
                override fun execute(action: com.bigboss.app.engine.Action) {
                    executor?.execute(action)
                }
            })
            ruleEngine.paused = true // EDIT MODE: sisteme asla dokunulmaz
            ruleEngine.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
            ScreenCaptureService.ruleEngine = ruleEngine

            com.bigboss.app.engine.ScriptRuntime.engine = com.bigboss.app.engine.ScriptEngine(
                executor = object : com.bigboss.app.engine.ActionExecutor {
                    override fun execute(action: com.bigboss.app.engine.Action) { executor?.execute(action) }
                },
                frameProvider = { ScreenCaptureService.latestFrame },
                functionByName = { name ->
                    FunctionStorage.load(this).find { it.name == name }
                        ?.let { RuleDefinitionMapper.toRules(it.rules) } ?: emptyList()
                },
                runRuleList = { rulesToRun, frame -> ruleEngine.evaluateRulesOnce(rulesToRun, frame) },
                pausedProvider = { true } // Edit Mode'da script'ler asla gerçek dokunuş yapamaz
            )

            val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(captureIntent)

            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "EDIT")
            })

            binding.tvEditStatus.text = "Hazır! Şimdi oyuna geç — ekranın üstünde küçük bir ✏️ simge duracak, ondan \"Alan Ekle\" ile kural ekleyebilirsin."
        } else if (requestCode == REQUEST_CODE_CAPTURE) {
            binding.tvEditStatus.text = "İzin verilmedi — ekran görüntüsü olmadan alan çizemezsin."
        } else if (requestCode == REQUEST_CODE_GALLERY_PICK && resultCode == RESULT_OK && data?.data != null) {
            handleGalleryImagePicked(data.data!!)
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Edit Mode'dan çık")
            .setMessage("Tüm değişiklikler zaten kaydedildi. Edit Mode'dan çıkmak istiyor musun?")
            .setPositiveButton("Evet, çık") { _, _ ->
                stopService(Intent(this, ScreenCaptureService::class.java))
                stopService(Intent(this, OverlayService::class.java))
                finish()
            }
            .setNegativeButton("Hayır, devam et", null)
            .show()
    }

    // ---- Sekme mantığı ----

    private fun switchTab(tab: Tab) {
        currentTab = tab
        when (tab) {
            Tab.MAIN_FLOW -> {
                binding.rvRules.adapter = rulesAdapter
                binding.btnAddToTab.text = "🖼️👆 Aksiyon Ekle"
            }
            Tab.FUNCTIONS -> {
                binding.rvRules.adapter = functionsAdapter
                binding.btnAddToTab.text = "➕ Yeni Fonksiyon"
            }
            Tab.SCRIPTS -> {
                binding.rvRules.adapter = scriptsAdapter
                binding.btnAddToTab.text = "➕ Yeni Script"
            }
        }
        refreshCurrentList()
    }

    private fun refreshCurrentList() {
        when (currentTab) {
            Tab.MAIN_FLOW -> rulesAdapter.submitList(RuleStorage.load(this))
            Tab.FUNCTIONS -> functionsAdapter.submitList(FunctionStorage.load(this))
            Tab.SCRIPTS -> scriptsAdapter.submitList(com.bigboss.app.storage.ScriptStorage.load(this))
        }
    }

    private fun onAddPressed() {
        when (currentTab) {
            Tab.MAIN_FLOW -> openEditor(null)
            Tab.FUNCTIONS -> createNewFunction()
            Tab.SCRIPTS -> startActivity(Intent(this, ScriptEditorActivity::class.java))
        }
    }

    // ---- Ana Akış ----

    private fun onRuleToggled(rule: RuleDefinition, checked: Boolean) {
        rule.enabled = checked
        RuleStorage.upsert(this, rule)
    }

    private fun onRuleDeleted(rule: RuleDefinition) {
        RuleStorage.deleteRule(this, rule.id)
        refreshCurrentList()
    }

    private fun openEditor(ruleId: String?, functionId: String? = null) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Ekran görüntüsü henüz hazır değil, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RuleEditorActivity::class.java)
        if (ruleId != null) intent.putExtra(RuleEditorActivity.EXTRA_EDIT_RULE_ID, ruleId)
        if (functionId != null) intent.putExtra(RuleEditorActivity.EXTRA_FUNCTION_ID, functionId)
        startActivity(intent)
    }

    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Ekran görüntüsü henüz hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        AlertDialog.Builder(this)
            .setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()}  (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null)
            .show()
    }

    // ---- Fonksiyonlar ----

    private fun createNewFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı (örn. doBattle)" }
        AlertDialog.Builder(this)
            .setTitle("Yeni Fonksiyon")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
                refreshCurrentList()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun openFunction(fn: FunctionDefinition) {
        val labels = fn.rules.mapIndexed { i, r -> "${i + 1}. ${r.name}" }.toTypedArray()
        val builder = AlertDialog.Builder(this)
            .setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setPositiveButton("➕ Kural Ekle") { _, _ -> openEditor(null, fn.id) }
            .setNegativeButton("Kapat", null)
        if (labels.isNotEmpty()) {
            builder.setItems(labels) { _, index ->
                val rule = fn.rules[index]
                AlertDialog.Builder(this)
                    .setTitle(rule.name)
                    .setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                        if (action == 0) openEditor(rule.id, fn.id)
                        else { FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id); refreshCurrentList() }
                    }
                    .show()
            }
        } else {
            builder.setMessage("Bu fonksiyonda henüz kural yok. \"➕ Kural Ekle\" ile başla.")
        }
        builder.show()
    }

    private fun deleteFunction(fn: FunctionDefinition) {
        AlertDialog.Builder(this)
            .setTitle(fn.name)
            .setMessage("Bu fonksiyonu silmek istediğine emin misin? Onu çağıran kurallar artık çalışmaz.")
            .setPositiveButton("Sil") { _, _ -> FunctionStorage.delete(this, fn.id); refreshCurrentList() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    // ---- Kütüphane ----

    private fun showLibraryDialog() {
        val items = LibraryStorage.load(this)
        val options = mutableListOf("📷 Ekrandan Kırp", "➕ Galeriden Resim Ekle")
        options.addAll(items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" })
        AlertDialog.Builder(this)
            .setTitle("Kütüphanem (${items.size})")
            .setItems(options.toTypedArray()) { _, index ->
                when (index) {
                    0 -> {
                        if (ScreenCaptureService.latestFrame == null) {
                            Toast.makeText(this, "Ekran görüntüsü henüz hazır değil, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
                        } else {
                            startActivity(Intent(this, LibraryCaptureActivity::class.java))
                        }
                    }
                    1 -> pickImageFromGallery()
                    else -> showLibraryItemOptions(items[index - 2])
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(intent, REQUEST_CODE_GALLERY_PICK)
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, index ->
                when (options[index]) {
                    "↻ 90° Döndür" -> rotateLibraryImage(item)
                    "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                    "🗑 Sil" -> confirmDeleteLibraryItem(item)
                }
            }
            .show()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Döndürüldü: ${item.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Döndürme başarısız: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        AlertDialog.Builder(this)
            .setTitle("Yeniden adlandır")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun confirmDeleteLibraryItem(item: LibraryItem) {
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("Bu öğeyi kütüphaneden silmek ister misin?")
            .setPositiveButton("Sil") { _, _ -> LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun handleGalleryImagePicked(uri: android.net.Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val bitmap = android.graphics.BitmapFactory.decodeStream(input)
            input.close()
            if (bitmap == null) {
                Toast.makeText(this, "Görsel okunamadı", Toast.LENGTH_SHORT).show()
                return
            }
            val path = TemplateStorage.save(this, bitmap)
            val nameInput = EditText(this).apply { hint = "Kütüphanedeki adı (örn. Potion İkonu)" }
            AlertDialog.Builder(this)
                .setTitle("Galeriden Eklendi")
                .setView(nameInput)
                .setPositiveButton("Kaydet") { _, _ ->
                    val name = nameInput.text.toString().ifBlank { "İsimsiz görsel" }
                    LibraryStorage.add(this, LibraryItem(UUID.randomUUID().toString(), name, "IMAGE", 0, path))
                    Toast.makeText(this, "Kütüphaneye eklendi: $name", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Vazgeç", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "Görsel yüklenemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 61
        private const val REQUEST_CODE_GALLERY_PICK = 62
    }
}
