package com.bigboss.app.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityEditModeBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

/**
 * EDIT MODE artık TAM EKRAN bir sayfa DEĞİL — sadece izinleri alıp
 * "✏️ Düzenleme" overlay'ini başlatır, sonra HEMEN kapanır (finish).
 * Bundan sonra HER ŞEY o küçük overlay simgesinden yönetiliyor —
 * Macrorify'daki gibi, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 */
class EditModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditModeBinding
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditModeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        projectionManager = getSystemService(MediaProjectionManager::class.java)

        if (ScreenCaptureService.latestFrame != null) {
            // Zaten çalışıyor — sadece overlay'i EDIT moduna al ve çık.
            ScreenCaptureService.ruleEngine?.paused = true
            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "EDIT")
            })
            finish()
            return
        }

        binding.tvEditStatus.text = "Ekran kaydı izni isteniyor..."
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CODE_CAPTURE) return
        if (data == null) { finish(); return }

        val executor = BigBossAccessibilityService.instance
        val ruleEngine = RuleEngine(object : com.bigboss.app.engine.ActionExecutor {
            override fun execute(action: com.bigboss.app.engine.Action) { executor?.execute(action) }
        })
        ruleEngine.paused = true // EDIT MODE: sisteme asla dokunulmaz
        ruleEngine.setRules(com.bigboss.app.storage.EngineAssembler.buildRules(this))
        ruleEngine.setFunctionsProvider(com.bigboss.app.storage.EngineAssembler.buildFunctionsProvider(this))
        ScreenCaptureService.ruleEngine = ruleEngine

        com.bigboss.app.engine.ScriptRuntime.engine = com.bigboss.app.engine.ScriptEngine(
            executor = object : com.bigboss.app.engine.ActionExecutor {
                override fun execute(action: com.bigboss.app.engine.Action) { executor?.execute(action) }
            },
            frameProvider = { ScreenCaptureService.latestFrame },
            functionByName = { name ->
                FunctionStorage.load(this).find { it.name == name }
                    ?.let { RuleDefinitionMapper.toRules(it.rules) } ?: emptyList()
            },
            runRuleList = { rulesToRun, frame -> ruleEngine.evaluateRulesOnce(rulesToRun, frame) },
            pausedProvider = { true }
        )

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(captureIntent)

        startService(Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_MODE, "EDIT")
        })

        // Kritik: hemen kapanıyoruz. Kullanıcı artık istediği uygulamaya
        // geçebilir, küçük ✏️ simgeden tüm işlemleri yapabilir.
        finish()
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 61
    }
}
