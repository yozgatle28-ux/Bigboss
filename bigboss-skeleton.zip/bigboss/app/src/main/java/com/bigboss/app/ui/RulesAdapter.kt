package com.bigboss.app.ui

import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bigboss.app.databinding.ItemRuleBinding
import com.bigboss.app.storage.RuleDefinition

class RulesAdapter(
    private val onToggle: (RuleDefinition, Boolean) -> Unit,
    private val onDelete: (RuleDefinition) -> Unit,
    private val onEdit: (RuleDefinition) -> Unit,
    private val onTest: (RuleDefinition) -> Unit
) : RecyclerView.Adapter<RulesAdapter.RuleViewHolder>() {

    private val items = mutableListOf<RuleDefinition>()

    fun submitList(newItems: List<RuleDefinition>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class RuleViewHolder(val binding: ItemRuleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RuleViewHolder {
        val binding = ItemRuleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RuleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RuleViewHolder, position: Int) {
        val rule = items[position]
        val typeLabel = if (rule.actionType == "SWIPE") "↔ Swipe" else "👆 Tap"
        val kindLabel = if (rule.conditionKind == "IMAGE") "🖼️ Resim" else "🎨 Renk"
        holder.binding.tvRuleName.text = "${position + 1}. ${rule.name}"
        holder.binding.tvRuleSubtitle.text =
            "$kindLabel · Min Score %${rule.minScore} · Süre ${if (rule.timeoutMs < 0) "sınırsız" else "${rule.timeoutMs}ms"} · $typeLabel"

        holder.binding.cbEnabled.setOnCheckedChangeListener(null)
        holder.binding.cbEnabled.isChecked = rule.enabled

        if (rule.conditionKind == "IMAGE" && !rule.templatePath.isNullOrBlank()) {
            val bmp = BitmapFactory.decodeFile(rule.templatePath)
            if (bmp != null) holder.binding.ivPreview.setImageBitmap(bmp)
            else holder.binding.ivPreview.setImageDrawable(ColorDrawable(rule.condColor))
        } else {
            holder.binding.ivPreview.setImageDrawable(ColorDrawable(rule.condColor))
        }

        holder.binding.cbEnabled.setOnCheckedChangeListener { _, isChecked -> onToggle(rule, isChecked) }
        holder.binding.btnDelete.setOnClickListener { onDelete(rule) }
        holder.binding.btnEdit.setOnClickListener { onEdit(rule) }
        holder.binding.btnTest.setOnClickListener { onTest(rule) }
    }

    override fun getItemCount(): Int = items.size
}
