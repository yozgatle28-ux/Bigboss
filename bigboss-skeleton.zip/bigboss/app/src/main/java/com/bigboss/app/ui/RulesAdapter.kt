package com.bigboss.app.ui

import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bigboss.app.databinding.ItemRuleBinding
import com.bigboss.app.storage.RuleDefinition

class RulesAdapter(
    private val onToggle: (RuleDefinition, Boolean) -> Unit,
    private val onDelete: (RuleDefinition) -> Unit,
    private val onEdit: (RuleDefinition) -> Unit,
    private val onTest: (RuleDefinition) -> Unit
) : RecyclerView.Adapter<RulesAdapter.RuleViewHolder>() {

    private val items = mutableListOf<RuleDefinition>()

    fun submitList(newItems: List<RuleDefinition>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class RuleViewHolder(val binding: ItemRuleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RuleViewHolder {
        val binding = ItemRuleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RuleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RuleViewHolder, position: Int) {
        val rule = items[position]
        val first = rule.alternatives.firstOrNull()
        val typeLabel = if (rule.actionType == "SWIPE") "↔ Swipe" else "👆 Tap"
        val altCount = rule.alternatives.size
        val kindLabel = when {
            altCount > 1 -> "🔀 ${altCount} alternatif (VEYA)"
            first?.conditionKind == "IMAGE" -> "🖼️ Resim"
            first?.conditionKind == "TEXT" -> "📝 Yazı"
            else -> "🎨 Renk"
        }
        val groupTag = rule.groupName?.let { "[$it] " } ?: ""

        holder.binding.tvRuleName.text = "${position + 1}. $groupTag${rule.name}"

        val subtitleParts = mutableListOf(
            kindLabel,
            "Süre ${if (rule.timeoutMs < 0) "sınırsız" else "${rule.timeoutMs}ms"}",
            typeLabel
        )
        if (!rule.requireVariableName.isNullOrBlank()) {
            subtitleParts.add("Şart: ${rule.requireVariableName} ${rule.requireVariableOp} ${rule.requireVariableValue}")
        }
        if (!rule.incrementVariableName.isNullOrBlank()) {
            subtitleParts.add("Sayaç: ${rule.incrementVariableName} +${rule.incrementVariableDelta}")
        }
        holder.binding.tvRuleSubtitle.text = subtitleParts.joinToString(" · ")

        holder.binding.cbEnabled.setOnCheckedChangeListener(null)
        holder.binding.cbEnabled.isChecked = rule.enabled

        when {
            first?.conditionKind == "IMAGE" && !first.templatePath.isNullOrBlank() -> {
                val bmp = BitmapFactory.decodeFile(first.templatePath)
                if (bmp != null) holder.binding.ivPreview.setImageBitmap(bmp)
                else holder.binding.ivPreview.setImageDrawable(ColorDrawable(android.graphics.Color.DKGRAY))
            }
            first?.conditionKind == "TEXT" -> {
                holder.binding.ivPreview.setImageDrawable(ColorDrawable(android.graphics.Color.DKGRAY))
            }
            else -> holder.binding.ivPreview.setImageDrawable(ColorDrawable(first?.color ?: 0))
        }

        holder.binding.cbEnabled.setOnCheckedChangeListener { _, isChecked -> onToggle(rule, isChecked) }
        holder.binding.btnDelete.setOnClickListener { onDelete(rule) }
        holder.binding.btnEdit.setOnClickListener { onEdit(rule) }
        holder.binding.btnTest.setOnClickListener { onTest(rule) }
    }

    override fun getItemCount(): Int = items.size
}
