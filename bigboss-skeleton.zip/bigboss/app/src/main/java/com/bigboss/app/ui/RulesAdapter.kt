package com.bigboss.app.ui

import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bigboss.app.databinding.ItemRuleBinding
import com.bigboss.app.storage.RuleDefinition

class RulesAdapter(
    private val onToggle: (RuleDefinition, Boolean) -> Unit,
    private val onDelete: (RuleDefinition) -> Unit
) : RecyclerView.Adapter<RulesAdapter.RuleViewHolder>() {

    private val items = mutableListOf<RuleDefinition>()

    fun submitList(newItems: List<RuleDefinition>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class RuleViewHolder(val binding: ItemRuleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RuleViewHolder {
        val binding = ItemRuleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RuleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RuleViewHolder, position: Int) {
        val rule = items[position]
        holder.binding.tvRuleName.text = rule.name
        holder.binding.cbEnabled.setOnCheckedChangeListener(null)
        holder.binding.cbEnabled.isChecked = rule.enabled
        holder.binding.colorSwatch.background = ColorDrawable(rule.condColor)

        holder.binding.cbEnabled.setOnCheckedChangeListener { _, isChecked ->
            onToggle(rule, isChecked)
        }
        holder.binding.btnDelete.setOnClickListener { onDelete(rule) }
    }

    override fun getItemCount(): Int = items.size
}
