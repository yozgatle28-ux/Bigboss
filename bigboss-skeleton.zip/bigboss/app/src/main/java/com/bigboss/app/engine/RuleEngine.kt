package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

/**
 * Gerçek dokunuş/kaydırma olaylarını cihaza uygulayan katman.
 * Gerçek implementasyonu BigBossAccessibilityService içinde olacak.
 */
interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify tarzı SIRALI SENARYO motoru.
 *
 * Kural listesindeki her adım, kendi timeoutMs'i kadar aktif olarak aranır:
 *  - Koşul eşleşirse (ya da negate=true ise KAYBOLURSA / eşleşmezse) ->
 *    aksiyon çalışır. loopMode'a göre ya aynı kuralda kalınıp tekrar
 *    denenir ya da bir sonraki adıma geçilir.
 *  - Süre dolarsa (timeoutMs >= 0) -> loopMode'a göre tekrar denenir ya
 *    da eşleşmeden bir sonraki adıma geçilir.
 *  - timeoutMs = -1 ise -> eşleşene kadar bu adımda süresiz beklenir.
 * Liste sonuna gelince başa dönülür (döngü).
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private var rules: List<Rule> = emptyList()
    private var currentIndex = 0
    private var stepStartTime = 0L
    private var loopIteration = 0

    /**
     * Macrorify'daki Edit Mode / Play Mode ayrımı: true iken (Edit Mode)
     * motor frame'leri görür ama hiçbir aksiyon çalıştırmaz — böylece
     * kural eklerken/düzenlerken botun yanlışlıkla dokunması engellenir.
     * Play Mode'a geçince false yapılır ve motor gerçekten çalışmaya başlar.
     */
    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        rules = newRules
        currentIndex = 0
        stepStartTime = 0L
        loopIteration = 0
    }

    /** Yeni bir ekran görüntüsü (frame) geldiğinde çağrılır. */
    fun onFrame(frame: Bitmap) {
        if (paused) return
        if (rules.isEmpty()) return
        if (currentIndex >= rules.size) currentIndex = 0

        val rule = rules[currentIndex]
        if (!rule.enabled) {
            advance()
            return
        }

        if (stepStartTime == 0L) stepStartTime = System.currentTimeMillis()

        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        // negate=true -> "Wait till vanish": koşul EŞLEŞMEYİNCE başarı sayılır
        val success = if (rule.negate) !conditionMatched else conditionMatched

        if (success) {
            executor.execute(rule.thenAction)
            handleAfterSuccess(rule)
            return
        }

        val elapsed = System.currentTimeMillis() - stepStartTime
        if (rule.timeoutMs >= 0 && elapsed >= rule.timeoutMs) {
            handleAfterTimeout(rule)
        }
        // aksi halde bu adımda beklemeye devam
    }

    private fun handleAfterSuccess(rule: Rule) {
        val shouldLoop = rule.loopMode == "WHILE_SUCCESS" || rule.loopMode == "ALWAYS"
        if (shouldLoop && !loopLimitReached(rule)) {
            loopIteration++
            stepStartTime = 0L // aynı kuralda kal, süreyi sıfırla
        } else {
            advance()
        }
    }

    private fun handleAfterTimeout(rule: Rule) {
        val shouldLoop = rule.loopMode == "WHILE_FAIL" || rule.loopMode == "ALWAYS"
        if (shouldLoop && !loopLimitReached(rule)) {
            loopIteration++
            stepStartTime = 0L
        } else {
            advance()
        }
    }

    private fun loopLimitReached(rule: Rule): Boolean =
        rule.maxLoopCount > 0 && loopIteration >= rule.maxLoopCount

    private fun advance() {
        currentIndex = (currentIndex + 1) % rules.size
        stepStartTime = 0L
        loopIteration = 0
    }
}
