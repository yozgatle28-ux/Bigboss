package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

/**
 * Gerçek dokunuş/kaydırma olaylarını cihaza uygulayan katman.
 * Gerçek implementasyonu BigBossAccessibilityService içinde olacak.
 */
interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify tarzı SIRALI SENARYO motoru.
 *
 * Kural listesindeki her adım, kendi timeoutMs'i kadar aktif olarak aranır:
 *  - Koşul eşleşirse -> aksiyon çalışır, bir sonraki adıma geçilir.
 *  - Süre dolarsa (timeoutMs >= 0) -> eşleşmeden bir sonraki adıma geçilir.
 *  - timeoutMs = -1 ise -> eşleşene kadar bu adımda süresiz beklenir.
 * Liste sonuna gelince başa dönülür (döngü).
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private var rules: List<Rule> = emptyList()
    private var currentIndex = 0
    private var stepStartTime = 0L

    fun setRules(newRules: List<Rule>) {
        rules = newRules
        currentIndex = 0
        stepStartTime = 0L
    }

    /** Yeni bir ekran görüntüsü (frame) geldiğinde çağrılır. */
    fun onFrame(frame: Bitmap) {
        if (rules.isEmpty()) return
        if (currentIndex >= rules.size) currentIndex = 0

        val rule = rules[currentIndex]
        if (!rule.enabled) {
            advance()
            return
        }

        if (stepStartTime == 0L) stepStartTime = System.currentTimeMillis()

        val matched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }

        if (matched) {
            executor.execute(rule.thenAction)
            advance()
            return
        }

        val elapsed = System.currentTimeMillis() - stepStartTime
        if (rule.timeoutMs >= 0 && elapsed >= rule.timeoutMs) {
            advance() // süre doldu, eşleşmeden bir sonrakine geç
        }
        // aksi halde bu adımda beklemeye devam
    }

    private fun advance() {
        currentIndex = (currentIndex + 1) % rules.size
        stepStartTime = 0L
    }
}
