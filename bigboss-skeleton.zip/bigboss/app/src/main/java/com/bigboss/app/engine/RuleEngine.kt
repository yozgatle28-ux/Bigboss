package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

/**
 * Gerçek dokunuş/kaydırma olaylarını cihaza uygulayan katman.
 * Gerçek implementasyonu BigBossAccessibilityService içinde olacak.
 */
interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Kullanıcının tanımladığı kural listesini her "tick" te (yeni ekran görüntüsü
 * geldiğinde) sırayla değerlendirir. Her üst-seviye Rule, kendi elseIf
 * zincirini kendi içinde dolaşır; zincirdeki ilk true olan koşulun
 * aksiyonunu çalıştırıp bir sonraki tick'e geçer.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private val rules = mutableListOf<Rule>()

    fun setRules(newRules: List<Rule>) {
        rules.clear()
        rules.addAll(newRules)
    }

    fun addRule(rule: Rule) {
        rules.add(rule)
    }

    /** Yeni bir ekran görüntüsü (frame) geldiğinde çağrılır. */
    fun onFrame(frame: Bitmap) {
        for (rule in rules) {
            if (!rule.enabled) continue
            val matched = evaluateChain(rule, frame)
            if (matched) {
                // Bir kural tetiklendiyse diğer üst-seviye kuralları bu tick'te atla.
                // (İstersen bu davranışı değiştirip hepsini çalıştırabiliriz.)
                break
            }
        }
    }

    /**
     * Bir kuralın kendi elseIf zincirini dolaşır.
     * İlk koşulu true olan düğümün aksiyonunu çalıştırır.
     * Hiçbiri true değilse false döner (bu üst-seviye kural hiç tetiklenmemiş demektir).
     */
    private fun evaluateChain(rule: Rule, frame: Bitmap): Boolean {
        var current: Rule? = rule
        while (current != null) {
            val isMatch = try {
                current.condition.evaluate(frame)
            } catch (e: Exception) {
                Log.e("RuleEngine", "Koşul değerlendirme hatası: ${current.id}", e)
                false
            }
            if (isMatch) {
                executor.execute(current.thenAction)
                return true
            }
            current = current.elseIf
        }
        return false
    }
}
