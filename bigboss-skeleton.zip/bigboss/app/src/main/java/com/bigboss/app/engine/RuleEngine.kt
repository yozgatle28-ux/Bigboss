package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify'ın GERÇEK motor mantığı: PARALEL / REAKTİF, artık "Loop"
 * yaşam döngüsü de destekleniyor:
 *
 *  - NONE: kural bir kere denenir (başarılı olsun olmasın), sonra
 *    kendini devre dışı bırakır ("tarar ve durur").
 *  - ALWAYS: normal sürekli davranış — sonsuz döngü, hiç durmaz.
 *  - WHILE_SUCCESS: koşul doğru olana kadar bekler, doğru olunca BİR
 *    KERE tetiklenir ve kendini durdurur.
 *  - WHILE_FAIL: koşul doğru olduğu sürece tetiklenmeye devam eder;
 *    koşul YANLIŞA dönünce (kaybolunca) kendini durdurur.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private var rules: List<Rule> = emptyList()
    private var functionsProvider: (String) -> List<Rule> = { emptyList() }

    /** "NONE/WHILE_SUCCESS/WHILE_FAIL" ömrünü tamamlamış kural id'leri — bir daha kontrol edilmez. */
    private val completedRuleIds = mutableSetOf<String>()
    /** WHILE_FAIL için: bu kural en az bir kez başarılı oldu mu (kaybolma anını tespit etmek için). */
    private val everSucceededIds = mutableSetOf<String>()

    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        rules = newRules
        completedRuleIds.clear()
        everSucceededIds.clear()
    }

    /** "Stop" butonu için: NONE/WHILE_SUCCESS/WHILE_FAIL kurallarının "bitti" durumunu sıfırlar — bir sonraki Play baştan başlar. */
    fun resetLoopState() {
        completedRuleIds.clear()
        everSucceededIds.clear()
        ActionResultRegistry.reset()
    }

    fun setFunctionsProvider(provider: (String) -> List<Rule>) {
        functionsProvider = provider
    }

    fun lastFiredAt(ruleId: String): Long? = ActionResultRegistry.lastFiredAt(ruleId)

    fun onFrame(frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rules) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    fun evaluateRulesOnce(rulesToRun: List<Rule>, frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rulesToRun) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    private fun evaluateAndMaybeFire(rule: Rule, frame: Bitmap, now: Long) {
        if (rule.id in completedRuleIds) return

        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        val success = if (rule.negate) !conditionMatched else conditionMatched

        when (rule.loopMode) {
            "NONE" -> {
                if (success) fireWithDelay(rule, frame, now)
                completedRuleIds.add(rule.id) // ne olursa olsun tek seferlik
                return
            }
            "WHILE_SUCCESS" -> {
                if (!success) return
                val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - last < rule.cooldownMs) return
                fireWithDelay(rule, frame, now)
                completedRuleIds.add(rule.id) // yakaladı, bir kere ateşle, bitir
                return
            }
            "WHILE_FAIL" -> {
                if (success) {
                    everSucceededIds.add(rule.id)
                    val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                    if (now - last < rule.cooldownMs) return
                    fireWithDelay(rule, frame, now)
                } else if (rule.id in everSucceededIds) {
                    completedRuleIds.add(rule.id) // daha önce vardı, şimdi kayboldu -> bitir
                }
                return
            }
            else -> { // "ALWAYS" (varsayılan, sürekli)
                if (!success) return
                val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - last < rule.cooldownMs) return
                fireWithDelay(rule, frame, now)
            }
        }
    }

    private fun fireWithDelay(rule: Rule, frame: Bitmap, now: Long) {
        ActionResultRegistry.markFired(rule.id)
        if (rule.matchDelayMs > 0) Thread.sleep(rule.matchDelayMs)
        fireAction(rule, rule.thenAction, frame, now)
    }

    private fun fireAction(rule: Rule, action: Action, frame: Bitmap, now: Long) {
        val callAction = extractCallFunction(action)
        if (callAction != null) {
            if (action is Action.Sequence) {
                action.steps.filter { it !is Action.CallFunction }.forEach { resolveAndExecute(rule, it, frame) }
            }
            val funcRules = functionsProvider(callAction.functionId)
            repeat(callAction.repeat.coerceAtLeast(1)) {
                for (funcRule in funcRules) {
                    if (!funcRule.enabled) continue
                    evaluateAndMaybeFire(funcRule, frame, now)
                }
            }
        } else {
            resolveAndExecute(rule, action, frame)
        }
    }

    /** Action.TapAtMatch gibi "koşula bağlı" aksiyonları somut koordinata çevirip çalıştırır. */
    private fun resolveAndExecute(rule: Rule, action: Action, frame: Bitmap) {
        when (action) {
            is Action.TapAtMatch -> {
                val loc = rule.condition.matchLocation(frame)
                if (loc != null) executor.execute(Action.Tap(loc.first, loc.second, action.repeat))
            }
            is Action.Sequence -> action.steps.forEach { resolveAndExecute(rule, it, frame) }
            else -> executor.execute(action)
        }
    }

    private fun extractCallFunction(action: Action): Action.CallFunction? = when (action) {
        is Action.CallFunction -> action
        is Action.Sequence -> action.steps.filterIsInstance<Action.CallFunction>().firstOrNull()
        else -> null
    }
}
