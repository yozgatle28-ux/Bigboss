package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

/**
 * Gerçek dokunuş/kaydırma olaylarını cihaza uygulayan katman.
 * Gerçek implementasyonu BigBossAccessibilityService içinde olacak.
 */
interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify'ın GERÇEK motor mantığı: PARALEL / REAKTİF.
 *
 * Her frame'de TÜM kurallar bağımsız olarak kontrol edilir (sıra yok,
 * "sıradaki kural" diye bir kavram yok). Koşulu doğru olan HER kuralın
 * aksiyonu tetiklenir (kendi cooldown'u izin veriyorsa). Bir kuralın
 * koşulu ekranda ne kadar süre doğru kalırsa, o kural o kadar süre
 * (cooldown aralıklarıyla) tetiklenmeye devam eder — "React to the
 * screen" mantığı.
 *
 * Sıra gerekiyorsa (örn. "önce A, sonra B") Macrorify'ın kullandığı
 * yöntem: Condition.ActionResult ile bir kuralın diğerinin yakın
 * zamanda tetiklenip tetiklenmediğini şart koşmak.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private var rules: List<Rule> = emptyList()
    private var functionsProvider: (String) -> List<Rule> = { emptyList() }

    /** Macrorify'daki Edit Mode / Play Mode ayrımı: true iken motor hiçbir aksiyon çalıştırmaz. */
    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        rules = newRules
    }

    fun setFunctionsProvider(provider: (String) -> List<Rule>) {
        functionsProvider = provider
    }

    /** Bir kuralın en son ne zaman (ms) tetiklendiğini döner, hiç tetiklenmediyse null. */
    fun lastFiredAt(ruleId: String): Long? = ActionResultRegistry.lastFiredAt(ruleId)

    fun onFrame(frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rules) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    /** Script sistemindeki callFunction() köprüsü için: bir kural listesini bir kere değerlendirir. */
    fun evaluateRulesOnce(rulesToRun: List<Rule>, frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rulesToRun) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    private fun evaluateAndMaybeFire(rule: Rule, frame: Bitmap, now: Long) {
        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        val success = if (rule.negate) !conditionMatched else conditionMatched
        if (!success) return

        val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
        if (now - last < rule.cooldownMs) return // cooldown dolmadı, tetiklenmez

        ActionResultRegistry.markFired(rule.id)
        fireAction(rule.thenAction, frame, now)
    }

    private fun fireAction(action: Action, frame: Bitmap, now: Long) {
        val callAction = extractCallFunction(action)
        if (callAction != null) {
            if (action is Action.Sequence) {
                action.steps.filter { it !is Action.CallFunction }.forEach { executor.execute(it) }
            }
            val funcRules = functionsProvider(callAction.functionId)
            // Reaktif model: fonksiyonun kurallarını AYNI frame'e karşı, repeat kadar tur çalıştır.
            repeat(callAction.repeat.coerceAtLeast(1)) {
                for (funcRule in funcRules) {
                    if (!funcRule.enabled) continue
                    evaluateAndMaybeFire(funcRule, frame, now)
                }
            }
        } else {
            executor.execute(action)
        }
    }

    private fun extractCallFunction(action: Action): Action.CallFunction? = when (action) {
        is Action.CallFunction -> action
        is Action.Sequence -> action.steps.filterIsInstance<Action.CallFunction>().firstOrNull()
        else -> null
    }
}
