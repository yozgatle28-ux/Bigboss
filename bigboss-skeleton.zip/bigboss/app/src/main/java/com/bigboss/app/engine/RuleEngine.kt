package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

/**
 * Gerçek dokunuş/kaydırma olaylarını cihaza uygulayan katman.
 * Gerçek implementasyonu BigBossAccessibilityService içinde olacak.
 */
interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify tarzı SIRALI SENARYO motoru — artık FONKSİYON ÇAĞRISINI da
 * destekliyor (bir çağrı yığını / call stack ile).
 *
 * - Ana akış (Home) sürekli döner (bitince başa sarar).
 * - Bir kuralın aksiyonu "Fonksiyon Çağır" ise, o fonksiyonun kural
 *   listesi yığına eklenir (push) ve motor o listeyi çalıştırmaya başlar.
 * - Fonksiyon kendi listesini (repeat sayısı kadar) bitirince yığından
 *   çıkar (pop) ve ana akış, çağıran kuraldan SONRAKİ adımdan devam eder.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    private class Frame(val rules: List<Rule>) {
        var index = 0
        var stepStart = 0L
        var loopIter = 0
        var repeatsLeft = 1
    }

    private var mainRules: List<Rule> = emptyList()
    private val stack = mutableListOf<Frame>()
    private var functionsProvider: (String) -> List<Rule> = { emptyList() }

    /** Macrorify'daki Edit Mode / Play Mode ayrımı: true iken motor hiçbir aksiyon çalıştırmaz. */
    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        mainRules = newRules
        stack.clear()
        stack.add(Frame(mainRules))
    }

    /** MainActivity botu başlatırken, fonksiyon id -> o fonksiyonun Rule listesini döndüren bir sağlayıcı verir. */
    fun setFunctionsProvider(provider: (String) -> List<Rule>) {
        functionsProvider = provider
    }

    fun onFrame(frame: Bitmap) {
        if (paused) return
        if (stack.isEmpty()) return
        val top = stack.last()
        if (top.rules.isEmpty()) return
        if (top.index >= top.rules.size) top.index = 0

        val rule = top.rules[top.index]
        if (!rule.enabled) {
            advance(top, rule, viaTimeout = false, skip = true)
            return
        }

        if (top.stepStart == 0L) top.stepStart = System.currentTimeMillis()

        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        val success = if (rule.negate) !conditionMatched else conditionMatched

        if (success) {
            val action = rule.thenAction
            val callAction = extractCallFunction(action)
            if (callAction != null) {
                // Fonksiyon dışındaki adımları (örn. sayaç artırma) hemen çalıştır
                if (action is Action.Sequence) {
                    action.steps.filter { it !is Action.CallFunction }.forEach { executor.execute(it) }
                }
                val funcRules = functionsProvider(callAction.functionId)
                if (funcRules.isNotEmpty()) {
                    val callFrame = Frame(funcRules).apply { repeatsLeft = callAction.repeat.coerceAtLeast(1) }
                    stack.add(callFrame)
                    // top (çağıran) burada İLERLEMEZ; callFrame pop olduğunda ilerletilecek.
                } else {
                    advance(top, rule, viaTimeout = false)
                }
            } else {
                executor.execute(action)
                advance(top, rule, viaTimeout = false)
            }
            return
        }

        val elapsed = System.currentTimeMillis() - top.stepStart
        if (rule.timeoutMs >= 0 && elapsed >= rule.timeoutMs) {
            advance(top, rule, viaTimeout = true)
        }
    }

    private fun extractCallFunction(action: Action): Action.CallFunction? = when (action) {
        is Action.CallFunction -> action
        is Action.Sequence -> action.steps.filterIsInstance<Action.CallFunction>().firstOrNull()
        else -> null
    }

    /**
     * Bir kuralın çalışmasından sonra sırayı ilerletir. Loop (tekrar) mantığını
     * uygular; bir Frame'in tüm kuralları bitince (fonksiyon çağrısıysa) yığından
     * çıkarır ve çağıranı da bir adım ilerletir.
     */
    private fun advance(frame: Frame, rule: Rule, viaTimeout: Boolean, skip: Boolean = false) {
        if (!skip) {
            val shouldLoop = if (viaTimeout) {
                rule.loopMode == "WHILE_FAIL" || rule.loopMode == "ALWAYS"
            } else {
                rule.loopMode == "WHILE_SUCCESS" || rule.loopMode == "ALWAYS"
            }
            val limitReached = rule.maxLoopCount > 0 && frame.loopIter >= rule.maxLoopCount
            if (shouldLoop && !limitReached) {
                frame.loopIter++
                frame.stepStart = 0L
                return
            }
        }

        frame.index++
        frame.stepStart = 0L
        frame.loopIter = 0

        if (frame.index >= frame.rules.size) {
            if (stack.size > 1 && stack.last() === frame) {
                // Bu bir fonksiyon çağrısı çerçevesiydi, bir tur tamamlandı.
                frame.repeatsLeft--
                if (frame.repeatsLeft > 0) {
                    frame.index = 0
                } else {
                    stack.removeAt(stack.size - 1)
                    val parent = stack.lastOrNull()
                    if (parent != null && parent.index < parent.rules.size) {
                        val callerRule = parent.rules[parent.index]
                        advance(parent, callerRule, viaTimeout = false, skip = true)
                    }
                }
            } else {
                frame.index = 0 // ana akış başa sarar
            }
        }
    }
}
