package com.bigboss.app.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.bigboss.app.model.Region
import org.mozilla.javascript.Context as RhinoContext
import org.mozilla.javascript.NativeObject
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject

/**
 * BigBoss'un "EMScript'ten ilham alan kod sistemi" — v2, GENİŞLETİLMİŞ KÜTÜPHANE.
 *
 * Macrorify'ın EMScript'i kendi yazdıkları, "barebone" (iskelet) bir dil —
 * biz bunun yerine saf-Java olan Rhino JavaScript motorunu gömüyoruz, bu
 * yüzden dilin KENDİSİ (değişken, if/else, for/while/do-while, fonksiyon,
 * class, array, obje, try/catch, closure...) zaten EMScript'ten daha güçlü,
 * GERÇEK JavaScript. Bu güncellemede eksik olan KÜTÜPHANE (bridge API)
 * tarafını EMScript'in Region/Point/Match/CParam ekosistemine yakın bir
 * zenginliğe getirdim.
 *
 * ---- Basit fonksiyonlar ----
 *   tap(x, y, opts?)     opts: {repeat, hold, delay, random}
 *   swipe(x1,y1,x2,y2, opts?)   opts: {duration, holdStart, holdEnd, delay, random}
 *   swipePath([{x,y,hold}, ...], durationMs?)   -- çok noktalı kaydırma
 *   wait(ms)
 *   back() / home() / recents() / notifications() / quickSettings()
 *   getVar(name) / setVar(name, value)                  -- sayı değişken (birleşik, kalıcı)
 *   getVarStr(name) / setVarStr(name, text)             -- metin (String) değişken
 *   getGlobalVar(name) / setGlobalVar(name, value)       -- getVar/setVar ile AYNI (geriye dönük)
 *   Setting.get(key) / Setting.show()                    -- özel ayar (Setting Builder) oku/göster
 *   colorAt(x, y) -> "#RRGGBB"
 *   randomInt(min, max)
 *   callFunction(functionName, repeat?)   -- tanımlı bir Fonksiyonu/Action Group'u çağırır
 *   runScript(scriptName)                 -- başka kayıtlı bir Script'i çalıştırır
 *   log(msg)
 *
 * ---- Region nesnesi (EMScript'teki Region class'ının karşılığı) ----
 *   var r = Region(x, y, w, h)
 *   r.findColor(hex, minScore?)          -> true/false
 *   r.findImage(libraryName, minScore?)  -> true/false  (KÜTÜPHANEDEKİ İSİMLE arar)
 *   r.findText(text, minScore?)          -> true/false
 *   r.findImageMatch(libraryName, minScore?) -> {found, x, y, score} ya da null
 *   r.tap(opts?)                          -- bölgenin ortasına dokunur
 *   r.center()                            -> {x, y}
 *
 * ---- Örnek ----
 *   var enemy = Region(100, 200, 300, 300)
 *   if (enemy.findImage("düşman")) {
 *       var m = enemy.findImageMatch("düşman")
 *       tap(m.x, m.y, {hold: 80})
 *       setVar("vurus", getVar("vurus") + 1)
 *   }
 */
class ScriptEngine(
    private val executor: ActionExecutor,
    private val frameProvider: () -> Bitmap?,
    private val functionByName: (String) -> List<Rule>,
    private val runRuleList: (List<Rule>, Bitmap) -> Unit,
    /** true iken (Edit Mode) script'in tap/swipe/sistem çağrıları GERÇEK dokunuşa çevrilmez — güvenlik. */
    private val pausedProvider: () -> Boolean = { false },
    /** Kütüphanedeki bir görselin İSMİNDEN dosya yolunu bulur (findImage("isim") için). */
    private val libraryLookup: (String) -> String? = { null },
    /** Kayıtlı bir Script'i İSMİNDEN bulup kodunu döner (runScript("isim") için). */
    private val scriptLookup: (String) -> String? = { null }
) {

    /** Setting.show() çağrılınca UI thread'de özel ayar diyaloğunu açan köprü (OverlayService kurar). */
    var settingShowRequester: (() -> Boolean)? = null

    /** Bir script'i bir kere çalıştırır. Hata olursa mesajı döner, olmazsa null. */
    fun run(code: String): String? {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1 // Android'de bytecode üretimi yerine yorumlanır (daha güvenli)
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            cx.evaluateString(scope, code, "bigboss-script", 1, null)
            null
        } catch (e: Exception) {
            Log.e("BigBossScript", "Script hatası", e)
            e.message ?: e.toString()
        } finally {
            RhinoContext.exit()
        }
    }

    /** Bir script'i KOŞUL olarak çalıştırır: son ifadenin/return'ün boolean'a çevrilmiş hâlini döner. */
    fun evaluateAsCondition(code: String): Boolean {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            val result = cx.evaluateString(scope, code, "bigboss-condition-script", 1, null)
            RhinoContext.toBoolean(result)
        } catch (e: Exception) {
            Log.e("BigBossScript", "Koşul script hatası", e)
            false
        } finally {
            RhinoContext.exit()
        }
    }

    /**
     * Bir ifadeyi (REFERENCE tipli değişkenler için) değerlendirip sonucu METİN olarak döner.
     * Örn. "getVar(\"a\") + 5" -> "15". Hata olursa null.
     */
    fun evaluateExpression(code: String): String? {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            val result = cx.evaluateString(scope, code, "bigboss-reference", 1, null)
            when (result) {
                null, RhinoContext.getUndefinedValue() -> null
                is Double -> if (result == Math.floor(result) && !result.isInfinite()) result.toLong().toString() else result.toString()
                else -> RhinoContext.toString(result)
            }
        } catch (e: Exception) {
            Log.e("BigBossScript", "Reference ifade hatası", e)
            null
        } finally {
            RhinoContext.exit()
        }
    }

    private fun bindBridgeFunctions(cx: RhinoContext, scope: Scriptable) {
        fun define(name: String, fn: (Array<Any?>) -> Any?) {
            val f = object : org.mozilla.javascript.BaseFunction() {
                override fun call(cx: RhinoContext?, scope: Scriptable?, thisObj: Scriptable?, args: Array<Any?>): Any {
                    return fn(args) ?: RhinoContext.getUndefinedValue()
                }
            }
            ScriptableObject.putProperty(scope, name, f)
        }

        fun num(v: Any?, default: Int = 0): Int = (v as? Number)?.toInt() ?: default
        fun long(v: Any?, default: Long = 0L): Long = (v as? Number)?.toLong() ?: default

        /** JS obje argümanından (örn. {repeat: 2, hold: 80}) bir alanı okur. */
        fun opt(args: Array<Any?>, index: Int, key: String): Any? {
            val obj = args.getOrNull(index) as? NativeObject ?: return null
            return if (obj.containsKey(key)) obj.get(key) else null
        }

        fun newObj(cx: RhinoContext, scope: Scriptable, fields: Map<String, Any?>): Scriptable {
            val o = cx.newObject(scope)
            fields.forEach { (k, v) -> ScriptableObject.putProperty(o, k, v) }
            return o
        }

        // ---- Dokunma / Kaydırma ----

        define("tap") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — tap() engellendi)"); return@define null }
            val x = num(args.getOrNull(0)); val y = num(args.getOrNull(1))
            val repeat = num(opt(args, 2, "repeat"), 1)
            val hold = long(opt(args, 2, "hold"), 50L)
            val delay = long(opt(args, 2, "delay"), 0L)
            val random = num(opt(args, 2, "random"), 0)
            executor.execute(Action.Tap(x, y, repeat.coerceAtLeast(1), hold.coerceAtLeast(1), delay, random))
            null
        }
        define("swipe") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — swipe() engellendi)"); return@define null }
            val x1 = num(args.getOrNull(0)); val y1 = num(args.getOrNull(1))
            val x2 = num(args.getOrNull(2)); val y2 = num(args.getOrNull(3))
            val duration = long(opt(args, 4, "duration"), 300L)
            val holdStart = long(opt(args, 4, "holdStart"), 0L)
            val holdEnd = long(opt(args, 4, "holdEnd"), 0L)
            val delay = long(opt(args, 4, "delay"), 0L)
            val random = num(opt(args, 4, "random"), 0)
            executor.execute(Action.Swipe(x1, y1, x2, y2, duration, holdStart, holdEnd, delay, random))
            null
        }
        define("swipePath") { args ->
            // EMScript'teki SwipePoint dizisiyle çoklu-nokta kaydırma: [{x,y,hold}, {x,y,hold}, ...]
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — swipePath() engellendi)"); return@define null }
            val points = args.getOrNull(0) as? org.mozilla.javascript.NativeArray ?: return@define null
            val durationEach = long(args.getOrNull(1), 300L)
            // Noktaları TEK bir MultiPointSwipe olarak topluyoruz: motorun continueStroke
            // zincirlemesi sayesinde parmak yerden HİÇ kalkmadan tüm noktalardan geçer
            // (eskiden her segment ayrı Action.Swipe idi; her segment arası parmak kalkıp
            // yeniden basıyordu — bu, sürükleme jestlerini bozuyordu).
            val defs = mutableListOf<Action.SwipePointDef>()
            for (i in 0 until points.length.toInt()) {
                val p = points.get(i, points) as? NativeObject ?: continue
                val px = num(p.get("x")); val py = num(p.get("y"))
                val hold = long(p.get("hold"), 0L)
                defs.add(Action.SwipePointDef(px, py, hold))
            }
            if (defs.size >= 2) {
                executor.execute(Action.MultiPointSwipe(defs, segmentDurationMs = durationEach))
            } else if (defs.size == 1) {
                // Tek nokta verildiyse basit bir dokunuşa düşür (motor da böyle davranıyor).
                executor.execute(Action.Tap(defs[0].x, defs[0].y, 1, defs[0].holdMs.coerceAtLeast(50)))
            }
            null
        }
        define("wait") { args ->
            val ms = long(args.getOrNull(0))
            if (ms > 0) Thread.sleep(ms)
            null
        }

        // ---- Sistem aksiyonları ----
        define("back") { if (!pausedProvider()) executor.execute(Action.SystemAction("BACK")); null }
        define("home") { if (!pausedProvider()) executor.execute(Action.SystemAction("HOME")); null }
        define("recents") { if (!pausedProvider()) executor.execute(Action.SystemAction("RECENTS")); null }
        define("notifications") { if (!pausedProvider()) executor.execute(Action.SystemAction("NOTIFICATIONS")); null }
        define("quickSettings") { if (!pausedProvider()) executor.execute(Action.SystemAction("QUICK_SETTINGS")); null }

        // ---- Değişkenler (BİRLEŞİK sistem — hepsi tek VariableStore'a gider) ----
        define("getVar") { args -> VariableStore.getNumber(args.getOrNull(0)?.toString() ?: "").toDouble() }
        define("setVar") { args ->
            VariableStore.set(args.getOrNull(0)?.toString() ?: return@define null, num(args.getOrNull(1)))
            null
        }
        // Metin (String) değişkenler için:
        define("getVarStr") { args -> VariableStore.getString(args.getOrNull(0)?.toString() ?: "") }
        define("setVarStr") { args ->
            VariableStore.setString(args.getOrNull(0)?.toString() ?: return@define null, args.getOrNull(1)?.toString() ?: "")
            null
        }
        // Geriye dönük: getGlobalVar/setGlobalVar artık AYNI birleşik değişkenlere erişir.
        define("getGlobalVar") { args -> VariableStore.getNumber(args.getOrNull(0)?.toString() ?: "").toDouble() }
        define("setGlobalVar") { args ->
            VariableStore.set(args.getOrNull(0)?.toString() ?: return@define null, num(args.getOrNull(1)))
            null
        }

        // ---- Setting (Macrorify "Setting Builder" script API) ----
        // Setting.get(key): kayıtlı özel ayardaki bir key'in GÜNCEL değerini (metin) döner.
        //   (Kaydet'e basılınca değişkenlere yazıldığı için doğrudan VariableStore'dan okunur.)
        // Setting.show(): kayıtlı özel ayar diyaloğunu gösterir (UI thread'de OverlayService açar).
        //   Diyalog gösterildiyse true, gösterilemezse false döner (assenkron; anlık sonuç UI'da).
        define("settingGet") { args -> VariableStore.getString(args.getOrNull(0)?.toString() ?: "") }
        define("settingShow") { settingShowRequester?.invoke() ?: false }
        // Setting nesnesi: Setting.get(key) / Setting.show()
        run {
            val settingObj = cx.newObject(scope)
            val getFn = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    VariableStore.getString(a.getOrNull(0)?.toString() ?: "")
            }
            val showFn = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    settingShowRequester?.invoke() ?: false
            }
            ScriptableObject.putProperty(settingObj, "get", getFn)
            ScriptableObject.putProperty(settingObj, "show", showFn)
            ScriptableObject.putProperty(scope, "Setting", settingObj)
        }

        // ---- Ekran okuma (düz fonksiyonlar — geriye dönük uyumluluk) ----
        define("colorAt") { args ->
            val frame = frameProvider() ?: return@define "#000000"
            val x = num(args.getOrNull(0)).coerceIn(0, frame.width - 1)
            val y = num(args.getOrNull(1)).coerceIn(0, frame.height - 1)
            String.format("#%06X", 0xFFFFFF and frame.getPixel(x, y))
        }
        define("findColor") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val hex = args.getOrNull(4)?.toString() ?: "#000000"
            val minScore = ((args.getOrNull(5) as? Number)?.toDouble() ?: 0.9).toFloat()
            val color = try { Color.parseColor(hex) } catch (e: Exception) { 0 }
            Condition.ColorInRegion(region, color, minScore).evaluate(frame)
        }
        define("findImage") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val nameOrPath = args.getOrNull(4)?.toString() ?: return@define false
            val path = libraryLookup(nameOrPath) ?: nameOrPath // önce kütüphane isminden dene, yoksa doğrudan yol say
            val minScore = ((args.getOrNull(5) as? Number)?.toDouble() ?: 0.8).toFloat()
            Condition.ImageInRegion(region, path, minScore).evaluate(frame)
        }
        define("findText") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val text = args.getOrNull(4)?.toString() ?: ""
            Condition.TextInRegion(region, text).evaluate(frame)
        }
        define("randomInt") { args ->
            val min = num(args.getOrNull(0), 0); val max = num(args.getOrNull(1), 100)
            if (max <= min) min.toDouble() else (min..max).random().toDouble()
        }

        // ---- Fonksiyon/Script çağırma ----
        define("callFunction") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val repeat = num(args.getOrNull(1), 1)
            val frame = frameProvider() ?: return@define null
            val rules = functionByName(name)
            repeat(repeat.coerceAtLeast(1)) { runRuleList(rules, frame) }
            null
        }
        define("runScript") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val code = scriptLookup(name) ?: run { Log.e("BigBossScript", "Script bulunamadı: $name"); return@define null }
            run(code) // recursive — kendi run() metodumuzu tekrar kullanıyoruz
            null
        }
        define("log") { args ->
            Log.i("BigBossScript", args.joinToString(" ") { it?.toString() ?: "null" })
            null
        }

        // ---- Point(x, y) yardımcı yapıcı ----
        define("Point") { args ->
            newObj(cx, scope, mapOf("x" to num(args.getOrNull(0)), "y" to num(args.getOrNull(1))))
        }

        // ---- Region(x, y, w, h) — EMScript'teki Region class'ının OOP benzeri karşılığı ----
        define("Region") { args ->
            val rx = num(args.getOrNull(0)); val ry = num(args.getOrNull(1))
            val rw = num(args.getOrNull(2), 1); val rh = num(args.getOrNull(3), 1)
            val regionObj = cx.newObject(scope)
            ScriptableObject.putProperty(regionObj, "x", rx)
            ScriptableObject.putProperty(regionObj, "y", ry)
            ScriptableObject.putProperty(regionObj, "w", rw)
            ScriptableObject.putProperty(regionObj, "h", rh)

            fun regionFn(name: String, fn: (Array<Any?>) -> Any?) {
                val f = object : org.mozilla.javascript.BaseFunction() {
                    override fun call(cx: RhinoContext?, scope: Scriptable?, thisObj: Scriptable?, callArgs: Array<Any?>): Any {
                        return fn(callArgs) ?: RhinoContext.getUndefinedValue()
                    }
                }
                ScriptableObject.putProperty(regionObj, name, f)
            }
            regionFn("center") { newObj(cx, scope, mapOf("x" to rx + rw / 2, "y" to ry + rh / 2)) }
            regionFn("findColor") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val hex = a.getOrNull(0)?.toString() ?: "#000000"
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.9).toFloat()
                val color = try { Color.parseColor(hex) } catch (e: Exception) { 0 }
                Condition.ColorInRegion(Region(rx, ry, rw, rh), color, minScore).evaluate(frame)
            }
            regionFn("findImage") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val nameOrPath = a.getOrNull(0)?.toString() ?: return@regionFn false
                val path = libraryLookup(nameOrPath) ?: nameOrPath
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.8).toFloat()
                Condition.ImageInRegion(Region(rx, ry, rw, rh), path, minScore).evaluate(frame)
            }
            regionFn("findImageMatch") { a ->
                val frame = frameProvider() ?: return@regionFn null
                val nameOrPath = a.getOrNull(0)?.toString() ?: return@regionFn null
                val path = libraryLookup(nameOrPath) ?: nameOrPath
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.8).toFloat()
                val result = ImageMatcher.bestLocation(frame, Region(rx, ry, rw, rh), path, 4) ?: return@regionFn null
                val (score, loc) = result
                if (score < minScore) return@regionFn null
                newObj(cx, scope, mapOf("found" to true, "x" to loc.first, "y" to loc.second, "score" to score.toDouble()))
            }
            regionFn("findText") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val text = a.getOrNull(0)?.toString() ?: ""
                Condition.TextInRegion(Region(rx, ry, rw, rh), text).evaluate(frame)
            }
            regionFn("tap") { a ->
                if (pausedProvider()) return@regionFn null
                val hold = long(opt(a, 0, "hold"), 50L)
                executor.execute(Action.Tap(rx + rw / 2, ry + rh / 2, 1, hold))
                null
            }
            regionFn("highlight") { /* Not: script'ten ekranda görsel vurgulama şu an desteklenmiyor — sadece dokümantasyon için yer tutucu. */ null }
            regionObj
        }
    }
}
