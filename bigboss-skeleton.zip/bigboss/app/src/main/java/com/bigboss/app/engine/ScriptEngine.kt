package com.bigboss.app.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.bigboss.app.model.Region
import org.mozilla.javascript.Context as RhinoContext
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject

/**
 * BigBoss'un "EMScript'ten ilham alan kod sistemi". Gerçek bir dil
 * yorumlayıcısı yazmak yerine, saf-Java olan Rhino JavaScript motorunu
 * gömüyoruz — böylece değişken, if/else, for/while, fonksiyon, hatta
 * ES class söz dizimi GERÇEKTEN çalışıyor. Söz dizimi EMScript'in
 * birebir aynısı değil (JavaScript), ama kavramsal olarak istenen her
 * şeyi (değişken/kontrol akışı/fonksiyon/sınıf) sağlıyor.
 *
 * Script içinden çağrılabilecek köprü fonksiyonları (README'de de
 * belgelenmiştir):
 *   tap(x, y)
 *   swipe(x1, y1, x2, y2, durationMs?)
 *   wait(ms)
 *   getVar(name) / setVar(name, value)
 *   colorAt(x, y)                         -> "#RRGGBB"
 *   findColor(x, y, w, h, hex, minScore?) -> true/false
 *   findImage(x, y, w, h, libraryName, minScore?) -> true/false
 *   findText(x, y, w, h, text)            -> true/false
 *   callFunction(functionName, repeat?)   -> tanımlı bir Fonksiyonu çağırır
 *   log(msg)                              -> Logcat'e yazar (tag: BigBossScript)
 */
class ScriptEngine(
    private val executor: ActionExecutor,
    private val frameProvider: () -> Bitmap?,
    private val functionByName: (String) -> List<Rule>,
    private val runRuleList: (List<Rule>, Bitmap) -> Unit,
    /** true iken (Edit Mode) script'in tap/swipe çağrıları GERÇEK dokunuşa çevrilmez — güvenlik. */
    private val pausedProvider: () -> Boolean = { false }
) {

    /** Bir script'i bir kere çalıştırır. Hata olursa mesajı döner, olmazsa null. */
    fun run(code: String): String? {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1 // Android'de bytecode üretimi yerine yorumlanır (daha güvenli)
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            cx.evaluateString(scope, code, "bigboss-script", 1, null)
            null
        } catch (e: Exception) {
            Log.e("BigBossScript", "Script hatası", e)
            e.message ?: e.toString()
        } finally {
            RhinoContext.exit()
        }
    }

    /** Bir script'i KOŞUL olarak çalıştırır: son ifadenin/return'ün boolean'a çevrilmiş hâlini döner. */
    fun evaluateAsCondition(code: String): Boolean {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            val result = cx.evaluateString(scope, code, "bigboss-condition-script", 1, null)
            RhinoContext.toBoolean(result)
        } catch (e: Exception) {
            Log.e("BigBossScript", "Koşul script hatası", e)
            false
        } finally {
            RhinoContext.exit()
        }
    }

    private fun bindBridgeFunctions(cx: RhinoContext, scope: Scriptable) {
        fun define(name: String, fn: (Array<Any?>) -> Any?) {
            val f = object : org.mozilla.javascript.BaseFunction() {
                override fun call(cx: RhinoContext?, scope: Scriptable?, thisObj: Scriptable?, args: Array<Any?>): Any {
                    return fn(args) ?: RhinoContext.getUndefinedValue()
                }
            }
            ScriptableObject.putProperty(scope, name, f)
        }

        define("tap") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — tap() engellendi)"); return@define null }
            val x = (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val y = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            executor.execute(Action.Tap(x, y))
            null
        }
        define("swipe") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — swipe() engellendi)"); return@define null }
            val x1 = (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val y1 = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            val x2 = (args.getOrNull(2) as? Number)?.toInt() ?: 0
            val y2 = (args.getOrNull(3) as? Number)?.toInt() ?: 0
            val dur = (args.getOrNull(4) as? Number)?.toLong() ?: 300L
            executor.execute(Action.Swipe(x1, y1, x2, y2, dur))
            null
        }
        define("wait") { args ->
            val ms = (args.getOrNull(0) as? Number)?.toLong() ?: 0L
            if (ms > 0) Thread.sleep(ms)
            null
        }
        define("getVar") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define 0.0
            VariableStore.get(name).toDouble()
        }
        define("setVar") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val value = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            VariableStore.set(name, value)
            null
        }
        define("colorAt") { args ->
            val frame = frameProvider() ?: return@define "#000000"
            val x = (args.getOrNull(0) as? Number)?.toInt()?.coerceIn(0, frame.width - 1) ?: 0
            val y = (args.getOrNull(1) as? Number)?.toInt()?.coerceIn(0, frame.height - 1) ?: 0
            String.format("#%06X", 0xFFFFFF and frame.getPixel(x, y))
        }
        define("findColor") { args ->
            val frame = frameProvider() ?: return@define false
            val x = (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val y = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            val w = (args.getOrNull(2) as? Number)?.toInt() ?: 1
            val h = (args.getOrNull(3) as? Number)?.toInt() ?: 1
            val hex = args.getOrNull(4)?.toString() ?: "#000000"
            val minScore = (args.getOrNull(5) as? Number)?.toDouble()?.toFloat() ?: 0.9f
            val color = try { Color.parseColor(hex) } catch (e: Exception) { 0 }
            Condition.ColorInRegion(Region(x, y, w, h), color, minScore).evaluate(frame)
        }
        define("findImage") { args ->
            val frame = frameProvider() ?: return@define false
            val x = (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val y = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            val w = (args.getOrNull(2) as? Number)?.toInt() ?: 1
            val h = (args.getOrNull(3) as? Number)?.toInt() ?: 1
            val templatePath = args.getOrNull(4)?.toString() ?: return@define false
            val minScore = (args.getOrNull(5) as? Number)?.toDouble()?.toFloat() ?: 0.8f
            Condition.ImageInRegion(Region(x, y, w, h), templatePath, minScore).evaluate(frame)
        }
        define("findText") { args ->
            val frame = frameProvider() ?: return@define false
            val x = (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val y = (args.getOrNull(1) as? Number)?.toInt() ?: 0
            val w = (args.getOrNull(2) as? Number)?.toInt() ?: 1
            val h = (args.getOrNull(3) as? Number)?.toInt() ?: 1
            val text = args.getOrNull(4)?.toString() ?: ""
            Condition.TextInRegion(Region(x, y, w, h), text).evaluate(frame)
        }
        define("callFunction") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val repeat = (args.getOrNull(1) as? Number)?.toInt() ?: 1
            val frame = frameProvider() ?: return@define null
            val rules = functionByName(name)
            repeat(repeat.coerceAtLeast(1)) { runRuleList(rules, frame) }
            null
        }
        define("log") { args ->
            Log.i("BigBossScript", args.joinToString(" ") { it?.toString() ?: "null" })
            null
        }
    }
}
