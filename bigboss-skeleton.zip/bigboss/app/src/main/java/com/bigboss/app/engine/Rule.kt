package com.bigboss.app.engine

/**
 * Tek bir komut satırı: "Bu bölgede bu rengi/resmi en fazla X ms ara,
 * bulursan şu aksiyonu çalıştır."
 *
 * RuleEngine bunları SIRAYLA çalıştırır (Macrorify'daki script mantığı gibi):
 * bir kural eşleşene ya da timeoutMs dolana kadar o kuralda beklenir,
 * sonra bir sonrakine geçilir (liste bitince başa döner).
 */
data class Rule(
    val id: String,
    val name: String,
    val condition: Condition,
    val thenAction: Action,
    /** Bu koşulu en fazla kaç ms arayacağız. -1 = süresiz bekle (eşleşene kadar). */
    val timeoutMs: Long = 3000,
    val enabled: Boolean = true
)
