package com.bigboss.app.engine

/**
 * Macrorify'ın GERÇEK mantığı: her Rule BAĞIMSIZDIR, aralarında sıra
 * YOKTUR. Koşul (condition) doğru olduğu her an, o an aksiyonu (action)
 * tetiklenir — "sıradaki kurala geçmek" diye bir şey yok. Görsel/renk
 * ekranda olduğu sürece tetiklenmeye devam eder, kaybolunca durur,
 * tekrar belirince tekrar tetiklenir.
 */
data class Rule(
    val id: String,
    val name: String,
    val condition: Condition,
    val thenAction: Action,
    /**
     * "Wait Next" (Macrorify'daki Click Option alanı): bu aksiyon
     * tetiklendikten sonra, TEKRAR tetiklenebilmesi için en az kaç ms
     * geçmesi gerekir. Spam-tıklamayı önler. 0 = her frame'de tetiklenebilir.
     */
    val cooldownMs: Long = 300,
    val enabled: Boolean = true,
    /** true ise ters mantık: koşul KAYBOLUNCA (eşleşmeyince) tetiklenir ("Not Appear"). */
    val negate: Boolean = false
)
