package com.bigboss.app.engine

/**
 * Senin tanımlayacağın "if (...) then (...) else if (...) ..." zincirinin
 * tek bir düğümü. `elseIf` alanı, bir sonraki koşulu tutarak zinciri kurar.
 *
 * Örnek kullanım (kod ile):
 *
 * val hpRule = Rule(
 *     id = "hp_check",
 *     name = "HP düşükse potion iç",
 *     condition = Condition.PixelColorMatch(hpBarRegion, redColor),
 *     thenAction = Action.Tap(potionButtonX, potionButtonY),
 *     elseIf = Rule(
 *         id = "enemy_check",
 *         name = "Düşman görüldüyse saldır",
 *         condition = Condition.TemplateMatch(enemyRegion, "enemy_icon"),
 *         thenAction = Action.Tap(attackButtonX, attackButtonY),
 *         elseIf = null // zincir burada biter, hiçbiri tutmazsa NoOp
 *     )
 * )
 */
data class Rule(
    val id: String,
    val name: String,
    val condition: Condition,
    val thenAction: Action,
    val elseIf: Rule? = null,
    val enabled: Boolean = true
)
