package com.bigboss.app.engine

/**
 * Macrorify'ın GERÇEK mantığı: her Rule BAĞIMSIZDIR, aralarında sıra
 * YOKTUR. Koşul (condition) doğru olduğu her an, o an aksiyonu (action)
 * tetiklenir — "sıradaki kurala geçmek" diye bir şey yok. Görsel/renk
 * ekranda olduğu sürece tetiklenmeye devam eder, kaybolunca durur,
 * tekrar belirince tekrar tetiklenir.
 */
data class Rule(
    val id: String,
    val name: String,
    val condition: Condition,
    val thenAction: Action,
    /** "Wait Next": bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmeli. */
    val cooldownMs: Long = 300,
    val enabled: Boolean = true,
    /** true ise ters mantık: koşul KAYBOLUNCA (eşleşmeyince) tetiklenir ("Not Appear"). */
    val negate: Boolean = false,
    /** "NONE" | "ALWAYS" | "WHILE_SUCCESS" | "WHILE_FAIL" */
    val loopMode: String = "ALWAYS",
    /** Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre (ms). */
    val matchDelayMs: Long = 0
)
