package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Kullanıcının tanımladığı "IF" koşulları.
 * Her Condition, o anki ekran görüntüsüne (frame) bakarak true/false döner.
 */
sealed class Condition {

    abstract fun evaluate(frame: Bitmap): Boolean

    /** Belirli bir bölgedeki ortalama/tekil piksel rengi hedef renge yakın mı? (örn. HP barı kontrolü) */
    data class PixelColorMatch(
        val region: Region,
        val targetColor: Int,
        val tolerance: Int = 24
    ) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean {
            val px = frame.getPixel(region.centerX, region.centerY)
            return colorDistance(px, targetColor) <= tolerance
        }

        private fun colorDistance(a: Int, b: Int): Int {
            val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
            val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
            return (Math.abs(ar - br) + Math.abs(ag - bg) + Math.abs(ab - bb)) / 3
        }
    }

    /** Belirli bir bölgede önceden kaydedilmiş bir görsel (ör. düşman ikonu) var mı? */
    data class TemplateMatch(
        val region: Region,
        val templateAssetName: String,
        val threshold: Double = 0.82
    ) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean {
            // TODO: OpenCV entegrasyonu sonrası ScreenAnalyzer.matchTemplate(...) ile doldurulacak.
            // Bkz. vision/TemplateMatcher.kt
            return TemplateMatcher.matches(frame, region, templateAssetName, threshold)
        }
    }

    /** Birden fazla koşulu VE ile birleştirir. */
    data class And(val conditions: List<Condition>) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = conditions.all { it.evaluate(frame) }
    }

    /** Birden fazla koşulu VEYA ile birleştirir. */
    data class Or(val conditions: List<Condition>) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = conditions.any { it.evaluate(frame) }
    }

    /** Bir koşulun tersi (DEĞİL). */
    data class Not(val condition: Condition) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = !condition.evaluate(frame)
    }

    /** Her zaman aynı sonucu döner. "else" dalının son adımı için kullanışlı. */
    data class Always(val value: Boolean = true) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = value
    }
}
