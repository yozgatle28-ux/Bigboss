package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Kullanıcının tanımladığı "IF" koşulları.
 * Her Condition, o anki ekran görüntüsüne (frame) bakarak true/false döner.
 */
sealed class Condition {

    abstract fun evaluate(frame: Bitmap): Boolean

    /** Belirli bir bölgedeki ortalama/tekil piksel rengi hedef renge yakın mı? (örn. HP barı kontrolü) */
    data class PixelColorMatch(
        val region: Region,
        val targetColor: Int,
        val tolerance: Int = 24
    ) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean {
            val px = frame.getPixel(region.centerX, region.centerY)
            return colorDistance(px, targetColor) <= tolerance
        }

        private fun colorDistance(a: Int, b: Int): Int {
            val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
            val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
            return (Math.abs(ar - br) + Math.abs(ag - bg) + Math.abs(ab - bb)) / 3
        }
    }

    /**
     * Bir DİKDÖRTGEN BÖLGE içinde hedef renge yakın en az bir piksel var mı?
     * Tek nokta yerine geniş bir alanı taradığı için (örn. "düşman HP çubuğu
     * şu bölgede bir yerde belirir" gibi) PixelColorMatch'ten daha esnektir.
     * Performans için her pikseli değil, `sampleStep` aralıklarla tarar.
     */
    data class ColorInRegion(
        val region: Region,
        val targetColor: Int,
        val tolerance: Int = 24,
        val sampleStep: Int = 4
    ) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean {
            val left = region.x.coerceIn(0, frame.width - 1)
            val top = region.y.coerceIn(0, frame.height - 1)
            val right = (region.x + region.width).coerceIn(0, frame.width)
            val bottom = (region.y + region.height).coerceIn(0, frame.height)
            if (right <= left || bottom <= top) return false

            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val px = frame.getPixel(x, y)
                    if (colorDistance(px, targetColor) <= tolerance) return true
                    x += sampleStep
                }
                y += sampleStep
            }
            return false
        }

        private fun colorDistance(a: Int, b: Int): Int {
            val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
            val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
            return (Math.abs(ar - br) + Math.abs(ag - bg) + Math.abs(ab - bb)) / 3
        }
    }

    /** Belirli bir bölgede önceden kaydedilmiş bir görsel (ör. düşman ikonu) var mı? */
    data class TemplateMatch(
        val region: Region,
        val templateAssetName: String,
        val threshold: Double = 0.82
    ) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean {
            // TODO: OpenCV entegrasyonu sonrası ScreenAnalyzer.matchTemplate(...) ile doldurulacak.
            // Bkz. vision/TemplateMatcher.kt
            return TemplateMatcher.matches(frame, region, templateAssetName, threshold)
        }
    }

    /** Birden fazla koşulu VE ile birleştirir. */
    data class And(val conditions: List<Condition>) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = conditions.all { it.evaluate(frame) }
    }

    /** Birden fazla koşulu VEYA ile birleştirir. */
    data class Or(val conditions: List<Condition>) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = conditions.any { it.evaluate(frame) }
    }

    /** Bir koşulun tersi (DEĞİL). */
    data class Not(val condition: Condition) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = !condition.evaluate(frame)
    }

    /** Her zaman aynı sonucu döner. "else" dalının son adımı için kullanışlı. */
    data class Always(val value: Boolean = true) : Condition() {
        override fun evaluate(frame: Bitmap): Boolean = value
    }
}
