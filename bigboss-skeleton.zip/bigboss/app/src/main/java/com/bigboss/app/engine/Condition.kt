package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Kullanıcının tanımladığı "IF" koşulları (Macrorify'daki "Region + Template
 * + Min Score" ve "Multi Detection / Logical Group" mantığıyla aynı fikir).
 *
 * Her Condition, bir ekran görüntüsüne (frame) bakarak 0.0-1.0 arası bir
 * "benzerlik skoru" (matchScore) üretir. Skor, kendi minScore eşiğini
 * geçerse koşul "true" sayılır (evaluate()).
 */
sealed class Condition {

    abstract val minScore: Float

    abstract fun matchScore(frame: Bitmap): Float

    fun evaluate(frame: Bitmap): Boolean = matchScore(frame) >= minScore

    /** "Eşleşen Noktaya Tıkla" için: en iyi eşleşmenin bulunduğu (x,y) konumu. Yoksa null. */
    open fun matchLocation(frame: Bitmap): Pair<Int, Int>? = null

    /** Bir BÖLGE içinde hedef renge en çok benzeyen pikseli arar. */
    data class ColorInRegion(
        val region: Region,
        val targetColor: Int,
        override val minScore: Float = 0.85f,
        val sampleStep: Int = 4
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = bestMatch(frame).first

        override fun matchLocation(frame: Bitmap): Pair<Int, Int>? {
            val (score, loc) = bestMatch(frame)
            return if (score >= minScore) loc else null
        }

        private fun bestMatch(frame: Bitmap): Pair<Float, Pair<Int, Int>?> {
            val left = region.x.coerceIn(0, frame.width - 1)
            val top = region.y.coerceIn(0, frame.height - 1)
            val right = (region.x + region.width).coerceIn(0, frame.width)
            val bottom = (region.y + region.height).coerceIn(0, frame.height)
            if (right <= left || bottom <= top) return 0f to null

            var best = 0f
            var bestX = left; var bestY = top
            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val sim = colorSimilarity(frame.getPixel(x, y), targetColor)
                    if (sim > best) { best = sim; bestX = x; bestY = y }
                    x += sampleStep
                }
                y += sampleStep
            }
            return best to (bestX to bestY)
        }
    }

    /** Bir BÖLGE içinde daha önce kaydedilmiş bir referans görseli (template) arar. */
    data class ImageInRegion(
        val region: Region,
        val templatePath: String,
        override val minScore: Float = 0.85f,
        val searchStep: Int = 8
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = ImageMatcher.bestScore(frame, region, templatePath, searchStep)
        override fun matchLocation(frame: Bitmap): Pair<Int, Int>? {
            val loc = ImageMatcher.bestLocation(frame, region, templatePath, searchStep) ?: return null
            return if (loc.first >= minScore) loc.second else null
        }
    }

    /** Bir BÖLGE içinde belirli bir metnin (OCR ile) geçip geçmediğini arar. */
    data class TextInRegion(
        val region: Region,
        val expectedText: String,
        override val minScore: Float = 0.5f,
        val caseSensitive: Boolean = false,
        /** Sadece bu karakterlere izin ver (OCR'ın "1"/"l", "0"/"o" karıştırmasını önlemek için). Boşsa devre dışı. */
        val whitelist: String = "",
        /** Bu karakterleri OKUNAN metinden çıkar. Boşsa devre dışı. */
        val blacklist: String = ""
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = TextMatcher.contains(frame, region, expectedText, caseSensitive, whitelist, blacklist)
    }

    /** Bir sayaç/değişkenin şu anki değerini bir sayı ile karşılaştırır. */
    data class VariableCompare(
        val variableName: String,
        val op: String, // ">=", "<=", "==", ">", "<"
        val value: Int,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            val current = VariableStore.get(variableName)
            val ok = when (op) {
                ">=" -> current >= value
                "<=" -> current <= value
                "==" -> current == value
                ">" -> current > value
                "<" -> current < value
                else -> false
            }
            return if (ok) 1f else 0f
        }
    }

    /**
     * Macrorify'daki "Action Result" koşulu: başka bir kuralın YAKIN ZAMANDA
     * tetiklenip tetiklenmediğini şart koşar. Paralel/reaktif motorda SIRA
     * gerektiren senaryolar ("önce A olsun, sonra B çalışsın") için kullanılır.
     */
    data class ActionResult(
        val referencedRuleId: String,
        val withinMs: Long = 2000,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float =
            if (ActionResultRegistry.firedWithin(referencedRuleId, withinMs)) 1f else 0f
    }

    /** Kod sistemi: bir Script'i (JavaScript) KOŞUL olarak çalıştırır, true/false dönmesi beklenir. */
    data class Script(
        val code: String,
        override val minScore: Float = 0.5f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float =
            if (ScriptRuntime.engine?.evaluateAsCondition(code) == true) 1f else 0f
    }

    /** "Loop Always": ekranda ne olursa olsun her zaman doğru kabul edilir (cooldown'a göre tetiklenir). */
    object Always : Condition() {
        override val minScore: Float = 0f
        override fun matchScore(frame: Bitmap): Float = 1f
    }

    /** Macrorify'daki "Random" koşulu: her kontролde belirli bir OLASILIKLA doğru döner. %0 = asla, %100 = her zaman. */
    data class Random(val percent: Int) : Condition() {
        override val minScore: Float = 0.5f
        override fun matchScore(frame: Bitmap): Float =
            if ((0 until 100).random() < percent.coerceIn(0, 100)) 1f else 0f
    }

    /** Macrorify'daki "Multi Detection / Logical Group" — birden fazla koşulu VE/VEYA ile birleştirir. */
    enum class GroupLogic { ALL_SUCCESS, ONE_SUCCESS, ALL_FAIL, ONE_FAIL, ALWAYS_SUCCESS, ALWAYS_FAIL }

    data class Group(
        val conditions: List<Condition>,
        val logic: GroupLogic,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            if (conditions.isEmpty()) return 0f
            val success = when (logic) {
                GroupLogic.ALL_SUCCESS -> conditions.all { it.evaluate(frame) }
                GroupLogic.ONE_SUCCESS -> conditions.any { it.evaluate(frame) }
                GroupLogic.ALL_FAIL -> conditions.all { !it.evaluate(frame) }
                GroupLogic.ONE_FAIL -> conditions.any { !it.evaluate(frame) }
                GroupLogic.ALWAYS_SUCCESS -> true
                GroupLogic.ALWAYS_FAIL -> false
            }
            return if (success) 1f else 0f
        }
    }
}

/** 0.0 (tamamen farklı) - 1.0 (birebir aynı) arası renk benzerliği. */
/** sRGB -> CIE Lab dönüşümü (D65 beyaz nokta). Delta E hesaplaması için gerekli ara adım. */
private fun rgbToLab(r: Int, g: Int, b: Int): FloatArray {
    fun toLinear(c: Int): Double {
        val cs = c / 255.0
        return if (cs <= 0.04045) cs / 12.92 else Math.pow((cs + 0.055) / 1.055, 2.4)
    }
    val rl = toLinear(r); val gl = toLinear(g); val bl = toLinear(b)
    val x = rl * 0.4124564 + gl * 0.3575761 + bl * 0.1804375
    val y = rl * 0.2126729 + gl * 0.7151522 + bl * 0.0721750
    val z = rl * 0.0193339 + gl * 0.1191920 + bl * 0.9503041
    val xn = 0.95047; val yn = 1.0; val zn = 1.08883
    fun f(t: Double): Double = if (t > 0.008856) Math.cbrt(t) else (7.787 * t + 16.0 / 116.0)
    val fx = f(x / xn); val fy = f(y / yn); val fz = f(z / zn)
    val l = 116 * fy - 16
    val aStar = 500 * (fx - fy)
    val bStar = 200 * (fy - fz)
    return floatArrayOf(l.toFloat(), aStar.toFloat(), bStar.toFloat())
}

/**
 * Macrorify'daki "Delta E (dE)" metriği: insan gözünün renk algısını taklit eden bilimsel bir
 * karşılaştırma (CIE76). Basit RGB mesafesinden çok daha güvenilir — ışık/sıkıştırma
 * farklılıklarında bile "gözle aynı görünen" renkleri doğru eşleştirir.
 * dE ≈ 0 = birebir aynı, dE ≤ 10 = "gözle aynı" (Macrorify'ın varsayılan "Same" eşiği), yüksek dE = belirgin fark.
 */
internal fun deltaE(a: Int, b: Int): Float {
    val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
    val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
    val lab1 = rgbToLab(ar, ag, ab)
    val lab2 = rgbToLab(br, bg, bb)
    val dl = lab1[0] - lab2[0]; val da = lab1[1] - lab2[1]; val db = lab1[2] - lab2[2]
    return Math.sqrt((dl * dl + da * da + db * db).toDouble()).toFloat()
}

/** Delta E'yi bizim 0-1 skor sistemimize çevirir (dE=0 -> 1.0 mükemmel, dE=10 -> ~0.9 "aynı", yüksek dE -> 0'a yaklaşır). */
internal fun colorSimilarity(a: Int, b: Int): Float = (1f - (deltaE(a, b) / 100f)).coerceIn(0f, 1f)
