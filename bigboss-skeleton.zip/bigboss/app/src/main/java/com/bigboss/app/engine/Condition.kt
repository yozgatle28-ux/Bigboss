package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Kullanıcının tanımladığı "IF" koşulları (Macrorify'daki "Region + Template
 * + Min Score" mantığıyla aynı fikir).
 *
 * Her Condition, bir ekran görüntüsüne (frame) bakarak 0.0-1.0 arası bir
 * "benzerlik skoru" (matchScore) üretir. Skor, kendi minScore eşiğini
 * geçerse koşul "true" sayılır (evaluate()).
 */
sealed class Condition {

    abstract val minScore: Float

    /** 0.0 (hiç benzemiyor) - 1.0 (birebir aynı) arası benzerlik skoru döner. */
    abstract fun matchScore(frame: Bitmap): Float

    fun evaluate(frame: Bitmap): Boolean = matchScore(frame) >= minScore

    /**
     * Bir BÖLGE içinde hedef renge en çok benzeyen pikseli arar.
     * Tek nokta yerine tüm bölgeyi taradığı için daha toleranslıdır
     * (örn. "bu bölgede bir yerde kırmızı bir HP çubuğu var mı?").
     */
    data class ColorInRegion(
        val region: Region,
        val targetColor: Int,
        override val minScore: Float = 0.85f,
        val sampleStep: Int = 4
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            val left = region.x.coerceIn(0, frame.width - 1)
            val top = region.y.coerceIn(0, frame.height - 1)
            val right = (region.x + region.width).coerceIn(0, frame.width)
            val bottom = (region.y + region.height).coerceIn(0, frame.height)
            if (right <= left || bottom <= top) return 0f

            var best = 0f
            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val sim = colorSimilarity(frame.getPixel(x, y), targetColor)
                    if (sim > best) best = sim
                    x += sampleStep
                }
                y += sampleStep
            }
            return best
        }
    }

    /**
     * Bir BÖLGE içinde daha önce kaydedilmiş bir referans görseli (template)
     * arar. Basit (OpenCV'siz) bir "kayan pencere" karşılaştırması kullanır:
     * her aday konumda template ile o bölgedeki kırpma küçültülüp
     * karşılaştırılır. Küçük şablonlarda ve makul bölge boyutlarında iyi
     * çalışır; çok büyük bölgeler/şablonlar yavaş olabilir.
     */
    data class ImageInRegion(
        val region: Region,
        val templatePath: String,
        override val minScore: Float = 0.85f,
        val searchStep: Int = 8
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            return ImageMatcher.bestScore(frame, region, templatePath, searchStep)
        }
    }

    /** Birden fazla koşulu VE ile birleştirir (en düşük skor esas alınır). */
    data class And(val conditions: List<Condition>, override val minScore: Float = 1f) : Condition() {
        override fun matchScore(frame: Bitmap): Float = conditions.minOf { it.matchScore(frame) / it.minScore }
    }

    /** Her zaman aynı skoru döner. Test/varsayılan kural için kullanışlı. */
    data class Always(val score: Float = 1f, override val minScore: Float = 0.5f) : Condition() {
        override fun matchScore(frame: Bitmap): Float = score
    }
}

/** 0.0 (tamamen farklı) - 1.0 (birebir aynı) arası renk benzerliği. */
internal fun colorSimilarity(a: Int, b: Int): Float {
    val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
    val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
    val diff = kotlin.math.abs(ar - br) + kotlin.math.abs(ag - bg) + kotlin.math.abs(ab - bb)
    return 1f - (diff / (3f * 255f))
}
