package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region

/**
 * Kullanıcının tanımladığı "IF" koşulları (Macrorify'daki "Region + Template
 * + Min Score" ve "Multi Detection / Logical Group" mantığıyla aynı fikir).
 *
 * Her Condition, bir ekran görüntüsüne (frame) bakarak 0.0-1.0 arası bir
 * "benzerlik skoru" (matchScore) üretir. Skor, kendi minScore eşiğini
 * geçerse koşul "true" sayılır (evaluate()).
 */
sealed class Condition {

    abstract val minScore: Float

    abstract fun matchScore(frame: Bitmap): Float

    fun evaluate(frame: Bitmap): Boolean = matchScore(frame) >= minScore

    /** "Eşleşen Noktaya Tıkla" için: en iyi eşleşmenin bulunduğu (x,y) konumu. Yoksa null. */
    open fun matchLocation(frame: Bitmap): Pair<Int, Int>? = null

    /** Bir BÖLGE içinde hedef renge en çok benzeyen pikseli arar. */
    data class ColorInRegion(
        val region: Region,
        val targetColor: Int,
        override val minScore: Float = 0.85f,
        val sampleStep: Int = 4
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = bestMatch(frame).first

        override fun matchLocation(frame: Bitmap): Pair<Int, Int>? {
            val (score, loc) = bestMatch(frame)
            return if (score >= minScore) loc else null
        }

        private fun bestMatch(frame: Bitmap): Pair<Float, Pair<Int, Int>?> {
            val left = region.x.coerceIn(0, frame.width - 1)
            val top = region.y.coerceIn(0, frame.height - 1)
            val right = (region.x + region.width).coerceIn(0, frame.width)
            val bottom = (region.y + region.height).coerceIn(0, frame.height)
            if (right <= left || bottom <= top) return 0f to null

            var best = 0f
            var bestX = left; var bestY = top
            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val sim = colorSimilarity(frame.getPixel(x, y), targetColor)
                    if (sim > best) { best = sim; bestX = x; bestY = y }
                    x += sampleStep
                }
                y += sampleStep
            }
            return best to (bestX to bestY)
        }
    }

    /** Bir BÖLGE içinde daha önce kaydedilmiş bir referans görseli (template) arar. */
    data class ImageInRegion(
        val region: Region,
        val templatePath: String,
        override val minScore: Float = 0.85f,
        val searchStep: Int = 8
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = ImageMatcher.bestScore(frame, region, templatePath, searchStep)
        override fun matchLocation(frame: Bitmap): Pair<Int, Int>? {
            val loc = ImageMatcher.bestLocation(frame, region, templatePath, searchStep) ?: return null
            return if (loc.first >= minScore) loc.second else null
        }
    }

    /** Bir BÖLGE içinde belirli bir metnin (OCR ile) geçip geçmediğini arar. */
    data class TextInRegion(
        val region: Region,
        val expectedText: String,
        override val minScore: Float = 0.5f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float = TextMatcher.contains(frame, region, expectedText)
    }

    /** Bir sayaç/değişkenin şu anki değerini bir sayı ile karşılaştırır. */
    data class VariableCompare(
        val variableName: String,
        val op: String, // ">=", "<=", "==", ">", "<"
        val value: Int,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            val current = VariableStore.get(variableName)
            val ok = when (op) {
                ">=" -> current >= value
                "<=" -> current <= value
                "==" -> current == value
                ">" -> current > value
                "<" -> current < value
                else -> false
            }
            return if (ok) 1f else 0f
        }
    }

    /**
     * Macrorify'daki "Action Result" koşulu: başka bir kuralın YAKIN ZAMANDA
     * tetiklenip tetiklenmediğini şart koşar. Paralel/reaktif motorda SIRA
     * gerektiren senaryolar ("önce A olsun, sonra B çalışsın") için kullanılır.
     */
    data class ActionResult(
        val referencedRuleId: String,
        val withinMs: Long = 2000,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float =
            if (ActionResultRegistry.firedWithin(referencedRuleId, withinMs)) 1f else 0f
    }

    /** Kod sistemi: bir Script'i (JavaScript) KOŞUL olarak çalıştırır, true/false dönmesi beklenir. */
    data class Script(
        val code: String,
        override val minScore: Float = 0.5f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float =
            if (ScriptRuntime.engine?.evaluateAsCondition(code) == true) 1f else 0f
    }

    /** "Loop Always": ekranda ne olursa olsun her zaman doğru kabul edilir (cooldown'a göre tetiklenir). */
    object Always : Condition() {
        override val minScore: Float = 0f
        override fun matchScore(frame: Bitmap): Float = 1f
    }

    /** Macrorify'daki "Random" koşulu: her kontролde belirli bir OLASILIKLA doğru döner. %0 = asla, %100 = her zaman. */
    data class Random(val percent: Int) : Condition() {
        override val minScore: Float = 0.5f
        override fun matchScore(frame: Bitmap): Float =
            if ((0 until 100).random() < percent.coerceIn(0, 100)) 1f else 0f
    }

    /** Macrorify'daki "Multi Detection / Logical Group" — birden fazla koşulu VE/VEYA ile birleştirir. */
    enum class GroupLogic { ALL_SUCCESS, ONE_SUCCESS, ALL_FAIL, ONE_FAIL, ALWAYS_SUCCESS, ALWAYS_FAIL }

    data class Group(
        val conditions: List<Condition>,
        val logic: GroupLogic,
        override val minScore: Float = 0.999f
    ) : Condition() {
        override fun matchScore(frame: Bitmap): Float {
            if (conditions.isEmpty()) return 0f
            val success = when (logic) {
                GroupLogic.ALL_SUCCESS -> conditions.all { it.evaluate(frame) }
                GroupLogic.ONE_SUCCESS -> conditions.any { it.evaluate(frame) }
                GroupLogic.ALL_FAIL -> conditions.all { !it.evaluate(frame) }
                GroupLogic.ONE_FAIL -> conditions.any { !it.evaluate(frame) }
                GroupLogic.ALWAYS_SUCCESS -> true
                GroupLogic.ALWAYS_FAIL -> false
            }
            return if (success) 1f else 0f
        }
    }
}

/** 0.0 (tamamen farklı) - 1.0 (birebir aynı) arası renk benzerliği. */
internal fun colorSimilarity(a: Int, b: Int): Float {
    val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
    val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
    val diff = kotlin.math.abs(ar - br) + kotlin.math.abs(ag - bg) + kotlin.math.abs(ab - bb)
    return 1f - (diff / (3f * 255f))
}
