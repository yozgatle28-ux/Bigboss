package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.storage.ActionGroupStorage
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 *
 * ÖNEMLİ MİMARİ NOT: Alan çizme/düzenleme artık bir Activity DEĞİL —
 * doğrudan WindowManager ile eklenen GERÇEK overlay pencereleri.
 * Bunun sebebi: şeffaf temalı bir Activity, çoğu oyunun kullandığı
 * SurfaceView/GLSurfaceView tabanlı çizimle düzgün bindirilmiyor
 * (Android'in bilinen bir kısıtı) — bu yüzden oyunun üstünde değil,
 * koyu bir katmanın üstünde görünüyordu. Gerçek overlay pencereleri
 * (bizim küçük ✏️ simgemiz gibi) HER TÜRLÜ uygulamanın (oyunlar dahil)
 * üzerinde güvenilir şekilde çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (mode == "PLAY") {
            val engine = ScreenCaptureService.ruleEngine
            playState = if (engine != null && !engine.paused) "PLAYING" else if (playState == "STOPPED") "STOPPED" else "PAUSED"
        } else if (mode == "EDIT") {
            editTestRunning = false // güvenlik: Edit Mode'a her girişte varsayılan olarak dokunuş kapalı
        }
        if (rootView == null) buildOverlay() else rebuildPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    // ==================== Overlay pencere iskeleti (küçük simge) ====================

    private var sidebarCollapsed = false

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private var playState = "STOPPED" // PLAYING | PAUSED | STOPPED
    private var editTestRunning = false // Edit Mode'dan ÇIKMADAN motoru geçici çalıştırma anahtarı

    /** Panel'i doğrudan HUB yerine belirli bir ekrana açar (Hub yine ← ile bir tık geride durur). */
    private fun openPanelDirectTo(title: String, build: () -> View) {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
        pushScreen(title, build)
    }

    private fun rebuildPanel() {
        rootView?.removeAllViews()
        val density = resources.displayMetrics.density
        val btnSize = (46 * density).toInt()

        if (sidebarCollapsed) {
            val expandArrow = TextView(this).apply {
                text = "»"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#CC1A1A1A"))
                layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
                setOnClickListener { sidebarCollapsed = false; rebuildPanel() }
            }
            rootView?.addView(expandArrow)
            return
        }

        val sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE1A1A1A"))
        }

        val collapseArrow = TextView(this).apply {
            text = "«"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (30 * density).toInt())
            setOnClickListener { sidebarCollapsed = true; rebuildPanel() }
        }
        sidebar.addView(collapseArrow)

        // Macrorify'daki gibi: TEK dokunuşla direkt çalışan küçük ikon-kare butonlar
        // (önceki "aç sonra listeden seç" iki adımlı sistemin YERİNE geçti).
        fun iconBtn(icon: String, onClick: () -> Unit) = TextView(this).apply {
            text = icon; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            isClickable = true
            setOnClickListener { onClick() }
        }
        fun row(vararg buttons: View) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.forEach { r.addView(it) }
            sidebar.addView(r)
        }

        if (mode == "EDIT") {
            row(
                iconBtn("🖼️👆") { startAddRegion() },
                iconBtn("👆") { addSimpleStepToMainFlow("TAP") },
                iconBtn("🤚") { addSimpleStepToMainFlow("SWIPE") }
            )
            row(
                iconBtn("🏠") { openPanelDirectTo("🏠 Ana Akış") { buildAnaAkisScreen() } },
                iconBtn("f{}") { openPanelDirectTo("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } },
                iconBtn("📚") { showLibraryMenu() }
            )
            row(
                iconBtn("🖥️") { showScriptsMenu() },
                iconBtn("🔢") { showVariablesMenu() },
                iconBtn("🗺️") { showWorkspaceMenu() }
            )
            row(
                iconBtn(if (editTestRunning) "⏸️" else "🧪") { toggleEditTest() },
                iconBtn("▶️") { switchToPlayMode() },
                iconBtn("⚙️") { showAutoStopSettingsDialog() }
            )
            row(iconBtn("✕") { shutdown() })
        } else {
            // ---- PLAY MODE: Play / Pause / Stop / İzle / Ayarlar / Kapat ----
            row(
                iconBtn("▶️") { playMacro() },
                iconBtn(if (playState == "PAUSED") "▶️" else "⏸️") { togglePause() },
                iconBtn("⏹") { stopMacro() }
            )
            row(
                iconBtn(if (liveMonitorOn) "🙈" else "👁️") { toggleLiveMonitor() },
                iconBtn("⚙️") { showAutoStopSettingsDialog() },
                iconBtn("✕") { shutdown() }
            )
            sidebar.addView(TextView(this).apply {
                text = when (playState) { "PLAYING" -> "▶️ Çalışıyor"; "PAUSED" -> "⏸️ Duraklı"; else -> "⏹️ Durdu" }
                setTextColor(Color.WHITE); textSize = 10f; gravity = Gravity.CENTER
                setPadding(4, (4 * density).toInt(), 4, (4 * density).toInt())
            })
        }
        rootView?.addView(sidebar)
    }

    private fun switchToPlayMode() {
        mode = "PLAY"
        clearAllRegionWindows(); clearWorkspace()
        playMacro()
    }

    /** Edit Mode'dan hiç çıkmadan motoru geçici çalıştırır — sadece izlemek/test etmek için. */
    private fun toggleEditTest() {
        val engine = ScreenCaptureService.ruleEngine
        if (engine == null) {
            Toast.makeText(this, "Motor hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        editTestRunning = !editTestRunning
        engine.paused = !editTestRunning
        if (!editTestRunning) { engine.resetLoopState(); stopLiveMonitor() } else { startLiveMonitor() }
        rebuildPanel()
        Toast.makeText(
            this,
            if (editTestRunning) "🧪 Canlı test başladı — hangi alanın tarandığını yeşil/kırmızı ve sıralı vurguyla göreceksin"
            else "⏸️ Canlı test durdu — düzenlemeye devam edebilirsin",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun playMacro() {
        ScreenCaptureService.ruleEngine?.paused = false
        com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
        playState = "PLAYING"
        startAutoStopWatcher()
        rebuildPanel()
        Toast.makeText(this, "▶️ Çalışıyor", Toast.LENGTH_SHORT).show()
    }

    private fun togglePause() {
        val engine = ScreenCaptureService.ruleEngine ?: return
        if (playState == "PAUSED") {
            engine.paused = false
            com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
            playState = "PLAYING"
            startAutoStopWatcher()
            Toast.makeText(this, "▶️ Devam ediyor", Toast.LENGTH_SHORT).show()
        } else {
            engine.paused = true
            playState = "PAUSED"
            stopAutoStopWatcher()
            Toast.makeText(this, "⏸️ Duraklatıldı — kaldığı yerden devam edecek", Toast.LENGTH_SHORT).show()
        }
        rebuildPanel()
    }

    private fun stopMacro() {
        val engine = ScreenCaptureService.ruleEngine
        engine?.paused = true
        engine?.resetLoopState()
        playState = "STOPPED"
        stopLiveMonitor()
        stopAutoStopWatcher()
        rebuildPanel()
        Toast.makeText(this, "⏹ Durduruldu — Play'e basınca baştan başlar", Toast.LENGTH_SHORT).show()
    }

    // ==================== 🛑 Otomatik Durdurma (art arda hata / donma güvenlik ağı) ====================
    // "Play"deyken, HİÇBİR kural belirli bir süre boyunca hiç tetiklenmezse (bağlantı koptu,
    // oyun dondu, beklenmedik bir ekrana düşüldü vb.) makro sonsuza kadar boşa dönmesin diye
    // kendini otomatik durdurur.

    private val autoStopHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var autoStopRunnable: Runnable? = null

    private fun startAutoStopWatcher() {
        stopAutoStopWatcher()
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        if (minutes <= 0) return // kapalı
        val thresholdMs = minutes * 60_000L
        val tick = object : Runnable {
            override fun run() {
                if (playState != "PLAYING") return
                val elapsed = com.bigboss.app.engine.ActionResultRegistry.msSinceAnyFire()
                if (elapsed >= thresholdMs) {
                    stopMacro()
                    Toast.makeText(
                        this@OverlayService,
                        "🛑 Otomatik durduruldu — $minutes dakikadır hiçbir kural tetiklenmedi (bağlantı/donma olabilir)",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                autoStopHandler.postDelayed(this, 15_000L)
            }
        }
        autoStopRunnable = tick
        autoStopHandler.postDelayed(tick, 15_000L)
    }

    private fun stopAutoStopWatcher() {
        autoStopRunnable?.let { autoStopHandler.removeCallbacks(it) }
        autoStopRunnable = null
    }

    private fun autoStopSubtitle(): String {
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        return if (minutes <= 0) "Otomatik Durdurma: kapalı" else "Otomatik Durdurma: $minutes dk hareketsizlikte dur"
    }

    private fun showAutoStopSettingsDialog() {
        val ctx = this
        val current = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(ctx)
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(ctx).apply {
            text = "🛑 Otomatik Durdurma\n\nPlay Mode'dayken, kaç dakika boyunca HİÇBİR kural tetiklenmezse (bağlantı koptu, oyun dondu, beklenmedik ekran vb.) makro kendini otomatik durdursun? 0 = kapalı (asla otomatik durmaz)."
            textSize = 12f
        })
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
            hint = "Dakika (0 = kapalı)"
        }
        container.addView(input)
        overlayDialog().setTitle("⚙️ Ayarlar").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val minutes = input.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
                com.bigboss.app.storage.AppSettings.setAutoStopMinutes(ctx, minutes)
                if (playState == "PLAYING") startAutoStopWatcher() // yeni değeri hemen uygula
                Toast.makeText(ctx, if (minutes <= 0) "Otomatik durdurma kapatıldı" else "Otomatik durdurma: $minutes dakika", Toast.LENGTH_SHORT).show()
                refreshCurrentScreen()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir Hold/Delay alanı için: sabit sayı GİR ya da bir "🔢 Değişken"e BAĞLA seçeneği sunan birleşik alan. */
    private fun addHoldOrDelayField(
        ctx: android.content.Context, container: LinearLayout, label: String,
        currentValue: Long, currentVarName: String?,
        onValueChanged: (Long) -> Unit, onVarNameChanged: (String?) -> Unit
    ) {
        container.addView(TextView(ctx).apply { text = label; textSize = 12f; setPadding(0, 12, 0, 0) })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentValue.toString())
            isEnabled = currentVarName == null
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        input.addTextChangedListener(simpleWatcher { onValueChanged(it.toLongOrNull() ?: 0) })
        row.addView(input)
        lateinit var btnLink: Button
        btnLink = Button(ctx).apply {
            text = if (currentVarName != null) "🔗 $currentVarName" else "🔗 Bağla"
            textSize = 10f
            setOnClickListener {
                val vars = com.bigboss.app.storage.GlobalVariableStorage.load(this@OverlayService)
                if (vars.isEmpty()) {
                    Toast.makeText(this@OverlayService, "Henüz değişken yok — önce 🔢 Değişkenler'den oluştur", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val options = mutableListOf("❌ Bağlantıyı Kaldır (sabit değer kullan)")
                options.addAll(vars.map { "🔗 ${it.name} (${it.value})" })
                overlayDialog().setItems(options.toTypedArray()) { _, idx ->
                    if (idx == 0) {
                        onVarNameChanged(null); btnLink.text = "🔗 Bağla"; input.isEnabled = true
                    } else {
                        val v = vars[idx - 1]
                        onVarNameChanged(v.name); btnLink.text = "🔗 ${v.name}"
                        input.isEnabled = false; input.setText(v.value.toString())
                    }
                }.create().showOverlay()
            }
        }
        row.addView(btnLink)
        container.addView(row)
    }

    // ==================== 🔢 Değişkenler (Hold/Delay gibi alanların toplu değiştirilmesi için) ====================

    private fun showVariablesMenu() {
        val ctx = this
        val vars = com.bigboss.app.storage.GlobalVariableStorage.load(ctx)
        val options = mutableListOf("➕ Yeni Değişken")
        options.addAll(vars.map { "🔢 ${it.name} = ${it.value}" })
        overlayDialog().setTitle("🔢 Değişkenler (Hold/Delay için)").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createVariable() else showVariableOptions(vars[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createVariable() {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Değişken adı (örn. bekleme_suresi)" }
        val valueInput = EditText(ctx).apply { hint = "Başlangıç değeri (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("25") }
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); addView(nameInput); addView(valueInput) }
        overlayDialog().setTitle("Yeni Değişken").setView(container)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "degisken" }
                val value = valueInput.text.toString().toLongOrNull() ?: 0
                com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, com.bigboss.app.storage.GlobalVariableDefinition(UUID.randomUUID().toString(), name, value))
                Toast.makeText(ctx, "Oluşturuldu: $name = $value", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showVariableOptions(variable: com.bigboss.app.storage.GlobalVariableDefinition) {
        val ctx = this
        overlayDialog().setTitle("🔢 ${variable.name} = ${variable.value}")
            .setItems(arrayOf("✏️ Değeri Değiştir (buna bağlı HER ŞEY güncellenir)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    val input = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(variable.value.toString()) }
                    overlayDialog().setTitle("Yeni değer: ${variable.name}").setView(input)
                        .setPositiveButton("Kaydet") { _, _ ->
                            variable.value = input.text.toString().toLongOrNull() ?: variable.value
                            com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, variable)
                            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                            Toast.makeText(ctx, "Güncellendi: ${variable.name} = ${variable.value} — buna bağlı tüm alanlar etkilendi", Toast.LENGTH_LONG).show()
                        }.setNegativeButton("Vazgeç", null).create().showOverlay()
                } else {
                    com.bigboss.app.storage.GlobalVariableStorage.delete(ctx, variable.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                    Toast.makeText(ctx, "Silindi (buna bağlı alanlar artık kendi sabit değerlerini kullanır)", Toast.LENGTH_LONG).show()
                }
            }.create().showOverlay()
    }

    private var liveMonitorOn = false
    private val liveMonitorHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var liveMonitorRunnable: Runnable? = null
    private data class LiveBox(val rule: RuleDefinition, val box: View)
    private val liveBoxes = mutableListOf<LiveBox>()
    private var liveMonitorSweepIndex = 0
    private var liveMonitorSweepLabel: TextView? = null
    private var liveMonitorSweepLabelParams: WindowManager.LayoutParams? = null

    private fun toggleLiveMonitor() {
        if (liveMonitorOn) stopLiveMonitor() else startLiveMonitor()
        rebuildPanel()
    }

    private fun startLiveMonitor() {
        val rules = RuleStorage.load(this).filter { !it.id.endsWith("-fail") && it.enabled && it.alternatives.isNotEmpty() }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Ana Akışta izlenecek alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        liveMonitorOn = true
        liveMonitorSweepIndex = 0
        rules.forEach { rule ->
            val alt = rule.alternatives.first()
            val box = View(this).apply { background = borderDrawable(Color.GRAY) }
            val params = WindowManager.LayoutParams(
                alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }
            try {
                windowManager?.addView(box, params)
                liveBoxes.add(LiveBox(rule, box))
            } catch (e: Exception) {}
        }
        // Sırayla "şu an taranan alan" etiketi — Ana Akış listesindeki sırayla ilerler.
        val sweepLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD000000"))
            textSize = 12f
            setPadding(16, 6, 16, 6)
        }
        val sweepParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 400 }
        try {
            windowManager?.addView(sweepLabel, sweepParams)
            liveMonitorSweepLabel = sweepLabel; liveMonitorSweepLabelParams = sweepParams
        } catch (e: Exception) {}

        Toast.makeText(this, "👁️ Canlı izleme açık — yeşil: eşleşti, kırmızı: eşleşmedi, kalın çerçeve: şu an taranan alan", Toast.LENGTH_LONG).show()
        scheduleLiveMonitorTick()
    }

    private fun scheduleLiveMonitorTick() {
        val tick = object : Runnable {
            override fun run() {
                if (!liveMonitorOn) return
                val frame = ScreenCaptureService.latestFrame
                if (frame != null && liveBoxes.isNotEmpty()) {
                    val currentIdx = liveMonitorSweepIndex % liveBoxes.size
                    liveBoxes.forEachIndexed { idx, lb ->
                        val matched = try {
                            val condition = RuleDefinitionMapper.toCondition(lb.rule)
                            val rawMatch = condition.matchScore(frame) >= condition.minScore
                            if (lb.rule.negateCondition) !rawMatch else rawMatch
                        } catch (e: Exception) { false }
                        val color = if (matched) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
                        val strokeDp = if (idx == currentIdx) 6f else 2.5f
                        lb.box.background = borderDrawable(color, strokeDp)
                    }
                    liveMonitorSweepLabel?.text = "🔍 Taranıyor: ${liveBoxes[currentIdx].rule.name} (${currentIdx + 1}/${liveBoxes.size})"
                    liveMonitorSweepIndex++
                }
                liveMonitorHandler.postDelayed(this, 400L)
            }
        }
        liveMonitorRunnable = tick
        liveMonitorHandler.post(tick)
    }

    private fun stopLiveMonitor() {
        liveMonitorOn = false
        liveMonitorRunnable?.let { liveMonitorHandler.removeCallbacks(it) }
        liveMonitorRunnable = null
        liveBoxes.forEach { try { windowManager?.removeView(it.box) } catch (e: Exception) {} }
        liveBoxes.clear()
        liveMonitorSweepLabel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        liveMonitorSweepLabel = null; liveMonitorSweepLabelParams = null
    }

    // ==================== 🎨 Tasarım Sistemi — Macrorify'ın attığın ekran görüntülerine göre ====================
    // Fark ettiğim şeyler: (1) dolgulu renkli üst çubuk yerine CLOSE/Başlık/SAVE metin-linkli
    // hafif "sayfa" hissi (2) bol boşluklu liste satırları + ince gri ayırıcılar (3) her alanın
    // üstünde etiket + kutulu kenarlık + altında açıklama metni (4) MOR vurgu rengi, beyaz zemin.

    private val ACCENT = Color.parseColor("#7C4DFF")
    private val TEXT_PRIMARY = Color.parseColor("#212121")
    private val TEXT_SECONDARY = Color.parseColor("#757575")
    private val DIVIDER_COLOR = Color.parseColor("#E0E0E0")

    /** Macrorify'daki "CLOSE ... Başlık ... SAVE" üst çubuğu — dolgulu renk yerine beyaz zemin + mor metin linkler. */
    private fun buildSheetHeader(title: String, onClose: () -> Unit, rightLabel: String? = null, onRight: (() -> Unit)? = null): LinearLayout {
        val density = resources.displayMetrics.density
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt())
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setOnClickListener { onClose() }
        }
        val titleTv = TextView(this).apply {
            text = title; textSize = 15f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val rightTv = TextView(this).apply {
            text = rightLabel ?: ""
            textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            visibility = if (rightLabel != null) View.VISIBLE else View.INVISIBLE
            if (onRight != null) setOnClickListener { onRight() }
        }
        header.addView(closeBtn)
        header.addView(titleTv)
        header.addView(rightTv)
        return header
    }

    /** Macrorify'daki Ayarlar ekranındaki "etiket + kutulu alan + altında açıklama" deseni. */
    private fun styledField(label: String, helper: String?, value: String, keyboardNumeric: Boolean = true, onChange: (String) -> Unit): LinearLayout {
        val density = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (14 * density).toInt(), 0, 0)
        }
        val labelTv = TextView(this).apply { text = label; textSize = 11f; setTextColor(TEXT_SECONDARY) }
        val input = EditText(this).apply {
            setText(value)
            textSize = 15f
            setTextColor(TEXT_PRIMARY)
            if (keyboardNumeric) inputType = InputType.TYPE_CLASS_NUMBER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke((1 * density).toInt(), DIVIDER_COLOR)
                cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        input.addTextChangedListener(simpleWatcher { onChange(it) })
        container.addView(labelTv)
        container.addView(input)
        if (helper != null) {
            container.addView(TextView(this).apply {
                text = helper; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (4 * density).toInt(), 0, 0)
            })
        }
        return container
    }

    /** ListView satırları arasına Macrorify'daki gibi ince gri ayırıcı çizgi ekler. */
    private fun styleListDividers(listView: android.widget.ListView) {
        listView.divider = android.graphics.drawable.ColorDrawable(DIVIDER_COLOR)
        listView.dividerHeight = (1 * resources.displayMetrics.density).toInt()
    }

    // ==================== 📱 App Panel — Macrorify tarzı TEK, KALICI, gezinme yığınlı panel ====================
    // Eskiden HER işlem ayrı bir AlertDialog açıyordu (üst üste yığılıyordu, "neredeyim" belli değildi).
    // Şimdi TEK bir pencere var; içinde "ekranlar" (screen) arasında GERÇEK gezinme yapıyoruz —
    // üstte her zaman "neredeyim" (breadcrumb) + geri butonu görünüyor, tıpkı normal bir uygulama gibi.

    private data class NavEntry(val title: String, val build: () -> View)
    private val navStack = mutableListOf<NavEntry>()
    private var panelRoot: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelContent: android.widget.FrameLayout? = null
    private var panelTitle: TextView? = null
    private var panelBackBtn: TextView? = null

    private fun showAppPanel() {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
    }

    private fun buildAppPanelWindow() {
        val metrics = resources.displayMetrics
        val panelW = (metrics.widthPixels * 0.94).toInt()
        val panelH = (metrics.heightPixels * 0.82).toInt()
        val density = metrics.density

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding((12 * density).toInt(), (16 * density).toInt(), (12 * density).toInt(), (16 * density).toInt())
        }
        val backBtn = TextView(this).apply {
            text = "← GERİ"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((8 * density).toInt(), 0, (16 * density).toInt(), 0)
            visibility = View.INVISIBLE
        }
        val titleTv = TextView(this).apply {
            textSize = 13f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((16 * density).toInt(), 0, (8 * density).toInt(), 0)
        }
        val headerDivider = View(this).apply {
            setBackgroundColor(DIVIDER_COLOR)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt())
        }
        header.addView(backBtn); header.addView(titleTv); header.addView(closeBtn)

        val content = android.widget.FrameLayout(this)
        val contentScroll = android.widget.ScrollView(this).apply { addView(content) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(header)
            addView(headerDivider)
            addView(contentScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        backBtn.setOnClickListener { popScreen() }
        closeBtn.setOnClickListener { closeAppPanel() }

        val params = WindowManager.LayoutParams(
            panelW, panelH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager?.addView(root, params)
            panelRoot = root; panelParams = params
            panelContent = content; panelTitle = titleTv; panelBackBtn = backBtn
        } catch (e: Exception) {
            Toast.makeText(this, "Panel açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun pushScreen(title: String, build: () -> View) {
        navStack.add(NavEntry(title, build))
        renderCurrentScreen()
    }

    /** Aynı ekranı, güncel verilerle YENİDEN çizer (bir işlem sonrası liste tazelensin diye). */
    private fun refreshCurrentScreen() = renderCurrentScreen()

    private fun popScreen() {
        if (navStack.size <= 1) { closeAppPanel(); return }
        navStack.removeAt(navStack.size - 1)
        renderCurrentScreen()
    }

    private fun renderCurrentScreen() {
        val entry = navStack.lastOrNull() ?: return
        panelTitle?.text = navStack.joinToString("  ›  ") { it.title }
        panelBackBtn?.visibility = if (navStack.size > 1) View.VISIBLE else View.INVISIBLE
        panelContent?.removeAllViews()
        panelContent?.addView(entry.build())
    }

    private fun closeAppPanel() {
        panelRoot?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        panelRoot = null; panelParams = null; panelContent = null; panelTitle = null; panelBackBtn = null
        navStack.clear()
    }

    /** Panel açıkken bir alt-diyalog (AlertDialog) açmadan önce çağrılır — ikisi karışmasın diye paneli GEÇİCİ gizler. */
    private fun hidePanelTemporarily() { panelRoot?.visibility = View.GONE }
    private fun showPanelAgain() { panelRoot?.visibility = View.VISIBLE }

    // ---- Ana ekran (Hub): büyük kart-butonlar ----
    private fun buildHubScreen(): View {
        val ctx = this
        val density = resources.displayMetrics.density
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt()) }

        fun card(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (18 * density).toInt(), (16 * density).toInt(), (18 * density).toInt())
                setBackgroundColor(Color.parseColor("#F5F5F5"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, (10 * density).toInt())
                layoutParams = lp
                isClickable = true
                setOnClickListener { onClick() }
            }
            row.addView(TextView(ctx).apply { text = icon; textSize = 24f; setPadding(0, 0, (16 * density).toInt(), 0) })
            val textCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            textCol.addView(TextView(ctx).apply { text = title; textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(Color.parseColor("#212121")) })
            textCol.addView(TextView(ctx).apply { text = subtitle; textSize = 11f; setTextColor(Color.parseColor("#757575")) })
            row.addView(textCol)
            grid.addView(row)
        }

        val rules = RuleStorage.load(ctx).size
        val groups = ActionGroupStorage.load(ctx).size
        val fns = FunctionStorage.load(ctx).size

        card("🏠", "Ana Akış", "$rules kural, $groups grup") { pushScreen("🏠 Ana Akış") { buildAnaAkisScreen() } }
        card("f{}", "Fonksiyonlar", "$fns fonksiyon") { pushScreen("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } }
        card("📚", "Kütüphane", "Görsel/renk kaydet") { showLibraryMenu() }
        card("🖥️", "Kod", "Script'ler") { showScriptsMenu() }
        card("🔢", "Değişkenler", "Hold/Delay toplu yönetim") { showVariablesMenu() }
        card("🗺️", "Çalışma Alanı", "Alanları ekranda göster") { showWorkspaceMenu() }
        card("🖼️👆", "Alan Ekle", "Yeni tarama başlat") { closeAppPanel(); startAddRegion() }
        card("🧪", if (editTestRunning) "Canlı Testi Durdur" else "Canlı Test", "Edit Mode'da kalarak test et") { toggleEditTest(); refreshCurrentScreen() }
        card("▶️", "Play Mode'a Geç", "Kalıcı çalıştır") { closeAppPanel(); switchToPlayMode() }
        if (activeRegions.isNotEmpty()) {
            card("🧹", "Ekrandaki Kutuları Temizle", "${activeRegions.size} açık alan") { clearAllRegionWindows(); refreshCurrentScreen() }
        }
        card("⚙️", "Ayarlar", autoStopSubtitle()) { showAutoStopSettingsDialog() }
        card("✕", "Kapat", "Uygulamayı tamamen kapat") { shutdown() }

        return grid
    }

    private fun shutdown() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        stopAutoStopWatcher()
        removePointMarker()
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    // ==================== Overlay üzerinden Dialog gösterme yardımcıları ====================

    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ==================== ALAN ÇİZME SİSTEMİ (gerçek overlay pencereleri) ====================

    private data class ExtraAction(
        val type: String, // "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT"
        var x: Int = 0, var y: Int = 0,
        var x2: Int = 0, var y2: Int = 0,
        var waitMs: Long = 500,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1,
        var variableName: String = "",
        var variableDelta: Int = 1,
        var scriptId: String? = null,
        var scriptName: String = "",
        var holdMs: Long = 50,
        var swipeHoldStartMs: Long = 0,
        var swipeHoldEndMs: Long = 0,
        var postDelayMs: Long = 0
    )

    private inner class ActiveRegion(
        val id: String, val container: LinearLayout, val containerParams: WindowManager.LayoutParams,
        val label: TextView, val labelParams: WindowManager.LayoutParams,
        val frameContainer: android.widget.FrameLayout, val boxParams: android.widget.FrameLayout.LayoutParams,
        val handleParams: android.widget.FrameLayout.LayoutParams, val handleSizePx: Int
    ) {
        var existingRuleId: String? = null
        var name = ""
        var conditionKind = "COLOR"
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText = ""
        var minScore = 90
        var actionType = "TAP"
        var tapAtMatchLocation = false
        var actionRepeatCount = 1
        var actionHoldMs: Long = 50
        var actionPostDelayMs: Long = 0
        var randomOffsetPx: Int = 0
        var randomChancePercent: Int = 100
        var swipeHoldStartMs: Long = 0
        var swipeHoldEndMs: Long = 0
        var actionHoldVarName: String? = null
        var actionPostDelayVarName: String? = null
        var swipeHoldStartVarName: String? = null
        var swipeHoldEndVarName: String? = null
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName = ""
        var callFunctionRepeat = 1
        val extraActions = mutableListOf<ExtraAction>()
        val onFailActions = mutableListOf<ExtraAction>()
        var cooldownMs: Long = 300
        var matchDelayMs: Long = 0
        var scanTimeoutMs: Long = 0
        var negate = false
        var loopMode = "ALWAYS" // NONE | ALWAYS | WHILE_SUCCESS | WHILE_FAIL
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
        /** GENEL sekmesindeki Find Region alanlarını, alan sürüklenince canlı güncellemek için — BİRDEN FAZLA dinleyici destekler. */
        val onRectChangedListeners: MutableList<() -> Unit> = mutableListOf()
        /** Bu alan bir Action Group'un İÇİNE mi kaydedilecek, yoksa Ana Akışa mı? */
        var saveScope: SaveScope = SaveScope.MainFlow
        /** Bu alan bir Action Group'un KAPI koşulunu mu ayarlıyor (true ise sadece koşul kaydedilir)? */
        var isGateForGroupId: String? = null
        /** Bu alan Kütüphaneye "Ekrandan Kırp" için mi kullanılıyor (true ise dokununca kural penceresi değil, kaydetme sorulur)? */
        var isLibraryCapture: Boolean = false
        /** Kaydedildikten SONRA çalıştırılacak ekstra işlem (örn. Başarılı/Bulunamazsa listesine "Fonksiyon Çağır" eklemek için). */
        var onSavedCallback: (() -> Unit)? = null
    }

    private sealed class SaveScope {
        object MainFlow : SaveScope()
        data class Group(val groupId: String) : SaveScope()
        data class Function(val functionId: String) : SaveScope()
    }

    private val activeRegions = mutableListOf<ActiveRegion>()
    private var regionCounter = 0

    private sealed class PendingPick {
        data class ColorPick(val region: Any) : PendingPick()
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex = -1
    private var colorPickCatcher: View? = null

    private fun startAddRegion() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        addRegionWindow()
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    private fun addRegionWindow(initX: Int? = null, initY: Int? = null, initW: Int? = null, initH: Int? = null): ActiveRegion {
        val id = "r${regionCounter++}"
        val density = resources.displayMetrics.density
        val defaultSize = (130 * density).toInt()
        val handleSize = (22 * density).toInt()
        val offset = (regionCounter % 6) * (24 * density).toInt()

        val box = View(this).apply { background = borderDrawable(Color.parseColor("#2196F3")) }
        val handleView = View(this).apply { setBackgroundColor(Color.WHITE) }

        val container = LinearLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        val boxParams = android.widget.FrameLayout.LayoutParams(defaultSize, defaultSize)
        val handleParams = android.widget.FrameLayout.LayoutParams(handleSize, handleSize).apply {
            leftMargin = defaultSize - handleSize / 2
            topMargin = defaultSize - handleSize / 2
        }
        val frameContainer = android.widget.FrameLayout(this)
        frameContainer.addView(box, boxParams)
        frameContainer.addView(handleView, handleParams)
        container.addView(frameContainer)
        container.clipChildren = false

        val containerParams = WindowManager.LayoutParams(
            defaultSize + handleSize, defaultSize + handleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX ?: ((60 * density).toInt() + offset)
            y = initY ?: ((220 * density).toInt() + offset)
            width = (initW ?: defaultSize) + handleSize
            height = (initH ?: defaultSize) + handleSize
        }
        boxParams.width = initW ?: defaultSize
        boxParams.height = initH ?: defaultSize
        handleParams.leftMargin = (initW ?: defaultSize) - handleSize / 2
        handleParams.topMargin = (initH ?: defaultSize) - handleSize / 2

        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = containerParams.x
            y = (containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        }

        windowManager?.addView(container, containerParams)
        windowManager?.addView(label, labelParams)

        val region = ActiveRegion(id, container, containerParams, label, labelParams, frameContainer, boxParams, handleParams, handleSize)
        activeRegions.add(region)

        setupRegionTouch(region, frameContainer, box, boxParams, handleView, handleParams, containerParams, handleSize)
        return region
    }

    private fun borderDrawable(color: Int, strokeDp: Float = 2.5f): android.graphics.drawable.GradientDrawable {
        val density = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((strokeDp * density).toInt(), color)
        }
    }

    private fun updateLabelPosition(region: ActiveRegion) {
        val density = resources.displayMetrics.density
        region.labelParams.x = region.containerParams.x
        region.labelParams.y = (region.containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        windowManager?.updateViewLayout(region.label, region.labelParams)
    }

    private fun setupRegionTouch(
        region: ActiveRegion, frameContainer: android.widget.FrameLayout, box: View, boxParams: android.widget.FrameLayout.LayoutParams,
        handleView: View, handleParams: android.widget.FrameLayout.LayoutParams, containerParams: WindowManager.LayoutParams, handleSize: Int
    ) {
        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var startX = 0; var startY = 0
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    startX = containerParams.x; startY = containerParams.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    // Android'in kendi sistem "dokunma toleransı" (touch slop) değeri: doğal parmak
                    // titremesini görmezden gelirken, GERÇEK bir sürükleme başlangıcını hemen fark eder.
                    // (Önceki sabit 24dp değeri, yavaş bir sürüklemenin 500ms içinde bu eşiği aşamayıp
                    // yanlışlıkla "basılı tutma" menüsünü açmasına sebep oluyordu.)
                    val cancelThreshold = android.view.ViewConfiguration.get(this@OverlayService).scaledTouchSlop
                    if (abs(dx) > cancelThreshold || abs(dy) > cancelThreshold) longPressHandler.removeCallbacks(longPressRunnable)
                    containerParams.x = startX + dx
                    containerParams.y = startY + dy
                    windowManager?.updateViewLayout(region.container, containerParams)
                    updateLabelPosition(region)
                    region.onRectChangedListeners.forEach { it() }
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < 18 && dt < 350) {
                            if (region.isLibraryCapture) openLibraryCaptureSaveDialog(region) else openRegionConfigDialog(region)
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handleView.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSize = (40 * resources.displayMetrics.density).toInt()
                val localX = (event.rawX - containerParams.x).toInt().coerceAtLeast(minSize)
                val localY = (event.rawY - containerParams.y).toInt().coerceAtLeast(minSize)
                boxParams.width = localX
                boxParams.height = localY
                handleParams.leftMargin = localX - handleSize / 2
                handleParams.topMargin = localY - handleSize / 2
                frameContainer.requestLayout()
                containerParams.width = localX + handleSize
                containerParams.height = localY + handleSize
                windowManager?.updateViewLayout(region.container, containerParams)
                region.onRectChangedListeners.forEach { it() }
            }
            true
        }
    }

    private fun regionRect(region: ActiveRegion): IntArray {
        // Overlay pencere koordinatları GERÇEK ekran piksel koordinatlarıdır — MediaProjection
        // yakalaması da aynı çözünürlükte olduğu için doğrudan (ölçekleme gerekmeden) kullanılabilir.
        val p = region.containerParams
        val handleSize = (22 * resources.displayMetrics.density).toInt()
        return intArrayOf(p.x, p.y, (p.width - handleSize).coerceAtLeast(4), (p.height - handleSize).coerceAtLeast(4))
    }

    /** "Find Region" kutularına tam sayı yazınca, alanı EKRANDA da o konuma taşır/boyutlandırır. */
    private fun moveAndResizeRegion(region: ActiveRegion, x: Int, y: Int, w: Int, h: Int) {
        region.containerParams.x = x
        region.containerParams.y = y
        region.containerParams.width = w + region.handleSizePx
        region.containerParams.height = h + region.handleSizePx
        region.boxParams.width = w
        region.boxParams.height = h
        region.handleParams.leftMargin = w - region.handleSizePx / 2
        region.handleParams.topMargin = h - region.handleSizePx / 2
        try {
            region.frameContainer.requestLayout()
            windowManager?.updateViewLayout(region.container, region.containerParams)
        } catch (e: Exception) {}
        updateLabelPosition(region)
    }

    private fun openHideDeleteMenu(region: ActiveRegion) {
        overlayDialog()
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    region.container.visibility = View.GONE
                    region.label.visibility = View.GONE
                    Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
                } else {
                    deleteRegionCompletely(region)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir alanı hem ekrandan hem (kaydedilmiş bir kuralsa) kayıtlı veriden tamamen siler. */
    private fun deleteRegionCompletely(region: ActiveRegion) {
        val gateGroupId = region.isGateForGroupId
        if (gateGroupId != null) {
            val group = ActionGroupStorage.load(this).find { it.id == gateGroupId }
            if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
        } else {
            region.existingRuleId?.let { id ->
                when (val scope = region.saveScope) {
                    is SaveScope.MainFlow -> { RuleStorage.deleteRule(this, id); RuleStorage.deleteRule(this, "$id-fail") }
                    is SaveScope.Group -> { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, id); ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail") }
                    is SaveScope.Function -> { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, id); FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail") }
                }
            }
        }
        removeRegionWindow(region)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
    }

    private fun removeRegionWindow(region: ActiveRegion) {
        try { windowManager?.removeView(region.container) } catch (e: Exception) {}
        try { windowManager?.removeView(region.label) } catch (e: Exception) {}
        activeRegions.remove(region)
    }

    private fun clearAllRegionWindows() {
        activeRegions.toList().forEach { removeRegionWindow(it) }
    }

    // ==================== ÇALIŞMA ALANI (workspace) — Macrorify'daki "Draw selected/change working group" ====================

    private data class WorkspaceBox(val box: View, val label: TextView, val boxParams: WindowManager.LayoutParams, val labelParams: WindowManager.LayoutParams)
    private val workspaceBoxes = mutableListOf<WorkspaceBox>()
    private var workspaceHidden = false

    private fun showWorkspaceMenu() {
        val options = mutableListOf("🏠 Ana Akış")
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        var headerCount = 0
        if (workspaceBoxes.isNotEmpty()) {
            options.add(0, if (workspaceHidden) "👁️ Öğeleri Göster" else "🙈 Öğeleri Gizle")
            options.add(1, "🧹 Çalışma Alanı Görünümünü Kapat")
            headerCount = 2
        }
        overlayDialog().setTitle("🗺️ Hangi çalışma alanını göreyim?").setItems(options.toTypedArray()) { _, indexRaw ->
            var index = indexRaw
            if (headerCount > 0) {
                if (index == 0) { toggleWorkspaceHidden(); return@setItems }
                if (index == 1) { clearWorkspace(); return@setItems }
                index -= headerCount
            }
            when {
                index == 0 -> showWorkspaceFor(SaveScope.MainFlow, RuleStorage.load(this), "🏠 Ana Akış")
                index <= functions.size -> {
                    val fn = functions[index - 1]
                    showWorkspaceFor(SaveScope.Function(fn.id), fn.rules, "f{} ${fn.name}")
                }
                else -> {
                    val group = groups[index - 1 - functions.size]
                    showWorkspaceFor(SaveScope.Group(group.id), group.rules, "📦 ${group.name}")
                }
            }
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Çalışma Alanı kutularını (durumu KAYBETMEDEN) gizler/tekrar gösterir. */
    private fun toggleWorkspaceHidden() {
        workspaceHidden = !workspaceHidden
        val vis = if (workspaceHidden) View.GONE else View.VISIBLE
        workspaceBoxes.forEach { it.box.visibility = vis; it.label.visibility = vis }
        Toast.makeText(this, if (workspaceHidden) "🙈 Öğeler gizlendi (hâlâ ekranda kayıtlı)" else "👁️ Öğeler tekrar gösteriliyor", Toast.LENGTH_SHORT).show()
    }

    /** Seçilen kapsamdaki TÜM kuralların alanlarını, salt-okunur (dokununca düzenlemeye açılan) kutular olarak ekrana çizer — KALICI kalır. */
    private fun showWorkspaceFor(scope: SaveScope, rules: List<RuleDefinition>, label: String) {
        clearWorkspace()
        workspaceHidden = false
        val visible = rules.filter { !it.id.endsWith("-fail") && it.alternatives.isNotEmpty() }
        if (visible.isEmpty()) {
            Toast.makeText(this, "$label içinde henüz alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        visible.forEach { rule -> addWorkspaceBox(rule, scope) }
        Toast.makeText(this, "$label — ${visible.size} alan gösteriliyor (dokununca düzenlenir, kapatmak için tekrar 🗺️)", Toast.LENGTH_LONG).show()
    }

    private fun addWorkspaceBox(rule: RuleDefinition, scope: SaveScope) {
        val alt = rule.alternatives.first()
        val box = View(this).apply { background = borderDrawable(Color.parseColor("#FFA500")) } // turuncu = salt-okunur çalışma alanı kutusu
        val boxParams = WindowManager.LayoutParams(
            alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }

        val label = TextView(this).apply {
            text = "🗺️ ${rule.name}"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AAFFA500"))
            textSize = 10f
            setPadding(6, 2, 6, 2)
        }
        val density = resources.displayMetrics.density
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = alt.x
            y = (alt.y - 24 * density).toInt().coerceAtLeast(0)
        }

        box.setOnClickListener { /* no-op, dokunuşu ACTION_DOWN'da yakalıyoruz */ }
        box.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                clearWorkspace()
                editExistingRule(rule, scope)
            }
            true
        }

        try {
            windowManager?.addView(box, boxParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(box, label, boxParams, labelParams))
        } catch (e: Exception) {
            android.util.Log.e("BigBossWorkspace", "Kutu eklenemedi: ${rule.name}", e)
            Toast.makeText(this, "⚠️ '${rule.name}' gösterilemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun clearWorkspace() {
        workspaceBoxes.forEach {
            try { windowManager?.removeView(it.box) } catch (e: Exception) {}
            try { windowManager?.removeView(it.label) } catch (e: Exception) {}
        }
        workspaceBoxes.clear()
        workspaceHidden = false
    }

    // ==================== 👆 Dokunma/Kaydırma Noktası İşaretçisi (Macrorify'daki gibi sürüklenebilir parmak simgesi) ====================

    /** Şu an ekranda duran (henüz onaylanmamış) nokta işaretçisi ve onay butonu. */
    private var pointMarkerContainer: View? = null
    private var pointMarkerParams: WindowManager.LayoutParams? = null
    private var pointMarkerConfirmBtn: View? = null
    private var pointMarkerConfirmParams: WindowManager.LayoutParams? = null

    /**
     * Ekranda sürüklenebilir bir 👆 işaretçi gösterir (isteğe bağlı "1"/"2" etiketiyle).
     * Kullanıcı işaretçiyi istediği yere sürükler, ayrı duran "✓ Onayla" butonuna basınca
     * o anki TAM konum (markerSize/2 merkez alınarak) geri döner.
     */
    private fun pickPointWithMarker(badgeLabel: String, initialX: Int?, initialY: Int?, onConfirmed: (Int, Int) -> Unit) {
        removePointMarker() // önceki iz kaldıysa temizle
        val density = resources.displayMetrics.density
        val frame = ScreenCaptureService.latestFrame
        val markerSize = (56 * density).toInt()
        val startX = (initialX ?: ((frame?.width ?: 1080) / 2)) - markerSize / 2
        val startY = (initialY ?: ((frame?.height ?: 1920) / 2)) - markerSize / 2

        val icon = TextView(this).apply {
            text = "👆"; textSize = 30f; gravity = Gravity.CENTER
            layoutParams = android.widget.FrameLayout.LayoutParams(markerSize, markerSize)
        }
        val badge = TextView(this).apply {
            text = badgeLabel
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD2196F3"))
            textSize = 11f
            setPadding(10, 2, 10, 2)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.END }
        }
        val markerContainer = android.widget.FrameLayout(this).apply {
            addView(icon); addView(badge)
        }
        val markerParams = WindowManager.LayoutParams(
            markerSize, markerSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = startX; y = startY }

        val confirmBtn = Button(this).apply { text = "✓ $badgeLabel Noktasını Onayla" }
        val confirmParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 100 }

        windowManager?.addView(markerContainer, markerParams)
        windowManager?.addView(confirmBtn, confirmParams)
        pointMarkerContainer = markerContainer; pointMarkerParams = markerParams
        pointMarkerConfirmBtn = confirmBtn; pointMarkerConfirmParams = confirmParams

        var downRawX = 0f; var downRawY = 0f; var startPX = 0; var startPY = 0
        markerContainer.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downRawX = event.rawX; downRawY = event.rawY; startPX = markerParams.x; startPY = markerParams.y }
                MotionEvent.ACTION_MOVE -> {
                    markerParams.x = startPX + (event.rawX - downRawX).toInt()
                    markerParams.y = startPY + (event.rawY - downRawY).toInt()
                    try { windowManager?.updateViewLayout(markerContainer, markerParams) } catch (e: Exception) {}
                }
            }
            true
        }

        confirmBtn.setOnClickListener {
            val finalX = markerParams.x + markerSize / 2
            val finalY = markerParams.y + markerSize / 2
            removePointMarker()
            onConfirmed(finalX, finalY)
        }

        Toast.makeText(this, "👆 $badgeLabel — işaretçiyi istediğin yere sürükle, sonra \"✓ Onayla\"ya bas", Toast.LENGTH_LONG).show()
    }

    private fun removePointMarker() {
        pointMarkerContainer?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerConfirmBtn?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerContainer = null; pointMarkerParams = null
        pointMarkerConfirmBtn = null; pointMarkerConfirmParams = null
    }

    // ==================== Ekrana dokunarak nokta/renk seçme (tam ekran yakalayıcı — sadece renk örneklemede kullanılıyor) ====================

    private fun armColorPick(region: ActiveRegion) {
        pendingPick = PendingPick.ColorPick(region)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
        Toast.makeText(this, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    private fun armActionPoint(region: ActiveRegion, target: String) {
        val badge = if (target.contains("SWIPE_START")) "1" else if (target.contains("SWIPE_END")) "2" else "👆"
        val initial: Pair<Int, Int>? = when (target) {
            "TAP" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_START" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_END" -> if (region.actionX2 != 0 || region.actionY2 != 0) region.actionX2 to region.actionY2 else null
            else -> null
        }
        pickPointWithMarker(badge, initial?.first, initial?.second) { bx, by ->
            applyActionPoint(region, target, bx, by)
        }
    }

    private fun applyActionPoint(region: ActiveRegion, target: String, bx: Int, by: Int) {
        var reopenDialog = true
        when (target) {
            "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
            "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
            "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
            "EXTRA_TAP_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_TAP_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_SWIPE_START_SUCCESS" -> {
                if (pendingExtraActionIndex in region.extraActions.indices) {
                    region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_SUCCESS")
            }
            "EXTRA_SWIPE_END_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x2 = bx; region.extraActions[pendingExtraActionIndex].y2 = by
            }
            "EXTRA_SWIPE_START_FAIL" -> {
                if (pendingExtraActionIndex in region.onFailActions.indices) {
                    region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_FAIL")
            }
            "EXTRA_SWIPE_END_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x2 = bx; region.onFailActions[pendingExtraActionIndex].y2 = by
            }
        }
        if (reopenDialog) openRegionConfigDialog(region)
    }

    private fun showTouchCatcher(onTap: (Int, Int) -> Unit) {
        val catcher = View(this)
        val catcherParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val bx = event.rawX.toInt(); val by = event.rawY.toInt()
                try { windowManager?.removeView(catcher) } catch (e: Exception) {}
                colorPickCatcher = null
                onTap(bx, by)
            }
            true
        }
        colorPickCatcher = catcher
        windowManager?.addView(catcher, catcherParams)
    }

    private fun handlePointCaught(bx: Int, by: Int) {
        val pick = pendingPick ?: return
        pendingPick = null
        val frame = ScreenCaptureService.latestFrame
        when (pick) {
            is PendingPick.ColorPick -> {
                val region = pick.region as ActiveRegion
                val color = frame?.let {
                    if (bx in 0 until it.width && by in 0 until it.height) it.getPixel(bx, by) else Color.BLACK
                } ?: Color.BLACK
                showColorConfirm(region, color, bx, by)
            }
        }
    }

    private fun showColorConfirm(region: ActiveRegion, color: Int, bx: Int, by: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and color)
        val swatch = View(this).apply { setBackgroundColor(color) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@OverlayService).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        overlayDialog()
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = color
                openRegionConfigDialog(region)
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region) }
            .create().showOverlay()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: ActiveRegion) {
        var currentTab = "WHAT" // WHAT (ne aranacak) | DO (ne yapılacak: aksiyon+başarılı) | ADVANCED (bulunamazsa+tekrar)
        val density = resources.displayMetrics.density
        // Araştırma: MacroDroid (10M+ kurulum) "Tetikleyici → Aksiyon → Kısıt" 3 adımlı
        // sihirbaz modeliyle basitliğiyle övülüyor. Bizim eski 5 küçük sekmemiz (aynı anda
        // eşit ağırlıkta GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR) bu kanıtlanmış modelden
        // uzaktı. Şimdi AYNI 3 adım: "Ne Aranacak" (Tetikleyici) → "Ne Yapılacak" (Aksiyon,
        // içinde Başarılı Olunca ek adımları da var) → "Gelişmiş" (Bulunamazsa + Tekrar, ikisi
        // de İSTEĞE BAĞLI olduğu için tek yerde). Hiçbir özellik kaybolmadı, sadece gruplama
        // MacroDroid'in kanıtlanmış zihinsel modeline göre yeniden düzenlendi.
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tabButton(icon: String, label: String) = Button(this).apply {
            text = "$icon\n$label"; textSize = 12f; setPadding(4, (14 * density).toInt(), 4, (14 * density).toInt())
            isAllCaps = false
        }
        val tabWhat = tabButton("🔍", "1. Ne Aranacak")
        val tabDo = tabButton("⚡", "2. Ne Yapılacak")
        val tabAdvanced = tabButton("⚙️", "Gelişmiş")
        listOf(tabWhat, tabDo, tabAdvanced).forEach { tabRow.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabRow) }

        val autoSaveLabel = TextView(this).apply {
            text = "💾 Otomatik kaydediliyor — Kaydet'e basmana gerek yok"; textSize = 11f; setTextColor(Color.parseColor("#4CAF50"))
            setPadding((16 * density).toInt(), (8 * density).toInt(), (16 * density).toInt(), 0)
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * density).toInt(), (16 * density).toInt(), (20 * density).toInt(), 0) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabBar); addView(autoSaveLabel); addView(content) }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("✓ Bitir", null)
            .setNeutralButton("🗑 Sil", null)
            .setNegativeButton("Kapat (kaydeder)", null)
            .create()

        fun autoSave() {
            if (region !in activeRegions) return
            val gateGroupId = region.isGateForGroupId
            if (gateGroupId != null) saveRegionAsGate(region, gateGroupId, silent = true)
            else saveRegionAsRule(region, silent = true)
        }

        fun sectionHeader(text: String) = TextView(this).apply {
            this.text = text; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(ACCENT); setPadding(0, (20 * density).toInt(), 0, (8 * density).toInt())
        }
        fun divider() = View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt()).apply { topMargin = (12 * density).toInt() }
        }

        fun highlight() {
            listOf(tabWhat to "WHAT", tabDo to "DO", tabAdvanced to "ADVANCED").forEach { (b, k) ->
                if (k == currentTab) {
                    b.setTextColor(Color.WHITE)
                    b.setBackgroundColor(ACCENT)
                } else {
                    b.setTextColor(Color.DKGRAY)
                    b.setBackgroundColor(Color.parseColor("#EEEEEE"))
                }
            }
        }
        fun render() {
            region.onRectChangedListeners.clear()
            region.onRectChangedListeners.add { autoSave() }
            content.removeAllViews()
            when (currentTab) {
                "WHAT" -> buildGeneralTab(region, content, dialog)
                "DO" -> {
                    content.addView(sectionHeader("⚡ Aksiyon — bulununca ne yapılsın?"))
                    buildActionTab(region, content, dialog)
                    content.addView(divider())
                    content.addView(sectionHeader("✅ Ardından sırayla (isteğe bağlı ek adımlar)"))
                    buildExtraTab(region, content, dialog, false)
                }
                "ADVANCED" -> {
                    content.addView(sectionHeader("❌ Bulunamazsa (isteğe bağlı)"))
                    buildExtraTab(region, content, dialog, true)
                    content.addView(divider())
                    content.addView(sectionHeader("🔁 Tekrar / Döngü Davranışı"))
                    buildLoopTab(region, content)
                }
            }
            highlight()
        }
        fun switchTab(tab: String) { autoSave(); currentTab = tab; render() }
        tabWhat.setOnClickListener { switchTab("WHAT") }
        tabDo.setOnClickListener { switchTab("DO") }
        tabAdvanced.setOnClickListener { switchTab("ADVANCED") }

        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.setOnShowListener {
            render()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val gateGroupId = region.isGateForGroupId
                val saved = if (gateGroupId != null) saveRegionAsGate(region, gateGroupId) else saveRegionAsRule(region)
                if (saved) {
                    dialog.dismiss()
                    removeRegionWindow(region)
                    region.onSavedCallback?.invoke()
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                val scope = region.saveScope
                val gateGroupId2 = region.isGateForGroupId
                if (gateGroupId2 != null) {
                    val group = ActionGroupStorage.load(this).find { it.id == gateGroupId2 }
                    if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
                } else when (scope) {
                    is SaveScope.MainFlow -> region.existingRuleId?.let { RuleStorage.deleteRule(this, it) }
                    is SaveScope.Group -> region.existingRuleId?.let { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, it) }
                    is SaveScope.Function -> region.existingRuleId?.let { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, it) }
                }
                removeRegionWindow(region)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
            }
        }
        dialog.setOnDismissListener {
            // "Kapat" veya geri tuşu/dışarı dokunmayla kapandıysa: veriler ZATEN kayıtlı,
            // sadece alan EKRANDA KALSIN (istersen tekrar dokunup düzenlemeye devam edersin).
            autoSave()
        }
        dialog.show()
    }

    /** Bir alanı Action Group'un KAPI koşulu olarak kaydeder — sadece GENEL sekmesindeki koşul + cooldown kullanılır. */
    private fun saveRegionAsGate(region: ActiveRegion, groupId: String, silent: Boolean = false): Boolean {
        val group = ActionGroupStorage.load(this).find { it.id == groupId } ?: return false
        val r = regionRect(region)
        val gateAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { if (!silent) Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { if (!silent) Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        group.gate = gateAlt
        group.gateCooldownMs = region.cooldownMs
        ActionGroupStorage.upsert(this, group)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kapı koşulu kaydedildi: ${group.name}", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun buildGeneralTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Kural adı"; setText(region.name) }
        nameInput.addTextChangedListener(simpleWatcher { region.name = it })
        content.addView(nameInput)

        content.addView(TextView(ctx).apply { text = "Bu alanda ne aranacak?"; setPadding(0, 16, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD) })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk"; id = 1 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR)"; id = 3 }
        listOf(rbColor, rbImage, rbText).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    val path = region.conditionTemplatePath
                    if (!path.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(path)
                        if (bmp != null) iv.setImageBitmap(bmp)
                        sub.addView(TextView(ctx).apply { text = "Seçili resim:" })
                        sub.addView(iv)
                    } else {
                        sub.addView(TextView(ctx).apply { text = "Henüz resim seçilmedi — aşağıdan kütüphaneden seç ya da ekrandan kendin kırp." })
                    }
                    val btnLib = Button(ctx).apply { text = "📚 Kütüphaneden Seç" }
                    btnLib.setOnClickListener { pickFromLibrary(region) { renderSub() } }
                    sub.addView(btnLib)
                    val btnCropSelf = Button(ctx).apply { text = "✂️ Ekrandan Kendim Kırpacağım" }
                    btnCropSelf.setOnClickListener {
                        val r2 = regionRect(region)
                        val cropped = ScreenCaptureService.latestFrame?.let { safeCrop(it, r2[0], r2[1], r2[2], r2[3]) }
                        if (cropped == null) {
                            Toast.makeText(ctx, "Kırpılamadı, alan çok küçük olabilir", Toast.LENGTH_SHORT).show()
                        } else {
                            val nameInput = EditText(ctx).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
                            overlayDialog().setTitle("Bu resmi kaydet").setView(nameInput)
                                .setPositiveButton("Kaydet") { _, _ ->
                                    val name = nameInput.text.toString().ifBlank { "İsimsiz görsel" }
                                    val savedPath = TemplateStorage.save(ctx, cropped)
                                    LibraryStorage.add(ctx, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, savedPath))
                                    region.conditionTemplatePath = savedPath
                                    Toast.makeText(ctx, "Kütüphaneye eklendi ve seçildi: $name", Toast.LENGTH_SHORT).show()
                                    renderSub()
                                }
                                .setNegativeButton("Vazgeç", null)
                                .create().showOverlay()
                        }
                    }
                    sub.addView(btnCropSelf)
                    addMinScoreControls(ctx, sub, region)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.addTextChangedListener(simpleWatcher { region.conditionText = it })
                    sub.addView(input)
                    sub.addView(TextView(ctx).apply {
                        text = "Tolerans — OCR net okuyamayabilir, düşük skor daha esnek olur:"
                        textSize = 11f; setPadding(0, 12, 0, 0)
                    })
                    addMinScoreControls(ctx, sub, region)
                }
                else -> {
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply { text = String.format(" #%06X", 0xFFFFFF and region.conditionColor) })
                    sub.addView(row)
                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armColorPick(region) }
                    sub.addView(btnPick)
                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.addTextChangedListener(simpleWatcher { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) { region.conditionColor = parsed; swatch.setBackgroundColor(parsed) }
                    })
                    sub.addView(hexInput)
                    addMinScoreControls(ctx, sub, region)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; else -> "COLOR" }
            renderSub()
        }

        // ---- Bekleme süresi (cooldown) + Eşleşme sonrası Delay ----
        content.addView(TextView(ctx).apply {
            text = "ZAMANLAMA"; setPadding(0, 24, 0, 0); setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(TEXT_PRIMARY); textSize = 13f
        })
        content.addView(styledField(
            "BEKLEME SÜRESİ (ms)", "Tetiklendikten sonra tekrar tetiklenmeden önce en az ne kadar beklesin",
            region.cooldownMs.toString()
        ) { region.cooldownMs = it.toLongOrNull() ?: 300 })
        content.addView(styledField(
            "DELAY (ms)", "Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre",
            region.matchDelayMs.toString()
        ) { region.matchDelayMs = it.toLongOrNull() ?: 0 })
        content.addView(styledField(
            "TARAMA SÜRESİ (ms)", "Aksiyonu tetiklemeden önce EN AZ bu kadar süre KESİNTİSİZ eşleşmeli (yanlış pozitifleri eler). 0 = anında tetikle",
            region.scanTimeoutMs.toString()
        ) { region.scanTimeoutMs = it.toLongOrNull()?.coerceAtLeast(0) ?: 0 })
        content.addView(styledField(
            "RASTGELE ŞANS (%)", "Eşleşme bulunsa bile sadece bu yüzdelik ihtimalle tetiklenir. 100 = her zaman (kapalı)",
            region.randomChancePercent.toString()
        ) { region.randomChancePercent = it.toIntOrNull()?.coerceIn(0, 100) ?: 100 })

        // ---- Find Region: X/Y/Genişlik/Yükseklik — değiştirince alan EKRANDA da taşınır/boyutlanır ----
        content.addView(TextView(ctx).apply {
            text = "Find Region (alanın ekrandaki konumu)"; setPadding(0, 20, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val r = regionRect(region)
        val etX = EditText(ctx).apply { hint = "X"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[0].toString()) }
        val etY = EditText(ctx).apply { hint = "Y"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[1].toString()) }
        val etW = EditText(ctx).apply { hint = "Genişlik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[2].toString()) }
        val etH = EditText(ctx).apply { hint = "Yükseklik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[3].toString()) }
        val findRegionRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etX, etY).forEach { findRegionRow1.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val findRegionRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etW, etH).forEach { findRegionRow2.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        content.addView(findRegionRow1)
        content.addView(findRegionRow2)

        var suppressFindRegionSync = false
        fun applyFindRegionToScreen() {
            if (suppressFindRegionSync) return
            val x = etX.text.toString().toIntOrNull() ?: return
            val y = etY.text.toString().toIntOrNull() ?: return
            val w = etW.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            val h = etH.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            moveAndResizeRegion(region, x, y, w, h)
        }
        listOf(etX, etY, etW, etH).forEach { it.addTextChangedListener(simpleWatcher { applyFindRegionToScreen() }) }
        region.onRectChangedListeners.add {
            suppressFindRegionSync = true
            val r2 = regionRect(region)
            etX.setText(r2[0].toString()); etY.setText(r2[1].toString())
            etW.setText(r2[2].toString()); etH.setText(r2[3].toString())
            suppressFindRegionSync = false
        }
    }

    private fun addMinScoreControls(ctx: android.content.Context, sub: LinearLayout, region: ActiveRegion) {
        val density = resources.displayMetrics.density
        val label = TextView(ctx).apply {
            text = "MIN SKOR (%)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, (14 * density).toInt(), 0, 0)
        }
        var suppress = false
        val numberInput = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(region.minScore.toString())
            textSize = 15f; setTextColor(TEXT_PRIMARY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        val seek = SeekBar(ctx).apply {
            max = 100; progress = region.minScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    region.minScore = v
                    if (fromUser) { suppress = true; numberInput.setText(v.toString()); suppress = false }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        numberInput.addTextChangedListener(simpleWatcher { text ->
            if (suppress) return@simpleWatcher
            val v = text.toIntOrNull()?.coerceIn(0, 100) ?: return@simpleWatcher
            region.minScore = v; seek.progress = v
        })
        sub.addView(label); sub.addView(numberInput); sub.addView(seek)
    }

    private fun pickFromLibrary(region: ActiveRegion, onDone: () -> Unit) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        overlayDialog()
            .setTitle("Seç")
            .setItems(labels) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") { region.conditionKind = "IMAGE"; region.conditionTemplatePath = item.templatePath }
                else { region.conditionKind = "COLOR"; region.conditionColor = item.color }
                onDone()
            }
            .create().showOverlay()
    }

    private fun buildActionTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbTap = android.widget.RadioButton(ctx).apply { text = "👆 Dokunma"; id = 1 }
        val rbSwipe = android.widget.RadioButton(ctx).apply { text = "👉 Kaydırma"; id = 2 }
        val rbFunc = android.widget.RadioButton(ctx).apply { text = "🔧 Fonksiyon Çağır"; id = 3 }
        val rbSystem = android.widget.RadioButton(ctx).apply { text = "🔙 Sistem (Geri/Ana Ekran/vb)"; id = 4 }
        listOf(rbTap, rbSwipe, rbFunc, rbSystem).forEach { radioGroup.addView(it) }
        radioGroup.check(when { region.actionType == "SWIPE" -> 2; region.actionType == "CALL_FUNCTION" -> 3; region.actionType.startsWith("SYSTEM_") -> 4; else -> 1 })
        content.addView(radioGroup)
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        // "Randomize" — Dokunma/Kaydırma noktalarına küçük rastgele sapma (daha insani, tespit-karşıtı).
        content.addView(TextView(ctx).apply {
            text = "🎲 Rastgele Sapma (px) — her noktaya ± bu kadar rastgele kaydırma eklenir (0 = kapalı, tam nokta):"
            textSize = 11f; setPadding(0, 16, 0, 0)
        })
        val randomInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(region.randomOffsetPx.toString()) }
        randomInput.addTextChangedListener(simpleWatcher { region.randomOffsetPx = it.toIntOrNull()?.coerceAtLeast(0) ?: 0 })
        content.addView(randomInput)

        fun renderSub() {
            sub.removeAllViews()
            when (region.actionType) {
                "SWIPE" -> {
                    sub.addView(TextView(ctx).apply { text = "Başlangıç: (${region.actionX}, ${region.actionY})" })
                    val btnStart = Button(ctx).apply { text = "📍 Başlangıç Noktasını Seç" }
                    btnStart.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_START") }
                    sub.addView(btnStart)
                    sub.addView(TextView(ctx).apply { text = "Bitiş: (${region.actionX2}, ${region.actionY2})" })
                    val btnEnd = Button(ctx).apply { text = "📍 Bitiş Noktasını Seç" }
                    btnEnd.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_END") }
                    sub.addView(btnEnd)

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD (başlangıç) — hareket etmeden önce kaç ms basılı beklesin (sürükle-bırak için):",
                        region.swipeHoldStartMs, region.swipeHoldStartVarName,
                        { region.swipeHoldStartMs = it }, { region.swipeHoldStartVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD (bitiş) — vardıktan sonra parmağı kaldırmadan önce kaç ms daha beklesin:",
                        region.swipeHoldEndMs, region.swipeHoldEndVarName,
                        { region.swipeHoldEndMs = it }, { region.swipeHoldEndVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ DELAY — kaydırma tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:",
                        region.actionPostDelayMs, region.actionPostDelayVarName,
                        { region.actionPostDelayMs = it }, { region.actionPostDelayVarName = it })
                }
                "CALL_FUNCTION" -> {
                    sub.addView(TextView(ctx).apply { text = if (region.callFunctionName.isNotBlank()) "Seçili: f{} ${region.callFunctionName}" else "Henüz seçilmedi" })
                    val btnPick = Button(ctx).apply { text = "🔧 Fonksiyon Seç/Oluştur" }
                    btnPick.setOnClickListener { pickOrCreateFunction(region) { renderSub() } }
                    sub.addView(btnPick)
                    val repeatInput = EditText(ctx).apply {
                        hint = "Kaç kere çalışsın"; inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.callFunctionRepeat.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.callFunctionRepeat = it.toIntOrNull() ?: 1 })
                    sub.addView(repeatInput)
                }
                "SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS" -> {
                    sub.addView(TextView(ctx).apply { text = "Hangi sistem aksiyonu çalışsın?"; setPadding(0, 8, 0, 8) })
                    val sysRadio = android.widget.RadioGroup(ctx)
                    val opts = listOf(
                        "SYSTEM_BACK" to "🔙 Geri Tuşu",
                        "SYSTEM_HOME" to "🏠 Ana Ekran",
                        "SYSTEM_RECENTS" to "🗂️ Son Uygulamalar",
                        "SYSTEM_NOTIFICATIONS" to "🔔 Bildirim Paneli",
                        "SYSTEM_QUICK_SETTINGS" to "⚡ Hızlı Ayarlar"
                    )
                    opts.forEachIndexed { i, (type, label) ->
                        val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1 }
                        if (region.actionType == type) sysRadio.check(i + 1)
                        sysRadio.addView(rb)
                    }
                    sysRadio.setOnCheckedChangeListener { _, checkedId -> region.actionType = opts[checkedId - 1].first }
                    sub.addView(sysRadio)
                }
                else -> {
                    val matchRadio = android.widget.RadioGroup(ctx)
                    val rbFixed = android.widget.RadioButton(ctx).apply { text = "📍 Sabit Nokta"; id = 1 }
                    val rbMatch = android.widget.RadioButton(ctx).apply { text = "🎯 Eşleşen Noktaya Tıkla"; id = 2 }
                    listOf(rbFixed, rbMatch).forEach { matchRadio.addView(it) }
                    matchRadio.check(if (region.tapAtMatchLocation) 2 else 1)
                    sub.addView(matchRadio)

                    val pointInfo = TextView(ctx).apply {
                        text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                    }
                    sub.addView(pointInfo)
                    val btnPick = Button(ctx).apply {
                        text = "📍 Dokunulacak Noktayı Seç"
                        visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }
                    btnPick.setOnClickListener { dialog.dismiss(); armActionPoint(region, "TAP") }
                    sub.addView(btnPick)
                    matchRadio.setOnCheckedChangeListener { _, checkedId ->
                        region.tapAtMatchLocation = checkedId == 2
                        pointInfo.text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                        btnPick.visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }

                    sub.addView(TextView(ctx).apply { text = "Tekrar sayısı (kaç kere tıklansın):"; setPadding(0, 12, 0, 0) })
                    val repeatInput = EditText(ctx).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.actionRepeatCount.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.actionRepeatCount = it.toIntOrNull()?.coerceAtLeast(1) ?: 1 })
                    sub.addView(repeatInput)

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD — noktada kaç ms basılı tutulsun (uzun basış için artır):",
                        region.actionHoldMs, region.actionHoldVarName,
                        { region.actionHoldMs = it }, { region.actionHoldVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ DELAY — bu işlem tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:",
                        region.actionPostDelayMs, region.actionPostDelayVarName,
                        { region.actionPostDelayMs = it }, { region.actionPostDelayVarName = it })
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.actionType = when (checkedId) {
                2 -> "SWIPE"
                3 -> "CALL_FUNCTION"
                4 -> if (region.actionType.startsWith("SYSTEM_")) region.actionType else "SYSTEM_BACK"
                else -> "TAP"
            }
            renderSub()
        }
    }

    private fun pickOrCreateFunction(region: ActiveRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        overlayDialog().setItems(options.toTypedArray()) { _, index ->
            if (index == 0) {
                val input = EditText(this).apply { hint = "Fonksiyon adı" }
                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                    .setPositiveButton("Oluştur") { _, _ ->
                        val name = input.text.toString().ifBlank { "fonksiyon" }
                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                        FunctionStorage.upsert(this, fn)
                        region.callFunctionId = fn.id; region.callFunctionName = fn.name
                        onDone()
                    }.create().showOverlay()
            } else if (index <= functions.size) {
                val fn = functions[index - 1]
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            } else {
                val group = groups[index - 1 - functions.size]
                region.callFunctionId = group.id; region.callFunctionName = "📦 ${group.name}"
                onDone()
            }
        }.create().showOverlay()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki bir dokunma/kaydırma adımının HOLD süresini düzenler. */
    private fun showHoldEditDialog(extra: ExtraAction, onDone: () -> Unit) {
        val ctx = this
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        if (extra.type == "TAP") {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD — noktada kaç ms basılı tutulsun:" })
            val input = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.holdMs.toString()) }
            container.addView(input)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süresi").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.holdMs = input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        } else {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (başlangıç) — hareket etmeden önce kaç ms beklesin:" })
            val startInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldStartMs.toString()) }
            container.addView(startInput)
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (bitiş) — vardıktan sonra kaç ms daha beklesin:"; setPadding(0, 16, 0, 0) })
            val endInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldEndMs.toString()) }
            container.addView(endInput)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süreleri").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.swipeHoldStartMs = startInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.swipeHoldEndMs = endInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        }
    }

    /** BAŞARILI OLUNCA / BULUNAMAZSA listeleri için tek kullanımlık kopyala/kes panosu. */
    /**
     * "🔍 Tarama Alanı Ekle" (BAŞARILI/BULUNAMAZSA listesinde): ekrana koşullu bir
     * alan çizdirir, otomatik bir Fonksiyona kaydeder, sonra o Fonksiyonu çağıran
     * bir "🔧 Fonksiyon Çağır" adımını listeye ekler — böylece sıra içinde
     * GERÇEK bir koşullu tespit (iç içe tarama) yapılabilir.
     */
    private fun startExtraTabScan(callerRegion: ActiveRegion, list: MutableList<ExtraAction>, label: String) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val fnName = "🔍 ${callerRegion.name.ifBlank { "Tarama" }} → $label"
        val fn = FunctionDefinition(UUID.randomUUID().toString(), fnName)
        FunctionStorage.upsert(this, fn)
        val scanRegion = addRegionWindow()
        scanRegion.saveScope = SaveScope.Function(fn.id)
        scanRegion.label.text = "🔍 $label → yeni tarama"
        scanRegion.onSavedCallback = {
            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
            com.bigboss.app.storage.EngineAssembler.refresh(this)
            Toast.makeText(this, "Tarama eklendi: ${fn.name}", Toast.LENGTH_SHORT).show()
            openRegionConfigDialog(callerRegion)
        }
        Toast.makeText(this, "Bu alan \"$label\" listesine bir TARAMA (koşullu tespit) olarak eklenecek", Toast.LENGTH_LONG).show()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki dokunma/kaydırma noktalarını VE tarama alanlarını ekranda gösterir (Çalışma Alanı ile aynı mekanizma). */
    private fun showExtraListOnScreen(list: List<ExtraAction>, label: String) {
        clearWorkspace()
        var count = 0
        list.forEachIndexed { i, extra ->
            when (extra.type) {
                "TAP" -> { addWorkspacePointDot(extra.x, extra.y, "👆${i + 1}"); count++ }
                "SWIPE" -> {
                    addWorkspacePointDot(extra.x, extra.y, "1️⃣${i + 1}")
                    addWorkspacePointDot(extra.x2, extra.y2, "2️⃣${i + 1}")
                    count++
                }
                "CALL_FUNCTION" -> {
                    val fnRules = FunctionStorage.load(this).find { it.id == extra.functionId }?.rules
                        ?: ActionGroupStorage.load(this).find { it.id == extra.functionId }?.rules
                    fnRules?.filter { !it.id.endsWith("-fail") && it.alternatives.isNotEmpty() }?.forEach { r ->
                        addWorkspaceBox(r, SaveScope.Function(extra.functionId ?: ""))
                        count++
                    }
                }
            }
        }
        if (count == 0) Toast.makeText(this, "$label listesinde gösterilecek nokta/alan yok", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "$label listesi ekranda gösteriliyor ($count öğe) — 🗺️ Çalışma Alanı'ndan kapatabilirsin", Toast.LENGTH_LONG).show()
    }

    /** Salt-okunur, küçük bir NOKTA işaretçisi (TAP/SWIPE noktalarını göstermek için) — Çalışma Alanı mekanizmasını paylaşır. */
    private fun addWorkspacePointDot(px: Int, py: Int, labelText: String) {
        val density = resources.displayMetrics.density
        val dotSize = (18 * density).toInt()
        val dot = View(this).apply { background = borderDrawable(Color.parseColor("#FFEB3B"), 4f) }
        val dotParams = WindowManager.LayoutParams(
            dotSize, dotSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px - dotSize / 2; y = py - dotSize / 2 }
        val label = TextView(this).apply {
            text = labelText
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#DDFFEB3B"))
            textSize = 10f
            setPadding(6, 1, 6, 1)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px - dotSize / 2; y = (py - dotSize / 2 - 24 * density).toInt().coerceAtLeast(0) }
        try {
            windowManager?.addView(dot, dotParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(dot, label, dotParams, labelParams))
        } catch (e: Exception) {
            android.util.Log.e("BigBossWorkspace", "Nokta eklenemedi: $labelText", e)
            Toast.makeText(this, "⚠️ '$labelText' gösterilemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private var extraActionClipboard: ExtraAction? = null

    private fun buildExtraTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog, isFail: Boolean) {
        val ctx = this
        val list = if (isFail) region.onFailActions else region.extraActions
        val suffix = if (isFail) "FAIL" else "SUCCESS"
        val listLabel = if (isFail) "Bulunamazsa" else "Başarılı"
        content.addView(TextView(ctx).apply {
            text = if (isFail) "Bu alan BULUNAMAZSA sırayla yapılacaklar:" else "Birincil aksiyondan SONRA sırayla yapılacaklar:"
            textSize = 12f
        })
        val btnShowOnScreen = Button(ctx).apply { text = "🗺️ Bu Listenin Nokta/Alanlarını Ekranda Göster" }
        btnShowOnScreen.setOnClickListener { showExtraListOnScreen(list, listLabel) }
        content.addView(btnShowOnScreen)

        val selectedIndices = mutableSetOf<Int>()
        val inflater = android.view.LayoutInflater.from(ctx)
        val listView = android.widget.ListView(ctx)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val extra = list[position]
                val (icon, desc) = when (extra.type) {
                    "CALL_FUNCTION" -> "🔧" to "f{} ${extra.functionName} x${extra.repeat}"
                    "SWIPE" -> "👉" to "(${extra.x},${extra.y})→(${extra.x2},${extra.y2})"
                    "WAIT" -> "⏱️" to "Bekle ${extra.waitMs}ms"
                    "SET_VARIABLE" -> "(x)" to "${extra.variableName} += ${extra.variableDelta}"
                    "RUN_SCRIPT" -> "🖥️" to extra.scriptName
                    "SYSTEM_BACK" -> "🔙" to "Geri Tuşu"
                    "SYSTEM_HOME" -> "🏠" to "Ana Ekran"
                    "SYSTEM_RECENTS" -> "🗂️" to "Son Uygulamalar"
                    "SYSTEM_NOTIFICATIONS" -> "🔔" to "Bildirim Paneli"
                    "SYSTEM_QUICK_SETTINGS" -> "⚡" to "Hızlı Ayarlar"
                    else -> "👆" to "(${extra.x},${extra.y})"
                }
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "${position + 1}. $desc"
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = if (extra.holdMs != 50L || extra.postDelayMs > 0) "⏱️" else ""
                view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                return view
            }
        }
        listView.adapter = adapter
        styleListDividers(listView)
        listView.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.28).toInt()
        )
        // Kısa dokunuş: dokunma/kaydırma ise HOLD/DELAY düzenlemesini doğrudan açar.
        listView.setOnItemClickListener { _, _, position, _ ->
            val extra = list[position]
            if (extra.type == "TAP" || extra.type == "SWIPE") showHoldEditDialog(extra) { adapter.notifyDataSetChanged() }
            else Toast.makeText(ctx, "Bu adım türü için ek ayar yok — silmek/taşımak için basılı tut", Toast.LENGTH_SHORT).show()
        }
        // Basılı tutma: çoklu seçime ekler/çıkarır (toplu işlemler için).
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
            adapter.notifyDataSetChanged()
            true
        }
        content.addView(listView)
        content.addView(TextView(ctx).apply {
            text = "Dokun = ayarları aç · Basılı tut = çoklu seç (toplu işlem için)"
            textSize = 10f; setTextColor(Color.GRAY); setPadding(16, 4, 16, 8)
        })

        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply { text = label; textSize = 14f; setOnClickListener { onClick() } }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val toolbarRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val toolbarRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        content.addView(toolbarRow1); content.addView(toolbarRow2)

        fun openAddMenu() {
            overlayDialog().setItems(arrayOf(
                "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                "👆 Dokunma Ekle", "👉 Kaydırma Ekle", "⏱️ Bekleme Ekle",
                "🔧 Fonksiyon Çağırma Ekle", "(x) Değişken Ayarla Ekle", "🖥️ Kod Çalıştır Ekle",
                "🔙 Sistem Aksiyonu Ekle (Geri/Ana Ekran/vb)"
            )) { _, indexRaw ->
                val index = indexRaw - 1
                if (indexRaw == 0) {
                    // 🔍 Tarama Alanı: ekrana bir alan çizdirip, otomatik bir Fonksiyona kaydedip listeye "Fonksiyon Çağır" olarak ekler.
                    dialog.dismiss()
                    startExtraTabScan(region, list, if (isFail) "bulunamazsa" else "başarılı")
                    return@setItems
                }
                when (index) {
                    0 -> {
                        list.add(ExtraAction("TAP"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_TAP_$suffix")
                    }
                    1 -> {
                        list.add(ExtraAction("SWIPE"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_SWIPE_START_$suffix")
                    }
                    2 -> {
                        val input = EditText(ctx).apply { hint = "Bekleme (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("500") }
                        overlayDialog().setTitle("Bekleme Süresi").setView(input)
                            .setPositiveButton("Ekle") { _, _ ->
                                list.add(ExtraAction("WAIT", waitMs = input.text.toString().toLongOrNull() ?: 500))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                    }
                    3 -> {
                        val functions = FunctionStorage.load(ctx)
                        val groups = ActionGroupStorage.load(ctx)
                        val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                        opts.addAll(functions.map { "f{} ${it.name}" })
                        opts.addAll(groups.map { "📦 ${it.name}" })
                        overlayDialog().setItems(opts.toTypedArray()) { _, idx2 ->
                            if (idx2 == 0) {
                                val input = EditText(ctx).apply { hint = "Fonksiyon adı" }
                                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                                    .setPositiveButton("Oluştur") { _, _ ->
                                        val name = input.text.toString().ifBlank { "fonksiyon" }
                                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                                        FunctionStorage.upsert(ctx, fn)
                                        list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                        adapter.notifyDataSetChanged()
                                    }.create().showOverlay()
                            } else if (idx2 <= functions.size) {
                                val fn = functions[idx2 - 1]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                adapter.notifyDataSetChanged()
                            } else {
                                val group = groups[idx2 - 1 - functions.size]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = group.id, functionName = "📦 ${group.name}"))
                                adapter.notifyDataSetChanged()
                            }
                        }.create().showOverlay()
                    }
                    4 -> {
                        val nameInput = EditText(ctx).apply { hint = "Değişken/sayaç adı" }
                        val deltaInput = EditText(ctx).apply { hint = "Ne kadar artırılsın (örn. 1, -1)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("1") }
                        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; addView(nameInput); addView(deltaInput) }
                        overlayDialog().setTitle("Değişken Ayarla").setView(box)
                            .setPositiveButton("Ekle") { _, _ ->
                                val vname = nameInput.text.toString().ifBlank { "sayac" }
                                val delta = deltaInput.text.toString().toIntOrNull() ?: 1
                                list.add(ExtraAction("SET_VARIABLE", variableName = vname, variableDelta = delta))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                    }
                    5 -> {
                        val scripts = com.bigboss.app.storage.ScriptStorage.load(ctx)
                        if (scripts.isEmpty()) {
                            Toast.makeText(ctx, "Henüz script yok — önce 🖥️ Kod menüsünden oluştur", Toast.LENGTH_LONG).show()
                        } else {
                            val labels = scripts.map { "🖥️ ${it.name}" }.toTypedArray()
                            overlayDialog().setItems(labels) { _, sIdx ->
                                val s = scripts[sIdx]
                                list.add(ExtraAction("RUN_SCRIPT", scriptId = s.id, scriptName = s.name))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                        }
                    }
                    6 -> {
                        val sysOpts = arrayOf("🔙 Geri Tuşu", "🏠 Ana Ekran", "🗂️ Son Uygulamalar", "🔔 Bildirim Paneli", "⚡ Hızlı Ayarlar")
                        val sysTypes = arrayOf("SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS")
                        overlayDialog().setItems(sysOpts) { _, sIdx ->
                            list.add(ExtraAction(sysTypes[sIdx]))
                            adapter.notifyDataSetChanged()
                        }.create().showOverlay()
                    }
                }
            }.create().showOverlay()
        }

        toolbarRow1.addView(toolBtn("☑️") {
            if (selectedIndices.size == list.size) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(list.indices) }
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("➕") { openAddMenu() }, toolbarParams)
        toolbarRow1.addView(toolBtn("📋") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            extraActionClipboard = list[idx].copy()
            Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("✂️") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            extraActionClipboard = list[idx].copy()
            list.removeAt(idx)
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        }, toolbarParams)

        toolbarRow2.addView(toolBtn("📥") {
            val clip = extraActionClipboard
            if (clip == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            list.add(clip.copy())
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("🗑") {
            if (selectedIndices.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            selectedIndices.sortedDescending().forEach { list.removeAt(it) }
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↑") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            if (idx > 0) {
                val tmp = list[idx - 1]; list[idx - 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx - 1)
                adapter.notifyDataSetChanged()
            }
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↓") {
            val idx = selectedIndices.maxOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            if (idx < list.size - 1) {
                val tmp = list[idx + 1]; list[idx + 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx + 1)
                adapter.notifyDataSetChanged()
            }
        }, toolbarParams)
    }

    private fun buildLoopTab(region: ActiveRegion, content: LinearLayout) {
        val ctx = this
        content.addView(TextView(ctx).apply {
            text = "Bu alan nasıl çalışsın?"
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbNone = android.widget.RadioButton(ctx).apply {
            text = "None — tarama yapar ve durur (bir kere dener, biter)"; id = 1
        }
        val rbAlways = android.widget.RadioButton(ctx).apply {
            text = "Loop Always — sonsuz döngü, hep açık kalır"; id = 2
        }
        val rbWhileSuccess = android.widget.RadioButton(ctx).apply {
            text = "Loop When Success — eşleşmeyi yakalayana kadar bekler, sonra biter"; id = 3
        }
        val rbWhileFail = android.widget.RadioButton(ctx).apply {
            text = "Loop When Fail — eşleşme kayboluncaya kadar devam eder, sonra biter"; id = 4
        }
        listOf(rbNone, rbAlways, rbWhileSuccess, rbWhileFail).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.loopMode) {
            "NONE" -> 1; "WHILE_SUCCESS" -> 3; "WHILE_FAIL" -> 4; else -> 2
        })
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.loopMode = when (checkedId) {
                1 -> "NONE"; 3 -> "WHILE_SUCCESS"; 4 -> "WHILE_FAIL"; else -> "ALWAYS"
            }
        }
        content.addView(radioGroup)
    }

    private fun extraActionToStep(extra: ExtraAction): com.bigboss.app.storage.ActionStep =
        com.bigboss.app.storage.ActionStep(
            type = extra.type, x = extra.x, y = extra.y, x2 = extra.x2, y2 = extra.y2,
            waitMs = extra.waitMs, repeat = extra.repeat, functionId = extra.functionId,
            variableName = extra.variableName, variableDelta = extra.variableDelta,
            scriptId = extra.scriptId,
            scriptCode = extra.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.code },
            holdMs = extra.holdMs, swipeHoldStartMs = extra.swipeHoldStartMs, swipeHoldEndMs = extra.swipeHoldEndMs, postDelayMs = extra.postDelayMs
        )

    private fun saveRegionAsRule(region: ActiveRegion, silent: Boolean = false): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            if (!silent) Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show()
            return false
        }
        val r = regionRect(region)
        val mainAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { if (!silent) Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { if (!silent) Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        val name = region.name.ifBlank { "İsimsiz kural" }
        // ÖNEMLİ: id'yi BİR KERE üretip region'a KALICI olarak yazıyoruz — yoksa her otomatik
        // kaydetmede YENİ bir rastgele id üretilip aynı kuraldan kopyalar oluşurdu.
        val ruleId = region.existingRuleId ?: UUID.randomUUID().toString().also { region.existingRuleId = it }

        // Birincil kural: GENEL/AKSİYON/BAŞARILI/TEKRAR sekmelerindeki her şeyi taşır.
        val def = RuleDefinition(
            id = ruleId, name = name, enabled = true,
            alternatives = mutableListOf(mainAlt),
            timeoutMs = region.cooldownMs,
            matchDelayMs = region.matchDelayMs,
            scanTimeoutMs = region.scanTimeoutMs,
            negateCondition = region.negate,
            loopMode = region.loopMode,
            requireVariableName = region.requireVariableName, requireVariableOp = region.requireVariableOp, requireVariableValue = region.requireVariableValue,
            actionType = region.actionType,
            actionX = region.actionX, actionY = region.actionY, actionX2 = region.actionX2, actionY2 = region.actionY2,
            tapAtMatchLocation = region.tapAtMatchLocation,
            actionRepeatCount = region.actionRepeatCount,
            actionHoldMs = region.actionHoldMs,
            actionPostDelayMs = region.actionPostDelayMs,
            randomOffsetPx = region.randomOffsetPx,
            randomChancePercent = region.randomChancePercent,
            swipeHoldStartMs = region.swipeHoldStartMs,
            swipeHoldEndMs = region.swipeHoldEndMs,
            actionHoldVarName = region.actionHoldVarName,
            actionPostDelayVarName = region.actionPostDelayVarName,
            swipeHoldStartVarName = region.swipeHoldStartVarName,
            swipeHoldEndVarName = region.swipeHoldEndVarName,
            callFunctionId = region.callFunctionId, callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName, incrementVariableDelta = region.incrementVariableDelta,
            extraSteps = region.extraActions.map { extraActionToStep(it) }.toMutableList()
        )

        val scope = region.saveScope
        when (scope) {
            is SaveScope.MainFlow -> RuleStorage.upsert(this, def)
            is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, def)
            is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, def)
        }

        // "BULUNAMAZSA" adımları varsa: AYNI koşulun TERSİYLE tetiklenen, sadece bu adımları çalıştıran ayrı bir kural.
        if (region.onFailActions.isNotEmpty()) {
            val failDef = RuleDefinition(
                id = region.existingRuleId?.let { "$it-fail" } ?: UUID.randomUUID().toString(),
                name = "$name → bulunamazsa", enabled = true,
                alternatives = mutableListOf(mainAlt),
                timeoutMs = region.cooldownMs,
                negateCondition = !region.negate,
                loopMode = region.loopMode,
                actionType = "WAIT", actionX = 0, actionY = 0,
                extraSteps = region.onFailActions.map { extraActionToStep(it) }.toMutableList()
            )
            when (scope) {
                is SaveScope.MainFlow -> RuleStorage.upsert(this, failDef)
                is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, failDef)
                is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, failDef)
            }
        } else {
            // Önceden "bulunamazsa" kuralı vardıysa ve şimdi boşaltıldıysa temizle.
            region.existingRuleId?.let { id ->
                when (scope) {
                    is SaveScope.MainFlow -> RuleStorage.deleteRule(this, "$id-fail")
                    is SaveScope.Group -> ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail")
                    is SaveScope.Function -> FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail")
                }
            }
        }

        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeX = x.coerceIn(0, bitmap.width - 1)
        val safeY = y.coerceIn(0, bitmap.height - 1)
        val safeW = w.coerceAtMost(bitmap.width - safeX)
        val safeH = h.coerceAtMost(bitmap.height - safeY)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ==================== Ana Akış ====================

    private data class MenuRow(val icon: String, val name: String, val extra: String, val onClick: () -> Unit)

    private fun showRowListDialog(title: String, rows: List<MenuRow>, closable: Boolean = true) {
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val row = rows[position]
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = row.icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = row.name
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = row.extra
                return view
            }
        }
        val builder = overlayDialog().setTitle(title).setAdapter(adapter) { _, position -> rows[position].onClick() }
        if (closable) builder.setNegativeButton("Kapat", null)
        builder.create().showOverlay()
    }

    /** Ana Akış listesindeki tek bir öğe: ya bir kural ya bir Action Group. */
    private sealed class AnaAkisEntry {
        data class Rule(val rule: RuleDefinition) : AnaAkisEntry()
        data class Group(val group: com.bigboss.app.storage.ActionGroupDefinition) : AnaAkisEntry()
    }

    /**
     * "Ana Akış" artık küçük bir liste penceresi değil, Macrorify'daki gibi TAM BİR
     * SAYFA: üstte kaydırılabilir liste, altta seçili öğe üzerinde çalışan 8 ikonlu
     * araç çubuğu (Görüntüle, Ekle, Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı).
     */
    private fun buildAnaAkisScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer)
        root.addView(footer)

        fun currentEntries(): List<AnaAkisEntry> {
            val entries = mutableListOf<AnaAkisEntry>()
            ActionGroupStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Group(it)) }
            RuleStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Rule(it)) }
            return entries
        }

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz kural/grup yok — alttaki ➕ ile başla"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    when (val entry = entries[position]) {
                        is AnaAkisEntry.Group -> {
                            val g = entry.group
                            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (g.enabled) "📦" else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = g.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "$gateInfo · ${g.rules.size} · x${g.gateRepeat}"
                        }
                        is AnaAkisEntry.Rule -> {
                            val r = entry.rule
                            val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆")
                                else when (r.alternatives.first().conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
                            val extra = if (!r.enabled) "🔕" else if (r.loopMode == "ALWAYS") "" else r.loopMode
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (r.enabled) icon else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = r.groupName?.let { "[$it] " }.orEmpty() + r.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = extra
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.4).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is AnaAkisEntry.Rule -> showRuleOptions(entry.rule)
                    is AnaAkisEntry.Group -> showActionGroupOptions(entry.group)
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<AnaAkisEntry> {
            val entries = currentEntries()
            return selectedIndices.sorted().mapNotNull { entries.getOrNull(it) }
        }

        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply {
            text = label; textSize = 15f
            setOnClickListener { onClick() }
        }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        row1.addView(toolBtn("☑️") {
            val total = currentEntries().size
            if (selectedIndices.size == total) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(0 until total) }
            buildContent()
        }, toolbarParams)
        row1.addView(toolBtn("➕") {
            overlayDialog().setTitle("Ne eklemek istersin?")
                .setItems(arrayOf(
                    "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                    "👆 Sadece Dokunma Ekle (koşulsuz)",
                    "👉 Sadece Kaydırma Ekle (koşulsuz)",
                    "📦 Yeni Action Group",
                    "f{} Yeni Fonksiyon",
                    "🖥️ Yeni Script (Kod)"
                )) { _, idx ->
                    when (idx) {
                        0 -> { closeAppPanel(); startAddRegion() }
                        1 -> addSimpleStepToMainFlow("TAP")
                        2 -> addSimpleStepToMainFlow("SWIPE")
                        3 -> createActionGroup()
                        4 -> createFunction()
                        5 -> openScriptEditorOverlay(null)
                    }
                }.create().showOverlay()
        }, toolbarParams)
        row1.addView(toolBtn("📋") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                Toast.makeText(ctx, "Kopyalandı: ${sel.rule.name}", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        row1.addView(toolBtn("✂️") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                RuleStorage.deleteRule(ctx, sel.rule.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                refreshThisScreen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        row2.addView(toolBtn("📥") {
            val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            RuleStorage.upsert(ctx, pasted)
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("🗑") {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { entry ->
                when (entry) {
                    is AnaAkisEntry.Rule -> { RuleStorage.deleteRule(ctx, entry.rule.id); RuleStorage.deleteRule(ctx, "${entry.rule.id}-fail") }
                    is AnaAkisEntry.Group -> ActionGroupStorage.delete(ctx, entry.group.id)
                }
            }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↑") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { RuleStorage.moveUp(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↓") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { RuleStorage.moveDown(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        footer.addView(row1)
        footer.addView(row2)

        buildContent()
        return root
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog().setTitle("Grup Seç").setItems(groups.toTypedArray()) { _, gIndex ->
            val group = groups[gIndex]
            val filtered = RuleStorage.load(this).filter { it.groupName == group }
            val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
            overlayDialog().setTitle("[$group] (${filtered.size})").setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                .setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showRuleOptions(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle", if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir", "🧪 Test Et",
            "📋 Kopyala", "✂️ Kes", "⬆️ Yukarı Taşı", "⬇️ Aşağı Taşı", "🗑 Sil"
        )
        overlayDialog().setTitle(rule.name).setItems(options) { _, index ->
            when (index) {
                0 -> {
                    if (rule.alternatives.isEmpty()) {
                        RuleStorage.deleteRule(this, rule.id)
                        addSimpleStepToMainFlow(rule.actionType)
                    } else {
                        editExistingRule(rule)
                    }
                }
                1 -> { rule.enabled = !rule.enabled; RuleStorage.upsert(this, rule); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                2 -> testRule(rule)
                3 -> { com.bigboss.app.storage.RuleClipboard.copy(rule); Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show() }
                4 -> {
                    com.bigboss.app.storage.RuleClipboard.copy(rule)
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Kesildi: ${rule.name}", Toast.LENGTH_SHORT).show()
                }
                5 -> { RuleStorage.moveUp(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                6 -> { RuleStorage.moveDown(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                7 -> {
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Var olan bir kuralı düzenlemek için, o kuralın alanını ekranda GERÇEK overlay kutusu olarak geri getirir. */
    private fun stepToExtraAction(step: com.bigboss.app.storage.ActionStep): ExtraAction {
        val fnName = step.functionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        }
        return ExtraAction(
            type = step.type, x = step.x, y = step.y, x2 = step.x2, y2 = step.y2,
            waitMs = step.waitMs, functionId = step.functionId, functionName = fnName ?: "",
            repeat = step.repeat, variableName = step.variableName, variableDelta = step.variableDelta,
            scriptId = step.scriptId, scriptName = step.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.name } ?: "",
            holdMs = step.holdMs, swipeHoldStartMs = step.swipeHoldStartMs, swipeHoldEndMs = step.swipeHoldEndMs, postDelayMs = step.postDelayMs
        )
    }

    private fun editExistingRule(rule: RuleDefinition, scope: SaveScope = SaveScope.MainFlow) {
        val alt = rule.alternatives.firstOrNull() ?: return
        val region = addRegionWindow(alt.x, alt.y, alt.width, alt.height)
        region.saveScope = scope
        region.existingRuleId = rule.id
        region.name = rule.name
        region.conditionKind = alt.conditionKind
        region.conditionColor = alt.color
        region.conditionTemplatePath = alt.templatePath
        region.conditionText = alt.expectedText ?: ""
        region.minScore = alt.minScore
        region.actionType = rule.actionType
        region.actionX = rule.actionX; region.actionY = rule.actionY
        region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
        region.tapAtMatchLocation = rule.tapAtMatchLocation
        region.actionRepeatCount = rule.actionRepeatCount
        region.actionHoldMs = rule.actionHoldMs
        region.actionPostDelayMs = rule.actionPostDelayMs
        region.randomOffsetPx = rule.randomOffsetPx
        region.randomChancePercent = rule.randomChancePercent
        region.swipeHoldStartMs = rule.swipeHoldStartMs
        region.swipeHoldEndMs = rule.swipeHoldEndMs
        region.actionHoldVarName = rule.actionHoldVarName
        region.actionPostDelayVarName = rule.actionPostDelayVarName
        region.swipeHoldStartVarName = rule.swipeHoldStartVarName
        region.swipeHoldEndVarName = rule.swipeHoldEndVarName
        region.callFunctionId = rule.callFunctionId
        region.callFunctionName = rule.callFunctionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        } ?: ""
        region.callFunctionRepeat = rule.callFunctionRepeat
        region.cooldownMs = rule.timeoutMs
        region.matchDelayMs = rule.matchDelayMs
        region.scanTimeoutMs = rule.scanTimeoutMs
        region.negate = rule.negateCondition
        region.loopMode = rule.loopMode
        region.requireVariableName = rule.requireVariableName
        region.requireVariableOp = rule.requireVariableOp
        region.requireVariableValue = rule.requireVariableValue
        region.incrementVariableName = rule.incrementVariableName
        region.incrementVariableDelta = rule.incrementVariableDelta
        region.extraActions.clear()
        rule.extraSteps.forEach { region.extraActions.add(stepToExtraAction(it)) }

        // "-fail" eşleniği varsa, BULUNAMAZSA adımlarını da geri yükle (aynı kapsamdan).
        val failRule = when (scope) {
            is SaveScope.MainFlow -> RuleStorage.load(this).find { it.id == "${rule.id}-fail" }
            is SaveScope.Group -> ActionGroupStorage.load(this).find { it.id == scope.groupId }?.rules?.find { it.id == "${rule.id}-fail" }
            is SaveScope.Function -> FunctionStorage.load(this).find { it.id == scope.functionId }?.rules?.find { it.id == "${rule.id}-fail" }
        }
        region.onFailActions.clear()
        failRule?.extraSteps?.forEach { region.onFailActions.add(stepToExtraAction(it)) }

        val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
        region.label.text = "$icon ${region.name}"
        Toast.makeText(this, "Alan geri getirildi — düzenleyip kaydet", Toast.LENGTH_LONG).show()
    }

    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        overlayDialog().setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null).create().showOverlay()
    }

    // ==================== Action Group ====================

    private fun showActionGroupsMenu() {
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Action Group")
        options.addAll(groups.map { g ->
            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
            "📦 ${if (g.enabled) "" else "🔕 "}${g.name} ($gateInfo, ${g.rules.size} tarama)"
        })
        overlayDialog().setTitle("📦 Action Group'lar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createActionGroup() else showActionGroupOptions(groups[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createActionGroup() {
        val input = EditText(this).apply { hint = "Grup adı (örn. \"Savaş Ekranı\")" }
        overlayDialog().setTitle("Yeni Action Group").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "grup" }
                ActionGroupStorage.upsert(this, com.bigboss.app.storage.ActionGroupDefinition(UUID.randomUUID().toString(), name))
                Toast.makeText(this, "Oluşturuldu — şimdi \"🎯 Kapı Koşulunu Ayarla\" ile devam et", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showActionGroupOptions(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val options = arrayOf(
            "🎯 Kapı Koşulunu Ayarla/Değiştir",
            "➕ Bu Gruba Tarama Ekle",
            "📋 Gruptaki Taramaları Listele",
            "⚙️ Grup Ayarları (döngü sayısı, kapı sıklığı)",
            if (group.enabled) "🔕 Grubu Devre Dışı Bırak" else "🔔 Grubu Etkinleştir",
            "🗑 Grubu Sil"
        )
        overlayDialog().setTitle("📦 ${group.name}").setItems(options) { _, index ->
            when (index) {
                0 -> startGateRegion(group)
                1 -> startGroupScan(group)
                2 -> showGroupRulesList(group)
                3 -> showGroupSettingsDialog(group)
                4 -> {
                    group.enabled = !group.enabled
                    ActionGroupStorage.upsert(this, group)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
                5 -> {
                    ActionGroupStorage.delete(this, group.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Gruba özel ayarlar: kapı bulununca kaç kere taransın (döngü sayısı) + kapı ne sıklıkla kontrol edilsin. */
    private fun showGroupSettingsDialog(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply {
            text = "Döngü sayısı — kapı koşulu bulununca gruptaki taramalar kaç kere art arda çalışsın:"
            textSize = 12f
        })
        val repeatInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateRepeat.toString())
        }
        container.addView(repeatInput)
        container.addView(TextView(this).apply {
            text = "Kapı kontrol sıklığı (ms) — kapı koşulu en fazla ne kadar sık kontrol edilsin:"
            textSize = 12f; setPadding(0, 16, 0, 0)
        })
        val cooldownInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateCooldownMs.toString())
        }
        container.addView(cooldownInput)

        overlayDialog().setTitle("⚙️ ${group.name} Ayarları").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                group.gateRepeat = repeatInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                group.gateCooldownMs = cooldownInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 300
                ActionGroupStorage.upsert(this, group)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Ayarlar kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Grubun KAPI koşulunu ayarlamak için ekrana bir alan çizer. */
    private fun startGateRegion(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val gate = group.gate
        val region = if (gate != null) addRegionWindow(gate.x, gate.y, gate.width, gate.height) else addRegionWindow()
        region.isGateForGroupId = group.id
        if (gate != null) {
            region.conditionKind = gate.conditionKind
            region.conditionColor = gate.color
            region.conditionTemplatePath = gate.templatePath
            region.conditionText = gate.expectedText ?: ""
            region.minScore = gate.minScore
            region.cooldownMs = group.gateCooldownMs
        }
        region.label.text = "🎯 ${group.name}"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubunun KAPI koşulu — sadece GENEL sekmesi kullanılır", Toast.LENGTH_LONG).show()
    }

    /** Gruba yeni bir tarama (kural) eklemek için ekrana bir alan çizer. */
    private fun startGroupScan(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Group(group.id)
        region.label.text = "📦 ${group.name} → yeni"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showGroupRulesList(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val rules = group.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu grupta henüz tarama yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
        overlayDialog().setTitle("📦 ${group.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                if (action == 0) {
                    editExistingRule(rule, SaveScope.Group(group.id))
                } else {
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, rule.id)
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, "${rule.id}-fail")
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
            }.create().showOverlay()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Fonksiyonlar ====================

    /**
     * "f{} Fonksiyonlar" — Ana Akış için yaptığımız AYNI sayfa+araç çubuğu düzeni:
     * dokun = bilgiyi aç, basılı tut = çoklu seç, altta 8 ikonlu toplu işlem çubuğu.
     */
    private fun buildFonksiyonlarScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun buildContent() {
            listContainer.removeAllViews()
            val functions = FunctionStorage.load(ctx)
            if (functions.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz fonksiyon yok — alttaki ➕ ile oluştur"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = functions.size
                override fun getItem(position: Int): Any = functions[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    val fn = functions[position]
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "f{}"
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = fn.name
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "${fn.rules.size} adım"
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.45).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ -> showFunctionOptions(functions[position]) }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selected(): List<FunctionDefinition> = selectedIndices.sorted().mapNotNull { FunctionStorage.load(ctx).getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }
        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply { text = label; textSize = 15f; setOnClickListener { onClick() } }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        row1.addView(toolBtn("☑️") {
            val total = FunctionStorage.load(ctx).size
            if (selectedIndices.size == total) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(0 until total) }
            buildContent()
        }, toolbarParams)
        row1.addView(toolBtn("➕") { createFunction(); refreshThisScreen() }, toolbarParams)
        row1.addView(toolBtn("📋") {
            val sel = selected().firstOrNull()
            if (sel != null) { com.bigboss.app.storage.FunctionClipboard.copy(sel); Toast.makeText(ctx, "Kopyalandı: ${sel.name}", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        row1.addView(toolBtn("✂️") {
            val sel = selected().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.FunctionClipboard.copy(sel)
                FunctionStorage.delete(ctx, sel.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                refreshThisScreen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        row2.addView(toolBtn("📥") {
            val pasted = com.bigboss.app.storage.FunctionClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            FunctionStorage.upsert(ctx, pasted)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("🗑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.delete(ctx, it.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} fonksiyon silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.moveUp(ctx, it.id) }
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↓") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { FunctionStorage.moveDown(ctx, it.id) }
            refreshThisScreen()
        }, toolbarParams)
        footer.addView(row1); footer.addView(row2)

        buildContent()
        return root
    }

    private fun createFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı" }
        overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showFunctionOptions(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setItems(arrayOf("➕ Bu Fonksiyona Adım Ekle", "📋 Fonksiyondaki Adımları Listele", "🗑 Fonksiyonu Sil")) { _, index ->
                when (index) {
                    0 -> showAddToFunctionMenu(fn)
                    1 -> showFunctionRulesList(fn)
                    2 -> {
                        FunctionStorage.delete(this, fn.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }.create().showOverlay()
    }

    /** Fonksiyona ne eklemek istediğini soran menü — artık sadece "tarama" değil, çeşitlendirildi. */
    private fun showAddToFunctionMenu(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} — Ne eklemek istersin?")
            .setItems(arrayOf(
                "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                "👆 Sadece Dokunma Ekle (koşulsuz)",
                "👉 Sadece Kaydırma Ekle (koşulsuz)"
            )) { _, index ->
                when (index) {
                    0 -> startFunctionScan(fn)
                    1 -> addSimpleStepToFunction(fn, "TAP")
                    2 -> addSimpleStepToFunction(fn, "SWIPE")
                }
            }.create().showOverlay()
    }

    /** Fonksiyona tam bir tarama alanı YERİNE, sadece koşulsuz bir dokunma/kaydırma adımı ekler. */
    private fun promptTapHold(onDone: (Long) -> Unit) {
        val input = EditText(this).apply { hint = "HOLD (ms) — basılı tutma süresi"; inputType = InputType.TYPE_CLASS_NUMBER; setText("50") }
        overlayDialog().setTitle("⏱️ Basılı Tutma Süresi").setView(input)
            .setPositiveButton("Tamam") { _, _ -> onDone(input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50) }
            .setNegativeButton("Atla (varsayılan 50ms)") { _, _ -> onDone(50) }
            .create().showOverlay()
    }

    private fun promptSwipeHold(onDone: (Long, Long) -> Unit) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply { text = "Başlangıçta bekleme (ms) — sürükle-bırak için:" })
        val startInput = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("0") }
        container.addView(startInput)
        container.addView(TextView(this).apply { text = "Bitişte bekleme (ms):"; setPadding(0, 16, 0, 0) })
        val endInput = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("0") }
        container.addView(endInput)
        overlayDialog().setTitle("⏱️ Basılı Tutma Süreleri (isteğe bağlı)").setView(container)
            .setPositiveButton("Tamam") { _, _ -> onDone(startInput.text.toString().toLongOrNull() ?: 0, endInput.text.toString().toLongOrNull() ?: 0) }
            .setNegativeButton("Atla") { _, _ -> onDone(0, 0) }
            .create().showOverlay()
    }

    /** Ana Akış'a doğrudan, koşulsuz bir dokunma/kaydırma adımı ekler (tarama alanı gerekmeden). */
    private fun addSimpleStepToMainFlow(type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                promptTapHold { holdMs ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👆 Dokunma",
                        alternatives = mutableListOf(),
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "TAP",
                        actionX = x, actionY = y,
                        actionHoldMs = holdMs
                    )
                    RuleStorage.upsert(this, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Ana Akışa eklendi: 👆 Dokunma", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    promptSwipeHold { holdStart, holdEnd ->
                        val def = RuleDefinition(
                            id = UUID.randomUUID().toString(),
                            name = "👉 Kaydırma",
                            alternatives = mutableListOf(),
                            timeoutMs = 100,
                            loopMode = "ALWAYS",
                            actionType = "SWIPE",
                            actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2,
                            swipeHoldStartMs = holdStart, swipeHoldEndMs = holdEnd
                        )
                        RuleStorage.upsert(this, def)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        Toast.makeText(this, "Ana Akışa eklendi: 👉 Kaydırma", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun addSimpleStepToFunction(fn: FunctionDefinition, type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                promptTapHold { holdMs ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👆 Dokunma",
                        alternatives = mutableListOf(), // boş -> koşulsuz (her zaman doğru)
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "TAP",
                        actionX = x, actionY = y,
                        actionHoldMs = holdMs
                    )
                    FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Eklendi: 👆 Dokunma", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    promptSwipeHold { holdStart, holdEnd ->
                        val def = RuleDefinition(
                            id = UUID.randomUUID().toString(),
                            name = "👉 Kaydırma",
                            alternatives = mutableListOf(),
                            timeoutMs = 100,
                            loopMode = "ALWAYS",
                            actionType = "SWIPE",
                            actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2,
                            swipeHoldStartMs = holdStart, swipeHoldEndMs = holdEnd
                        )
                        FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        Toast.makeText(this, "Eklendi: 👉 Kaydırma", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    /** Fonksiyona yeni bir tarama (kural) eklemek için ekrana bir alan çizer — tıpkı Action Group'taki gibi. */
    private fun startFunctionScan(fn: FunctionDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Function(fn.id)
        region.label.text = "f{} ${fn.name} → yeni"
        Toast.makeText(this, "Bu alan \"${fn.name}\" fonksiyonuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showFunctionRulesList(fn: FunctionDefinition) {
        val rules = fn.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu fonksiyonda henüz tarama/adım yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r ->
            val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆") else "🔍"
            "${i + 1}. $icon ${if (r.enabled) "" else "🔕 "}${r.name}"
        }.toTypedArray()
        overlayDialog().setTitle("f{} ${fn.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            if (rule.alternatives.isEmpty()) {
                // Koşulsuz basit adım (Dokunma/Kaydırma) — tam alan düzenleyici yerine hızlı yeniden-seçim
                overlayDialog().setTitle(rule.name).setItems(arrayOf("🔄 Noktayı/Noktaları Yeniden Seç", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        addSimpleStepToFunction(fn, rule.actionType)
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            } else {
                overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        editExistingRule(rule, SaveScope.Function(fn.id))
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, "${rule.id}-fail")
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kod (Script) ====================

    private fun showScriptsMenu() {
        val scripts = com.bigboss.app.storage.ScriptStorage.load(this)
        val options = mutableListOf("➕ Yeni Script")
        options.addAll(scripts.map { "🖥️ ${it.name}" })
        overlayDialog().setTitle("🖥️ Kod").setItems(options.toTypedArray()) { _, index ->
            openScriptEditorOverlay(if (index > 0) scripts[index - 1].id else null)
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * Kod editörünü artık ScriptEditorActivity (bir Activity) yerine GERÇEK bir
     * overlay penceresi olarak açıyoruz — RuleEditorActivity/LibraryCaptureActivity'de
     * yaşadığımız AYNI sorun (Activity açılınca BigBoss öne geliyor, altındaki
     * uygulamanın ÜSTÜNDE kalmıyordu) burada da vardı, aynı çözümle düzelttim.
     */
    private fun openScriptEditorOverlay(scriptId: String?) {
        val ctx = this
        val density = resources.displayMetrics.density
        val existing = scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(ctx).find { it.id == id } }
        val isNew = existing == null
        val actualId = existing?.id ?: UUID.randomUUID().toString()

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt()) }
        root.addView(TextView(ctx).apply { text = "Script Adı"; textSize = 11f })
        val nameInput = EditText(ctx).apply { setText(existing?.name ?: "") ; hint = "İsimsiz script" }
        root.addView(nameInput)

        root.addView(TextView(ctx).apply { text = "Kod"; textSize = 11f; setPadding(0, (12 * density).toInt(), 0, 0) })
        val defaultCode = "// ==== Basit fonksiyonlar ====\n" +
            "// tap(x, y, {repeat, hold, delay, random})\n" +
            "// swipe(x1, y1, x2, y2, {duration, holdStart, holdEnd, delay, random})\n" +
            "// swipePath([{x,y,hold}, {x,y,hold}, ...], sureHer)  -- çok noktalı kaydırma\n" +
            "// wait(ms)\n" +
            "// back() | home() | recents() | notifications() | quickSettings()\n" +
            "// getVar(ad) | setVar(ad, deger)                -- oyun-içi sayaç\n" +
            "// getGlobalVar(ad) | setGlobalVar(ad, deger)     -- kalıcı Değişkenler\n" +
            "// colorAt(x, y) | randomInt(min, max)\n" +
            "// findColor(x,y,w,h,\"#RRGGBB\",minSkor) | findImage(x,y,w,h,\"kütüphaneAdi\",minSkor) | findText(x,y,w,h,\"metin\")\n" +
            "// callFunction(\"fonksiyonAdi\", tekrar) | runScript(\"scriptAdi\") | log(mesaj)\n" +
            "//\n" +
            "// ==== Region nesnesi ====\n" +
            "// var r = Region(x, y, w, h)\n" +
            "// r.findColor(\"#RRGGBB\", minSkor) | r.findImage(\"kütüphaneAdi\", minSkor) | r.findText(\"metin\")\n" +
            "// r.findImageMatch(\"kütüphaneAdi\", minSkor)  -> {found, x, y, score} ya da null\n" +
            "// r.tap({hold}) | r.center() -> {x, y}\n\n" +
            "log(\"Merhaba BigBoss\")\n"
        val codeInput = EditText(ctx).apply {
            setText(existing?.code ?: defaultCode)
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 12f
            gravity = Gravity.TOP or Gravity.START
            isSingleLine = false
            minLines = 12
            maxLines = 18
            setBackgroundColor(Color.parseColor("#F5F5F5"))
            setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
        }
        root.addView(codeInput)

        val outputText = TextView(ctx).apply {
            textSize = 11f; setPadding(0, (10 * density).toInt(), 0, 0)
        }
        root.addView(outputText)

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("💾 Kaydet", null)
            .setNeutralButton("▶️ Test Et", null)
            .setNegativeButton(if (isNew) "Vazgeç" else "🗑 Sil", null)
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameInput.text.toString().ifBlank { "İsimsiz script" }
                val code = codeInput.text.toString()
                com.bigboss.app.storage.ScriptStorage.upsert(ctx, com.bigboss.app.storage.ScriptDefinition(actualId, name, code))
                Toast.makeText(ctx, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val engine = com.bigboss.app.engine.ScriptRuntime.engine
                if (engine == null) {
                    outputText.text = "⚠️ Şu an çalışan bir motor yok — önce Canlı Test ya da Play Mode'u başlat."
                } else {
                    val error = engine.run(codeInput.text.toString())
                    outputText.text = if (error != null) "❌ Hata: $error" else "✅ Çalıştı (Logcat \"BigBossScript\" etiketinde log() çıktılarını görebilirsin)"
                    Toast.makeText(ctx, if (error != null) "Script hata verdi" else "Script çalıştı", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                if (isNew) { dialog.dismiss(); return@setOnClickListener }
                overlayDialog().setTitle("Sil")
                    .setMessage("Bu script'i silmek istediğine emin misin?")
                    .setPositiveButton("Sil") { _, _ ->
                        com.bigboss.app.storage.ScriptStorage.delete(ctx, actualId)
                        dialog.dismiss()
                    }
                    .setNegativeButton("Vazgeç", null)
                    .create().showOverlay()
            }
        }
        dialog.show()
    }

    // ==================== Kütüphane ====================

    private fun showLibraryMenu() {
        val items = LibraryStorage.load(this)
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size + 1
            override fun getItem(position: Int): Any? = if (position == 0) null else items[position - 1]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_library_dialog, parent, false)
                val ivThumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivThumb)
                val tvName = view.findViewById<TextView>(com.bigboss.app.R.id.tvName)
                if (position == 0) {
                    ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(Color.parseColor("#333333"))
                    tvName.text = "📷 Ekrandan Kırp"
                } else {
                    val item = items[position - 1]
                    if (item.kind == "IMAGE" && !item.templatePath.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(item.templatePath)
                        if (bmp != null) ivThumb.setImageBitmap(bmp) else ivThumb.setBackgroundColor(Color.DKGRAY)
                    } else { ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(item.color) }
                    tvName.text = "${if (item.kind == "IMAGE") "🖼️" else "🎨"} ${item.name}"
                }
                return view
            }
        }
        overlayDialog().setTitle("📚 Kütüphanem (${items.size})").setAdapter(adapter) { _, position ->
            if (position == 0) startLibraryCaptureRegion()
            else showLibraryItemOptions(items[position - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "📷 Ekrandan Kırp" — RuleEditorActivity'de yaşadığımız aynı sorunu önlemek için
     * bu da GERÇEK bir overlay penceresiyle çalışıyor, Activity açmıyor — böylece
     * başka uygulamaların (oyunlar dahil) üzerinde de sorunsuz çalışır. */
    private fun startLibraryCaptureRegion() {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isLibraryCapture = true
        region.label.text = "📷 Kırp"
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup kaydet", Toast.LENGTH_LONG).show()
    }

    private fun openLibraryCaptureSaveDialog(region: ActiveRegion) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val r = regionRect(region)
        val cropped = safeCrop(frame, r[0], r[1], r[2], r[3])
        if (cropped == null) { Toast.makeText(this, "Alan çok küçük", Toast.LENGTH_SHORT).show(); return }

        val input = EditText(this).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
        overlayDialog().setTitle("Bu resmi kaydet")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = input.text.toString().ifBlank { "İsimsiz görsel" }
                val path = TemplateStorage.save(this, cropped)
                LibraryStorage.add(this, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, path))
                Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
                removeRegionWindow(region)
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .setNeutralButton("🗑 Alanı Sil") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog().setTitle(item.name).setItems(options) { _, index ->
            when (options[index]) {
                "✂️ Piksel Kırp" -> startActivity(Intent(this, com.bigboss.app.ui.LibraryCropActivity::class.java).apply {
                    putExtra(com.bigboss.app.ui.LibraryCropActivity.EXTRA_LIBRARY_ITEM_ID, item.id)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                "↻ 90° Döndür" -> rotateLibraryImage(item)
                "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                "🗑 Sil" -> { LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
            }
        }.create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(Bitmap.CompressFormat.PNG, 100, it) }
            com.bigboss.app.engine.ImageMatcher.clearCache() // aynı yol üzerine yazıldı, eski önbellek geçersiz
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog().setTitle("Yeniden adlandır").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    override fun onDestroy() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        removePointMarker()
        colorPickCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
