package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.ScriptDefinition
import com.bigboss.app.storage.ScriptStorage
import com.bigboss.app.ui.LibraryCaptureActivity
import com.bigboss.app.ui.RuleEditorActivity
import com.bigboss.app.ui.ScriptEditorActivity
import java.util.UUID
import kotlin.math.abs

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 * Dikey ikon menüsü, herhangi bir uygulamanın ÜSTÜNDE çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var expanded = false
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (rootView == null) buildOverlay() else rebuildPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    // ---- Overlay pencere iskeleti ----

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        toggleButton = TextView(this).apply {
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }
        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#EE1A1A1A"))
        }
        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private fun rebuildPanel() {
        expandedPanel.removeAllViews()
        toggleButton.text = if (mode == "EDIT") "✏️" else "▶️"

        fun iconBtn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 13f
            setOnClickListener { collapse(); onClick() }
        }

        expandedPanel.addView(TextView(this).apply {
            text = if (mode == "EDIT") "✏️ DÜZENLEME — dokunuş yapılmaz" else "▶️ ÇALIŞIYOR"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(16, 12, 16, 8)
        })

        if (mode == "EDIT") {
            expandedPanel.addView(iconBtn("🖼️👆  Alan Ekle") { openRuleEditor() })
        }
        expandedPanel.addView(iconBtn("🏠  Ana Akış") { showRulesMenu() })
        expandedPanel.addView(iconBtn("f{}  Fonksiyonlar") { showFunctionsMenu() })
        expandedPanel.addView(iconBtn("🖥️  Kod") { showScriptsMenu() })
        expandedPanel.addView(iconBtn("📚  Kütüphane") { showLibraryMenu() })
        expandedPanel.addView(iconBtn(if (mode == "EDIT") "▶️  Çalışmayı Başlat" else "✏️  Düzenlemeye Geç") { toggleMode() })
        expandedPanel.addView(iconBtn("✕  Kapat") { shutdown() })
    }

    private fun collapse() {
        expanded = false
        expandedPanel.visibility = View.GONE
    }

    private fun toggleMode() {
        mode = if (mode == "EDIT") "PLAY" else "EDIT"
        ScreenCaptureService.ruleEngine?.paused = (mode == "EDIT")
        rebuildPanel()
        Toast.makeText(this, if (mode == "EDIT") "✏️ Düzenleme Modu" else "▶️ Çalışma Modu", Toast.LENGTH_SHORT).show()
    }

    private fun shutdown() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
    }

    // ---- Overlay üzerinden Dialog gösterme yardımcıları ----

    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ---- Alan Ekle ----

    private fun openRuleEditor() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "✏️ Alan editörü açılıyor — üstteki çubuğu göreceksin", Toast.LENGTH_LONG).show()
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_NO_ANIMATION
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---- Ana Akış ----

    private fun showRulesMenu() {
        val rules = RuleStorage.load(this)
        if (rules.isEmpty() && !com.bigboss.app.storage.RuleClipboard.hasContent()) {
            Toast.makeText(this, "Henüz kural yok — \"Alan Ekle\" ile başla", Toast.LENGTH_SHORT).show()
            return
        }
        val groups = rules.mapNotNull { it.groupName }.distinct()
        val labels = mutableListOf<String>()
        if (com.bigboss.app.storage.RuleClipboard.hasContent()) {
            labels.add("📥 Yapıştır (${com.bigboss.app.storage.RuleClipboard.peekName()})")
        }
        if (groups.isNotEmpty()) labels.add("🔍 Gruba Göre Filtrele")
        rules.forEachIndexed { i, r ->
            labels.add("${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.groupName?.let { "[$it] " } ?: ""}${r.name}")
        }
        val offset = labels.size - rules.size

        overlayDialog()
            .setTitle("🏠 Ana Akış (${rules.size})")
            .setItems(labels.toTypedArray()) { _, index ->
                when {
                    com.bigboss.app.storage.RuleClipboard.hasContent() && index == 0 -> pasteRule()
                    groups.isNotEmpty() && index == (if (com.bigboss.app.storage.RuleClipboard.hasContent()) 1 else 0) -> showGroupFilterMenu(groups)
                    else -> showRuleOptions(rules[index - offset])
                }
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog()
            .setTitle("Grup Seç")
            .setItems(groups.toTypedArray()) { _, gIndex ->
                val group = groups[gIndex]
                val filtered = RuleStorage.load(this).filter { it.groupName == group }
                val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
                overlayDialog()
                    .setTitle("[$group] (${filtered.size})")
                    .setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                    .setNegativeButton("Kapat", null)
                    .create().showOverlay()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    private fun showRuleOptions(rule: com.bigboss.app.storage.RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle",
            if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir",
            "🧪 Test Et",
            "📋 Kopyala",
            "✂️ Kes",
            "⬆️ Yukarı Taşı",
            "⬇️ Aşağı Taşı",
            "🗑 Sil"
        )
        overlayDialog()
            .setTitle(rule.name)
            .setItems(options) { _, index ->
                when (index) {
                    0 -> startActivity(Intent(this, RuleEditorActivity::class.java).apply {
                        putExtra(RuleEditorActivity.EXTRA_EDIT_RULE_ID, rule.id)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                    1 -> {
                        rule.enabled = !rule.enabled
                        RuleStorage.upsert(this, rule)
                        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                    }
                    2 -> testRule(rule)
                    3 -> {
                        com.bigboss.app.storage.RuleClipboard.copy(rule)
                        Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show()
                    }
                    4 -> {
                        com.bigboss.app.storage.RuleClipboard.copy(rule)
                        RuleStorage.deleteRule(this, rule.id)
                        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                        Toast.makeText(this, "Kesildi: ${rule.name} (yapıştırmaya hazır)", Toast.LENGTH_SHORT).show()
                    }
                    5 -> {
                        RuleStorage.moveUp(this, rule.id)
                        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                    }
                    6 -> {
                        RuleStorage.moveDown(this, rule.id)
                        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                    }
                    7 -> {
                        RuleStorage.deleteRule(this, rule.id)
                        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .create().showOverlay()
    }

    private fun testRule(rule: com.bigboss.app.storage.RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
            return
        }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        overlayDialog()
            .setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null)
            .create().showOverlay()
    }

    // ---- Fonksiyonlar ----

    private fun showFunctionsMenu() {
        val functions = FunctionStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon")
        options.addAll(functions.map { "f{} ${it.name} (${it.rules.size})" })
        overlayDialog()
            .setTitle("f{} Fonksiyonlar")
            .setItems(options.toTypedArray()) { _, index ->
                if (index == 0) createFunction() else showFunctionOptions(functions[index - 1])
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    private fun createFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı" }
        overlayDialog()
            .setTitle("Yeni Fonksiyon")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    private fun showFunctionOptions(fn: FunctionDefinition) {
        overlayDialog()
            .setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setItems(arrayOf("➕ Bu Fonksiyona Kural Ekle", "🗑 Fonksiyonu Sil")) { _, index ->
                if (index == 0) {
                    val frame = ScreenCaptureService.latestFrame
                    if (frame == null) {
                        Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
                    } else {
                        startActivity(Intent(this, RuleEditorActivity::class.java).apply {
                            putExtra(RuleEditorActivity.EXTRA_FUNCTION_ID, fn.id)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        })
                    }
                } else {
                    FunctionStorage.delete(this, fn.id)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
            .create().showOverlay()
    }

    // ---- Kod (Script) ----

    private fun showScriptsMenu() {
        val scripts = ScriptStorage.load(this)
        val options = mutableListOf("➕ Yeni Script")
        options.addAll(scripts.map { "🖥️ ${it.name}" })
        overlayDialog()
            .setTitle("🖥️ Kod")
            .setItems(options.toTypedArray()) { _, index ->
                val intent = Intent(this, ScriptEditorActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (index > 0) intent.putExtra(ScriptEditorActivity.EXTRA_SCRIPT_ID, scripts[index - 1].id)
                startActivity(intent)
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    // ---- Kütüphane ----

    private fun showLibraryMenu() {
        val items = LibraryStorage.load(this)

        // "Ekrandan Kırp" + kayıtlı öğeler için görsel önizlemeli özel liste
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size + 1
            override fun getItem(position: Int): Any? = if (position == 0) null else items[position - 1]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_library_dialog, parent, false)
                val ivThumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivThumb)
                val tvName = view.findViewById<TextView>(com.bigboss.app.R.id.tvName)
                if (position == 0) {
                    ivThumb.setImageDrawable(null)
                    ivThumb.setBackgroundColor(Color.parseColor("#333333"))
                    tvName.text = "📷 Ekrandan Kırp"
                } else {
                    val item = items[position - 1]
                    if (item.kind == "IMAGE" && !item.templatePath.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(item.templatePath)
                        if (bmp != null) ivThumb.setImageBitmap(bmp) else ivThumb.setBackgroundColor(Color.DKGRAY)
                    } else {
                        ivThumb.setImageDrawable(null)
                        ivThumb.setBackgroundColor(item.color)
                    }
                    tvName.text = "${if (item.kind == "IMAGE") "🖼️" else "🎨"} ${item.name}"
                }
                return view
            }
        }

        overlayDialog()
            .setTitle("📚 Kütüphanem (${items.size})")
            .setAdapter(adapter) { _, position ->
                if (position == 0) {
                    if (ScreenCaptureService.latestFrame == null) {
                        Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
                    } else {
                        startActivity(Intent(this, LibraryCaptureActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        })
                    }
                } else {
                    showLibraryItemOptions(items[position - 1])
                }
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog()
            .setTitle(item.name)
            .setItems(options) { _, index ->
                when (options[index]) {
                    "✂️ Piksel Kırp" -> startActivity(Intent(this, com.bigboss.app.ui.LibraryCropActivity::class.java).apply {
                        putExtra(com.bigboss.app.ui.LibraryCropActivity.EXTRA_LIBRARY_ITEM_ID, item.id)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                    "↻ 90° Döndür" -> rotateLibraryImage(item)
                    "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                    "🗑 Sil" -> { LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
                }
            }
            .create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog()
            .setTitle("Yeniden adlandır")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
