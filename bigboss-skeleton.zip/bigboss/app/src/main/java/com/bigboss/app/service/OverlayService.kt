package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import com.bigboss.app.ui.LibraryCaptureActivity
import com.bigboss.app.ui.ScriptEditorActivity
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 *
 * ÖNEMLİ MİMARİ NOT: Alan çizme/düzenleme artık bir Activity DEĞİL —
 * doğrudan WindowManager ile eklenen GERÇEK overlay pencereleri.
 * Bunun sebebi: şeffaf temalı bir Activity, çoğu oyunun kullandığı
 * SurfaceView/GLSurfaceView tabanlı çizimle düzgün bindirilmiyor
 * (Android'in bilinen bir kısıtı) — bu yüzden oyunun üstünde değil,
 * koyu bir katmanın üstünde görünüyordu. Gerçek overlay pencereleri
 * (bizim küçük ✏️ simgemiz gibi) HER TÜRLÜ uygulamanın (oyunlar dahil)
 * üzerinde güvenilir şekilde çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var expanded = false
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (rootView == null) buildOverlay() else rebuildPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    // ==================== Overlay pencere iskeleti (küçük simge) ====================

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        toggleButton = TextView(this).apply {
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }
        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#EE1A1A1A"))
        }
        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private fun rebuildPanel() {
        expandedPanel.removeAllViews()
        toggleButton.text = if (mode == "EDIT") "✏️" else "▶️"

        fun iconBtn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 13f
            setOnClickListener { collapse(); onClick() }
        }

        expandedPanel.addView(TextView(this).apply {
            text = if (mode == "EDIT") "✏️ DÜZENLEME — dokunuş yapılmaz" else "▶️ ÇALIŞIYOR"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(16, 12, 16, 8)
        })

        if (mode == "EDIT") {
            expandedPanel.addView(iconBtn("🖼️👆  Alan Ekle") { startAddRegion() })
            if (activeRegions.isNotEmpty()) {
                expandedPanel.addView(iconBtn("🧹  Ekrandaki Kutuları Temizle") { clearAllRegionWindows() })
            }
        }
        expandedPanel.addView(iconBtn("🏠  Ana Akış") { showRulesMenu() })
        expandedPanel.addView(iconBtn("f{}  Fonksiyonlar") { showFunctionsMenu() })
        expandedPanel.addView(iconBtn("🖥️  Kod") { showScriptsMenu() })
        expandedPanel.addView(iconBtn("📚  Kütüphane") { showLibraryMenu() })
        expandedPanel.addView(iconBtn(if (mode == "EDIT") "▶️  Çalışmayı Başlat" else "✏️  Düzenlemeye Geç") { toggleMode() })
        expandedPanel.addView(iconBtn("✕  Kapat") { shutdown() })
    }

    private fun collapse() {
        expanded = false
        expandedPanel.visibility = View.GONE
    }

    private fun toggleMode() {
        mode = if (mode == "EDIT") "PLAY" else "EDIT"
        ScreenCaptureService.ruleEngine?.paused = (mode == "EDIT")
        if (mode == "PLAY") clearAllRegionWindows()
        rebuildPanel()
        Toast.makeText(this, if (mode == "EDIT") "✏️ Düzenleme Modu" else "▶️ Çalışma Modu", Toast.LENGTH_SHORT).show()
    }

    private fun shutdown() {
        clearAllRegionWindows()
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
    }

    // ==================== Overlay üzerinden Dialog gösterme yardımcıları ====================

    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ==================== ALAN ÇİZME SİSTEMİ (gerçek overlay pencereleri) ====================

    private data class ExtraAction(
        val type: String, // "TAP" | "CALL_FUNCTION"
        var x: Int = 0, var y: Int = 0,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1
    )

    private inner class ActiveRegion(val id: String, val container: LinearLayout, val containerParams: WindowManager.LayoutParams, val label: TextView, val labelParams: WindowManager.LayoutParams) {
        var existingRuleId: String? = null
        var name = ""
        var groupName = ""
        var conditionKind = "COLOR"
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText = ""
        var minScore = 90
        var actionType = "TAP"
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName = ""
        var callFunctionRepeat = 1
        val extraActions = mutableListOf<ExtraAction>()
        val onFailActions = mutableListOf<ExtraAction>()
        var cooldownMs: Long = 300
        var negate = false
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
    }

    private val activeRegions = mutableListOf<ActiveRegion>()
    private var regionCounter = 0

    private sealed class PendingPick {
        data class ColorPick(val region: Any) : PendingPick()
        data class ActionPoint(val region: Any, val target: String) : PendingPick()
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex = -1
    private var colorPickCatcher: View? = null

    private fun startAddRegion() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        addRegionWindow()
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    private fun addRegionWindow(initX: Int? = null, initY: Int? = null, initW: Int? = null, initH: Int? = null): ActiveRegion {
        val id = "r${regionCounter++}"
        val density = resources.displayMetrics.density
        val defaultSize = (130 * density).toInt()
        val handleSize = (22 * density).toInt()
        val offset = (regionCounter % 6) * (24 * density).toInt()

        val box = View(this).apply { background = borderDrawable(Color.parseColor("#2196F3")) }
        val handleView = View(this).apply { setBackgroundColor(Color.WHITE) }

        val container = LinearLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        val boxParams = android.widget.FrameLayout.LayoutParams(defaultSize, defaultSize)
        val handleParams = android.widget.FrameLayout.LayoutParams(handleSize, handleSize).apply {
            leftMargin = defaultSize - handleSize / 2
            topMargin = defaultSize - handleSize / 2
        }
        val frameContainer = android.widget.FrameLayout(this)
        frameContainer.addView(box, boxParams)
        frameContainer.addView(handleView, handleParams)
        container.addView(frameContainer)
        container.clipChildren = false

        val containerParams = WindowManager.LayoutParams(
            defaultSize + handleSize, defaultSize + handleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX ?: ((60 * density).toInt() + offset)
            y = initY ?: ((220 * density).toInt() + offset)
            width = (initW ?: defaultSize) + handleSize
            height = (initH ?: defaultSize) + handleSize
        }
        boxParams.width = initW ?: defaultSize
        boxParams.height = initH ?: defaultSize
        handleParams.leftMargin = (initW ?: defaultSize) - handleSize / 2
        handleParams.topMargin = (initH ?: defaultSize) - handleSize / 2

        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = containerParams.x
            y = (containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        }

        windowManager?.addView(container, containerParams)
        windowManager?.addView(label, labelParams)

        val region = ActiveRegion(id, container, containerParams, label, labelParams)
        activeRegions.add(region)

        setupRegionTouch(region, frameContainer, box, boxParams, handleView, handleParams, containerParams, handleSize)
        return region
    }

    private fun borderDrawable(color: Int): android.graphics.drawable.GradientDrawable {
        val density = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((2.5f * density).toInt(), color)
        }
    }

    private fun updateLabelPosition(region: ActiveRegion) {
        val density = resources.displayMetrics.density
        region.labelParams.x = region.containerParams.x
        region.labelParams.y = (region.containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        windowManager?.updateViewLayout(region.label, region.labelParams)
    }

    private fun setupRegionTouch(
        region: ActiveRegion, frameContainer: android.widget.FrameLayout, box: View, boxParams: android.widget.FrameLayout.LayoutParams,
        handleView: View, handleParams: android.widget.FrameLayout.LayoutParams, containerParams: WindowManager.LayoutParams, handleSize: Int
    ) {
        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var startX = 0; var startY = 0
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    startX = containerParams.x; startY = containerParams.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 18 || abs(dy) > 18) longPressHandler.removeCallbacks(longPressRunnable)
                    containerParams.x = startX + dx
                    containerParams.y = startY + dy
                    windowManager?.updateViewLayout(region.container, containerParams)
                    updateLabelPosition(region)
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < 18 && dt < 350) openRegionConfigDialog(region)
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handleView.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSize = (40 * resources.displayMetrics.density).toInt()
                val localX = (event.rawX - containerParams.x).toInt().coerceAtLeast(minSize)
                val localY = (event.rawY - containerParams.y).toInt().coerceAtLeast(minSize)
                boxParams.width = localX
                boxParams.height = localY
                handleParams.leftMargin = localX - handleSize / 2
                handleParams.topMargin = localY - handleSize / 2
                frameContainer.requestLayout()
                containerParams.width = localX + handleSize
                containerParams.height = localY + handleSize
                windowManager?.updateViewLayout(region.container, containerParams)
            }
            true
        }
    }

    private fun regionRect(region: ActiveRegion): IntArray {
        // Overlay pencere koordinatları GERÇEK ekran piksel koordinatlarıdır — MediaProjection
        // yakalaması da aynı çözünürlükte olduğu için doğrudan (ölçekleme gerekmeden) kullanılabilir.
        val p = region.containerParams
        val handleSize = (22 * resources.displayMetrics.density).toInt()
        return intArrayOf(p.x, p.y, (p.width - handleSize).coerceAtLeast(4), (p.height - handleSize).coerceAtLeast(4))
    }

    private fun openHideDeleteMenu(region: ActiveRegion) {
        overlayDialog()
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    region.container.visibility = View.GONE
                    region.label.visibility = View.GONE
                    Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
                } else {
                    removeRegionWindow(region)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    private fun removeRegionWindow(region: ActiveRegion) {
        try { windowManager?.removeView(region.container) } catch (e: Exception) {}
        try { windowManager?.removeView(region.label) } catch (e: Exception) {}
        activeRegions.remove(region)
    }

    private fun clearAllRegionWindows() {
        activeRegions.toList().forEach { removeRegionWindow(it) }
    }

    // ==================== Ekrana dokunarak nokta/renk seçme (tam ekran yakalayıcı) ====================

    private fun armColorPick(region: ActiveRegion) {
        pendingPick = PendingPick.ColorPick(region)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
        Toast.makeText(this, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    private fun armActionPoint(region: ActiveRegion, target: String) {
        pendingPick = PendingPick.ActionPoint(region, target)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
    }

    private fun showTouchCatcher(onTap: (Int, Int) -> Unit) {
        val catcher = View(this)
        val catcherParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val bx = event.rawX.toInt(); val by = event.rawY.toInt()
                try { windowManager?.removeView(catcher) } catch (e: Exception) {}
                colorPickCatcher = null
                onTap(bx, by)
            }
            true
        }
        colorPickCatcher = catcher
        windowManager?.addView(catcher, catcherParams)
    }

    private fun handlePointCaught(bx: Int, by: Int) {
        val pick = pendingPick ?: return
        pendingPick = null
        val frame = ScreenCaptureService.latestFrame
        when (pick) {
            is PendingPick.ColorPick -> {
                val region = pick.region as ActiveRegion
                val color = frame?.let {
                    if (bx in 0 until it.width && by in 0 until it.height) it.getPixel(bx, by) else Color.BLACK
                } ?: Color.BLACK
                showColorConfirm(region, color, bx, by)
            }
            is PendingPick.ActionPoint -> {
                val region = pick.region as ActiveRegion
                when (pick.target) {
                    "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
                    "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
                    "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
                    "EXTRA_TAP_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                        region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
                    }
                    "EXTRA_TAP_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                        region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
                    }
                }
                openRegionConfigDialog(region)
            }
        }
    }

    private fun showColorConfirm(region: ActiveRegion, color: Int, bx: Int, by: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and color)
        val swatch = View(this).apply { setBackgroundColor(color) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@OverlayService).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        overlayDialog()
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = color
                openRegionConfigDialog(region)
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region) }
            .create().showOverlay()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: ActiveRegion) {
        var currentTab = "GENERAL"
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabGeneral = Button(this).apply { text = "GENEL"; textSize = 9f }
        val tabAction = Button(this).apply { text = "AKSİYON"; textSize = 9f }
        val tabSuccess = Button(this).apply { text = "BAŞARILI"; textSize = 9f }
        val tabFail = Button(this).apply { text = "BULUNAMAZSA"; textSize = 9f }
        val tabLoop = Button(this).apply { text = "TEKRAR"; textSize = 9f }
        listOf(tabGeneral, tabAction, tabSuccess, tabFail, tabLoop).forEach {
            tabBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 0) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabBar); addView(content) }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("💾 Kaydet", null)
            .setNeutralButton("🗑 Sil", null)
            .setNegativeButton("Kapat", null)
            .create()

        fun highlight() {
            listOf(tabGeneral to "GENERAL", tabAction to "ACTION", tabSuccess to "SUCCESS", tabFail to "FAIL", tabLoop to "LOOP").forEach { (b, k) ->
                b.setTextColor(if (k == currentTab) Color.parseColor("#2196F3") else Color.DKGRAY)
            }
        }
        fun render() {
            content.removeAllViews()
            when (currentTab) {
                "GENERAL" -> buildGeneralTab(region, content, dialog)
                "ACTION" -> buildActionTab(region, content, dialog)
                "SUCCESS" -> buildExtraTab(region, content, dialog, false)
                "FAIL" -> buildExtraTab(region, content, dialog, true)
                "LOOP" -> buildLoopTab(region, content)
            }
            highlight()
        }
        tabGeneral.setOnClickListener { currentTab = "GENERAL"; render() }
        tabAction.setOnClickListener { currentTab = "ACTION"; render() }
        tabSuccess.setOnClickListener { currentTab = "SUCCESS"; render() }
        tabFail.setOnClickListener { currentTab = "FAIL"; render() }
        tabLoop.setOnClickListener { currentTab = "LOOP"; render() }

        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.setOnShowListener {
            render()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (saveRegionAsRule(region)) { dialog.dismiss(); removeRegionWindow(region) }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                region.existingRuleId?.let { RuleStorage.deleteRule(this, it) }
                removeRegionWindow(region)
                ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
            }
        }
        dialog.show()
    }

    private fun buildGeneralTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Kural adı"; setText(region.name) }
        nameInput.addTextChangedListener(simpleWatcher { region.name = it })
        content.addView(nameInput)
        val groupInput = EditText(ctx).apply { hint = "Grup adı (isteğe bağlı)"; setText(region.groupName) }
        groupInput.addTextChangedListener(simpleWatcher { region.groupName = it })
        content.addView(groupInput)

        content.addView(TextView(ctx).apply { text = "Bu alanda ne aranacak?"; setPadding(0, 16, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD) })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk"; id = 1 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR)"; id = 3 }
        listOf(rbColor, rbImage, rbText).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    val r = regionRect(region)
                    val preview = ScreenCaptureService.latestFrame?.let { safeCrop(it, r[0], r[1], r[2], r[3]) }
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    if (preview != null) iv.setImageBitmap(preview)
                    sub.addView(TextView(ctx).apply { text = "Kırpma önizlemesi:" })
                    sub.addView(iv)
                    val btnRecrop = Button(ctx).apply { text = "🔄 Bu alandan yeniden kırp" }
                    btnRecrop.setOnClickListener {
                        val r2 = regionRect(region)
                        val cropped = ScreenCaptureService.latestFrame?.let { safeCrop(it, r2[0], r2[1], r2[2], r2[3]) }
                        if (cropped != null) { region.conditionTemplatePath = TemplateStorage.save(ctx, cropped); Toast.makeText(ctx, "Şablon güncellendi", Toast.LENGTH_SHORT).show() }
                    }
                    sub.addView(btnRecrop)
                    val btnLib = Button(ctx).apply { text = "📚 Kütüphaneden Seç" }
                    btnLib.setOnClickListener { pickFromLibrary(region) { renderSub() } }
                    sub.addView(btnLib)
                    addMinScoreControls(ctx, sub, region)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.addTextChangedListener(simpleWatcher { region.conditionText = it })
                    sub.addView(input)
                }
                else -> {
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply { text = String.format(" #%06X", 0xFFFFFF and region.conditionColor) })
                    sub.addView(row)
                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armColorPick(region) }
                    sub.addView(btnPick)
                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.addTextChangedListener(simpleWatcher { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) { region.conditionColor = parsed; swatch.setBackgroundColor(parsed) }
                    })
                    sub.addView(hexInput)
                    addMinScoreControls(ctx, sub, region)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; else -> "COLOR" }
            renderSub()
        }
    }

    private fun addMinScoreControls(ctx: android.content.Context, sub: LinearLayout, region: ActiveRegion) {
        val label = TextView(ctx).apply { text = "Min Skor: %${region.minScore}" }
        val seek = SeekBar(ctx).apply {
            max = 100; progress = region.minScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { region.minScore = v; label.text = "Min Skor: %$v" }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        sub.addView(label); sub.addView(seek)
    }

    private fun pickFromLibrary(region: ActiveRegion, onDone: () -> Unit) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        overlayDialog()
            .setTitle("Seç")
            .setItems(labels) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") { region.conditionKind = "IMAGE"; region.conditionTemplatePath = item.templatePath }
                else { region.conditionKind = "COLOR"; region.conditionColor = item.color }
                onDone()
            }
            .create().showOverlay()
    }

    private fun buildActionTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbTap = android.widget.RadioButton(ctx).apply { text = "👆 Dokunma"; id = 1 }
        val rbSwipe = android.widget.RadioButton(ctx).apply { text = "👉 Kaydırma"; id = 2 }
        val rbFunc = android.widget.RadioButton(ctx).apply { text = "🔧 Fonksiyon Çağır"; id = 3 }
        listOf(rbTap, rbSwipe, rbFunc).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.actionType) { "SWIPE" -> 2; "CALL_FUNCTION" -> 3; else -> 1 })
        content.addView(radioGroup)
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.actionType) {
                "SWIPE" -> {
                    sub.addView(TextView(ctx).apply { text = "Başlangıç: (${region.actionX}, ${region.actionY})" })
                    val btnStart = Button(ctx).apply { text = "📍 Başlangıç Noktasını Seç" }
                    btnStart.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_START") }
                    sub.addView(btnStart)
                    sub.addView(TextView(ctx).apply { text = "Bitiş: (${region.actionX2}, ${region.actionY2})" })
                    val btnEnd = Button(ctx).apply { text = "📍 Bitiş Noktasını Seç" }
                    btnEnd.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_END") }
                    sub.addView(btnEnd)
                }
                "CALL_FUNCTION" -> {
                    sub.addView(TextView(ctx).apply { text = if (region.callFunctionName.isNotBlank()) "Seçili: f{} ${region.callFunctionName}" else "Henüz seçilmedi" })
                    val btnPick = Button(ctx).apply { text = "🔧 Fonksiyon Seç/Oluştur" }
                    btnPick.setOnClickListener { pickOrCreateFunction(region) { renderSub() } }
                    sub.addView(btnPick)
                    val repeatInput = EditText(ctx).apply {
                        hint = "Kaç kere çalışsın"; inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.callFunctionRepeat.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.callFunctionRepeat = it.toIntOrNull() ?: 1 })
                    sub.addView(repeatInput)
                }
                else -> {
                    sub.addView(TextView(ctx).apply { text = "Nokta: (${region.actionX}, ${region.actionY})" })
                    val btnPick = Button(ctx).apply { text = "📍 Dokunulacak Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armActionPoint(region, "TAP") }
                    sub.addView(btnPick)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.actionType = when (checkedId) { 2 -> "SWIPE"; 3 -> "CALL_FUNCTION"; else -> "TAP" }
            renderSub()
        }
    }

    private fun pickOrCreateFunction(region: ActiveRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        overlayDialog().setItems(options.toTypedArray()) { _, index ->
            if (index == 0) {
                val input = EditText(this).apply { hint = "Fonksiyon adı" }
                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                    .setPositiveButton("Oluştur") { _, _ ->
                        val name = input.text.toString().ifBlank { "fonksiyon" }
                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                        FunctionStorage.upsert(this, fn)
                        region.callFunctionId = fn.id; region.callFunctionName = fn.name
                        onDone()
                    }.create().showOverlay()
            } else {
                val fn = functions[index - 1]
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            }
        }.create().showOverlay()
    }

    private fun buildExtraTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog, isFail: Boolean) {
        val ctx = this
        val list = if (isFail) region.onFailActions else region.extraActions
        val pickTarget = if (isFail) "EXTRA_TAP_FAIL" else "EXTRA_TAP_SUCCESS"
        content.addView(TextView(ctx).apply {
            text = if (isFail) "Bu alan BULUNAMAZSA yapılacaklar:" else "Birincil aksiyondan HEMEN SONRA yapılacaklar:"
            textSize = 12f
        })
        val listView = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(listView)
        fun renderList() {
            listView.removeAllViews()
            list.forEachIndexed { index, extra ->
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val desc = if (extra.type == "CALL_FUNCTION") "🔧 f{} ${extra.functionName} x${extra.repeat}" else "👆 Dokun (${extra.x},${extra.y})"
                row.addView(TextView(ctx).apply { text = desc; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                btnRemove.setOnClickListener { list.removeAt(index); renderList() }
                row.addView(btnRemove)
                listView.addView(row)
            }
        }
        renderList()
        val btnAdd = Button(ctx).apply { text = "+ Ekle" }
        btnAdd.setOnClickListener {
            overlayDialog().setItems(arrayOf("👆 Dokunma Ekle", "🔧 Fonksiyon Çağırma Ekle")) { _, index ->
                if (index == 0) {
                    list.add(ExtraAction("TAP"))
                    pendingExtraActionIndex = list.size - 1
                    dialog.dismiss()
                    armActionPoint(region, pickTarget)
                } else {
                    val functions = FunctionStorage.load(ctx)
                    val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                    opts.addAll(functions.map { "f{} ${it.name}" })
                    overlayDialog().setItems(opts.toTypedArray()) { _, idx2 ->
                        if (idx2 == 0) {
                            val input = EditText(ctx).apply { hint = "Fonksiyon adı" }
                            overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                                .setPositiveButton("Oluştur") { _, _ ->
                                    val name = input.text.toString().ifBlank { "fonksiyon" }
                                    val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                                    FunctionStorage.upsert(ctx, fn)
                                    list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                    renderList()
                                }.create().showOverlay()
                        } else {
                            val fn = functions[idx2 - 1]
                            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                            renderList()
                        }
                    }.create().showOverlay()
                }
            }.create().showOverlay()
        }
        content.addView(btnAdd)
    }

    private fun buildLoopTab(region: ActiveRegion, content: LinearLayout) {
        val ctx = this
        content.addView(TextView(ctx).apply { text = "Bekleme süresi (ms) — tetiklendikten sonra en az ne kadar beklesin:"; textSize = 12f })
        val cooldownInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(region.cooldownMs.toString()) }
        cooldownInput.addTextChangedListener(simpleWatcher { region.cooldownMs = it.toLongOrNull() ?: 300 })
        content.addView(cooldownInput)
        val negateCheck = android.widget.CheckBox(ctx).apply { text = "⏳ Ters mantık: koşul KAYBOLDUĞUNDA tetikle"; isChecked = region.negate }
        negateCheck.setOnCheckedChangeListener { _, checked -> region.negate = checked }
        content.addView(negateCheck)
        content.addView(TextView(ctx).apply { text = "İsteğe bağlı: Değişken/Sayaç"; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 16, 0, 0) })
        val incName = EditText(ctx).apply { hint = "Tetiklenince artırılacak sayaç adı"; setText(region.incrementVariableName ?: "") }
        incName.addTextChangedListener(simpleWatcher { region.incrementVariableName = it.ifBlank { null } })
        content.addView(incName)
        val incDelta = EditText(ctx).apply { hint = "Ne kadar artırılsın"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText(region.incrementVariableDelta.toString()) }
        incDelta.addTextChangedListener(simpleWatcher { region.incrementVariableDelta = it.toIntOrNull() ?: 1 })
        content.addView(incDelta)
        val reqName = EditText(ctx).apply { hint = "Ek şart: bu sayaç adı"; setText(region.requireVariableName ?: "") }
        reqName.addTextChangedListener(simpleWatcher { region.requireVariableName = it.ifBlank { null } })
        content.addView(reqName)
        val reqOp = EditText(ctx).apply { hint = ">=, <=, ==, >, <"; setText(region.requireVariableOp) }
        reqOp.addTextChangedListener(simpleWatcher { region.requireVariableOp = it.ifBlank { ">=" } })
        content.addView(reqOp)
        val reqVal = EditText(ctx).apply { hint = "Karşılaştırılacak sayı"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText(region.requireVariableValue.toString()) }
        reqVal.addTextChangedListener(simpleWatcher { region.requireVariableValue = it.toIntOrNull() ?: 0 })
        content.addView(reqVal)
    }

    private fun saveRegionAsRule(region: ActiveRegion): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show(); return false
        }
        val r = regionRect(region)
        val mainAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        val name = region.name.ifBlank { "İsimsiz kural" }
        val def = RuleDefinition(
            id = region.existingRuleId ?: UUID.randomUUID().toString(), name = name, enabled = true,
            groupName = region.groupName.ifBlank { null }, alternatives = mutableListOf(mainAlt),
            timeoutMs = region.cooldownMs, negateCondition = region.negate,
            requireVariableName = region.requireVariableName, requireVariableOp = region.requireVariableOp, requireVariableValue = region.requireVariableValue,
            actionType = region.actionType, actionX = region.actionX, actionY = region.actionY, actionX2 = region.actionX2, actionY2 = region.actionY2,
            callFunctionId = region.callFunctionId, callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName, incrementVariableDelta = region.incrementVariableDelta
        )
        RuleStorage.upsert(this, def)
        region.extraActions.forEachIndexed { index, extra ->
            RuleStorage.upsert(this, RuleDefinition(
                id = UUID.randomUUID().toString(), name = "$name → ek ${index + 1}", enabled = true,
                groupName = region.groupName.ifBlank { null }, alternatives = mutableListOf(mainAlt),
                timeoutMs = region.cooldownMs, negateCondition = region.negate,
                actionType = extra.type, actionX = extra.x, actionY = extra.y, callFunctionId = extra.functionId, callFunctionRepeat = extra.repeat
            ))
        }
        region.onFailActions.forEachIndexed { index, extra ->
            RuleStorage.upsert(this, RuleDefinition(
                id = UUID.randomUUID().toString(), name = "$name → bulunamazsa ${index + 1}", enabled = true,
                groupName = region.groupName.ifBlank { null }, alternatives = mutableListOf(mainAlt),
                timeoutMs = region.cooldownMs, negateCondition = !region.negate,
                actionType = extra.type, actionX = extra.x, actionY = extra.y, callFunctionId = extra.functionId, callFunctionRepeat = extra.repeat
            ))
        }
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeX = x.coerceIn(0, bitmap.width - 1)
        val safeY = y.coerceIn(0, bitmap.height - 1)
        val safeW = w.coerceAtMost(bitmap.width - safeX)
        val safeH = h.coerceAtMost(bitmap.height - safeY)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ==================== Ana Akış ====================

    private fun showRulesMenu() {
        val rules = RuleStorage.load(this)
        if (rules.isEmpty() && !com.bigboss.app.storage.RuleClipboard.hasContent()) {
            Toast.makeText(this, "Henüz kural yok — \"Alan Ekle\" ile başla", Toast.LENGTH_SHORT).show()
            return
        }
        val groups = rules.mapNotNull { it.groupName }.distinct()
        val labels = mutableListOf<String>()
        if (com.bigboss.app.storage.RuleClipboard.hasContent()) labels.add("📥 Yapıştır (${com.bigboss.app.storage.RuleClipboard.peekName()})")
        if (groups.isNotEmpty()) labels.add("🔍 Gruba Göre Filtrele")
        rules.forEachIndexed { i, r -> labels.add("${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.groupName?.let { "[$it] " } ?: ""}${r.name}") }
        val offset = labels.size - rules.size

        overlayDialog()
            .setTitle("🏠 Ana Akış (${rules.size})")
            .setItems(labels.toTypedArray()) { _, index ->
                when {
                    com.bigboss.app.storage.RuleClipboard.hasContent() && index == 0 -> pasteRule()
                    groups.isNotEmpty() && index == (if (com.bigboss.app.storage.RuleClipboard.hasContent()) 1 else 0) -> showGroupFilterMenu(groups)
                    else -> showRuleOptions(rules[index - offset])
                }
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog().setTitle("Grup Seç").setItems(groups.toTypedArray()) { _, gIndex ->
            val group = groups[gIndex]
            val filtered = RuleStorage.load(this).filter { it.groupName == group }
            val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
            overlayDialog().setTitle("[$group] (${filtered.size})").setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                .setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showRuleOptions(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle", if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir", "🧪 Test Et",
            "📋 Kopyala", "✂️ Kes", "⬆️ Yukarı Taşı", "⬇️ Aşağı Taşı", "🗑 Sil"
        )
        overlayDialog().setTitle(rule.name).setItems(options) { _, index ->
            when (index) {
                0 -> editExistingRule(rule)
                1 -> { rule.enabled = !rule.enabled; RuleStorage.upsert(this, rule); ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this))) }
                2 -> testRule(rule)
                3 -> { com.bigboss.app.storage.RuleClipboard.copy(rule); Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show() }
                4 -> {
                    com.bigboss.app.storage.RuleClipboard.copy(rule)
                    RuleStorage.deleteRule(this, rule.id)
                    ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                    Toast.makeText(this, "Kesildi: ${rule.name}", Toast.LENGTH_SHORT).show()
                }
                5 -> { RuleStorage.moveUp(this, rule.id); ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this))) }
                6 -> { RuleStorage.moveDown(this, rule.id); ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this))) }
                7 -> {
                    RuleStorage.deleteRule(this, rule.id)
                    ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Var olan bir kuralı düzenlemek için, o kuralın alanını ekranda GERÇEK overlay kutusu olarak geri getirir. */
    private fun editExistingRule(rule: RuleDefinition) {
        val alt = rule.alternatives.firstOrNull() ?: return
        val region = addRegionWindow(alt.x, alt.y, alt.width, alt.height)
        region.existingRuleId = rule.id
        region.name = rule.name
        region.groupName = rule.groupName ?: ""
        region.conditionKind = alt.conditionKind
        region.conditionColor = alt.color
        region.conditionTemplatePath = alt.templatePath
        region.conditionText = alt.expectedText ?: ""
        region.minScore = alt.minScore
        region.actionType = rule.actionType
        region.actionX = rule.actionX; region.actionY = rule.actionY
        region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
        region.callFunctionId = rule.callFunctionId
        region.callFunctionName = rule.callFunctionId?.let { id -> FunctionStorage.load(this).find { it.id == id }?.name } ?: ""
        region.callFunctionRepeat = rule.callFunctionRepeat
        region.cooldownMs = rule.timeoutMs
        region.negate = rule.negateCondition
        val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
        region.label.text = "$icon ${region.name}"
        Toast.makeText(this, "Alan geri getirildi — düzenleyip kaydet", Toast.LENGTH_LONG).show()
    }

    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        overlayDialog().setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null).create().showOverlay()
    }

    // ==================== Fonksiyonlar ====================

    private fun showFunctionsMenu() {
        val functions = FunctionStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon")
        options.addAll(functions.map { "f{} ${it.name} (${it.rules.size})" })
        overlayDialog().setTitle("f{} Fonksiyonlar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createFunction() else showFunctionOptions(functions[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı" }
        overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showFunctionOptions(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setItems(arrayOf("➕ Bu Fonksiyona Kural Ekle", "🗑 Fonksiyonu Sil")) { _, index ->
                if (index == 0) {
                    if (ScreenCaptureService.latestFrame == null) {
                        Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Not: fonksiyon içine alan ekleme henüz bu overlay sürümüne taşınmadı.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    FunctionStorage.delete(this, fn.id)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }.create().showOverlay()
    }

    // ==================== Kod (Script) ====================

    private fun showScriptsMenu() {
        val scripts = com.bigboss.app.storage.ScriptStorage.load(this)
        val options = mutableListOf("➕ Yeni Script")
        options.addAll(scripts.map { "🖥️ ${it.name}" })
        overlayDialog().setTitle("🖥️ Kod").setItems(options.toTypedArray()) { _, index ->
            val intent = Intent(this, ScriptEditorActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            if (index > 0) intent.putExtra(ScriptEditorActivity.EXTRA_SCRIPT_ID, scripts[index - 1].id)
            startActivity(intent)
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kütüphane ====================

    private fun showLibraryMenu() {
        val items = LibraryStorage.load(this)
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size + 1
            override fun getItem(position: Int): Any? = if (position == 0) null else items[position - 1]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_library_dialog, parent, false)
                val ivThumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivThumb)
                val tvName = view.findViewById<TextView>(com.bigboss.app.R.id.tvName)
                if (position == 0) {
                    ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(Color.parseColor("#333333"))
                    tvName.text = "📷 Ekrandan Kırp"
                } else {
                    val item = items[position - 1]
                    if (item.kind == "IMAGE" && !item.templatePath.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(item.templatePath)
                        if (bmp != null) ivThumb.setImageBitmap(bmp) else ivThumb.setBackgroundColor(Color.DKGRAY)
                    } else { ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(item.color) }
                    tvName.text = "${if (item.kind == "IMAGE") "🖼️" else "🎨"} ${item.name}"
                }
                return view
            }
        }
        overlayDialog().setTitle("📚 Kütüphanem (${items.size})").setAdapter(adapter) { _, position ->
            if (position == 0) {
                if (ScreenCaptureService.latestFrame == null) Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
                else startActivity(Intent(this, LibraryCaptureActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            } else showLibraryItemOptions(items[position - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog().setTitle(item.name).setItems(options) { _, index ->
            when (options[index]) {
                "✂️ Piksel Kırp" -> startActivity(Intent(this, com.bigboss.app.ui.LibraryCropActivity::class.java).apply {
                    putExtra(com.bigboss.app.ui.LibraryCropActivity.EXTRA_LIBRARY_ITEM_ID, item.id)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                "↻ 90° Döndür" -> rotateLibraryImage(item)
                "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                "🗑 Sil" -> { LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
            }
        }.create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog().setTitle("Yeniden adlandır").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    override fun onDestroy() {
        clearAllRegionWindows()
        colorPickCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
