package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.storage.ActionGroupStorage
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import com.bigboss.app.ui.ScriptEditorActivity
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 *
 * ÖNEMLİ MİMARİ NOT: Alan çizme/düzenleme artık bir Activity DEĞİL —
 * doğrudan WindowManager ile eklenen GERÇEK overlay pencereleri.
 * Bunun sebebi: şeffaf temalı bir Activity, çoğu oyunun kullandığı
 * SurfaceView/GLSurfaceView tabanlı çizimle düzgün bindirilmiyor
 * (Android'in bilinen bir kısıtı) — bu yüzden oyunun üstünde değil,
 * koyu bir katmanın üstünde görünüyordu. Gerçek overlay pencereleri
 * (bizim küçük ✏️ simgemiz gibi) HER TÜRLÜ uygulamanın (oyunlar dahil)
 * üzerinde güvenilir şekilde çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var expanded = false
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (mode == "PLAY") {
            val engine = ScreenCaptureService.ruleEngine
            playState = if (engine != null && !engine.paused) "PLAYING" else if (playState == "STOPPED") "STOPPED" else "PAUSED"
        } else if (mode == "EDIT") {
            editTestRunning = false // güvenlik: Edit Mode'a her girişte varsayılan olarak dokunuş kapalı
        }
        if (rootView == null) buildOverlay() else rebuildPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    // ==================== Overlay pencere iskeleti (küçük simge) ====================

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        toggleButton = TextView(this).apply {
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }
        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#EE1A1A1A"))
        }
        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private var playState = "STOPPED" // PLAYING | PAUSED | STOPPED
    private var editTestRunning = false // Edit Mode'dan ÇIKMADAN motoru geçici çalıştırma anahtarı

    private fun rebuildPanel() {
        expandedPanel.removeAllViews()
        toggleButton.text = if (mode == "EDIT") "✏️" else when (playState) {
            "PLAYING" -> "▶️"; "PAUSED" -> "⏸️"; else -> "⏹️"
        }

        fun iconBtn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 13f
            setOnClickListener { collapse(); onClick() }
        }

        if (mode == "EDIT") {
            expandedPanel.addView(TextView(this).apply {
                text = if (editTestRunning) "🧪 CANLI TEST — kurallar GERÇEKTEN çalışıyor" else "✏️ DÜZENLEME — dokunuş yapılmaz"
                setTextColor(Color.WHITE); textSize = 12f; setPadding(16, 12, 16, 8)
            })
            expandedPanel.addView(iconBtn("🖼️👆  Alan Ekle") { startAddRegion() })
            expandedPanel.addView(iconBtn("🗺️  Çalışma Alanı (alanları göster)") { showWorkspaceMenu() })
            if (activeRegions.isNotEmpty()) {
                expandedPanel.addView(iconBtn("🧹  Ekrandaki Kutuları Temizle") { clearAllRegionWindows() })
            }
            expandedPanel.addView(iconBtn("🏠  Ana Akış (kurallar + gruplar)") { showRulesMenu() })
            expandedPanel.addView(iconBtn("f{}  Fonksiyonlar") { showFunctionsMenu() })
            expandedPanel.addView(iconBtn("🖥️  Kod") { showScriptsMenu() })
            expandedPanel.addView(iconBtn("📚  Kütüphane") { showLibraryMenu() })
            expandedPanel.addView(iconBtn(if (editTestRunning) "⏸️  Canlı Testi Durdur" else "🧪  Canlı Test (Edit Mode'da kal)") { toggleEditTest() })
            expandedPanel.addView(iconBtn("▶️  Play Mode'a Geç (kalıcı çalıştır)") { switchToPlayMode() })
            expandedPanel.addView(iconBtn("✕  Kapat") { shutdown() })
        } else {
            // ---- PLAY MODE: sadece Play / Pause / Stop / Kapat ----
            expandedPanel.addView(TextView(this).apply {
                text = when (playState) {
                    "PLAYING" -> "▶️ ÇALIŞIYOR"
                    "PAUSED" -> "⏸️ DURAKLATILDI"
                    else -> "⏹️ DURDURULDU"
                }
                setTextColor(Color.WHITE); textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(16, 12, 16, 8)
            })
            expandedPanel.addView(iconBtn("▶️  Play — makroyu çalıştır") { playMacro() })
            expandedPanel.addView(iconBtn(if (playState == "PAUSED") "▶️  Devam Et" else "⏸️  Pause — duraklat") { togglePause() })
            expandedPanel.addView(iconBtn("⏹  Stop — durdur") { stopMacro() })
            expandedPanel.addView(iconBtn(if (liveMonitorOn) "👁️  Canlı İzlemeyi Kapat" else "👁️  Canlı İzleme (yeşil/kırmızı)") { toggleLiveMonitor() })
            expandedPanel.addView(iconBtn("✕  Kapat") { shutdown() })
        }
    }

    private fun switchToPlayMode() {
        mode = "PLAY"
        clearAllRegionWindows(); clearWorkspace()
        playMacro()
    }

    /** Edit Mode'dan hiç çıkmadan motoru geçici çalıştırır — sadece izlemek/test etmek için. */
    private fun toggleEditTest() {
        val engine = ScreenCaptureService.ruleEngine
        if (engine == null) {
            Toast.makeText(this, "Motor hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        editTestRunning = !editTestRunning
        engine.paused = !editTestRunning
        if (!editTestRunning) { engine.resetLoopState(); stopLiveMonitor() } else { startLiveMonitor() }
        rebuildPanel()
        Toast.makeText(
            this,
            if (editTestRunning) "🧪 Canlı test başladı — hangi alanın tarandığını yeşil/kırmızı ve sıralı vurguyla göreceksin"
            else "⏸️ Canlı test durdu — düzenlemeye devam edebilirsin",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun playMacro() {
        ScreenCaptureService.ruleEngine?.paused = false
        playState = "PLAYING"
        rebuildPanel()
        Toast.makeText(this, "▶️ Çalışıyor", Toast.LENGTH_SHORT).show()
    }

    private fun togglePause() {
        val engine = ScreenCaptureService.ruleEngine ?: return
        if (playState == "PAUSED") {
            engine.paused = false
            playState = "PLAYING"
            Toast.makeText(this, "▶️ Devam ediyor", Toast.LENGTH_SHORT).show()
        } else {
            engine.paused = true
            playState = "PAUSED"
            Toast.makeText(this, "⏸️ Duraklatıldı — kaldığı yerden devam edecek", Toast.LENGTH_SHORT).show()
        }
        rebuildPanel()
    }

    private fun stopMacro() {
        val engine = ScreenCaptureService.ruleEngine
        engine?.paused = true
        engine?.resetLoopState()
        playState = "STOPPED"
        stopLiveMonitor()
        rebuildPanel()
        Toast.makeText(this, "⏹ Durduruldu — Play'e basınca baştan başlar", Toast.LENGTH_SHORT).show()
    }

    // ==================== 👁️ Canlı İzleme: taranan alanlar yeşil/kırmızı yanar ====================

    private var liveMonitorOn = false
    private val liveMonitorHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var liveMonitorRunnable: Runnable? = null
    private data class LiveBox(val rule: RuleDefinition, val box: View)
    private val liveBoxes = mutableListOf<LiveBox>()
    private var liveMonitorSweepIndex = 0
    private var liveMonitorSweepLabel: TextView? = null
    private var liveMonitorSweepLabelParams: WindowManager.LayoutParams? = null

    private fun toggleLiveMonitor() {
        if (liveMonitorOn) stopLiveMonitor() else startLiveMonitor()
        rebuildPanel()
    }

    private fun startLiveMonitor() {
        val rules = RuleStorage.load(this).filter { !it.id.endsWith("-fail") && it.enabled && it.alternatives.isNotEmpty() }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Ana Akışta izlenecek alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        liveMonitorOn = true
        liveMonitorSweepIndex = 0
        rules.forEach { rule ->
            val alt = rule.alternatives.first()
            val box = View(this).apply { background = borderDrawable(Color.GRAY) }
            val params = WindowManager.LayoutParams(
                alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }
            try {
                windowManager?.addView(box, params)
                liveBoxes.add(LiveBox(rule, box))
            } catch (e: Exception) {}
        }
        // Sırayla "şu an taranan alan" etiketi — Ana Akış listesindeki sırayla ilerler.
        val sweepLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD000000"))
            textSize = 12f
            setPadding(16, 6, 16, 6)
        }
        val sweepParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 400 }
        try {
            windowManager?.addView(sweepLabel, sweepParams)
            liveMonitorSweepLabel = sweepLabel; liveMonitorSweepLabelParams = sweepParams
        } catch (e: Exception) {}

        Toast.makeText(this, "👁️ Canlı izleme açık — yeşil: eşleşti, kırmızı: eşleşmedi, kalın çerçeve: şu an taranan alan", Toast.LENGTH_LONG).show()
        scheduleLiveMonitorTick()
    }

    private fun scheduleLiveMonitorTick() {
        val tick = object : Runnable {
            override fun run() {
                if (!liveMonitorOn) return
                val frame = ScreenCaptureService.latestFrame
                if (frame != null && liveBoxes.isNotEmpty()) {
                    val currentIdx = liveMonitorSweepIndex % liveBoxes.size
                    liveBoxes.forEachIndexed { idx, lb ->
                        val matched = try {
                            val condition = RuleDefinitionMapper.toCondition(lb.rule)
                            val rawMatch = condition.matchScore(frame) >= condition.minScore
                            if (lb.rule.negateCondition) !rawMatch else rawMatch
                        } catch (e: Exception) { false }
                        val color = if (matched) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
                        val strokeDp = if (idx == currentIdx) 6f else 2.5f
                        lb.box.background = borderDrawable(color, strokeDp)
                    }
                    liveMonitorSweepLabel?.text = "🔍 Taranıyor: ${liveBoxes[currentIdx].rule.name} (${currentIdx + 1}/${liveBoxes.size})"
                    liveMonitorSweepIndex++
                }
                liveMonitorHandler.postDelayed(this, 400L)
            }
        }
        liveMonitorRunnable = tick
        liveMonitorHandler.post(tick)
    }

    private fun stopLiveMonitor() {
        liveMonitorOn = false
        liveMonitorRunnable?.let { liveMonitorHandler.removeCallbacks(it) }
        liveMonitorRunnable = null
        liveBoxes.forEach { try { windowManager?.removeView(it.box) } catch (e: Exception) {} }
        liveBoxes.clear()
        liveMonitorSweepLabel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        liveMonitorSweepLabel = null; liveMonitorSweepLabelParams = null
    }

    private fun collapse() {
        expanded = false
        expandedPanel.visibility = View.GONE
    }

    private fun shutdown() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        removePointMarker()
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
    }

    // ==================== Overlay üzerinden Dialog gösterme yardımcıları ====================

    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ==================== ALAN ÇİZME SİSTEMİ (gerçek overlay pencereleri) ====================

    private data class ExtraAction(
        val type: String, // "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT"
        var x: Int = 0, var y: Int = 0,
        var x2: Int = 0, var y2: Int = 0,
        var waitMs: Long = 500,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1,
        var variableName: String = "",
        var variableDelta: Int = 1,
        var scriptId: String? = null,
        var scriptName: String = ""
    )

    private inner class ActiveRegion(
        val id: String, val container: LinearLayout, val containerParams: WindowManager.LayoutParams,
        val label: TextView, val labelParams: WindowManager.LayoutParams,
        val frameContainer: android.widget.FrameLayout, val boxParams: android.widget.FrameLayout.LayoutParams,
        val handleParams: android.widget.FrameLayout.LayoutParams, val handleSizePx: Int
    ) {
        var existingRuleId: String? = null
        var name = ""
        var conditionKind = "COLOR"
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText = ""
        var minScore = 90
        var actionType = "TAP"
        var tapAtMatchLocation = false
        var actionRepeatCount = 1
        var actionHoldMs: Long = 50
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName = ""
        var callFunctionRepeat = 1
        val extraActions = mutableListOf<ExtraAction>()
        val onFailActions = mutableListOf<ExtraAction>()
        var cooldownMs: Long = 300
        var matchDelayMs: Long = 0
        var negate = false
        var loopMode = "ALWAYS" // NONE | ALWAYS | WHILE_SUCCESS | WHILE_FAIL
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
        /** GENEL sekmesindeki Find Region alanlarını, alan sürüklenince canlı güncellemek için. */
        var onRectChangedExternally: (() -> Unit)? = null
        /** Bu alan bir Action Group'un İÇİNE mi kaydedilecek, yoksa Ana Akışa mı? */
        var saveScope: SaveScope = SaveScope.MainFlow
        /** Bu alan bir Action Group'un KAPI koşulunu mu ayarlıyor (true ise sadece koşul kaydedilir)? */
        var isGateForGroupId: String? = null
        /** Bu alan Kütüphaneye "Ekrandan Kırp" için mi kullanılıyor (true ise dokununca kural penceresi değil, kaydetme sorulur)? */
        var isLibraryCapture: Boolean = false
    }

    private sealed class SaveScope {
        object MainFlow : SaveScope()
        data class Group(val groupId: String) : SaveScope()
        data class Function(val functionId: String) : SaveScope()
    }

    private val activeRegions = mutableListOf<ActiveRegion>()
    private var regionCounter = 0

    private sealed class PendingPick {
        data class ColorPick(val region: Any) : PendingPick()
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex = -1
    private var colorPickCatcher: View? = null

    private fun startAddRegion() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        addRegionWindow()
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    private fun addRegionWindow(initX: Int? = null, initY: Int? = null, initW: Int? = null, initH: Int? = null): ActiveRegion {
        val id = "r${regionCounter++}"
        val density = resources.displayMetrics.density
        val defaultSize = (130 * density).toInt()
        val handleSize = (22 * density).toInt()
        val offset = (regionCounter % 6) * (24 * density).toInt()

        val box = View(this).apply { background = borderDrawable(Color.parseColor("#2196F3")) }
        val handleView = View(this).apply { setBackgroundColor(Color.WHITE) }

        val container = LinearLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        val boxParams = android.widget.FrameLayout.LayoutParams(defaultSize, defaultSize)
        val handleParams = android.widget.FrameLayout.LayoutParams(handleSize, handleSize).apply {
            leftMargin = defaultSize - handleSize / 2
            topMargin = defaultSize - handleSize / 2
        }
        val frameContainer = android.widget.FrameLayout(this)
        frameContainer.addView(box, boxParams)
        frameContainer.addView(handleView, handleParams)
        container.addView(frameContainer)
        container.clipChildren = false

        val containerParams = WindowManager.LayoutParams(
            defaultSize + handleSize, defaultSize + handleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX ?: ((60 * density).toInt() + offset)
            y = initY ?: ((220 * density).toInt() + offset)
            width = (initW ?: defaultSize) + handleSize
            height = (initH ?: defaultSize) + handleSize
        }
        boxParams.width = initW ?: defaultSize
        boxParams.height = initH ?: defaultSize
        handleParams.leftMargin = (initW ?: defaultSize) - handleSize / 2
        handleParams.topMargin = (initH ?: defaultSize) - handleSize / 2

        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = containerParams.x
            y = (containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        }

        windowManager?.addView(container, containerParams)
        windowManager?.addView(label, labelParams)

        val region = ActiveRegion(id, container, containerParams, label, labelParams, frameContainer, boxParams, handleParams, handleSize)
        activeRegions.add(region)

        setupRegionTouch(region, frameContainer, box, boxParams, handleView, handleParams, containerParams, handleSize)
        return region
    }

    private fun borderDrawable(color: Int, strokeDp: Float = 2.5f): android.graphics.drawable.GradientDrawable {
        val density = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((strokeDp * density).toInt(), color)
        }
    }

    private fun updateLabelPosition(region: ActiveRegion) {
        val density = resources.displayMetrics.density
        region.labelParams.x = region.containerParams.x
        region.labelParams.y = (region.containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        windowManager?.updateViewLayout(region.label, region.labelParams)
    }

    private fun setupRegionTouch(
        region: ActiveRegion, frameContainer: android.widget.FrameLayout, box: View, boxParams: android.widget.FrameLayout.LayoutParams,
        handleView: View, handleParams: android.widget.FrameLayout.LayoutParams, containerParams: WindowManager.LayoutParams, handleSize: Int
    ) {
        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var startX = 0; var startY = 0
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    startX = containerParams.x; startY = containerParams.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    val cancelThreshold = (24 * resources.displayMetrics.density).toInt() // doğal parmak titremesiyle karışmasın diye geniş tolerans
                    if (abs(dx) > cancelThreshold || abs(dy) > cancelThreshold) longPressHandler.removeCallbacks(longPressRunnable)
                    containerParams.x = startX + dx
                    containerParams.y = startY + dy
                    windowManager?.updateViewLayout(region.container, containerParams)
                    updateLabelPosition(region)
                    region.onRectChangedExternally?.invoke()
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < 18 && dt < 350) {
                            if (region.isLibraryCapture) openLibraryCaptureSaveDialog(region) else openRegionConfigDialog(region)
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handleView.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSize = (40 * resources.displayMetrics.density).toInt()
                val localX = (event.rawX - containerParams.x).toInt().coerceAtLeast(minSize)
                val localY = (event.rawY - containerParams.y).toInt().coerceAtLeast(minSize)
                boxParams.width = localX
                boxParams.height = localY
                handleParams.leftMargin = localX - handleSize / 2
                handleParams.topMargin = localY - handleSize / 2
                frameContainer.requestLayout()
                containerParams.width = localX + handleSize
                containerParams.height = localY + handleSize
                windowManager?.updateViewLayout(region.container, containerParams)
                region.onRectChangedExternally?.invoke()
            }
            true
        }
    }

    private fun regionRect(region: ActiveRegion): IntArray {
        // Overlay pencere koordinatları GERÇEK ekran piksel koordinatlarıdır — MediaProjection
        // yakalaması da aynı çözünürlükte olduğu için doğrudan (ölçekleme gerekmeden) kullanılabilir.
        val p = region.containerParams
        val handleSize = (22 * resources.displayMetrics.density).toInt()
        return intArrayOf(p.x, p.y, (p.width - handleSize).coerceAtLeast(4), (p.height - handleSize).coerceAtLeast(4))
    }

    /** "Find Region" kutularına tam sayı yazınca, alanı EKRANDA da o konuma taşır/boyutlandırır. */
    private fun moveAndResizeRegion(region: ActiveRegion, x: Int, y: Int, w: Int, h: Int) {
        region.containerParams.x = x
        region.containerParams.y = y
        region.containerParams.width = w + region.handleSizePx
        region.containerParams.height = h + region.handleSizePx
        region.boxParams.width = w
        region.boxParams.height = h
        region.handleParams.leftMargin = w - region.handleSizePx / 2
        region.handleParams.topMargin = h - region.handleSizePx / 2
        try {
            region.frameContainer.requestLayout()
            windowManager?.updateViewLayout(region.container, region.containerParams)
        } catch (e: Exception) {}
        updateLabelPosition(region)
    }

    private fun openHideDeleteMenu(region: ActiveRegion) {
        overlayDialog()
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    region.container.visibility = View.GONE
                    region.label.visibility = View.GONE
                    Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
                } else {
                    deleteRegionCompletely(region)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir alanı hem ekrandan hem (kaydedilmiş bir kuralsa) kayıtlı veriden tamamen siler. */
    private fun deleteRegionCompletely(region: ActiveRegion) {
        val gateGroupId = region.isGateForGroupId
        if (gateGroupId != null) {
            val group = ActionGroupStorage.load(this).find { it.id == gateGroupId }
            if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
        } else {
            region.existingRuleId?.let { id ->
                when (val scope = region.saveScope) {
                    is SaveScope.MainFlow -> { RuleStorage.deleteRule(this, id); RuleStorage.deleteRule(this, "$id-fail") }
                    is SaveScope.Group -> { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, id); ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail") }
                    is SaveScope.Function -> { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, id); FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail") }
                }
            }
        }
        removeRegionWindow(region)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
    }

    private fun removeRegionWindow(region: ActiveRegion) {
        try { windowManager?.removeView(region.container) } catch (e: Exception) {}
        try { windowManager?.removeView(region.label) } catch (e: Exception) {}
        activeRegions.remove(region)
    }

    private fun clearAllRegionWindows() {
        activeRegions.toList().forEach { removeRegionWindow(it) }
    }

    // ==================== ÇALIŞMA ALANI (workspace) — Macrorify'daki "Draw selected/change working group" ====================

    private data class WorkspaceBox(val box: View, val label: TextView, val boxParams: WindowManager.LayoutParams, val labelParams: WindowManager.LayoutParams)
    private val workspaceBoxes = mutableListOf<WorkspaceBox>()
    private var workspaceHidden = false

    private fun showWorkspaceMenu() {
        val options = mutableListOf("🏠 Ana Akış")
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        var headerCount = 0
        if (workspaceBoxes.isNotEmpty()) {
            options.add(0, if (workspaceHidden) "👁️ Öğeleri Göster" else "🙈 Öğeleri Gizle")
            options.add(1, "🧹 Çalışma Alanı Görünümünü Kapat")
            headerCount = 2
        }
        overlayDialog().setTitle("🗺️ Hangi çalışma alanını göreyim?").setItems(options.toTypedArray()) { _, indexRaw ->
            var index = indexRaw
            if (headerCount > 0) {
                if (index == 0) { toggleWorkspaceHidden(); return@setItems }
                if (index == 1) { clearWorkspace(); return@setItems }
                index -= headerCount
            }
            when {
                index == 0 -> showWorkspaceFor(SaveScope.MainFlow, RuleStorage.load(this), "🏠 Ana Akış")
                index <= functions.size -> {
                    val fn = functions[index - 1]
                    showWorkspaceFor(SaveScope.Function(fn.id), fn.rules, "f{} ${fn.name}")
                }
                else -> {
                    val group = groups[index - 1 - functions.size]
                    showWorkspaceFor(SaveScope.Group(group.id), group.rules, "📦 ${group.name}")
                }
            }
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Çalışma Alanı kutularını (durumu KAYBETMEDEN) gizler/tekrar gösterir. */
    private fun toggleWorkspaceHidden() {
        workspaceHidden = !workspaceHidden
        val vis = if (workspaceHidden) View.GONE else View.VISIBLE
        workspaceBoxes.forEach { it.box.visibility = vis; it.label.visibility = vis }
        Toast.makeText(this, if (workspaceHidden) "🙈 Öğeler gizlendi (hâlâ ekranda kayıtlı)" else "👁️ Öğeler tekrar gösteriliyor", Toast.LENGTH_SHORT).show()
    }

    /** Seçilen kapsamdaki TÜM kuralların alanlarını, salt-okunur (dokununca düzenlemeye açılan) kutular olarak ekrana çizer — KALICI kalır. */
    private fun showWorkspaceFor(scope: SaveScope, rules: List<RuleDefinition>, label: String) {
        clearWorkspace()
        workspaceHidden = false
        val visible = rules.filter { !it.id.endsWith("-fail") && it.alternatives.isNotEmpty() }
        if (visible.isEmpty()) {
            Toast.makeText(this, "$label içinde henüz alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        visible.forEach { rule -> addWorkspaceBox(rule, scope) }
        Toast.makeText(this, "$label — ${visible.size} alan gösteriliyor (dokununca düzenlenir, kapatmak için tekrar 🗺️)", Toast.LENGTH_LONG).show()
    }

    private fun addWorkspaceBox(rule: RuleDefinition, scope: SaveScope) {
        val alt = rule.alternatives.first()
        val box = View(this).apply { background = borderDrawable(Color.parseColor("#FFA500")) } // turuncu = salt-okunur çalışma alanı kutusu
        val boxParams = WindowManager.LayoutParams(
            alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }

        val label = TextView(this).apply {
            text = "🗺️ ${rule.name}"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AAFFA500"))
            textSize = 10f
            setPadding(6, 2, 6, 2)
        }
        val density = resources.displayMetrics.density
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = alt.x
            y = (alt.y - 24 * density).toInt().coerceAtLeast(0)
        }

        box.setOnClickListener { /* no-op, dokunuşu ACTION_DOWN'da yakalıyoruz */ }
        box.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                clearWorkspace()
                editExistingRule(rule, scope)
            }
            true
        }

        try {
            windowManager?.addView(box, boxParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(box, label, boxParams, labelParams))
        } catch (e: Exception) {}
    }

    private fun clearWorkspace() {
        workspaceBoxes.forEach {
            try { windowManager?.removeView(it.box) } catch (e: Exception) {}
            try { windowManager?.removeView(it.label) } catch (e: Exception) {}
        }
        workspaceBoxes.clear()
        workspaceHidden = false
    }

    // ==================== 👆 Dokunma/Kaydırma Noktası İşaretçisi (Macrorify'daki gibi sürüklenebilir parmak simgesi) ====================

    /** Şu an ekranda duran (henüz onaylanmamış) nokta işaretçisi ve onay butonu. */
    private var pointMarkerContainer: View? = null
    private var pointMarkerParams: WindowManager.LayoutParams? = null
    private var pointMarkerConfirmBtn: View? = null
    private var pointMarkerConfirmParams: WindowManager.LayoutParams? = null

    /**
     * Ekranda sürüklenebilir bir 👆 işaretçi gösterir (isteğe bağlı "1"/"2" etiketiyle).
     * Kullanıcı işaretçiyi istediği yere sürükler, ayrı duran "✓ Onayla" butonuna basınca
     * o anki TAM konum (markerSize/2 merkez alınarak) geri döner.
     */
    private fun pickPointWithMarker(badgeLabel: String, initialX: Int?, initialY: Int?, onConfirmed: (Int, Int) -> Unit) {
        removePointMarker() // önceki iz kaldıysa temizle
        val density = resources.displayMetrics.density
        val frame = ScreenCaptureService.latestFrame
        val markerSize = (56 * density).toInt()
        val startX = (initialX ?: ((frame?.width ?: 1080) / 2)) - markerSize / 2
        val startY = (initialY ?: ((frame?.height ?: 1920) / 2)) - markerSize / 2

        val icon = TextView(this).apply {
            text = "👆"; textSize = 30f; gravity = Gravity.CENTER
            layoutParams = android.widget.FrameLayout.LayoutParams(markerSize, markerSize)
        }
        val badge = TextView(this).apply {
            text = badgeLabel
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD2196F3"))
            textSize = 11f
            setPadding(10, 2, 10, 2)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.END }
        }
        val markerContainer = android.widget.FrameLayout(this).apply {
            addView(icon); addView(badge)
        }
        val markerParams = WindowManager.LayoutParams(
            markerSize, markerSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = startX; y = startY }

        val confirmBtn = Button(this).apply { text = "✓ $badgeLabel Noktasını Onayla" }
        val confirmParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 100 }

        windowManager?.addView(markerContainer, markerParams)
        windowManager?.addView(confirmBtn, confirmParams)
        pointMarkerContainer = markerContainer; pointMarkerParams = markerParams
        pointMarkerConfirmBtn = confirmBtn; pointMarkerConfirmParams = confirmParams

        var downRawX = 0f; var downRawY = 0f; var startPX = 0; var startPY = 0
        markerContainer.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downRawX = event.rawX; downRawY = event.rawY; startPX = markerParams.x; startPY = markerParams.y }
                MotionEvent.ACTION_MOVE -> {
                    markerParams.x = startPX + (event.rawX - downRawX).toInt()
                    markerParams.y = startPY + (event.rawY - downRawY).toInt()
                    try { windowManager?.updateViewLayout(markerContainer, markerParams) } catch (e: Exception) {}
                }
            }
            true
        }

        confirmBtn.setOnClickListener {
            val finalX = markerParams.x + markerSize / 2
            val finalY = markerParams.y + markerSize / 2
            removePointMarker()
            onConfirmed(finalX, finalY)
        }

        Toast.makeText(this, "👆 $badgeLabel — işaretçiyi istediğin yere sürükle, sonra \"✓ Onayla\"ya bas", Toast.LENGTH_LONG).show()
    }

    private fun removePointMarker() {
        pointMarkerContainer?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerConfirmBtn?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerContainer = null; pointMarkerParams = null
        pointMarkerConfirmBtn = null; pointMarkerConfirmParams = null
    }

    // ==================== Ekrana dokunarak nokta/renk seçme (tam ekran yakalayıcı — sadece renk örneklemede kullanılıyor) ====================

    private fun armColorPick(region: ActiveRegion) {
        pendingPick = PendingPick.ColorPick(region)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
        Toast.makeText(this, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    private fun armActionPoint(region: ActiveRegion, target: String) {
        val badge = if (target.contains("SWIPE_START")) "1" else if (target.contains("SWIPE_END")) "2" else "👆"
        val initial: Pair<Int, Int>? = when (target) {
            "TAP" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_START" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_END" -> if (region.actionX2 != 0 || region.actionY2 != 0) region.actionX2 to region.actionY2 else null
            else -> null
        }
        pickPointWithMarker(badge, initial?.first, initial?.second) { bx, by ->
            applyActionPoint(region, target, bx, by)
        }
    }

    private fun applyActionPoint(region: ActiveRegion, target: String, bx: Int, by: Int) {
        var reopenDialog = true
        when (target) {
            "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
            "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
            "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
            "EXTRA_TAP_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_TAP_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_SWIPE_START_SUCCESS" -> {
                if (pendingExtraActionIndex in region.extraActions.indices) {
                    region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_SUCCESS")
            }
            "EXTRA_SWIPE_END_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x2 = bx; region.extraActions[pendingExtraActionIndex].y2 = by
            }
            "EXTRA_SWIPE_START_FAIL" -> {
                if (pendingExtraActionIndex in region.onFailActions.indices) {
                    region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_FAIL")
            }
            "EXTRA_SWIPE_END_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x2 = bx; region.onFailActions[pendingExtraActionIndex].y2 = by
            }
        }
        if (reopenDialog) openRegionConfigDialog(region)
    }

    private fun showTouchCatcher(onTap: (Int, Int) -> Unit) {
        val catcher = View(this)
        val catcherParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val bx = event.rawX.toInt(); val by = event.rawY.toInt()
                try { windowManager?.removeView(catcher) } catch (e: Exception) {}
                colorPickCatcher = null
                onTap(bx, by)
            }
            true
        }
        colorPickCatcher = catcher
        windowManager?.addView(catcher, catcherParams)
    }

    private fun handlePointCaught(bx: Int, by: Int) {
        val pick = pendingPick ?: return
        pendingPick = null
        val frame = ScreenCaptureService.latestFrame
        when (pick) {
            is PendingPick.ColorPick -> {
                val region = pick.region as ActiveRegion
                val color = frame?.let {
                    if (bx in 0 until it.width && by in 0 until it.height) it.getPixel(bx, by) else Color.BLACK
                } ?: Color.BLACK
                showColorConfirm(region, color, bx, by)
            }
        }
    }

    private fun showColorConfirm(region: ActiveRegion, color: Int, bx: Int, by: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and color)
        val swatch = View(this).apply { setBackgroundColor(color) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@OverlayService).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        overlayDialog()
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = color
                openRegionConfigDialog(region)
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region) }
            .create().showOverlay()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: ActiveRegion) {
        var currentTab = "GENERAL"
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabGeneral = Button(this).apply { text = "GENEL"; textSize = 9f }
        val tabAction = Button(this).apply { text = "AKSİYON"; textSize = 9f }
        val tabSuccess = Button(this).apply { text = "BAŞARILI"; textSize = 9f }
        val tabFail = Button(this).apply { text = "BULUNAMAZSA"; textSize = 9f }
        val tabLoop = Button(this).apply { text = "TEKRAR"; textSize = 9f }
        listOf(tabGeneral, tabAction, tabSuccess, tabFail, tabLoop).forEach {
            tabBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 0) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabBar); addView(content) }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("💾 Kaydet", null)
            .setNeutralButton("🗑 Sil", null)
            .setNegativeButton("Kapat", null)
            .create()

        fun highlight() {
            listOf(tabGeneral to "GENERAL", tabAction to "ACTION", tabSuccess to "SUCCESS", tabFail to "FAIL", tabLoop to "LOOP").forEach { (b, k) ->
                b.setTextColor(if (k == currentTab) Color.parseColor("#2196F3") else Color.DKGRAY)
            }
        }
        fun render() {
            content.removeAllViews()
            when (currentTab) {
                "GENERAL" -> buildGeneralTab(region, content, dialog)
                "ACTION" -> buildActionTab(region, content, dialog)
                "SUCCESS" -> buildExtraTab(region, content, dialog, false)
                "FAIL" -> buildExtraTab(region, content, dialog, true)
                "LOOP" -> buildLoopTab(region, content)
            }
            highlight()
        }
        tabGeneral.setOnClickListener { currentTab = "GENERAL"; render() }
        tabAction.setOnClickListener { currentTab = "ACTION"; render() }
        tabSuccess.setOnClickListener { currentTab = "SUCCESS"; render() }
        tabFail.setOnClickListener { currentTab = "FAIL"; render() }
        tabLoop.setOnClickListener { currentTab = "LOOP"; render() }

        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.setOnShowListener {
            render()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val gateGroupId = region.isGateForGroupId
                val saved = if (gateGroupId != null) saveRegionAsGate(region, gateGroupId) else saveRegionAsRule(region)
                if (saved) { dialog.dismiss(); removeRegionWindow(region) }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                val scope = region.saveScope
                val gateGroupId2 = region.isGateForGroupId
                if (gateGroupId2 != null) {
                    val group = ActionGroupStorage.load(this).find { it.id == gateGroupId2 }
                    if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
                } else when (scope) {
                    is SaveScope.MainFlow -> region.existingRuleId?.let { RuleStorage.deleteRule(this, it) }
                    is SaveScope.Group -> region.existingRuleId?.let { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, it) }
                    is SaveScope.Function -> region.existingRuleId?.let { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, it) }
                }
                removeRegionWindow(region)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
            }
        }
        dialog.show()
    }

    /** Bir alanı Action Group'un KAPI koşulu olarak kaydeder — sadece GENEL sekmesindeki koşul + cooldown kullanılır. */
    private fun saveRegionAsGate(region: ActiveRegion, groupId: String): Boolean {
        val group = ActionGroupStorage.load(this).find { it.id == groupId } ?: return false
        val r = regionRect(region)
        val gateAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        group.gate = gateAlt
        group.gateCooldownMs = region.cooldownMs
        ActionGroupStorage.upsert(this, group)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Kapı koşulu kaydedildi: ${group.name}", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun buildGeneralTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Kural adı"; setText(region.name) }
        nameInput.addTextChangedListener(simpleWatcher { region.name = it })
        content.addView(nameInput)

        content.addView(TextView(ctx).apply { text = "Bu alanda ne aranacak?"; setPadding(0, 16, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD) })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk"; id = 1 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR)"; id = 3 }
        listOf(rbColor, rbImage, rbText).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    val path = region.conditionTemplatePath
                    if (!path.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(path)
                        if (bmp != null) iv.setImageBitmap(bmp)
                        sub.addView(TextView(ctx).apply { text = "Seçili resim:" })
                        sub.addView(iv)
                    } else {
                        sub.addView(TextView(ctx).apply { text = "Henüz resim seçilmedi — aşağıdan kütüphaneden seç ya da ekrandan kendin kırp." })
                    }
                    val btnLib = Button(ctx).apply { text = "📚 Kütüphaneden Seç" }
                    btnLib.setOnClickListener { pickFromLibrary(region) { renderSub() } }
                    sub.addView(btnLib)
                    val btnCropSelf = Button(ctx).apply { text = "✂️ Ekrandan Kendim Kırpacağım" }
                    btnCropSelf.setOnClickListener {
                        val r2 = regionRect(region)
                        val cropped = ScreenCaptureService.latestFrame?.let { safeCrop(it, r2[0], r2[1], r2[2], r2[3]) }
                        if (cropped == null) {
                            Toast.makeText(ctx, "Kırpılamadı, alan çok küçük olabilir", Toast.LENGTH_SHORT).show()
                        } else {
                            val nameInput = EditText(ctx).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
                            overlayDialog().setTitle("Bu resmi kaydet").setView(nameInput)
                                .setPositiveButton("Kaydet") { _, _ ->
                                    val name = nameInput.text.toString().ifBlank { "İsimsiz görsel" }
                                    val savedPath = TemplateStorage.save(ctx, cropped)
                                    LibraryStorage.add(ctx, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, savedPath))
                                    region.conditionTemplatePath = savedPath
                                    Toast.makeText(ctx, "Kütüphaneye eklendi ve seçildi: $name", Toast.LENGTH_SHORT).show()
                                    renderSub()
                                }
                                .setNegativeButton("Vazgeç", null)
                                .create().showOverlay()
                        }
                    }
                    sub.addView(btnCropSelf)
                    addMinScoreControls(ctx, sub, region)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.addTextChangedListener(simpleWatcher { region.conditionText = it })
                    sub.addView(input)
                    sub.addView(TextView(ctx).apply {
                        text = "Tolerans — OCR net okuyamayabilir, düşük skor daha esnek olur:"
                        textSize = 11f; setPadding(0, 12, 0, 0)
                    })
                    addMinScoreControls(ctx, sub, region)
                }
                else -> {
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply { text = String.format(" #%06X", 0xFFFFFF and region.conditionColor) })
                    sub.addView(row)
                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armColorPick(region) }
                    sub.addView(btnPick)
                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.addTextChangedListener(simpleWatcher { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) { region.conditionColor = parsed; swatch.setBackgroundColor(parsed) }
                    })
                    sub.addView(hexInput)
                    addMinScoreControls(ctx, sub, region)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; else -> "COLOR" }
            renderSub()
        }

        // ---- Bekleme süresi (cooldown) + Eşleşme sonrası Delay ----
        content.addView(TextView(ctx).apply {
            text = "Zamanlama"; setPadding(0, 20, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(ctx).apply { text = "Bekleme süresi (ms) — tetiklendikten sonra tekrar tetiklenmeden önce en az ne kadar beklesin:"; textSize = 11f })
        val cooldownInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(region.cooldownMs.toString()) }
        cooldownInput.addTextChangedListener(simpleWatcher { region.cooldownMs = it.toLongOrNull() ?: 300 })
        content.addView(cooldownInput)
        content.addView(TextView(ctx).apply { text = "Delay (ms) — eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre:"; textSize = 11f; setPadding(0, 12, 0, 0) })
        val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(region.matchDelayMs.toString()) }
        delayInput.addTextChangedListener(simpleWatcher { region.matchDelayMs = it.toLongOrNull() ?: 0 })
        content.addView(delayInput)

        // ---- Find Region: X/Y/Genişlik/Yükseklik — değiştirince alan EKRANDA da taşınır/boyutlanır ----
        content.addView(TextView(ctx).apply {
            text = "Find Region (alanın ekrandaki konumu)"; setPadding(0, 20, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val r = regionRect(region)
        val etX = EditText(ctx).apply { hint = "X"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[0].toString()) }
        val etY = EditText(ctx).apply { hint = "Y"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[1].toString()) }
        val etW = EditText(ctx).apply { hint = "Genişlik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[2].toString()) }
        val etH = EditText(ctx).apply { hint = "Yükseklik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[3].toString()) }
        val findRegionRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etX, etY).forEach { findRegionRow1.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val findRegionRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etW, etH).forEach { findRegionRow2.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        content.addView(findRegionRow1)
        content.addView(findRegionRow2)

        var suppressFindRegionSync = false
        fun applyFindRegionToScreen() {
            if (suppressFindRegionSync) return
            val x = etX.text.toString().toIntOrNull() ?: return
            val y = etY.text.toString().toIntOrNull() ?: return
            val w = etW.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            val h = etH.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            moveAndResizeRegion(region, x, y, w, h)
        }
        listOf(etX, etY, etW, etH).forEach { it.addTextChangedListener(simpleWatcher { applyFindRegionToScreen() }) }
        region.onRectChangedExternally = {
            suppressFindRegionSync = true
            val r2 = regionRect(region)
            etX.setText(r2[0].toString()); etY.setText(r2[1].toString())
            etW.setText(r2[2].toString()); etH.setText(r2[3].toString())
            suppressFindRegionSync = false
        }
    }

    private fun addMinScoreControls(ctx: android.content.Context, sub: LinearLayout, region: ActiveRegion) {
        val label = TextView(ctx).apply { text = "Min Skor (%)" }
        var suppress = false
        val numberInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(region.minScore.toString()) }
        val seek = SeekBar(ctx).apply {
            max = 100; progress = region.minScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    region.minScore = v
                    if (fromUser) { suppress = true; numberInput.setText(v.toString()); suppress = false }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        numberInput.addTextChangedListener(simpleWatcher { text ->
            if (suppress) return@simpleWatcher
            val v = text.toIntOrNull()?.coerceIn(0, 100) ?: return@simpleWatcher
            region.minScore = v; seek.progress = v
        })
        sub.addView(label); sub.addView(numberInput); sub.addView(seek)
    }

    private fun pickFromLibrary(region: ActiveRegion, onDone: () -> Unit) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        overlayDialog()
            .setTitle("Seç")
            .setItems(labels) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") { region.conditionKind = "IMAGE"; region.conditionTemplatePath = item.templatePath }
                else { region.conditionKind = "COLOR"; region.conditionColor = item.color }
                onDone()
            }
            .create().showOverlay()
    }

    private fun buildActionTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbTap = android.widget.RadioButton(ctx).apply { text = "👆 Dokunma"; id = 1 }
        val rbSwipe = android.widget.RadioButton(ctx).apply { text = "👉 Kaydırma"; id = 2 }
        val rbFunc = android.widget.RadioButton(ctx).apply { text = "🔧 Fonksiyon Çağır"; id = 3 }
        listOf(rbTap, rbSwipe, rbFunc).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.actionType) { "SWIPE" -> 2; "CALL_FUNCTION" -> 3; else -> 1 })
        content.addView(radioGroup)
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.actionType) {
                "SWIPE" -> {
                    sub.addView(TextView(ctx).apply { text = "Başlangıç: (${region.actionX}, ${region.actionY})" })
                    val btnStart = Button(ctx).apply { text = "📍 Başlangıç Noktasını Seç" }
                    btnStart.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_START") }
                    sub.addView(btnStart)
                    sub.addView(TextView(ctx).apply { text = "Bitiş: (${region.actionX2}, ${region.actionY2})" })
                    val btnEnd = Button(ctx).apply { text = "📍 Bitiş Noktasını Seç" }
                    btnEnd.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_END") }
                    sub.addView(btnEnd)
                }
                "CALL_FUNCTION" -> {
                    sub.addView(TextView(ctx).apply { text = if (region.callFunctionName.isNotBlank()) "Seçili: f{} ${region.callFunctionName}" else "Henüz seçilmedi" })
                    val btnPick = Button(ctx).apply { text = "🔧 Fonksiyon Seç/Oluştur" }
                    btnPick.setOnClickListener { pickOrCreateFunction(region) { renderSub() } }
                    sub.addView(btnPick)
                    val repeatInput = EditText(ctx).apply {
                        hint = "Kaç kere çalışsın"; inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.callFunctionRepeat.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.callFunctionRepeat = it.toIntOrNull() ?: 1 })
                    sub.addView(repeatInput)
                }
                else -> {
                    val matchRadio = android.widget.RadioGroup(ctx)
                    val rbFixed = android.widget.RadioButton(ctx).apply { text = "📍 Sabit Nokta"; id = 1 }
                    val rbMatch = android.widget.RadioButton(ctx).apply { text = "🎯 Eşleşen Noktaya Tıkla"; id = 2 }
                    listOf(rbFixed, rbMatch).forEach { matchRadio.addView(it) }
                    matchRadio.check(if (region.tapAtMatchLocation) 2 else 1)
                    sub.addView(matchRadio)

                    val pointInfo = TextView(ctx).apply {
                        text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                    }
                    sub.addView(pointInfo)
                    val btnPick = Button(ctx).apply {
                        text = "📍 Dokunulacak Noktayı Seç"
                        visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }
                    btnPick.setOnClickListener { dialog.dismiss(); armActionPoint(region, "TAP") }
                    sub.addView(btnPick)
                    matchRadio.setOnCheckedChangeListener { _, checkedId ->
                        region.tapAtMatchLocation = checkedId == 2
                        pointInfo.text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                        btnPick.visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }

                    sub.addView(TextView(ctx).apply { text = "Tekrar sayısı (kaç kere tıklansın):"; setPadding(0, 12, 0, 0) })
                    val repeatInput = EditText(ctx).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.actionRepeatCount.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.actionRepeatCount = it.toIntOrNull()?.coerceAtLeast(1) ?: 1 })
                    sub.addView(repeatInput)

                    sub.addView(TextView(ctx).apply { text = "⏱️ HOLD — noktada kaç ms basılı tutulsun (uzun basış için artır):"; setPadding(0, 12, 0, 0) })
                    val holdInput = EditText(ctx).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.actionHoldMs.toString())
                    }
                    holdInput.addTextChangedListener(simpleWatcher { region.actionHoldMs = it.toLongOrNull()?.coerceAtLeast(1) ?: 50 })
                    sub.addView(holdInput)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.actionType = when (checkedId) { 2 -> "SWIPE"; 3 -> "CALL_FUNCTION"; else -> "TAP" }
            renderSub()
        }
    }

    private fun pickOrCreateFunction(region: ActiveRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        overlayDialog().setItems(options.toTypedArray()) { _, index ->
            if (index == 0) {
                val input = EditText(this).apply { hint = "Fonksiyon adı" }
                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                    .setPositiveButton("Oluştur") { _, _ ->
                        val name = input.text.toString().ifBlank { "fonksiyon" }
                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                        FunctionStorage.upsert(this, fn)
                        region.callFunctionId = fn.id; region.callFunctionName = fn.name
                        onDone()
                    }.create().showOverlay()
            } else if (index <= functions.size) {
                val fn = functions[index - 1]
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            } else {
                val group = groups[index - 1 - functions.size]
                region.callFunctionId = group.id; region.callFunctionName = "📦 ${group.name}"
                onDone()
            }
        }.create().showOverlay()
    }

    private fun buildExtraTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog, isFail: Boolean) {
        val ctx = this
        val list = if (isFail) region.onFailActions else region.extraActions
        val suffix = if (isFail) "FAIL" else "SUCCESS"
        content.addView(TextView(ctx).apply {
            text = if (isFail) "Bu alan BULUNAMAZSA sırayla yapılacaklar:" else "Birincil aksiyondan SONRA sırayla yapılacaklar:"
            textSize = 12f
        })
        val listView = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(listView)
        fun renderList() {
            listView.removeAllViews()
            list.forEachIndexed { index, extra ->
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val desc = when (extra.type) {
                    "CALL_FUNCTION" -> "🔧 f{} ${extra.functionName} x${extra.repeat}"
                    "SWIPE" -> "👉 Kaydır (${extra.x},${extra.y})→(${extra.x2},${extra.y2})"
                    "WAIT" -> "⏱️ Bekle ${extra.waitMs}ms"
                    "SET_VARIABLE" -> "(x) ${extra.variableName} += ${extra.variableDelta}"
                    "RUN_SCRIPT" -> "🖥️ ${extra.scriptName}"
                    else -> "👆 Dokun (${extra.x},${extra.y})"
                }
                row.addView(TextView(ctx).apply { text = "${index + 1}. $desc"; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                btnRemove.setOnClickListener { list.removeAt(index); renderList() }
                row.addView(btnRemove)
                listView.addView(row)
            }
        }
        renderList()
        val btnAdd = Button(ctx).apply { text = "+ Ekle" }
        btnAdd.setOnClickListener {
            overlayDialog().setItems(arrayOf(
                "👆 Dokunma Ekle", "👉 Kaydırma Ekle", "⏱️ Bekleme Ekle",
                "🔧 Fonksiyon Çağırma Ekle", "(x) Değişken Ayarla Ekle", "🖥️ Kod Çalıştır Ekle"
            )) { _, index ->
                when (index) {
                    0 -> {
                        list.add(ExtraAction("TAP"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_TAP_$suffix")
                    }
                    1 -> {
                        list.add(ExtraAction("SWIPE"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_SWIPE_START_$suffix")
                    }
                    2 -> {
                        val input = EditText(ctx).apply { hint = "Bekleme (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("500") }
                        overlayDialog().setTitle("Bekleme Süresi").setView(input)
                            .setPositiveButton("Ekle") { _, _ ->
                                list.add(ExtraAction("WAIT", waitMs = input.text.toString().toLongOrNull() ?: 500))
                                renderList()
                            }.create().showOverlay()
                    }
                    3 -> {
                        val functions = FunctionStorage.load(ctx)
                        val groups = ActionGroupStorage.load(ctx)
                        val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                        opts.addAll(functions.map { "f{} ${it.name}" })
                        opts.addAll(groups.map { "📦 ${it.name}" })
                        overlayDialog().setItems(opts.toTypedArray()) { _, idx2 ->
                            if (idx2 == 0) {
                                val input = EditText(ctx).apply { hint = "Fonksiyon adı" }
                                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                                    .setPositiveButton("Oluştur") { _, _ ->
                                        val name = input.text.toString().ifBlank { "fonksiyon" }
                                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                                        FunctionStorage.upsert(ctx, fn)
                                        list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                        renderList()
                                    }.create().showOverlay()
                            } else if (idx2 <= functions.size) {
                                val fn = functions[idx2 - 1]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                renderList()
                            } else {
                                val group = groups[idx2 - 1 - functions.size]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = group.id, functionName = "📦 ${group.name}"))
                                renderList()
                            }
                        }.create().showOverlay()
                    }
                    4 -> {
                        val nameInput = EditText(ctx).apply { hint = "Değişken/sayaç adı" }
                        val deltaInput = EditText(ctx).apply { hint = "Ne kadar artırılsın (örn. 1, -1)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("1") }
                        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; addView(nameInput); addView(deltaInput) }
                        overlayDialog().setTitle("Değişken Ayarla").setView(box)
                            .setPositiveButton("Ekle") { _, _ ->
                                val vname = nameInput.text.toString().ifBlank { "sayac" }
                                val delta = deltaInput.text.toString().toIntOrNull() ?: 1
                                list.add(ExtraAction("SET_VARIABLE", variableName = vname, variableDelta = delta))
                                renderList()
                            }.create().showOverlay()
                    }
                    5 -> {
                        val scripts = com.bigboss.app.storage.ScriptStorage.load(ctx)
                        if (scripts.isEmpty()) {
                            Toast.makeText(ctx, "Henüz script yok — önce 🖥️ Kod menüsünden oluştur", Toast.LENGTH_LONG).show()
                        } else {
                            val labels = scripts.map { "🖥️ ${it.name}" }.toTypedArray()
                            overlayDialog().setItems(labels) { _, sIdx ->
                                val s = scripts[sIdx]
                                list.add(ExtraAction("RUN_SCRIPT", scriptId = s.id, scriptName = s.name))
                                renderList()
                            }.create().showOverlay()
                        }
                    }
                }
            }.create().showOverlay()
        }
        content.addView(btnAdd)
    }

    private fun buildLoopTab(region: ActiveRegion, content: LinearLayout) {
        val ctx = this
        content.addView(TextView(ctx).apply {
            text = "Bu alan nasıl çalışsın?"
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbNone = android.widget.RadioButton(ctx).apply {
            text = "None — tarama yapar ve durur (bir kere dener, biter)"; id = 1
        }
        val rbAlways = android.widget.RadioButton(ctx).apply {
            text = "Loop Always — sonsuz döngü, hep açık kalır"; id = 2
        }
        val rbWhileSuccess = android.widget.RadioButton(ctx).apply {
            text = "Loop When Success — eşleşmeyi yakalayana kadar bekler, sonra biter"; id = 3
        }
        val rbWhileFail = android.widget.RadioButton(ctx).apply {
            text = "Loop When Fail — eşleşme kayboluncaya kadar devam eder, sonra biter"; id = 4
        }
        listOf(rbNone, rbAlways, rbWhileSuccess, rbWhileFail).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.loopMode) {
            "NONE" -> 1; "WHILE_SUCCESS" -> 3; "WHILE_FAIL" -> 4; else -> 2
        })
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.loopMode = when (checkedId) {
                1 -> "NONE"; 3 -> "WHILE_SUCCESS"; 4 -> "WHILE_FAIL"; else -> "ALWAYS"
            }
        }
        content.addView(radioGroup)
    }

    private fun extraActionToStep(extra: ExtraAction): com.bigboss.app.storage.ActionStep =
        com.bigboss.app.storage.ActionStep(
            type = extra.type, x = extra.x, y = extra.y, x2 = extra.x2, y2 = extra.y2,
            waitMs = extra.waitMs, repeat = extra.repeat, functionId = extra.functionId,
            variableName = extra.variableName, variableDelta = extra.variableDelta,
            scriptId = extra.scriptId,
            scriptCode = extra.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.code }
        )

    private fun saveRegionAsRule(region: ActiveRegion): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show(); return false
        }
        val r = regionRect(region)
        val mainAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        val name = region.name.ifBlank { "İsimsiz kural" }

        // Birincil kural: GENEL/AKSİYON/BAŞARILI/TEKRAR sekmelerindeki her şeyi taşır.
        val def = RuleDefinition(
            id = region.existingRuleId ?: UUID.randomUUID().toString(), name = name, enabled = true,
            alternatives = mutableListOf(mainAlt),
            timeoutMs = region.cooldownMs,
            matchDelayMs = region.matchDelayMs,
            negateCondition = region.negate,
            loopMode = region.loopMode,
            requireVariableName = region.requireVariableName, requireVariableOp = region.requireVariableOp, requireVariableValue = region.requireVariableValue,
            actionType = region.actionType,
            actionX = region.actionX, actionY = region.actionY, actionX2 = region.actionX2, actionY2 = region.actionY2,
            tapAtMatchLocation = region.tapAtMatchLocation,
            actionRepeatCount = region.actionRepeatCount,
            actionHoldMs = region.actionHoldMs,
            callFunctionId = region.callFunctionId, callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName, incrementVariableDelta = region.incrementVariableDelta,
            extraSteps = region.extraActions.map { extraActionToStep(it) }.toMutableList()
        )

        val scope = region.saveScope
        when (scope) {
            is SaveScope.MainFlow -> RuleStorage.upsert(this, def)
            is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, def)
            is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, def)
        }

        // "BULUNAMAZSA" adımları varsa: AYNI koşulun TERSİYLE tetiklenen, sadece bu adımları çalıştıran ayrı bir kural.
        if (region.onFailActions.isNotEmpty()) {
            val failDef = RuleDefinition(
                id = region.existingRuleId?.let { "$it-fail" } ?: UUID.randomUUID().toString(),
                name = "$name → bulunamazsa", enabled = true,
                alternatives = mutableListOf(mainAlt),
                timeoutMs = region.cooldownMs,
                negateCondition = !region.negate,
                loopMode = region.loopMode,
                actionType = "WAIT", actionX = 0, actionY = 0,
                extraSteps = region.onFailActions.map { extraActionToStep(it) }.toMutableList()
            )
            when (scope) {
                is SaveScope.MainFlow -> RuleStorage.upsert(this, failDef)
                is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, failDef)
                is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, failDef)
            }
        } else {
            // Önceden "bulunamazsa" kuralı vardıysa ve şimdi boşaltıldıysa temizle.
            region.existingRuleId?.let { id ->
                when (scope) {
                    is SaveScope.MainFlow -> RuleStorage.deleteRule(this, "$id-fail")
                    is SaveScope.Group -> ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail")
                    is SaveScope.Function -> FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail")
                }
            }
        }

        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeX = x.coerceIn(0, bitmap.width - 1)
        val safeY = y.coerceIn(0, bitmap.height - 1)
        val safeW = w.coerceAtMost(bitmap.width - safeX)
        val safeH = h.coerceAtMost(bitmap.height - safeY)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ==================== Ana Akış ====================

    private data class MenuRow(val icon: String, val name: String, val extra: String, val onClick: () -> Unit)

    private fun showRowListDialog(title: String, rows: List<MenuRow>, closable: Boolean = true) {
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val row = rows[position]
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = row.icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = row.name
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = row.extra
                return view
            }
        }
        val builder = overlayDialog().setTitle(title).setAdapter(adapter) { _, position -> rows[position].onClick() }
        if (closable) builder.setNegativeButton("Kapat", null)
        builder.create().showOverlay()
    }

    /** Ana Akış listesindeki tek bir öğe: ya bir kural ya bir Action Group. */
    private sealed class AnaAkisEntry {
        data class Rule(val rule: RuleDefinition) : AnaAkisEntry()
        data class Group(val group: com.bigboss.app.storage.ActionGroupDefinition) : AnaAkisEntry()
    }

    /**
     * "Ana Akış" artık küçük bir liste penceresi değil, Macrorify'daki gibi TAM BİR
     * SAYFA: üstte kaydırılabilir liste, altta seçili öğe üzerinde çalışan 8 ikonlu
     * araç çubuğu (Görüntüle, Ekle, Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı).
     */
    private fun showRulesMenu() {
        val rules = RuleStorage.load(this)
        val actionGroups = ActionGroupStorage.load(this)
        if (rules.isEmpty() && actionGroups.isEmpty()) {
            Toast.makeText(this, "Henüz kural yok — \"Alan Ekle\" ile başla", Toast.LENGTH_SHORT).show()
            return
        }
        val ctx = this
        val entries = mutableListOf<AnaAkisEntry>()
        actionGroups.forEach { entries.add(AnaAkisEntry.Group(it)) }
        rules.forEach { entries.add(AnaAkisEntry.Rule(it)) }

        val selectedIndices = mutableSetOf<Int>()
        lateinit var dialog: AlertDialog
        val inflater = android.view.LayoutInflater.from(ctx)

        val listView = android.widget.ListView(ctx)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = entries.size
            override fun getItem(position: Int): Any = entries[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                when (val entry = entries[position]) {
                    is AnaAkisEntry.Group -> {
                        val g = entry.group
                        val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (g.enabled) "📦" else "🔕"
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = g.name
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "$gateInfo · ${g.rules.size} · x${g.gateRepeat}"
                    }
                    is AnaAkisEntry.Rule -> {
                        val r = entry.rule
                        val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆")
                            else when (r.alternatives.first().conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
                        val extra = if (!r.enabled) "🔕" else if (r.loopMode == "ALWAYS") "" else r.loopMode
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (r.enabled) icon else "🔕"
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = r.groupName?.let { "[$it] " }.orEmpty() + r.name
                        view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = extra
                    }
                }
                view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#552196F3") else Color.TRANSPARENT)
                return view
            }
        }
        listView.adapter = adapter
        listView.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.45).toInt()
        )
        // Kısa dokunuş: DOĞRUDAN o öğenin bilgilerini/ayarlarını açar.
        listView.setOnItemClickListener { _, _, position, _ ->
            when (val entry = entries[position]) {
                is AnaAkisEntry.Rule -> { dialog.dismiss(); showRuleOptions(entry.rule) }
                is AnaAkisEntry.Group -> { dialog.dismiss(); showActionGroupOptions(entry.group) }
            }
        }
        // Basılı tutma: ÇOKLU SEÇİME ekler/çıkarır (toplu işlemler için).
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
            adapter.notifyDataSetChanged()
            true
        }

        fun selectedEntries(): List<AnaAkisEntry> = selectedIndices.sorted().map { entries[it] }
        fun reopen() { dialog.dismiss(); showRulesMenu() }

        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply {
            text = label; textSize = 15f
            setOnClickListener { onClick() }
        }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

        val toolbarRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val toolbarRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        toolbarRow1.addView(toolBtn("☑️") { // Tümünü Seç / Seçimi Temizle
            if (selectedIndices.size == entries.size) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(entries.indices) }
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("➕") { // Ekle
            dialog.dismiss()
            overlayDialog().setTitle("Ne eklemek istersin?")
                .setItems(arrayOf(
                    "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                    "👆 Sadece Dokunma Ekle (koşulsuz)",
                    "👉 Sadece Kaydırma Ekle (koşulsuz)",
                    "📦 Yeni Action Group",
                    "f{} Yeni Fonksiyon",
                    "🖥️ Yeni Script (Kod)"
                )) { _, idx ->
                    when (idx) {
                        0 -> startAddRegion()
                        1 -> addSimpleStepToMainFlow("TAP")
                        2 -> addSimpleStepToMainFlow("SWIPE")
                        3 -> createActionGroup()
                        4 -> createFunction()
                        5 -> startActivity(Intent(this, ScriptEditorActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                    }
                }.create().showOverlay()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("📋") { // Kopyala (sadece 1 kural desteklenir)
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                Toast.makeText(ctx, "Kopyalandı: ${sel.rule.name}", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("✂️") { // Kes (sadece 1 kural desteklenir)
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                RuleStorage.deleteRule(ctx, sel.rule.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                reopen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        toolbarRow2.addView(toolBtn("📥") { // Yapıştır
            val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            RuleStorage.upsert(ctx, pasted)
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("🗑") { // Sil — SEÇİLİ TÜM öğeleri (toplu)
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { entry ->
                when (entry) {
                    is AnaAkisEntry.Rule -> { RuleStorage.deleteRule(ctx, entry.rule.id); RuleStorage.deleteRule(ctx, "${entry.rule.id}-fail") }
                    is AnaAkisEntry.Group -> ActionGroupStorage.delete(ctx, entry.group.id)
                }
            }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↑") { // Yukarı taşı — SEÇİLİ TÜM kurallar
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { RuleStorage.moveUp(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↓") { // Aşağı taşı — SEÇİLİ TÜM kurallar
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { RuleStorage.moveDown(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            reopen()
        }, toolbarParams)

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(listView)
            addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(16, 8, 16, 8)
            })
            addView(toolbarRow1)
            addView(toolbarRow2)
        }

        dialog = overlayDialog()
            .setTitle("🏠 Ana Akış (${rules.size} kural, ${actionGroups.size} grup)")
            .setView(root)
            .setNegativeButton("Kapat", null)
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show()
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog().setTitle("Grup Seç").setItems(groups.toTypedArray()) { _, gIndex ->
            val group = groups[gIndex]
            val filtered = RuleStorage.load(this).filter { it.groupName == group }
            val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
            overlayDialog().setTitle("[$group] (${filtered.size})").setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                .setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showRuleOptions(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle", if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir", "🧪 Test Et",
            "📋 Kopyala", "✂️ Kes", "⬆️ Yukarı Taşı", "⬇️ Aşağı Taşı", "🗑 Sil"
        )
        overlayDialog().setTitle(rule.name).setItems(options) { _, index ->
            when (index) {
                0 -> {
                    if (rule.alternatives.isEmpty()) {
                        RuleStorage.deleteRule(this, rule.id)
                        addSimpleStepToMainFlow(rule.actionType)
                    } else {
                        editExistingRule(rule)
                    }
                }
                1 -> { rule.enabled = !rule.enabled; RuleStorage.upsert(this, rule); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                2 -> testRule(rule)
                3 -> { com.bigboss.app.storage.RuleClipboard.copy(rule); Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show() }
                4 -> {
                    com.bigboss.app.storage.RuleClipboard.copy(rule)
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Kesildi: ${rule.name}", Toast.LENGTH_SHORT).show()
                }
                5 -> { RuleStorage.moveUp(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                6 -> { RuleStorage.moveDown(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                7 -> {
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Var olan bir kuralı düzenlemek için, o kuralın alanını ekranda GERÇEK overlay kutusu olarak geri getirir. */
    private fun stepToExtraAction(step: com.bigboss.app.storage.ActionStep): ExtraAction {
        val fnName = step.functionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        }
        return ExtraAction(
            type = step.type, x = step.x, y = step.y, x2 = step.x2, y2 = step.y2,
            waitMs = step.waitMs, functionId = step.functionId, functionName = fnName ?: "",
            repeat = step.repeat, variableName = step.variableName, variableDelta = step.variableDelta,
            scriptId = step.scriptId, scriptName = step.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.name } ?: ""
        )
    }

    private fun editExistingRule(rule: RuleDefinition, scope: SaveScope = SaveScope.MainFlow) {
        val alt = rule.alternatives.firstOrNull() ?: return
        val region = addRegionWindow(alt.x, alt.y, alt.width, alt.height)
        region.saveScope = scope
        region.existingRuleId = rule.id
        region.name = rule.name
        region.conditionKind = alt.conditionKind
        region.conditionColor = alt.color
        region.conditionTemplatePath = alt.templatePath
        region.conditionText = alt.expectedText ?: ""
        region.minScore = alt.minScore
        region.actionType = rule.actionType
        region.actionX = rule.actionX; region.actionY = rule.actionY
        region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
        region.tapAtMatchLocation = rule.tapAtMatchLocation
        region.actionRepeatCount = rule.actionRepeatCount
        region.actionHoldMs = rule.actionHoldMs
        region.callFunctionId = rule.callFunctionId
        region.callFunctionName = rule.callFunctionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        } ?: ""
        region.callFunctionRepeat = rule.callFunctionRepeat
        region.cooldownMs = rule.timeoutMs
        region.matchDelayMs = rule.matchDelayMs
        region.negate = rule.negateCondition
        region.loopMode = rule.loopMode
        region.requireVariableName = rule.requireVariableName
        region.requireVariableOp = rule.requireVariableOp
        region.requireVariableValue = rule.requireVariableValue
        region.incrementVariableName = rule.incrementVariableName
        region.incrementVariableDelta = rule.incrementVariableDelta
        region.extraActions.clear()
        rule.extraSteps.forEach { region.extraActions.add(stepToExtraAction(it)) }

        // "-fail" eşleniği varsa, BULUNAMAZSA adımlarını da geri yükle (aynı kapsamdan).
        val failRule = when (scope) {
            is SaveScope.MainFlow -> RuleStorage.load(this).find { it.id == "${rule.id}-fail" }
            is SaveScope.Group -> ActionGroupStorage.load(this).find { it.id == scope.groupId }?.rules?.find { it.id == "${rule.id}-fail" }
            is SaveScope.Function -> FunctionStorage.load(this).find { it.id == scope.functionId }?.rules?.find { it.id == "${rule.id}-fail" }
        }
        region.onFailActions.clear()
        failRule?.extraSteps?.forEach { region.onFailActions.add(stepToExtraAction(it)) }

        val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; else -> "🎨" }
        region.label.text = "$icon ${region.name}"
        Toast.makeText(this, "Alan geri getirildi — düzenleyip kaydet", Toast.LENGTH_LONG).show()
    }

    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        overlayDialog().setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null).create().showOverlay()
    }

    // ==================== Action Group ====================

    private fun showActionGroupsMenu() {
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Action Group")
        options.addAll(groups.map { g ->
            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
            "📦 ${if (g.enabled) "" else "🔕 "}${g.name} ($gateInfo, ${g.rules.size} tarama)"
        })
        overlayDialog().setTitle("📦 Action Group'lar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createActionGroup() else showActionGroupOptions(groups[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createActionGroup() {
        val input = EditText(this).apply { hint = "Grup adı (örn. \"Savaş Ekranı\")" }
        overlayDialog().setTitle("Yeni Action Group").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "grup" }
                ActionGroupStorage.upsert(this, com.bigboss.app.storage.ActionGroupDefinition(UUID.randomUUID().toString(), name))
                Toast.makeText(this, "Oluşturuldu — şimdi \"🎯 Kapı Koşulunu Ayarla\" ile devam et", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showActionGroupOptions(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val options = arrayOf(
            "🎯 Kapı Koşulunu Ayarla/Değiştir",
            "➕ Bu Gruba Tarama Ekle",
            "📋 Gruptaki Taramaları Listele",
            "⚙️ Grup Ayarları (döngü sayısı, kapı sıklığı)",
            if (group.enabled) "🔕 Grubu Devre Dışı Bırak" else "🔔 Grubu Etkinleştir",
            "🗑 Grubu Sil"
        )
        overlayDialog().setTitle("📦 ${group.name}").setItems(options) { _, index ->
            when (index) {
                0 -> startGateRegion(group)
                1 -> startGroupScan(group)
                2 -> showGroupRulesList(group)
                3 -> showGroupSettingsDialog(group)
                4 -> {
                    group.enabled = !group.enabled
                    ActionGroupStorage.upsert(this, group)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
                5 -> {
                    ActionGroupStorage.delete(this, group.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Gruba özel ayarlar: kapı bulununca kaç kere taransın (döngü sayısı) + kapı ne sıklıkla kontrol edilsin. */
    private fun showGroupSettingsDialog(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply {
            text = "Döngü sayısı — kapı koşulu bulununca gruptaki taramalar kaç kere art arda çalışsın:"
            textSize = 12f
        })
        val repeatInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateRepeat.toString())
        }
        container.addView(repeatInput)
        container.addView(TextView(this).apply {
            text = "Kapı kontrol sıklığı (ms) — kapı koşulu en fazla ne kadar sık kontrol edilsin:"
            textSize = 12f; setPadding(0, 16, 0, 0)
        })
        val cooldownInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateCooldownMs.toString())
        }
        container.addView(cooldownInput)

        overlayDialog().setTitle("⚙️ ${group.name} Ayarları").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                group.gateRepeat = repeatInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                group.gateCooldownMs = cooldownInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 300
                ActionGroupStorage.upsert(this, group)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Ayarlar kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Grubun KAPI koşulunu ayarlamak için ekrana bir alan çizer. */
    private fun startGateRegion(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val gate = group.gate
        val region = if (gate != null) addRegionWindow(gate.x, gate.y, gate.width, gate.height) else addRegionWindow()
        region.isGateForGroupId = group.id
        if (gate != null) {
            region.conditionKind = gate.conditionKind
            region.conditionColor = gate.color
            region.conditionTemplatePath = gate.templatePath
            region.conditionText = gate.expectedText ?: ""
            region.minScore = gate.minScore
            region.cooldownMs = group.gateCooldownMs
        }
        region.label.text = "🎯 ${group.name}"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubunun KAPI koşulu — sadece GENEL sekmesi kullanılır", Toast.LENGTH_LONG).show()
    }

    /** Gruba yeni bir tarama (kural) eklemek için ekrana bir alan çizer. */
    private fun startGroupScan(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Group(group.id)
        region.label.text = "📦 ${group.name} → yeni"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showGroupRulesList(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val rules = group.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu grupta henüz tarama yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
        overlayDialog().setTitle("📦 ${group.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                if (action == 0) {
                    editExistingRule(rule, SaveScope.Group(group.id))
                } else {
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, rule.id)
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, "${rule.id}-fail")
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
            }.create().showOverlay()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Fonksiyonlar ====================

    /**
     * "f{} Fonksiyonlar" — Ana Akış için yaptığımız AYNI sayfa+araç çubuğu düzeni:
     * dokun = bilgiyi aç, basılı tut = çoklu seç, altta 8 ikonlu toplu işlem çubuğu.
     */
    private fun showFunctionsMenu() {
        val functions = FunctionStorage.load(this)
        if (functions.isEmpty()) {
            Toast.makeText(this, "Henüz fonksiyon yok — aşağıdan ➕ ile oluştur", Toast.LENGTH_SHORT).show()
        }
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        lateinit var dialog: AlertDialog
        val inflater = android.view.LayoutInflater.from(ctx)

        val listView = android.widget.ListView(ctx)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = functions.size
            override fun getItem(position: Int): Any = functions[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val fn = functions[position]
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "f{}"
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = fn.name
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "${fn.rules.size} adım"
                view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#552196F3") else Color.TRANSPARENT)
                return view
            }
        }
        listView.adapter = adapter
        listView.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.45).toInt()
        )
        listView.setOnItemClickListener { _, _, position, _ -> dialog.dismiss(); showFunctionOptions(functions[position]) }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
            adapter.notifyDataSetChanged()
            true
        }

        fun selected(): List<FunctionDefinition> = selectedIndices.sorted().map { functions[it] }
        fun reopen() { dialog.dismiss(); showFunctionsMenu() }
        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply { text = label; textSize = 15f; setOnClickListener { onClick() } }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val toolbarRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val toolbarRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        toolbarRow1.addView(toolBtn("☑️") {
            if (selectedIndices.size == functions.size) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(functions.indices) }
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("➕") { dialog.dismiss(); createFunction() }, toolbarParams)
        toolbarRow1.addView(toolBtn("📋") {
            val sel = selected().firstOrNull()
            if (sel != null) { com.bigboss.app.storage.FunctionClipboard.copy(sel); Toast.makeText(ctx, "Kopyalandı: ${sel.name}", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("✂️") {
            val sel = selected().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.FunctionClipboard.copy(sel)
                FunctionStorage.delete(ctx, sel.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                reopen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        toolbarRow2.addView(toolBtn("📥") {
            val pasted = com.bigboss.app.storage.FunctionClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            FunctionStorage.upsert(ctx, pasted)
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("🗑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.delete(ctx, it.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} fonksiyon silindi", Toast.LENGTH_SHORT).show()
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.moveUp(ctx, it.id) }
            reopen()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↓") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { FunctionStorage.moveDown(ctx, it.id) }
            reopen()
        }, toolbarParams)

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(listView)
            addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(16, 8, 16, 8)
            })
            addView(toolbarRow1)
            addView(toolbarRow2)
        }

        dialog = overlayDialog()
            .setTitle("f{} Fonksiyonlar (${functions.size})")
            .setView(root)
            .setNegativeButton("Kapat", null)
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show()
    }

    private fun createFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı" }
        overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showFunctionOptions(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setItems(arrayOf("➕ Bu Fonksiyona Adım Ekle", "📋 Fonksiyondaki Adımları Listele", "🗑 Fonksiyonu Sil")) { _, index ->
                when (index) {
                    0 -> showAddToFunctionMenu(fn)
                    1 -> showFunctionRulesList(fn)
                    2 -> {
                        FunctionStorage.delete(this, fn.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }.create().showOverlay()
    }

    /** Fonksiyona ne eklemek istediğini soran menü — artık sadece "tarama" değil, çeşitlendirildi. */
    private fun showAddToFunctionMenu(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} — Ne eklemek istersin?")
            .setItems(arrayOf(
                "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                "👆 Sadece Dokunma Ekle (koşulsuz)",
                "👉 Sadece Kaydırma Ekle (koşulsuz)"
            )) { _, index ->
                when (index) {
                    0 -> startFunctionScan(fn)
                    1 -> addSimpleStepToFunction(fn, "TAP")
                    2 -> addSimpleStepToFunction(fn, "SWIPE")
                }
            }.create().showOverlay()
    }

    /** Fonksiyona tam bir tarama alanı YERİNE, sadece koşulsuz bir dokunma/kaydırma adımı ekler. */
    /** Ana Akış'a doğrudan, koşulsuz bir dokunma/kaydırma adımı ekler (tarama alanı gerekmeden). */
    private fun addSimpleStepToMainFlow(type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                val def = RuleDefinition(
                    id = UUID.randomUUID().toString(),
                    name = "👆 Dokunma",
                    alternatives = mutableListOf(),
                    timeoutMs = 100,
                    loopMode = "ALWAYS",
                    actionType = "TAP",
                    actionX = x, actionY = y
                )
                RuleStorage.upsert(this, def)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Ana Akışa eklendi: 👆 Dokunma", Toast.LENGTH_SHORT).show()
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👉 Kaydırma",
                        alternatives = mutableListOf(),
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "SWIPE",
                        actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2
                    )
                    RuleStorage.upsert(this, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Ana Akışa eklendi: 👉 Kaydırma", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun addSimpleStepToFunction(fn: FunctionDefinition, type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                val def = RuleDefinition(
                    id = UUID.randomUUID().toString(),
                    name = "👆 Dokunma",
                    alternatives = mutableListOf(), // boş -> koşulsuz (her zaman doğru)
                    timeoutMs = 100,
                    loopMode = "ALWAYS",
                    actionType = "TAP",
                    actionX = x, actionY = y
                )
                FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Eklendi: 👆 Dokunma", Toast.LENGTH_SHORT).show()
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👉 Kaydırma",
                        alternatives = mutableListOf(),
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "SWIPE",
                        actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2
                    )
                    FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Eklendi: 👉 Kaydırma", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /** Fonksiyona yeni bir tarama (kural) eklemek için ekrana bir alan çizer — tıpkı Action Group'taki gibi. */
    private fun startFunctionScan(fn: FunctionDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Function(fn.id)
        region.label.text = "f{} ${fn.name} → yeni"
        Toast.makeText(this, "Bu alan \"${fn.name}\" fonksiyonuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showFunctionRulesList(fn: FunctionDefinition) {
        val rules = fn.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu fonksiyonda henüz tarama/adım yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r ->
            val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆") else "🔍"
            "${i + 1}. $icon ${if (r.enabled) "" else "🔕 "}${r.name}"
        }.toTypedArray()
        overlayDialog().setTitle("f{} ${fn.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            if (rule.alternatives.isEmpty()) {
                // Koşulsuz basit adım (Dokunma/Kaydırma) — tam alan düzenleyici yerine hızlı yeniden-seçim
                overlayDialog().setTitle(rule.name).setItems(arrayOf("🔄 Noktayı/Noktaları Yeniden Seç", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        addSimpleStepToFunction(fn, rule.actionType)
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            } else {
                overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        editExistingRule(rule, SaveScope.Function(fn.id))
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, "${rule.id}-fail")
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kod (Script) ====================

    private fun showScriptsMenu() {
        val scripts = com.bigboss.app.storage.ScriptStorage.load(this)
        val options = mutableListOf("➕ Yeni Script")
        options.addAll(scripts.map { "🖥️ ${it.name}" })
        overlayDialog().setTitle("🖥️ Kod").setItems(options.toTypedArray()) { _, index ->
            val intent = Intent(this, ScriptEditorActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            if (index > 0) intent.putExtra(ScriptEditorActivity.EXTRA_SCRIPT_ID, scripts[index - 1].id)
            startActivity(intent)
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kütüphane ====================

    private fun showLibraryMenu() {
        val items = LibraryStorage.load(this)
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size + 1
            override fun getItem(position: Int): Any? = if (position == 0) null else items[position - 1]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_library_dialog, parent, false)
                val ivThumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivThumb)
                val tvName = view.findViewById<TextView>(com.bigboss.app.R.id.tvName)
                if (position == 0) {
                    ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(Color.parseColor("#333333"))
                    tvName.text = "📷 Ekrandan Kırp"
                } else {
                    val item = items[position - 1]
                    if (item.kind == "IMAGE" && !item.templatePath.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(item.templatePath)
                        if (bmp != null) ivThumb.setImageBitmap(bmp) else ivThumb.setBackgroundColor(Color.DKGRAY)
                    } else { ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(item.color) }
                    tvName.text = "${if (item.kind == "IMAGE") "🖼️" else "🎨"} ${item.name}"
                }
                return view
            }
        }
        overlayDialog().setTitle("📚 Kütüphanem (${items.size})").setAdapter(adapter) { _, position ->
            if (position == 0) startLibraryCaptureRegion()
            else showLibraryItemOptions(items[position - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "📷 Ekrandan Kırp" — RuleEditorActivity'de yaşadığımız aynı sorunu önlemek için
     * bu da GERÇEK bir overlay penceresiyle çalışıyor, Activity açmıyor — böylece
     * başka uygulamaların (oyunlar dahil) üzerinde de sorunsuz çalışır. */
    private fun startLibraryCaptureRegion() {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isLibraryCapture = true
        region.label.text = "📷 Kırp"
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup kaydet", Toast.LENGTH_LONG).show()
    }

    private fun openLibraryCaptureSaveDialog(region: ActiveRegion) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val r = regionRect(region)
        val cropped = safeCrop(frame, r[0], r[1], r[2], r[3])
        if (cropped == null) { Toast.makeText(this, "Alan çok küçük", Toast.LENGTH_SHORT).show(); return }

        val input = EditText(this).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
        overlayDialog().setTitle("Bu resmi kaydet")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = input.text.toString().ifBlank { "İsimsiz görsel" }
                val path = TemplateStorage.save(this, cropped)
                LibraryStorage.add(this, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, path))
                Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
                removeRegionWindow(region)
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .setNeutralButton("🗑 Alanı Sil") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog().setTitle(item.name).setItems(options) { _, index ->
            when (options[index]) {
                "✂️ Piksel Kırp" -> startActivity(Intent(this, com.bigboss.app.ui.LibraryCropActivity::class.java).apply {
                    putExtra(com.bigboss.app.ui.LibraryCropActivity.EXTRA_LIBRARY_ITEM_ID, item.id)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                "↻ 90° Döndür" -> rotateLibraryImage(item)
                "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                "🗑 Sil" -> { LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
            }
        }.create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(Bitmap.CompressFormat.PNG, 100, it) }
            com.bigboss.app.engine.ImageMatcher.clearCache() // aynı yol üzerine yazıldı, eski önbellek geçersiz
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog().setTitle("Yeniden adlandır").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    override fun onDestroy() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        removePointMarker()
        colorPickCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
