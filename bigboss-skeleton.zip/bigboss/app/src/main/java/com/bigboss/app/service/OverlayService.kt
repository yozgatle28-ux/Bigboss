package com.bigboss.app.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.ui.EditModeActivity
import com.bigboss.app.ui.RuleEditorActivity
import kotlin.math.abs

/**
 * Oyunun ÜZERİNDE yüzen, KÜÇÜK bir simge (Macrorify'daki "floating
 * control panel" gibi). İki modu var:
 *
 *  - EDIT: "➕ Alan Ekle" / "📋 Yönet" ikonları — oyunun içindeyken,
 *    hiç ayrılmadan kural ekleyip düzenleyebilmen için. Bu, sorunun
 *    asıl çözümü: artık BigBoss'un kendi ekranına geçmiyorsun, alan
 *    ekleme penceresi doğrudan oyunun ÜSTÜNE şeffaf olarak açılıyor.
 *  - PLAY: sadece durum + "⏹ Durdur" — sisteme müdahale imkanı yok.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var expanded = false
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (rootView == null) buildOverlay() else rebuildPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        toggleButton = TextView(this).apply {
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }
        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private fun rebuildPanel() {
        expandedPanel.removeAllViews()
        if (mode == "EDIT") {
            toggleButton.text = "✏️"
            val status = TextView(this).apply {
                text = "✏️ DÜZENLEME — oyunun içinde kural ekleyebilirsin"
                setPadding(16, 8, 16, 8)
                setBackgroundColor(Color.parseColor("#CC000000"))
                setTextColor(Color.WHITE)
            }
            val btnAdd = Button(this).apply {
                text = "🖼️👆 Alan Ekle"
                setOnClickListener { openRuleEditor() }
            }
            val btnManage = Button(this).apply {
                text = "📋 Yönet (Ana Akış/Fonksiyon/Kod)"
                setOnClickListener { openManage() }
            }
            expandedPanel.addView(status)
            expandedPanel.addView(btnAdd)
            expandedPanel.addView(btnManage)
        } else {
            toggleButton.text = "▶️"
            val status = TextView(this).apply {
                text = "▶️ ÇALIŞMA MODU — sistem çalışıyor"
                setPadding(16, 8, 16, 8)
                setBackgroundColor(Color.parseColor("#CC000000"))
                setTextColor(Color.WHITE)
            }
            val btnStop = Button(this).apply {
                text = "⏹ Durdur"
                setOnClickListener {
                    stopService(Intent(this@OverlayService, ScreenCaptureService::class.java))
                    stopSelf()
                }
            }
            expandedPanel.addView(status)
            expandedPanel.addView(btnStop)
        }
    }

    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
    }

    private fun openRuleEditor() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        expanded = false; expandedPanel.visibility = View.GONE
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    private fun openManage() {
        expanded = false; expandedPanel.visibility = View.GONE
        val intent = Intent(this, EditModeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
