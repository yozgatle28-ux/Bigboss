package com.bigboss.app.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * PLAY MODE çalışırken oyunun üzerinde duran, KÜÇÜK, sadece durum ve
 * "Durdur" içeren minimal bir gösterge. Artık düzenleme ikonları YOK —
 * düzenleme tamamen uygulama içindeki "EDIT MODE" ekranında yapılıyor,
 * PLAY MODE'da sisteme hiçbir müdahale imkanı yok, sadece izleyip
 * durdurabilirsin.
 */
class OverlayService : Service() {

    private var expanded = false
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout
    private lateinit var statusLabel: TextView
    private lateinit var stopButton: Button

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        toggleButton = TextView(this).apply {
            text = "▶️"
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }

        statusLabel = TextView(this).apply {
            text = "▶️ ÇALIŞMA MODU — sistem çalışıyor"
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.parseColor("#CC000000"))
            setTextColor(Color.WHITE)
        }
        stopButton = Button(this).apply {
            text = "⏹ Durdur"
            setOnClickListener {
                stopService(Intent(this@OverlayService, ScreenCaptureService::class.java))
                stopSelf()
            }
        }

        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(statusLabel)
            addView(stopButton)
        }

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)
        windowManager?.addView(rootView, params)
    }

    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
