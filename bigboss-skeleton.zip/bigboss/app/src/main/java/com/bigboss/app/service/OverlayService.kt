package com.bigboss.app.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import com.bigboss.app.ui.RuleEditorActivity

/**
 * Diğer uygulamaların üzerinde küçük bir kontrol paneli gösterir:
 *  - "BigBoss ●" : çalışma durumunu gösterir
 *  - "+ Kural Ekle" : anlık ekran görüntüsünü dondurup kural editörünü açar
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        val statusButton = Button(this).apply {
            text = "BigBoss ●"
        }

        val addRuleButton = Button(this).apply {
            text = "+ Kural Ekle"
            setOnClickListener { openRuleEditor() }
        }

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(statusButton)
            addView(addRuleButton)
        }

        windowManager?.addView(rootView, params)
    }

    private fun openRuleEditor() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
