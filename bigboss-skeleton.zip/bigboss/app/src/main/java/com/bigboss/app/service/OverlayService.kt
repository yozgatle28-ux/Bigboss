package com.bigboss.app.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.ui.MainActivity
import com.bigboss.app.ui.RuleEditorActivity

/**
 * Macrorify tarzı Edit Mode / Play Mode kontrolü. Diğer uygulamaların
 * üzerinde küçük bir panel gösterir:
 *
 *  - EDIT MODE (varsayılan, botu başlatınca burada başlar): kural
 *    eklemek/düzenlemek içindir. RuleEngine.paused = true olduğu için
 *    motor hiçbir dokunuş yapmaz, sadece ekranı izler.
 *  - PLAY MODE: gerçekten çalışır — motor kuralları uygulayıp
 *    dokunuş/kaydırma yapar.
 */
class OverlayService : Service() {

    private enum class Mode { EDIT, PLAY }
    private var mode = Mode.EDIT

    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private lateinit var statusLabel: TextView
    private lateinit var modeToggleButton: Button
    private lateinit var addRuleButton: Button
    private lateinit var listButton: Button

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        statusLabel = TextView(this).apply {
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.parseColor("#CC000000"))
            setTextColor(Color.WHITE)
        }

        modeToggleButton = Button(this).apply {
            setOnClickListener { toggleMode() }
        }
        addRuleButton = Button(this).apply {
            text = "+ Kural Ekle"
            setOnClickListener { openRuleEditor() }
        }
        listButton = Button(this).apply {
            text = "📋 Kurallar"
            setOnClickListener { openRulesList() }
        }

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(statusLabel)
            addView(modeToggleButton)
            addView(addRuleButton)
            addView(listButton)
        }

        windowManager?.addView(rootView, params)
        applyMode()
    }

    private fun toggleMode() {
        mode = if (mode == Mode.EDIT) Mode.PLAY else Mode.EDIT
        applyMode()
    }

    private fun applyMode() {
        val engine = ScreenCaptureService.ruleEngine
        when (mode) {
            Mode.EDIT -> {
                engine?.paused = true
                statusLabel.text = "✏️ DÜZENLEME MODU — bot dokunmuyor"
                modeToggleButton.text = "▶️ Çalışma Moduna Geç"
                addRuleButton.visibility = android.view.View.VISIBLE
                listButton.visibility = android.view.View.VISIBLE
            }
            Mode.PLAY -> {
                engine?.paused = false
                statusLabel.text = "▶️ ÇALIŞMA MODU — bot çalışıyor"
                modeToggleButton.text = "✏️ Düzenleme Moduna Geç"
                addRuleButton.visibility = android.view.View.GONE
                listButton.visibility = android.view.View.GONE
            }
        }
    }

    private fun openRuleEditor() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    private fun openRulesList() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
