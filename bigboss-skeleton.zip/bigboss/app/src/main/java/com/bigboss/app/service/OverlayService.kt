package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.R.drawable as Ic
import com.bigboss.app.storage.ActionGroupStorage
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 *
 * ÖNEMLİ MİMARİ NOT: Alan çizme/düzenleme artık bir Activity DEĞİL —
 * doğrudan WindowManager ile eklenen GERÇEK overlay pencereleri.
 * Bunun sebebi: şeffaf temalı bir Activity, çoğu oyunun kullandığı
 * SurfaceView/GLSurfaceView tabanlı çizimle düzgün bindirilmiyor
 * (Android'in bilinen bir kısıtı) — bu yüzden oyunun üstünde değil,
 * koyu bir katmanın üstünde görünüyordu. Gerçek overlay pencereleri
 * (bizim küçük ✏️ simgemiz gibi) HER TÜRLÜ uygulamanın (oyunlar dahil)
 * üzerinde güvenilir şekilde çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
    }

    private var mode = "PLAY"
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (mode == "PLAY") {
            val engine = ScreenCaptureService.ruleEngine
            playState = if (engine != null && !engine.paused) "PLAYING" else if (playState == "STOPPED") "STOPPED" else "PAUSED"
        } else if (mode == "EDIT") {
            editTestRunning = false // güvenlik: Edit Mode'a her girişte varsayılan olarak dokunuş kapalı
        }
        if (rootView == null) buildOverlay() else rebuildPanel()
        // Script'ten Setting.show() çağrıldığında UI thread'de diyaloğu açan köprüyü kur.
        ScreenCaptureService.ruleEngine // (motorun kurulu olduğundan emin ol)
        com.bigboss.app.engine.ScriptRuntime.engine?.settingShowRequester = {
            val def = com.bigboss.app.storage.SettingStorage.load(this)
            if (def.views.isNotEmpty()) {
                rootView?.post { showCustomSettingsDialog() }
                true
            } else false
        }
        // Macrorify "Show at start up": Play Mode'a İLK geçişte, ayarlanmışsa özel ayar
        // diyaloğunu otomatik göster (sadece bir kez).
        if (mode == "PLAY" && !startupSettingsShown) {
            startupSettingsShown = true
            val def = com.bigboss.app.storage.SettingStorage.load(this)
            if (def.showAtStartup && def.views.isNotEmpty()) {
                rootView?.postDelayed({ showCustomSettingsDialog() }, 600)
            }
        }
        return START_STICKY
    }

    /** Play Mode başlangıç ayar diyaloğunun bu oturumda gösterilip gösterilmediği. */
    private var startupSettingsShown = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        isDarkMode = com.bigboss.app.storage.AppSettings.isDarkMode(this)
    }

    // ==================== Overlay pencere iskeleti (küçük simge) ====================

    private var sidebarCollapsed = false

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private var playState = "STOPPED" // PLAYING | PAUSED | STOPPED
    private var editTestRunning = false // Edit Mode'dan ÇIKMADAN motoru geçici çalıştırma anahtarı

    /** Panel'i doğrudan HUB yerine belirli bir ekrana açar (Hub yine ← ile bir tık geride durur). */
    private fun openPanelDirectTo(title: String, build: () -> View) {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
        pushScreen(title, build)
    }

    private fun rebuildPanel() {
        rootView?.removeAllViews()
        val density = resources.displayMetrics.density
        val btnSize = (46 * density).toInt()
        val iconSize = (22 * density).toInt()

        if (sidebarCollapsed) {
            val expandArrow = android.widget.ImageView(this).apply {
                setImageResource(com.bigboss.app.R.drawable.ic_chevron_right)
                setBackgroundColor(Color.parseColor("#F0F7F7F9"))
                layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
                setPadding((10 * density).toInt(), (10 * density).toInt(), (10 * density).toInt(), (10 * density).toInt())
                setColorFilter(C_PURPLE)
                setOnClickListener { sidebarCollapsed = false; rebuildPanel() }
            }
            rootView?.addView(expandArrow)
            return
        }

        val sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Macrorify gibi AYDINLIK zemin + renkli ikonlar (koyu tek-renk yerine).
            setBackgroundColor(Color.parseColor("#F7F7F9"))
        }

        val collapseArrow = android.widget.ImageView(this).apply {
            setImageResource(com.bigboss.app.R.drawable.ic_chevron_left)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (28 * density).toInt())
            setPadding(0, (4 * density).toInt(), 0, (4 * density).toInt())
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setColorFilter(Color.parseColor("#9B59F6")) // mor navigasyon
            setOnClickListener { sidebarCollapsed = true; rebuildPanel() }
        }
        sidebar.addView(collapseArrow)

        // Macrorify'daki gibi: TEK dokunuşla direkt çalışan, AYDINLIK zeminde RENKLİ vektör
        // ikonlu küçük kare butonlar. Her ikon işlevine göre renk taşır (tint ile).
        // color=null ise ikon kendi rengini kullanır (play/pause/stop gibi dolgu ikonlar).
        fun iconBtn(drawableRes: Int, color: Int? = null, onClick: () -> Unit) = android.widget.ImageView(this).apply {
            setImageResource(drawableRes)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            val pad = (btnSize - iconSize) / 2
            setPadding(pad, pad, pad, pad)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            if (color != null) setColorFilter(color)
            isClickable = true
            setOnClickListener { onClick() }
        }
        fun row(vararg buttons: View) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.forEach { r.addView(it) }
            sidebar.addView(r)
        }

        if (mode == "EDIT") {
            row(
                iconBtn(Ic.ic_scan, C_ORANGE) { startAddRegion() },
                iconBtn(Ic.ic_tap, C_GREEN) { addSimpleStepToMainFlow("TAP") },
                iconBtn(Ic.ic_swipe, C_GREEN) { addSimpleStepToMainFlow("SWIPE") }
            )
            row(
                iconBtn(Ic.ic_home, C_ORANGE) { openPanelDirectTo("🏠 Ana Akış") { buildAnaAkisScreen() } },
                iconBtn(Ic.ic_function, C_GREEN) { openPanelDirectTo("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } },
                iconBtn(Ic.ic_library, C_ORANGE) { showLibraryMenu() }
            )
            row(
                iconBtn(Ic.ic_code, C_GREEN) { showScriptsMenu() },
                iconBtn(Ic.ic_variable, C_PURPLE) { showVariablesMenu() },
                iconBtn(Ic.ic_workspace, C_BLUE) { showWorkspaceMenu() }
            )
            row(
                iconBtn(if (editTestRunning) Ic.ic_pause else Ic.ic_test, C_GREEN) { toggleEditTest() },
                iconBtn(Ic.ic_play) { switchToPlayMode() },
                iconBtn(Ic.ic_settings, C_BLUE) { showAutoStopSettingsDialog() }
            )
            row(iconBtn(Ic.ic_close, C_RED) { shutdown() })
        } else {
            // ---- PLAY MODE: Play / Pause / Stop / İzle / Ayarlar / Kapat ----
            row(
                iconBtn(Ic.ic_play) { playMacro() },
                iconBtn(if (playState == "PAUSED") Ic.ic_play else Ic.ic_pause) { togglePause() },
                iconBtn(Ic.ic_stop) { stopMacro() }
            )
            row(
                iconBtn(Ic.ic_eye, C_GREEN) { toggleLiveMonitor() },
                iconBtn(Ic.ic_settings, C_BLUE) { showPlayModeSettingsMenu() },
                iconBtn(Ic.ic_close, C_RED) { shutdown() }
            )
            sidebar.addView(TextView(this).apply {
                text = when (playState) { "PLAYING" -> "▶ Çalışıyor"; "PAUSED" -> "⏸ Duraklı"; else -> "⏹ Durdu" }
                setTextColor(Color.parseColor("#444444")); textSize = 10f; gravity = Gravity.CENTER
                setPadding(4, (4 * density).toInt(), 4, (4 * density).toInt())
            })
        }
        rootView?.addView(sidebar)
    }

    /**
     * Macrorify'daki "Unit Test": seçili kuralları (ya da hiç seçim yoksa hepsini) GERÇEKTEN
     * çalıştırır — tüm makroyu baştan sona test etmek yerine sadece ilgilendiğin parçayı.
     */
    private fun testSelectedRules(ruleDefs: List<RuleDefinition>) {
        val engine = ScreenCaptureService.ruleEngine
        val frame = ScreenCaptureService.latestFrame
        if (engine == null || frame == null) {
            Toast.makeText(this, "Motor/ekran görüntüsü hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        val rules = RuleDefinitionMapper.toRules(ruleDefs, this)
        val wasPaused = engine.paused
        engine.paused = false
        try {
            engine.evaluateRulesOnce(rules, frame)
        } finally {
            engine.paused = wasPaused
        }
        Toast.makeText(this, "▶️ Test edildi: ${rules.size} kural", Toast.LENGTH_SHORT).show()
    }

    private fun switchToPlayMode() {
        mode = "PLAY"
        clearAllRegionWindows(); clearWorkspace()
        playMacro()
    }

    /** Edit Mode'dan hiç çıkmadan motoru geçici çalıştırır — sadece izlemek/test etmek için. */
    private fun toggleEditTest() {
        val engine = ScreenCaptureService.ruleEngine
        if (engine == null) {
            Toast.makeText(this, "Motor hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        editTestRunning = !editTestRunning
        engine.paused = !editTestRunning
        if (!editTestRunning) { engine.resetLoopState(); stopLiveMonitor() } else { startLiveMonitor() }
        rebuildPanel()
        Toast.makeText(
            this,
            if (editTestRunning) "🧪 Canlı test başladı — hangi alanın tarandığını yeşil/kırmızı ve sıralı vurguyla göreceksin"
            else "⏸️ Canlı test durdu — düzenlemeye devam edebilirsin",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun playMacro() {
        ScreenCaptureService.ruleEngine?.paused = false
        com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
        playState = "PLAYING"
        startAutoStopWatcher()
        rebuildPanel()
        Toast.makeText(this, "▶️ Çalışıyor", Toast.LENGTH_SHORT).show()
    }

    private fun togglePause() {
        val engine = ScreenCaptureService.ruleEngine ?: return
        if (playState == "PAUSED") {
            engine.paused = false
            com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
            playState = "PLAYING"
            startAutoStopWatcher()
            Toast.makeText(this, "▶️ Devam ediyor", Toast.LENGTH_SHORT).show()
        } else {
            engine.paused = true
            playState = "PAUSED"
            stopAutoStopWatcher()
            Toast.makeText(this, "⏸️ Duraklatıldı — kaldığı yerden devam edecek", Toast.LENGTH_SHORT).show()
        }
        rebuildPanel()
    }

    private fun stopMacro() {
        val engine = ScreenCaptureService.ruleEngine
        engine?.paused = true
        engine?.resetLoopState()
        playState = "STOPPED"
        stopLiveMonitor()
        stopAutoStopWatcher()
        rebuildPanel()
        Toast.makeText(this, "⏹ Durduruldu — Play'e basınca baştan başlar", Toast.LENGTH_SHORT).show()
    }

    // ==================== 🛑 Otomatik Durdurma (art arda hata / donma güvenlik ağı) ====================
    // "Play"deyken, HİÇBİR kural belirli bir süre boyunca hiç tetiklenmezse (bağlantı koptu,
    // oyun dondu, beklenmedik bir ekrana düşüldü vb.) makro sonsuza kadar boşa dönmesin diye
    // kendini otomatik durdurur.

    private val autoStopHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var autoStopRunnable: Runnable? = null

    private fun startAutoStopWatcher() {
        stopAutoStopWatcher()
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        if (minutes <= 0) return // kapalı
        val thresholdMs = minutes * 60_000L
        val tick = object : Runnable {
            override fun run() {
                if (playState != "PLAYING") return
                val elapsed = com.bigboss.app.engine.ActionResultRegistry.msSinceAnyFire()
                if (elapsed >= thresholdMs) {
                    stopMacro()
                    Toast.makeText(
                        this@OverlayService,
                        "🛑 Otomatik durduruldu — $minutes dakikadır hiçbir kural tetiklenmedi (bağlantı/donma olabilir)",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                autoStopHandler.postDelayed(this, 15_000L)
            }
        }
        autoStopRunnable = tick
        autoStopHandler.postDelayed(tick, 15_000L)
    }

    private fun stopAutoStopWatcher() {
        autoStopRunnable?.let { autoStopHandler.removeCallbacks(it) }
        autoStopRunnable = null
    }

    private fun autoStopSubtitle(): String {
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        return if (minutes <= 0) "Otomatik Durdurma: kapalı" else "Otomatik Durdurma: $minutes dk hareketsizlikte dur"
    }

    /** Play Mode'daki ⚙️ ikonunun menüsü: Otomatik Durdurma + Custom Settings (Macrorify "Setting" sekmesi). */
    private fun showPlayModeSettingsMenu() {
        val ctx = this
        val hasCustom = com.bigboss.app.storage.SettingStorage.hasViews(ctx)
        val items = mutableListOf("🛑 Otomatik Durdurma Ayarı")
        items.add(if (hasCustom) "⚙️ Custom Settings (özel ayarları aç)" else "⚙️ Custom Settings (henüz tanımsız)")
        overlayDialog().setTitle("Ayarlar")
            .setItems(items.toTypedArray()) { _, idx ->
                when (idx) {
                    0 -> showAutoStopSettingsDialog()
                    1 -> if (hasCustom) showCustomSettingsDialog() else showSettingBuilderEditor()
                }
            }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun showAutoStopSettingsDialog() {
        val ctx = this
        val current = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(ctx)
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }

        container.addView(TextView(ctx).apply {
            text = "🌗 Görünüm"
            setTypeface(null, android.graphics.Typeface.BOLD); textSize = 13f
        })
        val darkModeCheck = android.widget.CheckBox(ctx).apply {
            text = "Karanlık Mod"
            isChecked = isDarkMode
            setPadding(0, 8, 0, 16)
        }
        darkModeCheck.setOnCheckedChangeListener { _, checked ->
            isDarkMode = checked
            com.bigboss.app.storage.AppSettings.setDarkMode(ctx, checked)
            rebuildPanel() // sidebar'ı da hemen güncelle
            if (panelRoot != null) { closeAppPanel(); showAppPanel() } // panel açıksa yeni temayla yeniden çiz
        }
        container.addView(darkModeCheck)

        container.addView(TextView(ctx).apply {
            text = "🛑 Otomatik Durdurma\n\nPlay Mode'dayken, kaç dakika boyunca HİÇBİR kural tetiklenmezse (bağlantı koptu, oyun dondu, beklenmedik ekran vb.) makro kendini otomatik durdursun? 0 = kapalı (asla otomatik durmaz)."
            textSize = 12f
        })
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
            hint = "Dakika (0 = kapalı)"
        }
        container.addView(input)
        overlayDialog().setTitle("⚙️ Ayarlar").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val minutes = input.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
                com.bigboss.app.storage.AppSettings.setAutoStopMinutes(ctx, minutes)
                if (playState == "PLAYING") startAutoStopWatcher() // yeni değeri hemen uygula
                Toast.makeText(ctx, if (minutes <= 0) "Otomatik durdurma kapatıldı" else "Otomatik durdurma: $minutes dakika", Toast.LENGTH_SHORT).show()
                refreshCurrentScreen()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir Hold/Delay alanı için: sabit sayı GİR ya da bir "🔢 Değişken"e BAĞLA seçeneği sunan birleşik alan. */
    private fun addHoldOrDelayField(
        ctx: android.content.Context, container: LinearLayout, label: String,
        currentValue: Long, currentVarName: String?,
        onValueChanged: (Long) -> Unit, onVarNameChanged: (String?) -> Unit
    ) {
        container.addView(TextView(ctx).apply { text = label; textSize = 12f; setPadding(0, 12, 0, 0) })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentValue.toString())
            isEnabled = currentVarName == null
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        input.addTextChangedListener(simpleWatcher { onValueChanged(it.toLongOrNull() ?: 0) })
        row.addView(input)
        lateinit var btnLink: Button
        btnLink = Button(ctx).apply {
            text = if (currentVarName != null) "🔗 $currentVarName" else "🔗 Bağla"
            textSize = 10f
            setOnClickListener {
                val vars = com.bigboss.app.storage.GlobalVariableStorage.load(this@OverlayService).filter { !it.disabled }
                if (vars.isEmpty()) {
                    Toast.makeText(this@OverlayService, "Henüz değişken yok — önce 🔢 Değişkenler'den oluştur", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val options = mutableListOf("❌ Bağlantıyı Kaldır (sabit değer kullan)")
                options.addAll(vars.map { "🔗 ${it.name} (${it.raw()})" })
                overlayDialog().setItems(options.toTypedArray()) { _, idx ->
                    if (idx == 0) {
                        onVarNameChanged(null); btnLink.text = "🔗 Bağla"; input.isEnabled = true
                    } else {
                        val v = vars[idx - 1]
                        onVarNameChanged(v.name); btnLink.text = "🔗 ${v.name}"
                        input.isEnabled = false; input.setText(v.raw())
                    }
                }.create().showOverlay()
            }
        }
        row.addView(btnLink)
        container.addView(row)
    }

    // ==================== ⚙️ Custom Settings (Macrorify "Setting Builder") ====================

    /**
     * Kayıtlı özel ayar diyaloğunu GERÇEK bir arayüz olarak gösterir. Kullanıcı "Kaydet"e
     * basınca her view'ın (TextView hariç) değeri, key'iyle aynı isimli bir DEĞİŞKENe yazılır.
     * onDone: diyalog kapandığında çağrılır (true=Kaydet, false=İptal) — Play Mode başlangıç
     * akışı için (Kaydet'ten sonra botu başlat gibi).
     */
    private fun showCustomSettingsDialog(onDone: ((saved: Boolean) -> Unit)? = null) {
        val ctx = this
        val def = com.bigboss.app.storage.SettingStorage.load(ctx)
        if (def.views.isEmpty()) {
            Toast.makeText(ctx, "Henüz özel ayar yok — '⚙️ Custom Settings' editöründen ekle", Toast.LENGTH_LONG).show()
            onDone?.invoke(false)
            return
        }
        // Her view için, girilen değeri okuyan bir lambda toplayacağız.
        val valueReaders = LinkedHashMap<String, () -> String>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 8) }

        def.views.forEach { v ->
            when (v.type) {
                "TEXTVIEW" -> {
                    root.addView(TextView(ctx).apply {
                        text = v.label; setTextColor(TEXT_PRIMARY); textSize = 15f; setPadding(0, 16, 0, 4)
                        setTypeface(null, android.graphics.Typeface.BOLD)
                    })
                }
                "CHECKBOX" -> {
                    val cb = android.widget.CheckBox(ctx).apply {
                        text = v.label.ifBlank { v.key }
                        isChecked = v.defaultValue == "true"
                        setTextColor(TEXT_PRIMARY); setPadding(0, 16, 0, 0)
                    }
                    root.addView(cb)
                    if (v.helper.isNotBlank()) root.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    valueReaders[v.key] = { if (cb.isChecked) "true" else "false" }
                }
                "RADIO" -> {
                    if (v.label.isNotBlank()) root.addView(TextView(ctx).apply {
                        text = v.label; setTextColor(TEXT_PRIMARY); setPadding(0, 16, 0, 2)
                    })
                    val rg = android.widget.RadioGroup(ctx)
                    val selectedIdx = v.defaultValue.toIntOrNull() ?: 0
                    v.radioOptions.forEachIndexed { i, opt ->
                        val rb = android.widget.RadioButton(ctx).apply { text = opt; id = i + 1; setTextColor(TEXT_PRIMARY) }
                        if (i == selectedIdx) rb.isChecked = true
                        rg.addView(rb)
                    }
                    root.addView(rg)
                    if (v.helper.isNotBlank()) root.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    // Değer: seçili radyonun index'i (0 tabanlı). Seçili yoksa 0.
                    valueReaders[v.key] = { (rg.checkedRadioButtonId - 1).coerceAtLeast(0).toString() }
                }
                else -> { // EDITTEXT
                    if (v.label.isNotBlank()) root.addView(TextView(ctx).apply {
                        text = v.label; textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 16, 0, 2)
                    })
                    val et = EditText(ctx).apply {
                        setText(v.defaultValue)
                        hint = v.hint
                        setTextColor(TEXT_PRIMARY)
                        if (v.inputMethod == "NUMBER") inputType = InputType.TYPE_CLASS_NUMBER
                    }
                    root.addView(et)
                    if (v.helper.isNotBlank()) root.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    valueReaders[v.key] = { et.text.toString() }
                }
            }
        }

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }
        overlayDialog().setTitle("⚙️ ${def.title}").setView(scroll)
            .setPositiveButton("Kaydet") { _, _ ->
                val values = LinkedHashMap<String, String>()
                valueReaders.forEach { (key, reader) -> if (key.isNotBlank()) values[key] = reader() }
                com.bigboss.app.storage.SettingStorage.applyValues(ctx, values)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                Toast.makeText(ctx, "Ayarlar kaydedildi — değişkenler güncellendi", Toast.LENGTH_SHORT).show()
                onDone?.invoke(true)
            }
            .setNegativeButton("İptal") { _, _ -> onDone?.invoke(false) }
            .setOnCancelListener { onDone?.invoke(false) }
            .create().showOverlay()
    }

    /** Setting Builder editörü — özel ayar diyaloğundaki view'ları ekle/düzenle/sil/sırala. */
    private fun showSettingBuilderEditor() {
        val ctx = this
        val def = com.bigboss.app.storage.SettingStorage.load(ctx)

        fun rebuild() {
            com.bigboss.app.storage.SettingStorage.save(ctx, def)
        }

        val options = mutableListOf(
            "➕ View Ekle (TextView/EditText/CheckBox/Radio)",
            "📝 Başlık: ${def.title}",
            if (def.showAtStartup) "🚀 Başlangıçta Göster: AÇIK" else "🚀 Başlangıçta Göster: KAPALI",
            "👁️ Önizle (diyaloğu şimdi göster)"
        )
        def.views.forEachIndexed { i, v ->
            val icon = when (v.type) { "TEXTVIEW" -> "🏷️"; "CHECKBOX" -> "☑️"; "RADIO" -> "🔘"; else -> "✏️" }
            val keyPart = if (v.type == "TEXTVIEW") "" else " [${v.key}]"
            options.add("$icon ${v.label.ifBlank { v.key }}$keyPart")
        }
        overlayDialog().setTitle("⚙️ Custom Settings — ${def.views.size} view")
            .setItems(options.toTypedArray()) { _, idx ->
                when (idx) {
                    0 -> addSettingView(def)
                    1 -> {
                        val input = EditText(ctx).apply { setText(def.title) }
                        overlayDialog().setTitle("Diyalog başlığı").setView(input)
                            .setPositiveButton("Kaydet") { _, _ ->
                                def.title = input.text.toString().ifBlank { "Ayarlar" }; rebuild(); showSettingBuilderEditor()
                            }.setNegativeButton("Vazgeç", null).create().showOverlay()
                    }
                    2 -> { def.showAtStartup = !def.showAtStartup; rebuild(); showSettingBuilderEditor() }
                    3 -> showCustomSettingsDialog()
                    else -> editSettingView(def, def.views[idx - 4])
                }
            }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** Yeni view eklemek için tip seçtirir. */
    private fun addSettingView(def: com.bigboss.app.storage.SettingDefinition) {
        val ctx = this
        val types = listOf(
            "🏷️ TextView (sadece metin)" to "TEXTVIEW",
            "✏️ EditText (metin/sayı girişi)" to "EDITTEXT",
            "☑️ CheckBox (açık/kapalı)" to "CHECKBOX",
            "🔘 Radio Group (seçenekler)" to "RADIO"
        )
        overlayDialog().setTitle("Hangi view?")
            .setItems(types.map { it.first }.toTypedArray()) { _, i ->
                val newView = com.bigboss.app.storage.SettingViewDef(java.util.UUID.randomUUID().toString(), type = types[i].second)
                def.views.add(newView)
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                editSettingView(def, newView)
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Bir view'ın alanlarını düzenler (tipine göre). */
    private fun editSettingView(def: com.bigboss.app.storage.SettingDefinition, view: com.bigboss.app.storage.SettingViewDef) {
        val ctx = this
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }

        val keyInput = EditText(ctx).apply { setText(view.key); hint = "key (değişken adı)" }
        val labelInput = EditText(ctx).apply { setText(view.label); hint = if (view.type == "TEXTVIEW") "gösterilecek metin" else "etiket (üst başlık)" }
        val defaultInput = EditText(ctx).apply { setText(view.defaultValue); hint = "varsayılan değer" }
        val hintInput = EditText(ctx).apply { setText(view.hint); hint = "kutu içi ipucu (hint)" }
        val helperInput = EditText(ctx).apply { setText(view.helper); hint = "yardımcı açıklama (helper)" }

        if (view.type != "TEXTVIEW") {
            box.addView(TextView(ctx).apply { text = "Key (değişken adı — makro her yerinde {bu} olarak kullanılır)"; textSize = 11f; setTextColor(TEXT_SECONDARY) })
            box.addView(keyInput)
        }
        box.addView(TextView(ctx).apply { text = if (view.type == "TEXTVIEW") "Metin" else "Etiket"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
        box.addView(labelInput)

        // Tipe özel alanlar
        when (view.type) {
            "EDITTEXT" -> {
                box.addView(TextView(ctx).apply { text = "Varsayılan metin"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                box.addView(defaultInput)
                box.addView(hintInput)
                box.addView(helperInput)
                val numCheck = android.widget.CheckBox(ctx).apply {
                    text = "Sayı girişi (Number)"; isChecked = view.inputMethod == "NUMBER"; setTextColor(TEXT_PRIMARY); setPadding(0, 8, 0, 0)
                }
                box.addView(numCheck)
                box.tag = numCheck // sonradan okumak için
            }
            "CHECKBOX" -> {
                val defCheck = android.widget.CheckBox(ctx).apply {
                    text = "Varsayılan: işaretli"; isChecked = view.defaultValue == "true"; setTextColor(TEXT_PRIMARY); setPadding(0, 8, 0, 0)
                }
                box.addView(defCheck)
                box.addView(helperInput)
                box.tag = defCheck
            }
            "RADIO" -> {
                box.addView(TextView(ctx).apply { text = "Seçenekler (her satır bir seçenek)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                val optsInput = EditText(ctx).apply {
                    setText(view.radioOptions.joinToString("\n")); isSingleLine = false; minLines = 2; maxLines = 6
                }
                box.addView(optsInput)
                box.addView(helperInput)
                box.tag = optsInput
            }
        }

        overlayDialog().setTitle("${view.type} düzenle").setView(android.widget.ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("Kaydet") { _, _ ->
                if (view.type != "TEXTVIEW") {
                    val k = keyInput.text.toString().trim()
                    if (!isValidVariableName(k)) {
                        Toast.makeText(ctx, "Geçersiz key: harf/rakam/_ kullan, sayıyla başlama", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                    view.key = k
                }
                view.label = labelInput.text.toString()
                view.helper = helperInput.text.toString()
                when (view.type) {
                    "EDITTEXT" -> {
                        view.defaultValue = defaultInput.text.toString()
                        view.hint = hintInput.text.toString()
                        view.inputMethod = if ((box.tag as? android.widget.CheckBox)?.isChecked == true) "NUMBER" else "TEXT"
                    }
                    "CHECKBOX" -> {
                        view.defaultValue = if ((box.tag as? android.widget.CheckBox)?.isChecked == true) "true" else "false"
                    }
                    "RADIO" -> {
                        val lines = (box.tag as? EditText)?.text?.toString()?.split("\n")?.map { it.trim() }?.filter { it.isNotBlank() }
                        if (!lines.isNullOrEmpty()) view.radioOptions = lines.toMutableList()
                        if (view.defaultValue.toIntOrNull() == null) view.defaultValue = "0"
                    }
                }
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                showSettingBuilderEditor()
            }
            .setNeutralButton("🗑 Sil") { _, _ ->
                def.views.removeAll { it.id == view.id }
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                showSettingBuilderEditor()
            }
            .setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    // ==================== 🔢 Değişkenler (Hold/Delay gibi alanların toplu değiştirilmesi için) ====================

    private fun showVariablesMenu() {
        val ctx = this
        val vars = com.bigboss.app.storage.GlobalVariableStorage.load(ctx)
        val options = mutableListOf("➕ Yeni Değişken")
        options.addAll(vars.map { v ->
            val icon = when (v.type) { "STRING" -> "🔤"; "REFERENCE" -> "🔗"; else -> "🔢" }
            val dis = if (v.disabled) "🔕 " else ""
            "$icon $dis${v.name} = ${v.raw()}"
        })
        overlayDialog().setTitle("🔢 Değişkenler (her yerde kullanılabilir)").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createVariable() else showVariableOptions(vars[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** Macrorify isimlendirme kuralı: sadece a-z A-Z 0-9 ve _ ; sayıyla başlayamaz. */
    private fun isValidVariableName(name: String): Boolean =
        name.isNotBlank() && name.matches(Regex("^[A-Za-z_][A-Za-z0-9_]*$"))

    /** Tip seçici (Number/String/Reference) radyo grubu üretir; seçili tipi callback ile bildirir. */
    private fun buildTypeSelector(ctx: android.content.Context, current: String, onChange: (String) -> Unit): LinearLayout {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(ctx).apply { text = "Tip"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
        val rg = android.widget.RadioGroup(ctx)
        val types = listOf("NUMBER" to "🔢 Number (sayı)", "STRING" to "🔤 String (metin)", "REFERENCE" to "🔗 Reference (ifade)")
        types.forEachIndexed { i, (key, label) ->
            val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1 }
            if (current == key) rb.isChecked = true
            rg.addView(rb)
        }
        rg.setOnCheckedChangeListener { _, id -> onChange(types[id - 1].first) }
        box.addView(rg)
        return box
    }

    private fun createVariable() {
        val ctx = this
        var selectedType = "NUMBER"
        val nameInput = EditText(ctx).apply { hint = "Değişken adı (örn. beklemeSuresi) — harf/rakam/_ , sayıyla başlamaz" }
        val valueInput = EditText(ctx).apply { hint = "Başlangıç değeri"; setText("0") }
        val hintTv = TextView(ctx).apply {
            text = "🔢 Number: sayı (10) · 🔤 String: metin (merhaba) · 🔗 Reference: ifade (getVar(\"a\")+5, çalışırken hesaplanır)"
            textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0)
        }
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(nameInput)
        container.addView(buildTypeSelector(ctx, selectedType) { selectedType = it })
        container.addView(TextView(ctx).apply { text = "Değer"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
        container.addView(valueInput)
        container.addView(hintTv)
        overlayDialog().setTitle("Yeni Değişken").setView(container)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (!isValidVariableName(name)) {
                    Toast.makeText(ctx, "Geçersiz ad: sadece harf/rakam/_ kullan, sayıyla başlama (örn. topRegion)", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val value = valueInput.text.toString()
                com.bigboss.app.storage.GlobalVariableStorage.upsert(
                    ctx, com.bigboss.app.storage.GlobalVariableDefinition(UUID.randomUUID().toString(), name, type = selectedType, textValue = value)
                )
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                Toast.makeText(ctx, "Oluşturuldu: $name = $value ($selectedType)", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showVariableOptions(variable: com.bigboss.app.storage.GlobalVariableDefinition) {
        val ctx = this
        val typeLabel = when (variable.type) { "STRING" -> "🔤 String"; "REFERENCE" -> "🔗 Reference"; else -> "🔢 Number" }
        overlayDialog().setTitle("$typeLabel — ${variable.name} = ${variable.raw()}")
            .setItems(arrayOf(
                "✏️ Değeri/Tipi Değiştir (buna bağlı HER ŞEY güncellenir)",
                if (variable.disabled) "🔔 Etkinleştir" else "🔕 Devre Dışı Bırak",
                "🗑 Sil"
            )) { _, index ->
                when (index) {
                    0 -> {
                        var selectedType = variable.type
                        val input = EditText(ctx).apply { setText(variable.raw()) }
                        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
                        box.addView(buildTypeSelector(ctx, selectedType) { selectedType = it })
                        box.addView(TextView(ctx).apply { text = "Değer"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
                        box.addView(input)
                        overlayDialog().setTitle("Değiştir: ${variable.name}").setView(box)
                            .setPositiveButton("Kaydet") { _, _ ->
                                variable.textValue = input.text.toString()
                                variable.type = selectedType
                                com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, variable)
                                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                                com.bigboss.app.storage.EngineAssembler.setupVariableStore(ctx) { com.bigboss.app.engine.ScriptRuntime.engine }
                                Toast.makeText(ctx, "Güncellendi: ${variable.name} = ${variable.raw()} — buna bağlı tüm alanlar etkilendi", Toast.LENGTH_LONG).show()
                            }.setNegativeButton("Vazgeç", null).create().showOverlay()
                    }
                    1 -> {
                        variable.disabled = !variable.disabled
                        com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, variable)
                        com.bigboss.app.storage.EngineAssembler.setupVariableStore(ctx) { com.bigboss.app.engine.ScriptRuntime.engine }
                        Toast.makeText(ctx, if (variable.disabled) "Devre dışı" else "Etkin", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        com.bigboss.app.storage.GlobalVariableStorage.delete(ctx, variable.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                        Toast.makeText(ctx, "Silindi (buna bağlı alanlar artık kendi sabit değerlerini kullanır)", Toast.LENGTH_LONG).show()
                    }
                }
            }.create().showOverlay()
    }

    private var liveMonitorOn = false
    private val liveMonitorHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var liveMonitorRunnable: Runnable? = null
    private data class LiveBox(val rule: RuleDefinition, val box: View)
    private val liveBoxes = mutableListOf<LiveBox>()
    private var liveMonitorSweepIndex = 0
    private var liveMonitorSweepLabel: TextView? = null
    private var liveMonitorSweepLabelParams: WindowManager.LayoutParams? = null

    private fun toggleLiveMonitor() {
        if (liveMonitorOn) stopLiveMonitor() else startLiveMonitor()
        rebuildPanel()
    }

    private fun startLiveMonitor() {
        // Sadece EKRANDA bölgesi olan (COLOR/IMAGE/TEXT) kuralları görsel kutu olarak izleriz;
        // VARIABLE/CUSTOM koşulları ekranı taramadığı için onlar için kutu çizmenin anlamı yok.
        val rules = RuleStorage.load(this).filter {
            !it.id.endsWith("-fail") && it.enabled && it.alternatives.isNotEmpty() &&
                it.alternatives.first().conditionKind !in listOf("VARIABLE", "CUSTOM")
        }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Ana Akışta izlenecek (ekran tabanlı) alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        liveMonitorOn = true
        liveMonitorSweepIndex = 0
        rules.forEach { rule ->
            val alt = rule.alternatives.first()
            val box = View(this).apply { background = borderDrawable(Color.GRAY) }
            val params = WindowManager.LayoutParams(
                alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }
            try {
                windowManager?.addView(box, params)
                liveBoxes.add(LiveBox(rule, box))
            } catch (e: Exception) {}
        }
        // Sırayla "şu an taranan alan" etiketi — Ana Akış listesindeki sırayla ilerler.
        val sweepLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD000000"))
            textSize = 12f
            setPadding(16, 6, 16, 6)
        }
        val sweepParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 400 }
        try {
            windowManager?.addView(sweepLabel, sweepParams)
            liveMonitorSweepLabel = sweepLabel; liveMonitorSweepLabelParams = sweepParams
        } catch (e: Exception) {}

        Toast.makeText(this, "👁️ Canlı izleme açık — yeşil: eşleşti, kırmızı: eşleşmedi, kalın çerçeve: şu an taranan alan", Toast.LENGTH_LONG).show()
        scheduleLiveMonitorTick()
    }

    private fun scheduleLiveMonitorTick() {
        val tick = object : Runnable {
            override fun run() {
                if (!liveMonitorOn) return
                val frame = ScreenCaptureService.latestFrame
                if (frame != null && liveBoxes.isNotEmpty()) {
                    val currentIdx = liveMonitorSweepIndex % liveBoxes.size
                    liveBoxes.forEachIndexed { idx, lb ->
                        val matched = try {
                            val condition = RuleDefinitionMapper.toCondition(lb.rule)
                            val rawMatch = condition.matchScore(frame) >= condition.minScore
                            if (lb.rule.negateCondition) !rawMatch else rawMatch
                        } catch (e: Exception) { false }
                        val color = if (matched) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
                        val strokeDp = if (idx == currentIdx) 6f else 2.5f
                        lb.box.background = borderDrawable(color, strokeDp)
                    }
                    liveMonitorSweepLabel?.text = "🔍 Taranıyor: ${liveBoxes[currentIdx].rule.name} (${currentIdx + 1}/${liveBoxes.size})"
                    liveMonitorSweepIndex++
                }
                liveMonitorHandler.postDelayed(this, 400L)
            }
        }
        liveMonitorRunnable = tick
        liveMonitorHandler.post(tick)
    }

    private fun stopLiveMonitor() {
        liveMonitorOn = false
        liveMonitorRunnable?.let { liveMonitorHandler.removeCallbacks(it) }
        liveMonitorRunnable = null
        liveBoxes.forEach { try { windowManager?.removeView(it.box) } catch (e: Exception) {} }
        liveBoxes.clear()
        liveMonitorSweepLabel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        liveMonitorSweepLabel = null; liveMonitorSweepLabelParams = null
    }

    // ==================== 🎨 Tasarım Sistemi — Macrorify'ın attığın ekran görüntülerine göre ====================
    // Fark ettiğim şeyler: (1) dolgulu renkli üst çubuk yerine CLOSE/Başlık/SAVE metin-linkli
    // hafif "sayfa" hissi (2) bol boşluklu liste satırları + ince gri ayırıcılar (3) her alanın
    // üstünde etiket + kutulu kenarlık + altında açıklama metni (4) MOR vurgu rengi, beyaz zemin.

    /** Karanlık/Aydınlık Mod: panel/ekranların rengi buna göre değişir. */
    private var isDarkMode: Boolean = false
    private val ACCENT: Int get() = if (isDarkMode) Color.parseColor("#B39DFF") else Color.parseColor("#7C4DFF")

    // Macrorify tarzı panel ikon renkleri (aydınlık zeminde okunaklı, işleve göre).
    private val C_GREEN = Color.parseColor("#27C46B")   // tap/swipe/function/test/eye
    private val C_ORANGE = Color.parseColor("#F5871F")  // scan/image/home/library
    private val C_BLUE = Color.parseColor("#3B9EE8")    // settings/workspace/save
    private val C_PURPLE = Color.parseColor("#9B59F6")  // variable/navigation
    private val C_RED = Color.parseColor("#E8503B")     // close/stop
    private val TEXT_PRIMARY: Int get() = if (isDarkMode) Color.parseColor("#F0F0F0") else Color.parseColor("#212121")
    private val TEXT_SECONDARY: Int get() = if (isDarkMode) Color.parseColor("#AAAAAA") else Color.parseColor("#757575")
    private val DIVIDER_COLOR: Int get() = if (isDarkMode) Color.parseColor("#3A3A3A") else Color.parseColor("#E0E0E0")
    /** Panel/kart arka planı — Aydınlık modda beyaz, Karanlık modda koyu gri. */
    private val SURFACE_COLOR: Int get() = if (isDarkMode) Color.parseColor("#1E1E1E") else Color.WHITE
    /** Hafif vurgulu satır arka planı (kart, liste satırı vb.) */
    private val SURFACE_ALT_COLOR: Int get() = if (isDarkMode) Color.parseColor("#2A2A2A") else Color.parseColor("#F5F5F5")

    /** Macrorify'daki "CLOSE ... Başlık ... SAVE" üst çubuğu — dolgulu renk yerine beyaz zemin + mor metin linkler. */
    private fun buildSheetHeader(title: String, onClose: () -> Unit, rightLabel: String? = null, onRight: (() -> Unit)? = null): LinearLayout {
        val density = resources.displayMetrics.density
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt())
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setOnClickListener { onClose() }
        }
        val titleTv = TextView(this).apply {
            text = title; textSize = 15f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val rightTv = TextView(this).apply {
            text = rightLabel ?: ""
            textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            visibility = if (rightLabel != null) View.VISIBLE else View.INVISIBLE
            if (onRight != null) setOnClickListener { onRight() }
        }
        header.addView(closeBtn)
        header.addView(titleTv)
        header.addView(rightTv)
        return header
    }

    /** Macrorify'daki Ayarlar ekranındaki "etiket + kutulu alan + altında açıklama" deseni. */
    /** Macrorify'daki "?" ipucu balonlarının karşılığı: temiz beyaz pencere, kalın etiketli açıklamalar, "ANLADIM" butonu. */
    private fun showHintDialog(title: String, body: CharSequence) {
        val ctx = this
        val density = resources.displayMetrics.density
        val content = TextView(ctx).apply {
            text = body
            textSize = 13f
            setTextColor(TEXT_PRIMARY)
            setPadding((20 * density).toInt(), (16 * density).toInt(), (20 * density).toInt(), (8 * density).toInt())
            setLineSpacing(6f, 1.1f)
        }
        val scroll = android.widget.ScrollView(ctx).apply { addView(content) }
        overlayDialog().setTitle(title).setView(scroll)
            .setPositiveButton("ANLADIM", null)
            .create().showOverlay()
    }

    /** Kalın etiket + açıklama satırlarından bir SpannableStringBuilder oluşturur (hint metinleri için). */
    private fun hintText(vararg parts: Pair<String, String>): CharSequence {
        val sb = android.text.SpannableStringBuilder()
        parts.forEach { (bold, rest) ->
            val start = sb.length
            sb.append(bold)
            sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, sb.length, 0)
            sb.append(rest).append("\n\n")
        }
        return sb
    }

    private fun styledField(label: String, helper: String?, value: String, keyboardNumeric: Boolean = true, hintTitle: String? = null, hintBody: CharSequence? = null, onChange: (String) -> Unit): LinearLayout {
        val density = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (14 * density).toInt(), 0, 0)
        }
        val labelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val labelTv = TextView(this).apply { text = label; textSize = 11f; setTextColor(TEXT_SECONDARY) }
        labelRow.addView(labelTv)
        if (hintTitle != null && hintBody != null) {
            labelRow.addView(TextView(this).apply {
                text = "  ⓘ"; textSize = 11f; setTextColor(ACCENT)
                setOnClickListener { showHintDialog(hintTitle, hintBody) }
            })
        }
        val input = EditText(this).apply {
            setText(value)
            textSize = 15f
            setTextColor(TEXT_PRIMARY)
            if (keyboardNumeric) inputType = InputType.TYPE_CLASS_NUMBER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke((1 * density).toInt(), DIVIDER_COLOR)
                cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        input.addTextChangedListener(simpleWatcher { onChange(it) })
        container.addView(labelRow)
        container.addView(input)
        if (helper != null) {
            container.addView(TextView(this).apply {
                text = helper; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (4 * density).toInt(), 0, 0)
            })
        }
        return container
    }

    /** ListView satırları arasına Macrorify'daki gibi ince gri ayırıcı çizgi ekler. */
    private fun styleListDividers(listView: android.widget.ListView) {
        listView.divider = android.graphics.drawable.ColorDrawable(DIVIDER_COLOR)
        listView.dividerHeight = (1 * resources.displayMetrics.density).toInt()
    }

    // ==================== 📱 App Panel — Macrorify tarzı TEK, KALICI, gezinme yığınlı panel ====================
    // Eskiden HER işlem ayrı bir AlertDialog açıyordu (üst üste yığılıyordu, "neredeyim" belli değildi).
    // Şimdi TEK bir pencere var; içinde "ekranlar" (screen) arasında GERÇEK gezinme yapıyoruz —
    // üstte her zaman "neredeyim" (breadcrumb) + geri butonu görünüyor, tıpkı normal bir uygulama gibi.

    private data class NavEntry(val title: String, val build: () -> View)
    private val navStack = mutableListOf<NavEntry>()
    private var panelRoot: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelContent: android.widget.FrameLayout? = null
    private var panelTitle: TextView? = null
    private var panelBackBtn: TextView? = null

    private fun showAppPanel() {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
    }

    private fun buildAppPanelWindow() {
        val metrics = resources.displayMetrics
        val panelW = (metrics.widthPixels * 0.94).toInt()
        val panelH = (metrics.heightPixels * 0.82).toInt()
        val density = metrics.density

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            setPadding((12 * density).toInt(), (16 * density).toInt(), (12 * density).toInt(), (16 * density).toInt())
        }
        val backBtn = TextView(this).apply {
            text = "← GERİ"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((8 * density).toInt(), 0, (16 * density).toInt(), 0)
            visibility = View.INVISIBLE
        }
        val titleTv = TextView(this).apply {
            textSize = 13f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((16 * density).toInt(), 0, (8 * density).toInt(), 0)
        }
        val headerDivider = View(this).apply {
            setBackgroundColor(DIVIDER_COLOR)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt())
        }
        header.addView(backBtn); header.addView(titleTv); header.addView(closeBtn)

        val content = android.widget.FrameLayout(this)
        val contentScroll = android.widget.ScrollView(this).apply { addView(content) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            addView(header)
            addView(headerDivider)
            addView(contentScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        backBtn.setOnClickListener { popScreen() }
        closeBtn.setOnClickListener { closeAppPanel() }

        val params = WindowManager.LayoutParams(
            panelW, panelH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager?.addView(root, params)
            panelRoot = root; panelParams = params
            panelContent = content; panelTitle = titleTv; panelBackBtn = backBtn
        } catch (e: Exception) {
            Toast.makeText(this, "Panel açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun pushScreen(title: String, build: () -> View) {
        navStack.add(NavEntry(title, build))
        renderCurrentScreen()
    }

    /** Aynı ekranı, güncel verilerle YENİDEN çizer (bir işlem sonrası liste tazelensin diye). */
    private fun refreshCurrentScreen() = renderCurrentScreen()

    private fun popScreen() {
        if (navStack.size <= 1) { closeAppPanel(); return }
        navStack.removeAt(navStack.size - 1)
        renderCurrentScreen()
    }

    private fun renderCurrentScreen() {
        val entry = navStack.lastOrNull() ?: return
        panelTitle?.text = navStack.joinToString("  ›  ") { it.title }
        panelBackBtn?.visibility = if (navStack.size > 1) View.VISIBLE else View.INVISIBLE
        panelContent?.removeAllViews()
        panelContent?.addView(entry.build())
    }

    private fun closeAppPanel() {
        panelRoot?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        panelRoot = null; panelParams = null; panelContent = null; panelTitle = null; panelBackBtn = null
        navStack.clear()
    }

    /** Panel açıkken bir alt-diyalog (AlertDialog) açmadan önce çağrılır — ikisi karışmasın diye paneli GEÇİCİ gizler. */
    private fun hidePanelTemporarily() { panelRoot?.visibility = View.GONE }
    private fun showPanelAgain() { panelRoot?.visibility = View.VISIBLE }

    // ---- Ana ekran (Hub): büyük kart-butonlar ----
    private fun buildHubScreen(): View {
        val ctx = this
        val density = resources.displayMetrics.density
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt()) }

        fun card(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (18 * density).toInt(), (16 * density).toInt(), (18 * density).toInt())
                setBackgroundColor(SURFACE_ALT_COLOR)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, (10 * density).toInt())
                layoutParams = lp
                isClickable = true
                setOnClickListener { onClick() }
            }
            row.addView(TextView(ctx).apply { text = icon; textSize = 24f; setPadding(0, 0, (16 * density).toInt(), 0) })
            val textCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            textCol.addView(TextView(ctx).apply { text = title; textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
            textCol.addView(TextView(ctx).apply { text = subtitle; textSize = 11f; setTextColor(TEXT_SECONDARY) })
            row.addView(textCol)
            grid.addView(row)
        }

        val rules = RuleStorage.load(ctx).size
        val groups = ActionGroupStorage.load(ctx).size
        val fns = FunctionStorage.load(ctx).size

        card("🏠", "Ana Akış", "$rules kural, $groups grup") { pushScreen("🏠 Ana Akış") { buildAnaAkisScreen() } }
        card("f{}", "Fonksiyonlar", "$fns fonksiyon") { pushScreen("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } }
        card("📚", "Kütüphane", "Görsel/renk kaydet") { showLibraryMenu() }
        card("🖥️", "Kod", "Script'ler") { showScriptsMenu() }
        card("🔢", "Değişkenler", "Number/String/Reference") { showVariablesMenu() }
        card("⚙️", "Custom Settings", "Çalışma-anı ayar arayüzü") { showSettingBuilderEditor() }
        card("🗺️", "Çalışma Alanı", "Alanları ekranda göster") { showWorkspaceMenu() }
        card("🖼️👆", "Alan Ekle", "Yeni tarama başlat") { closeAppPanel(); startAddRegion() }
        card("🧪", if (editTestRunning) "Canlı Testi Durdur" else "Canlı Test", "Edit Mode'da kalarak test et") { toggleEditTest(); refreshCurrentScreen() }
        card("▶️", "Play Mode'a Geç", "Kalıcı çalıştır") { closeAppPanel(); switchToPlayMode() }
        if (activeRegions.isNotEmpty()) {
            card("🧹", "Ekrandaki Kutuları Temizle", "${activeRegions.size} açık alan") { clearAllRegionWindows(); refreshCurrentScreen() }
        }
        card("⚙️", "Ayarlar", autoStopSubtitle()) { showAutoStopSettingsDialog() }
        card("✕", "Kapat", "Uygulamayı tamamen kapat") { shutdown() }

        return grid
    }

    private fun shutdown() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        stopAutoStopWatcher()
        removePointMarker()
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    // ==================== Overlay üzerinden Dialog gösterme yardımcıları ====================

    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ==================== ALAN ÇİZME SİSTEMİ (gerçek overlay pencereleri) ====================

    private data class ExtraAction(
        val type: String, // "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT"
        var x: Int = 0, var y: Int = 0,
        var x2: Int = 0, var y2: Int = 0,
        var waitMs: Long = 500,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1,
        var variableName: String = "",
        var variableDelta: Int = 1,
        var scriptId: String? = null,
        var scriptName: String = "",
        var holdMs: Long = 50,
        var swipeHoldStartMs: Long = 0,
        var swipeHoldEndMs: Long = 0,
        var postDelayMs: Long = 0,
        /** "READ_TEXT" için: x,y,x2,y2 alanları BÖLGE (x,y,w,h) olarak kullanılır. */
        var readDefaultValue: Int = 0,
        var readWhitelist: String = "",
        var readBlacklist: String = ""
    )

    private inner class ActiveRegion(
        val id: String, val container: LinearLayout, val containerParams: WindowManager.LayoutParams,
        val label: TextView, val labelParams: WindowManager.LayoutParams,
        val frameContainer: android.widget.FrameLayout, val boxParams: android.widget.FrameLayout.LayoutParams,
        val handleParams: android.widget.FrameLayout.LayoutParams, val handleSizePx: Int
    ) {
        var existingRuleId: String? = null
        var name = ""
        var conditionKind = "COLOR"
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText = ""
        var conditionTextCaseSensitive: Boolean = false
        var conditionTextWhitelist: String = ""
        var conditionTextBlacklist: String = ""
        // ---- Macrorify "Conditional" koşul tipleri (ekran taramasından bağımsız) ----
        /** conditionKind = "VARIABLE" için: karşılaştırılacak değişkenin adı. */
        var conditionVariableName: String = ""
        /** conditionKind = "VARIABLE" için operatör: ">=", "<=", "==", "!=", ">", "<" */
        var conditionVariableOp: String = ">="
        /** conditionKind = "VARIABLE" için karşılaştırılacak sabit sayı. */
        var conditionCompareValue: Int = 0
        /** conditionKind = "CUSTOM" için: true/false dönen JavaScript ifadesi. */
        var conditionCustomCode: String = ""
        /** Macrorify'daki "Multi Detection": bu koşula EK olarak eklenen başka koşullar (her biri kendi bölgesinde). */
        val extraConditions: MutableList<com.bigboss.app.storage.ConditionAlt> = mutableListOf()
        /** extraConditions doluysa, hepsi (ana koşulla birlikte) nasıl birleşsin: VE/VEYA/vb. */
        var conditionsLogic: String = "ONE_SUCCESS"
        var minScore = 90
        var actionType = "TAP"
        var tapAtMatchLocation = false
        var actionRepeatCount = 1
        var actionHoldMs: Long = 50
        var actionPostDelayMs: Long = 0
        var randomOffsetPx: Int = 0
        var randomChancePercent: Int = 100
        var swipeHoldStartMs: Long = 0
        var swipeHoldEndMs: Long = 0
        var actionHoldVarName: String? = null
        var actionPostDelayVarName: String? = null
        var swipeHoldStartVarName: String? = null
        var swipeHoldEndVarName: String? = null
        // Macrorify "her input alanında değişken" — yeni bağlanabilir alanlar:
        var actionRepeatVarName: String? = null
        var randomOffsetVarName: String? = null
        var swipeDurationVarName: String? = null
        var actionXVarName: String? = null
        var actionYVarName: String? = null
        var actionX2VarName: String? = null
        var actionY2VarName: String? = null
        /** Macrorify'daki "Swipe Path": Başlangıç/Bitiş dışındaki EK ara noktalar (x, y, o noktada bekleme). */
        val swipeExtraPoints: MutableList<com.bigboss.app.storage.SwipePointData> = mutableListOf()
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName = ""
        var callFunctionRepeat = 1
        val extraActions = mutableListOf<ExtraAction>()
        val onFailActions = mutableListOf<ExtraAction>()
        var cooldownMs: Long = 300
        var matchDelayMs: Long = 0
        var scanTimeoutMs: Long = 0
        var scanRateHz: Float = 0f
        var maxConsecutiveFailures: Int = 0
        var enabled: Boolean = true
        var negate = false
        var loopMode = "ALWAYS" // NONE | ALWAYS | WHILE_SUCCESS | WHILE_FAIL
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
        /** GENEL sekmesindeki Find Region alanlarını, alan sürüklenince canlı güncellemek için — BİRDEN FAZLA dinleyici destekler. */
        val onRectChangedListeners: MutableList<() -> Unit> = mutableListOf()
        /** Bu alan bir Action Group'un İÇİNE mi kaydedilecek, yoksa Ana Akışa mı? */
        var saveScope: SaveScope = SaveScope.MainFlow
        /** Bu alan bir Action Group'un KAPI koşulunu mu ayarlıyor (true ise sadece koşul kaydedilir)? */
        var isGateForGroupId: String? = null
        /** Bu alan Kütüphaneye "Ekrandan Kırp" için mi kullanılıyor (true ise dokununca kural penceresi değil, kaydetme sorulur)? */
        var isLibraryCapture: Boolean = false
        var isTextReadCapture: Boolean = false
        /** "Metni Değişkene Oku" hangi Başarılı/Bulunamazsa listesine ekleniyor. */
        var textReadTargetList: MutableList<ExtraAction>? = null
        /** "🔄 Değiştir" ile hangi Kütüphane öğesinin görselini AYNI dosya yoluna güncelleyeceğiz. */
        var isReplaceCaptureItem: LibraryItem? = null
        /** Bu alan bir "Multi Detection" EK koşulu olarak çiziliyorsa, hangi ana alana ait olduğu. */
        var isMultiDetectionExtraFor: ActiveRegion? = null
        /** Kaydedildikten SONRA çalıştırılacak ekstra işlem (örn. Başarılı/Bulunamazsa listesine "Fonksiyon Çağır" eklemek için). */
        var onSavedCallback: (() -> Unit)? = null
    }

    private sealed class SaveScope {
        object MainFlow : SaveScope()
        data class Group(val groupId: String) : SaveScope()
        data class Function(val functionId: String) : SaveScope()
    }

    private val activeRegions = mutableListOf<ActiveRegion>()
    private var regionCounter = 0

    private sealed class PendingPick {
        data class ColorPick(val region: Any) : PendingPick()
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex = -1
    private var colorPickCatcher: View? = null

    private fun startAddRegion() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        addRegionWindow()
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    /**
     * Macrorify'daki "Conditional" (✛): ekranı taramayan, saf mantıksal bir koşul (Değişken/Custom)
     * ekler. Bir region kutusu oluşturur ama koşul tipi VARIABLE olduğu için o kutu ekranda GİZLENİR;
     * kullanıcı doğrudan ayar penceresinde koşulu (On True → Ne Yapılacak, On False → Bulunamazsa) kurar.
     */
    private fun startAddConditional(scope: SaveScope) {
        // Ekran görüntüsü olmasa bile Conditional kurulabilir (ekranı taramaz); yine de motor/servis
        // hazır değilse aksiyon noktası seçimi vb. çalışmayabilir, o yüzden yalnızca uyarı veriyoruz.
        val region = addRegionWindow()
        region.saveScope = scope
        region.conditionKind = "VARIABLE"
        region.name = "🔀 Koşul"
        // Kutuyu hemen gizle (bölgesiz koşul); ayar penceresi açıkken zaten görünmesine gerek yok.
        region.container.visibility = View.GONE
        region.label.visibility = View.GONE
        openRegionConfigDialog(region)
        Toast.makeText(this, "🔀 Koşul: bir değişkeni karşılaştır ya da custom kod yaz — doğruysa \"Ne Yapılacak\", yanlışsa \"Bulunamazsa\" çalışır", Toast.LENGTH_LONG).show()
    }

    private fun addRegionWindow(initX: Int? = null, initY: Int? = null, initW: Int? = null, initH: Int? = null): ActiveRegion {
        val id = "r${regionCounter++}"
        val density = resources.displayMetrics.density
        val defaultSize = (130 * density).toInt()
        val handleSize = (22 * density).toInt()
        val offset = (regionCounter % 6) * (24 * density).toInt()

        val box = View(this).apply { background = borderDrawable(Color.parseColor("#2196F3")) }
        val handleView = View(this).apply { setBackgroundColor(Color.WHITE) }

        val container = LinearLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        val boxParams = android.widget.FrameLayout.LayoutParams(defaultSize, defaultSize)
        val handleParams = android.widget.FrameLayout.LayoutParams(handleSize, handleSize).apply {
            leftMargin = defaultSize - handleSize / 2
            topMargin = defaultSize - handleSize / 2
        }
        val frameContainer = android.widget.FrameLayout(this)
        frameContainer.addView(box, boxParams)
        frameContainer.addView(handleView, handleParams)
        container.addView(frameContainer)
        container.clipChildren = false

        val containerParams = WindowManager.LayoutParams(
            defaultSize + handleSize, defaultSize + handleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX ?: ((60 * density).toInt() + offset)
            y = initY ?: ((220 * density).toInt() + offset)
            width = (initW ?: defaultSize) + handleSize
            height = (initH ?: defaultSize) + handleSize
        }
        boxParams.width = initW ?: defaultSize
        boxParams.height = initH ?: defaultSize
        handleParams.leftMargin = (initW ?: defaultSize) - handleSize / 2
        handleParams.topMargin = (initH ?: defaultSize) - handleSize / 2

        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 11f
            text = "?"
            setPadding(8, 2, 8, 2)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = containerParams.x
            y = (containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        }

        windowManager?.addView(container, containerParams)
        windowManager?.addView(label, labelParams)

        val region = ActiveRegion(id, container, containerParams, label, labelParams, frameContainer, boxParams, handleParams, handleSize)
        activeRegions.add(region)

        setupRegionTouch(region, frameContainer, box, boxParams, handleView, handleParams, containerParams, handleSize)
        return region
    }

    private fun borderDrawable(color: Int, strokeDp: Float = 2.5f): android.graphics.drawable.GradientDrawable {
        val density = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((strokeDp * density).toInt(), color)
        }
    }

    private fun updateLabelPosition(region: ActiveRegion) {
        val density = resources.displayMetrics.density
        region.labelParams.x = region.containerParams.x
        region.labelParams.y = (region.containerParams.y - 28 * density).toInt().coerceAtLeast(0)
        windowManager?.updateViewLayout(region.label, region.labelParams)
    }

    private fun setupRegionTouch(
        region: ActiveRegion, frameContainer: android.widget.FrameLayout, box: View, boxParams: android.widget.FrameLayout.LayoutParams,
        handleView: View, handleParams: android.widget.FrameLayout.LayoutParams, containerParams: WindowManager.LayoutParams, handleSize: Int
    ) {
        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var startX = 0; var startY = 0
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    startX = containerParams.x; startY = containerParams.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    // Android'in kendi sistem "dokunma toleransı" (touch slop) değeri: doğal parmak
                    // titremesini görmezden gelirken, GERÇEK bir sürükleme başlangıcını hemen fark eder.
                    // (Önceki sabit 24dp değeri, yavaş bir sürüklemenin 500ms içinde bu eşiği aşamayıp
                    // yanlışlıkla "basılı tutma" menüsünü açmasına sebep oluyordu.)
                    val cancelThreshold = android.view.ViewConfiguration.get(this@OverlayService).scaledTouchSlop
                    if (abs(dx) > cancelThreshold || abs(dy) > cancelThreshold) longPressHandler.removeCallbacks(longPressRunnable)
                    containerParams.x = startX + dx
                    containerParams.y = startY + dy
                    windowManager?.updateViewLayout(region.container, containerParams)
                    updateLabelPosition(region)
                    region.onRectChangedListeners.forEach { it() }
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < 18 && dt < 350) {
                            when {
                                region.isLibraryCapture -> openLibraryCaptureSaveDialog(region)
                                region.isTextReadCapture -> openTextReadSaveDialog(region)
                                region.isReplaceCaptureItem != null -> openReplaceImageConfirmDialog(region)
                                else -> openRegionConfigDialog(region)
                            }
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handleView.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                val minSize = (40 * resources.displayMetrics.density).toInt()
                val localX = (event.rawX - containerParams.x).toInt().coerceAtLeast(minSize)
                val localY = (event.rawY - containerParams.y).toInt().coerceAtLeast(minSize)
                boxParams.width = localX
                boxParams.height = localY
                handleParams.leftMargin = localX - handleSize / 2
                handleParams.topMargin = localY - handleSize / 2
                frameContainer.requestLayout()
                containerParams.width = localX + handleSize
                containerParams.height = localY + handleSize
                windowManager?.updateViewLayout(region.container, containerParams)
                region.onRectChangedListeners.forEach { it() }
            }
            true
        }
    }

    private fun regionRect(region: ActiveRegion): IntArray {
        // Overlay pencere koordinatları GERÇEK ekran piksel koordinatlarıdır — MediaProjection
        // yakalaması da aynı çözünürlükte olduğu için doğrudan (ölçekleme gerekmeden) kullanılabilir.
        val p = region.containerParams
        val handleSize = (22 * resources.displayMetrics.density).toInt()
        return intArrayOf(p.x, p.y, (p.width - handleSize).coerceAtLeast(4), (p.height - handleSize).coerceAtLeast(4))
    }

    /** "Find Region" kutularına tam sayı yazınca, alanı EKRANDA da o konuma taşır/boyutlandırır. */
    private fun moveAndResizeRegion(region: ActiveRegion, x: Int, y: Int, w: Int, h: Int) {
        region.containerParams.x = x
        region.containerParams.y = y
        region.containerParams.width = w + region.handleSizePx
        region.containerParams.height = h + region.handleSizePx
        region.boxParams.width = w
        region.boxParams.height = h
        region.handleParams.leftMargin = w - region.handleSizePx / 2
        region.handleParams.topMargin = h - region.handleSizePx / 2
        try {
            region.frameContainer.requestLayout()
            windowManager?.updateViewLayout(region.container, region.containerParams)
        } catch (e: Exception) {}
        updateLabelPosition(region)
    }

    private fun openHideDeleteMenu(region: ActiveRegion) {
        overlayDialog()
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    region.container.visibility = View.GONE
                    region.label.visibility = View.GONE
                    Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
                } else {
                    deleteRegionCompletely(region)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir alanı hem ekrandan hem (kaydedilmiş bir kuralsa) kayıtlı veriden tamamen siler. */
    private fun deleteRegionCompletely(region: ActiveRegion) {
        val gateGroupId = region.isGateForGroupId
        if (gateGroupId != null) {
            val group = ActionGroupStorage.load(this).find { it.id == gateGroupId }
            if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
        } else {
            region.existingRuleId?.let { id ->
                when (val scope = region.saveScope) {
                    is SaveScope.MainFlow -> { RuleStorage.deleteRule(this, id); RuleStorage.deleteRule(this, "$id-fail") }
                    is SaveScope.Group -> { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, id); ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail") }
                    is SaveScope.Function -> { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, id); FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail") }
                }
            }
        }
        removeRegionWindow(region)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
    }

    private fun removeRegionWindow(region: ActiveRegion) {
        try { windowManager?.removeView(region.container) } catch (e: Exception) {}
        try { windowManager?.removeView(region.label) } catch (e: Exception) {}
        activeRegions.remove(region)
    }

    private fun clearAllRegionWindows() {
        activeRegions.toList().forEach { removeRegionWindow(it) }
    }

    // ==================== ÇALIŞMA ALANI (workspace) — Macrorify'daki "Draw selected/change working group" ====================

    private data class WorkspaceBox(val box: View, val label: TextView, val boxParams: WindowManager.LayoutParams, val labelParams: WindowManager.LayoutParams)
    private val workspaceBoxes = mutableListOf<WorkspaceBox>()
    private var workspaceHidden = false

    private fun showWorkspaceMenu() {
        val options = mutableListOf("🏠 Ana Akış")
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        var headerCount = 0
        if (workspaceBoxes.isNotEmpty()) {
            options.add(0, if (workspaceHidden) "👁️ Öğeleri Göster" else "🙈 Öğeleri Gizle")
            options.add(1, "🧹 Çalışma Alanı Görünümünü Kapat")
            headerCount = 2
        }
        overlayDialog().setTitle("🗺️ Hangi çalışma alanını göreyim?").setItems(options.toTypedArray()) { _, indexRaw ->
            var index = indexRaw
            if (headerCount > 0) {
                if (index == 0) { toggleWorkspaceHidden(); return@setItems }
                if (index == 1) { clearWorkspace(); return@setItems }
                index -= headerCount
            }
            when {
                index == 0 -> showWorkspaceFor(SaveScope.MainFlow, RuleStorage.load(this), "🏠 Ana Akış")
                index <= functions.size -> {
                    val fn = functions[index - 1]
                    showWorkspaceFor(SaveScope.Function(fn.id), fn.rules, "f{} ${fn.name}")
                }
                else -> {
                    val group = groups[index - 1 - functions.size]
                    showWorkspaceFor(SaveScope.Group(group.id), group.rules, "📦 ${group.name}")
                }
            }
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Çalışma Alanı kutularını (durumu KAYBETMEDEN) gizler/tekrar gösterir. */
    private fun toggleWorkspaceHidden() {
        workspaceHidden = !workspaceHidden
        val vis = if (workspaceHidden) View.GONE else View.VISIBLE
        workspaceBoxes.forEach { it.box.visibility = vis; it.label.visibility = vis }
        Toast.makeText(this, if (workspaceHidden) "🙈 Öğeler gizlendi (hâlâ ekranda kayıtlı)" else "👁️ Öğeler tekrar gösteriliyor", Toast.LENGTH_SHORT).show()
    }

    /** Seçilen kapsamdaki TÜM kuralların alanlarını, salt-okunur (dokununca düzenlemeye açılan) kutular olarak ekrana çizer — KALICI kalır. */
    private fun showWorkspaceFor(scope: SaveScope, rules: List<RuleDefinition>, label: String) {
        clearWorkspace()
        workspaceHidden = false
        val visible = rules.filter { !it.id.endsWith("-fail") }
        if (visible.isEmpty()) {
            Toast.makeText(this, "$label içinde henüz alan yok", Toast.LENGTH_SHORT).show()
            return
        }
        visible.forEach { rule ->
            val firstKind = rule.alternatives.firstOrNull()?.conditionKind
            val isScreenless = firstKind == "VARIABLE" || firstKind == "CUSTOM"
            if (rule.alternatives.isNotEmpty() && !isScreenless) {
                addWorkspaceBox(rule, scope)
            } else if (isScreenless) {
                // VARIABLE/CUSTOM: ekranda bölge yok — aksiyon noktasında bir işaretçi göster (dokununca düzenlenir).
                when (rule.actionType) {
                    "SWIPE" -> {
                        addWorkspacePointDot(rule.actionX, rule.actionY, "🔢1️⃣ ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                        addWorkspacePointDot(rule.actionX2, rule.actionY2, "🔢2️⃣ ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                    }
                    else -> addWorkspacePointDot(rule.actionX, rule.actionY, "🔢 ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                }
            } else when (rule.actionType) {
                "SWIPE" -> {
                    addWorkspacePointDot(rule.actionX, rule.actionY, "1️⃣ ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                    addWorkspacePointDot(rule.actionX2, rule.actionY2, "2️⃣ ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                }
                "TAP" -> addWorkspacePointDot(rule.actionX, rule.actionY, "👆 ${rule.name}") { clearWorkspace(); editExistingRule(rule, scope) }
                else -> {}
            }
        }
        Toast.makeText(this, "$label — ${visible.size} öğe gösteriliyor (dokununca düzenlenir, kapatmak için tekrar 🗺️)", Toast.LENGTH_LONG).show()
    }

    private fun addWorkspaceBox(rule: RuleDefinition, scope: SaveScope) {
        val alt = rule.alternatives.first()
        val box = View(this).apply { background = borderDrawable(Color.parseColor("#FFA500")) } // turuncu = salt-okunur çalışma alanı kutusu
        val boxParams = WindowManager.LayoutParams(
            alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }

        val label = TextView(this).apply {
            text = "🗺️ ${rule.name}"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AAFFA500"))
            textSize = 10f
            setPadding(6, 2, 6, 2)
        }
        val density = resources.displayMetrics.density
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = alt.x
            y = (alt.y - 24 * density).toInt().coerceAtLeast(0)
        }

        box.setOnClickListener { /* no-op, dokunuşu ACTION_DOWN'da yakalıyoruz */ }
        box.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                clearWorkspace()
                editExistingRule(rule, scope)
            }
            true
        }

        try {
            windowManager?.addView(box, boxParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(box, label, boxParams, labelParams))
        } catch (e: Exception) {
            android.util.Log.e("BigBossWorkspace", "Kutu eklenemedi: ${rule.name}", e)
            Toast.makeText(this, "⚠️ '${rule.name}' gösterilemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun clearWorkspace() {
        workspaceBoxes.forEach {
            try { windowManager?.removeView(it.box) } catch (e: Exception) {}
            try { windowManager?.removeView(it.label) } catch (e: Exception) {}
        }
        workspaceBoxes.clear()
        workspaceHidden = false
    }

    // ==================== 👆 Dokunma/Kaydırma Noktası İşaretçisi (Macrorify'daki gibi sürüklenebilir parmak simgesi) ====================

    /** Şu an ekranda duran (henüz onaylanmamış) nokta işaretçisi ve onay butonu. */
    private var pointMarkerContainer: View? = null
    private var pointMarkerParams: WindowManager.LayoutParams? = null
    private var pointMarkerConfirmBtn: View? = null
    private var pointMarkerConfirmParams: WindowManager.LayoutParams? = null

    /**
     * Ekranda sürüklenebilir bir 👆 işaretçi gösterir (isteğe bağlı "1"/"2" etiketiyle).
     * Kullanıcı işaretçiyi istediği yere sürükler, ayrı duran "✓ Onayla" butonuna basınca
     * o anki TAM konum (markerSize/2 merkez alınarak) geri döner.
     */
    private fun pickPointWithMarker(badgeLabel: String, initialX: Int?, initialY: Int?, onConfirmed: (Int, Int) -> Unit) {
        removePointMarker() // önceki iz kaldıysa temizle
        val density = resources.displayMetrics.density
        val frame = ScreenCaptureService.latestFrame
        val markerSize = (56 * density).toInt()
        val startX = (initialX ?: ((frame?.width ?: 1080) / 2)) - markerSize / 2
        val startY = (initialY ?: ((frame?.height ?: 1920) / 2)) - markerSize / 2

        val icon = TextView(this).apply {
            text = "👆"; textSize = 30f; gravity = Gravity.CENTER
            layoutParams = android.widget.FrameLayout.LayoutParams(markerSize, markerSize)
        }
        val badge = TextView(this).apply {
            text = badgeLabel
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#DD2196F3"))
            textSize = 11f
            setPadding(10, 2, 10, 2)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.END }
        }
        val markerContainer = android.widget.FrameLayout(this).apply {
            addView(icon); addView(badge)
        }
        val markerParams = WindowManager.LayoutParams(
            markerSize, markerSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = startX; y = startY }

        val confirmBtn = Button(this).apply { text = "✓ $badgeLabel Noktasını Onayla" }
        val confirmParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 100 }

        windowManager?.addView(markerContainer, markerParams)
        windowManager?.addView(confirmBtn, confirmParams)
        pointMarkerContainer = markerContainer; pointMarkerParams = markerParams
        pointMarkerConfirmBtn = confirmBtn; pointMarkerConfirmParams = confirmParams

        var downRawX = 0f; var downRawY = 0f; var startPX = 0; var startPY = 0
        markerContainer.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downRawX = event.rawX; downRawY = event.rawY; startPX = markerParams.x; startPY = markerParams.y }
                MotionEvent.ACTION_MOVE -> {
                    markerParams.x = startPX + (event.rawX - downRawX).toInt()
                    markerParams.y = startPY + (event.rawY - downRawY).toInt()
                    try { windowManager?.updateViewLayout(markerContainer, markerParams) } catch (e: Exception) {}
                }
            }
            true
        }

        confirmBtn.setOnClickListener {
            val finalX = markerParams.x + markerSize / 2
            val finalY = markerParams.y + markerSize / 2
            removePointMarker()
            onConfirmed(finalX, finalY)
        }

        Toast.makeText(this, "👆 $badgeLabel — işaretçiyi istediğin yere sürükle, sonra \"✓ Onayla\"ya bas", Toast.LENGTH_LONG).show()
    }

    private fun removePointMarker() {
        pointMarkerContainer?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerConfirmBtn?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerContainer = null; pointMarkerParams = null
        pointMarkerConfirmBtn = null; pointMarkerConfirmParams = null
    }

    // ==================== Ekrana dokunarak nokta/renk seçme (tam ekran yakalayıcı — sadece renk örneklemede kullanılıyor) ====================

    private fun armColorPick(region: ActiveRegion) {
        pendingPick = PendingPick.ColorPick(region)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
        Toast.makeText(this, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    private fun armActionPoint(region: ActiveRegion, target: String) {
        val badge = if (target.contains("SWIPE_START")) "1" else if (target.contains("SWIPE_END")) "2" else "👆"
        val initial: Pair<Int, Int>? = when (target) {
            "TAP" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_START" -> if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
            "SWIPE_END" -> if (region.actionX2 != 0 || region.actionY2 != 0) region.actionX2 to region.actionY2 else null
            else -> null
        }
        pickPointWithMarker(badge, initial?.first, initial?.second) { bx, by ->
            applyActionPoint(region, target, bx, by)
        }
    }

    private fun applyActionPoint(region: ActiveRegion, target: String, bx: Int, by: Int) {
        var reopenDialog = true
        when (target) {
            "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
            "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
            "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
            "EXTRA_TAP_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_TAP_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
            }
            "EXTRA_SWIPE_START_SUCCESS" -> {
                if (pendingExtraActionIndex in region.extraActions.indices) {
                    region.extraActions[pendingExtraActionIndex].x = bx; region.extraActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_SUCCESS")
            }
            "EXTRA_SWIPE_END_SUCCESS" -> if (pendingExtraActionIndex in region.extraActions.indices) {
                region.extraActions[pendingExtraActionIndex].x2 = bx; region.extraActions[pendingExtraActionIndex].y2 = by
            }
            "EXTRA_SWIPE_START_FAIL" -> {
                if (pendingExtraActionIndex in region.onFailActions.indices) {
                    region.onFailActions[pendingExtraActionIndex].x = bx; region.onFailActions[pendingExtraActionIndex].y = by
                }
                reopenDialog = false
                armActionPoint(region, "EXTRA_SWIPE_END_FAIL")
            }
            "EXTRA_SWIPE_END_FAIL" -> if (pendingExtraActionIndex in region.onFailActions.indices) {
                region.onFailActions[pendingExtraActionIndex].x2 = bx; region.onFailActions[pendingExtraActionIndex].y2 = by
            }
        }
        if (reopenDialog) openRegionConfigDialog(region)
    }

    private fun showTouchCatcher(onTap: (Int, Int) -> Unit) {
        val catcher = View(this)
        val catcherParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val bx = event.rawX.toInt(); val by = event.rawY.toInt()
                try { windowManager?.removeView(catcher) } catch (e: Exception) {}
                colorPickCatcher = null
                onTap(bx, by)
            }
            true
        }
        colorPickCatcher = catcher
        windowManager?.addView(catcher, catcherParams)
    }

    private fun handlePointCaught(bx: Int, by: Int) {
        val pick = pendingPick ?: return
        pendingPick = null
        val frame = ScreenCaptureService.latestFrame
        when (pick) {
            is PendingPick.ColorPick -> {
                val region = pick.region as ActiveRegion
                val color = frame?.let {
                    if (bx in 0 until it.width && by in 0 until it.height) it.getPixel(bx, by) else Color.BLACK
                } ?: Color.BLACK
                showColorConfirm(region, color, bx, by)
            }
        }
    }

    private fun showColorConfirm(region: ActiveRegion, color: Int, bx: Int, by: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and color)
        val swatch = View(this).apply { setBackgroundColor(color) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@OverlayService).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        overlayDialog()
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = color
                openRegionConfigDialog(region)
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region) }
            .create().showOverlay()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: ActiveRegion) {
        var currentTab = "WHAT" // WHAT (ne aranacak) | DO (ne yapılacak: aksiyon+başarılı) | ADVANCED (bulunamazsa+tekrar)
        val density = resources.displayMetrics.density
        // Araştırma: MacroDroid (10M+ kurulum) "Tetikleyici → Aksiyon → Kısıt" 3 adımlı
        // sihirbaz modeliyle basitliğiyle övülüyor. Bizim eski 5 küçük sekmemiz (aynı anda
        // eşit ağırlıkta GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR) bu kanıtlanmış modelden
        // uzaktı. Şimdi AYNI 3 adım: "Ne Aranacak" (Tetikleyici) → "Ne Yapılacak" (Aksiyon,
        // içinde Başarılı Olunca ek adımları da var) → "Gelişmiş" (Bulunamazsa + Tekrar, ikisi
        // de İSTEĞE BAĞLI olduğu için tek yerde). Hiçbir özellik kaybolmadı, sadece gruplama
        // MacroDroid'in kanıtlanmış zihinsel modeline göre yeniden düzenlendi.
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tabButton(icon: String, label: String) = Button(this).apply {
            text = "$icon\n$label"; textSize = 12f; setPadding(4, (14 * density).toInt(), 4, (14 * density).toInt())
            isAllCaps = false
        }
        val tabWhat = tabButton("🔍", "1. Ne Aranacak")
        val tabDo = tabButton("⚡", "2. Ne Yapılacak")
        val tabAdvanced = tabButton("⚙️", "Gelişmiş")
        listOf(tabWhat, tabDo, tabAdvanced).forEach { tabRow.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabRow) }

        val autoSaveLabel = TextView(this).apply {
            text = "💾 Otomatik kaydediliyor — Kaydet'e basmana gerek yok"; textSize = 11f; setTextColor(Color.parseColor("#4CAF50"))
            setPadding((16 * density).toInt(), (8 * density).toInt(), (16 * density).toInt(), 0)
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * density).toInt(), (16 * density).toInt(), (20 * density).toInt(), 0) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabBar); addView(autoSaveLabel); addView(content) }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("✓ Bitir", null)
            .setNeutralButton("🗑 Sil", null)
            .setNegativeButton("Kapat (kaydeder)", null)
            .create()

        fun autoSave() {
            if (region !in activeRegions) return
            val gateGroupId = region.isGateForGroupId
            if (gateGroupId != null) saveRegionAsGate(region, gateGroupId, silent = true)
            else saveRegionAsRule(region, silent = true)
        }

        fun sectionHeader(text: String) = TextView(this).apply {
            this.text = text; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(ACCENT); setPadding(0, (20 * density).toInt(), 0, (8 * density).toInt())
        }
        fun divider() = View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt()).apply { topMargin = (12 * density).toInt() }
        }

        fun highlight() {
            listOf(tabWhat to "WHAT", tabDo to "DO", tabAdvanced to "ADVANCED").forEach { (b, k) ->
                if (k == currentTab) {
                    b.setTextColor(Color.WHITE)
                    b.setBackgroundColor(ACCENT)
                } else {
                    b.setTextColor(Color.DKGRAY)
                    b.setBackgroundColor(SURFACE_ALT_COLOR)
                }
            }
        }
        fun render() {
            region.onRectChangedListeners.clear()
            region.onRectChangedListeners.add { autoSave() }
            content.removeAllViews()
            when (currentTab) {
                "WHAT" -> buildGeneralTab(region, content, dialog)
                "DO" -> {
                    content.addView(sectionHeader("⚡ Aksiyon — bulununca ne yapılsın?"))
                    buildActionTab(region, content, dialog)
                    content.addView(divider())
                    content.addView(sectionHeader("✅ Ardından sırayla (isteğe bağlı ek adımlar)"))
                    buildExtraTab(region, content, dialog, false)
                }
                "ADVANCED" -> {
                    content.addView(sectionHeader("❌ Bulunamazsa (isteğe bağlı)"))
                    buildExtraTab(region, content, dialog, true)
                    content.addView(divider())
                    content.addView(sectionHeader("🔁 Tekrar / Döngü Davranışı"))
                    buildLoopTab(region, content)
                }
            }
            highlight()
        }
        fun switchTab(tab: String) { autoSave(); currentTab = tab; render() }
        tabWhat.setOnClickListener { switchTab("WHAT") }
        tabDo.setOnClickListener { switchTab("DO") }
        tabAdvanced.setOnClickListener { switchTab("ADVANCED") }

        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.setOnShowListener {
            render()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val parentRegion = region.isMultiDetectionExtraFor
                if (parentRegion != null) {
                    val alt = buildConditionAltFromRegion(region)
                    if (alt != null) {
                        parentRegion.extraConditions.add(alt)
                        dialog.dismiss()
                        removeRegionWindow(region)
                        Toast.makeText(this, "Koşul eklendi (${parentRegion.extraConditions.size + 1} koşul toplam)", Toast.LENGTH_SHORT).show()
                        openRegionConfigDialog(parentRegion)
                    } else {
                        Toast.makeText(this, "Koşulu tamamla (renk/resim/yazı seç)", Toast.LENGTH_LONG).show()
                    }
                    return@setOnClickListener
                }
                val gateGroupId = region.isGateForGroupId
                val saved = if (gateGroupId != null) saveRegionAsGate(region, gateGroupId) else saveRegionAsRule(region)
                if (saved) {
                    dialog.dismiss()
                    removeRegionWindow(region)
                    region.onSavedCallback?.invoke()
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                val scope = region.saveScope
                val gateGroupId2 = region.isGateForGroupId
                if (gateGroupId2 != null) {
                    val group = ActionGroupStorage.load(this).find { it.id == gateGroupId2 }
                    if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
                } else when (scope) {
                    is SaveScope.MainFlow -> region.existingRuleId?.let { RuleStorage.deleteRule(this, it) }
                    is SaveScope.Group -> region.existingRuleId?.let { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, it) }
                    is SaveScope.Function -> region.existingRuleId?.let { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, it) }
                }
                removeRegionWindow(region)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
            }
        }
        dialog.setOnDismissListener {
            // "Kapat" veya geri tuşu/dışarı dokunmayla kapandıysa: veriler ZATEN kayıtlı,
            // sadece alan EKRANDA KALSIN (istersen tekrar dokunup düzenlemeye devam edersin).
            autoSave()
        }
        dialog.show()
    }

    /** Bir alanı Action Group'un KAPI koşulu olarak kaydeder — sadece GENEL sekmesindeki koşul + cooldown kullanılır. */
    private fun saveRegionAsGate(region: ActiveRegion, groupId: String, silent: Boolean = false): Boolean {
        val group = ActionGroupStorage.load(this).find { it.id == groupId } ?: return false
        val r = regionRect(region)
        val gateAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { if (!silent) Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { if (!silent) Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore,
                    textCaseSensitive = region.conditionTextCaseSensitive, textWhitelist = region.conditionTextWhitelist, textBlacklist = region.conditionTextBlacklist)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        group.gate = gateAlt
        group.gateCooldownMs = region.cooldownMs
        ActionGroupStorage.upsert(this, group)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kapı koşulu kaydedildi: ${group.name}", Toast.LENGTH_SHORT).show()
        return true
    }

    /** Bir ActiveRegion'ın GÜNCEL koşul alanlarından (renk/resim/yazı/değişken/custom) bir ConditionAlt üretir. Eksikse null döner. */
    private fun buildConditionAltFromRegion(region: ActiveRegion): ConditionAlt? {
        val r = regionRect(region)
        return when (region.conditionKind) {
            "IMAGE" -> {
                val path = region.conditionTemplatePath ?: return null
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = path, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) return null
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore,
                    textCaseSensitive = region.conditionTextCaseSensitive, textWhitelist = region.conditionTextWhitelist, textBlacklist = region.conditionTextBlacklist)
            }
            "VARIABLE" -> {
                if (region.conditionVariableName.isBlank()) return null
                ConditionAlt("VARIABLE", variableName = region.conditionVariableName, variableOp = region.conditionVariableOp, compareValue = region.conditionCompareValue)
            }
            "CUSTOM" -> {
                if (region.conditionCustomCode.isBlank()) return null
                ConditionAlt("CUSTOM", customCode = region.conditionCustomCode)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
    }

    /** Macrorify'daki "Multi Detection": ana koşula EK bir koşul çizdirir (kendi bölgesinde). */
    private fun startMultiDetectionCondition(parentRegion: ActiveRegion) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.isMultiDetectionExtraFor = parentRegion
        region.label.text = "🔀 Ek Koşul ${parentRegion.extraConditions.size + 2}"
        Toast.makeText(this, "Koşulu ayarla (GENEL sekmesi yeter), sonra ✓ Bitir'e bas", Toast.LENGTH_LONG).show()
    }

    private fun buildGeneralTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Kural adı"; setText(region.name) }
        nameInput.addTextChangedListener(simpleWatcher { region.name = it })
        content.addView(nameInput)

        content.addView(TextView(ctx).apply { text = "Koşul tipi — ekranda ne aranacak / neye bakılacak?"; setPadding(0, 16, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD) })
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbColor = android.widget.RadioButton(ctx).apply { text = "🎨 Renk"; id = 1 }
        val rbImage = android.widget.RadioButton(ctx).apply { text = "🖼️ Resim"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "📝 Yazı (OCR)"; id = 3 }
        // Macrorify "Conditional" — ekran taramasından BAĞIMSIZ mantıksal koşullar:
        val rbVariable = android.widget.RadioButton(ctx).apply { text = "🔢 Değişken (sayaç karşılaştır)"; id = 4 }
        val rbCustom = android.widget.RadioButton(ctx).apply { text = "⚡ Custom (JavaScript ifadesi)"; id = 5 }
        listOf(rbColor, rbImage, rbText, rbVariable, rbCustom).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; "VARIABLE" -> 4; "CUSTOM" -> 5; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    val path = region.conditionTemplatePath
                    if (!path.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(path)
                        if (bmp != null) iv.setImageBitmap(bmp)
                        sub.addView(TextView(ctx).apply { text = "Seçili resim:" })
                        sub.addView(iv)
                    } else {
                        sub.addView(TextView(ctx).apply { text = "Henüz resim seçilmedi — aşağıdan kütüphaneden seç ya da ekrandan kendin kırp." })
                    }
                    val btnLib = Button(ctx).apply { text = "📚 Kütüphaneden Seç" }
                    btnLib.setOnClickListener { pickFromLibrary(region) { renderSub() } }
                    sub.addView(btnLib)
                    val btnCropSelf = Button(ctx).apply { text = "✂️ Ekrandan Kendim Kırpacağım" }
                    btnCropSelf.setOnClickListener {
                        val r2 = regionRect(region)
                        val cropped = ScreenCaptureService.latestFrame?.let { safeCrop(it, r2[0], r2[1], r2[2], r2[3]) }
                        if (cropped == null) {
                            Toast.makeText(ctx, "Kırpılamadı, alan çok küçük olabilir", Toast.LENGTH_SHORT).show()
                        } else {
                            val nameInput = EditText(ctx).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
                            overlayDialog().setTitle("Bu resmi kaydet").setView(nameInput)
                                .setPositiveButton("Kaydet") { _, _ ->
                                    val name = nameInput.text.toString().ifBlank { "İsimsiz görsel" }
                                    val savedPath = TemplateStorage.save(ctx, cropped)
                                    LibraryStorage.add(ctx, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, savedPath))
                                    region.conditionTemplatePath = savedPath
                                    Toast.makeText(ctx, "Kütüphaneye eklendi ve seçildi: $name", Toast.LENGTH_SHORT).show()
                                    renderSub()
                                }
                                .setNegativeButton("Vazgeç", null)
                                .create().showOverlay()
                        }
                    }
                    sub.addView(btnCropSelf)
                    addMinScoreControls(ctx, sub, region)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.addTextChangedListener(simpleWatcher { region.conditionText = it })
                    sub.addView(input)
                    sub.addView(TextView(ctx).apply {
                        text = "Tolerans — OCR net okuyamayabilir, düşük skor daha esnek olur:"
                        textSize = 11f; setPadding(0, 12, 0, 0)
                    })
                    addMinScoreControls(ctx, sub, region)

                    sub.addView(styledField(
                        "WHITELIST", "Sadece BU karakterlere izin ver, gerisini at (örn. sadece sayı bekliyorsan: 0123456789). Boş = kapalı",
                        region.conditionTextWhitelist, keyboardNumeric = false
                    ) { region.conditionTextWhitelist = it })
                    sub.addView(styledField(
                        "BLACKLIST", "BU karakterleri okunan metinden çıkar (örn. 'O' harfi hep '0' okunuyorsa listeye ekle). Boş = kapalı",
                        region.conditionTextBlacklist, keyboardNumeric = false
                    ) { region.conditionTextBlacklist = it })
                    val caseSensitiveCheck = android.widget.CheckBox(ctx).apply {
                        text = "Büyük/Küçük Harf Duyarlı (Case Sensitive)"
                        isChecked = region.conditionTextCaseSensitive
                        setPadding(0, 12, 0, 0)
                    }
                    caseSensitiveCheck.setOnCheckedChangeListener { _, checked -> region.conditionTextCaseSensitive = checked }
                    sub.addView(caseSensitiveCheck)
                }
                "VARIABLE" -> {
                    sub.addView(TextView(ctx).apply {
                        text = "🔢 Değişken Koşulu — bir sayacın değeri bir sayıyla karşılaştırılır. Doğruysa \"Ne Yapılacak\" (On True), yanlışsa \"Bulunamazsa\" (On False) çalışır.\n\nNOT: Bu koşul EKRANI TARAMAZ — bölge/renk/skor gerekmez. Değişkeni script'lerle (setVar) ya da aksiyonlardaki \"Değişken Ayarla\" ile değiştirirsin."
                        textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 8)
                    })
                    sub.addView(styledField(
                        "DEĞİŞKEN ADI", "Karşılaştırılacak sayacın adı (örn. tur, can, altin)",
                        region.conditionVariableName, keyboardNumeric = false
                    ) { region.conditionVariableName = it })

                    sub.addView(TextView(ctx).apply { text = "OPERATÖR"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 12, 0, 4) })
                    val ops = listOf(">=", "<=", "==", "!=", ">", "<")
                    val opLabels = listOf("≥ büyük/eşit", "≤ küçük/eşit", "= eşit", "≠ eşit değil", "> büyük", "< küçük")
                    val opRow1 = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.HORIZONTAL }
                    ops.forEachIndexed { i, op ->
                        val rb = android.widget.RadioButton(ctx).apply { text = opLabels[i]; id = i + 1; textSize = 12f }
                        if (region.conditionVariableOp == op) rb.isChecked = true
                        opRow1.addView(rb)
                    }
                    opRow1.setOnCheckedChangeListener { _, checkedId -> region.conditionVariableOp = ops[checkedId - 1] }
                    val opScroll = android.widget.HorizontalScrollView(ctx).apply { addView(opRow1); isHorizontalScrollBarEnabled = false }
                    sub.addView(opScroll)

                    sub.addView(styledField(
                        "KARŞILAŞTIRILACAK DEĞER", "Değişken bu sayıyla karşılaştırılır",
                        region.conditionCompareValue.toString()
                    ) { region.conditionCompareValue = it.toIntOrNull() ?: 0 })
                }
                "CUSTOM" -> {
                    sub.addView(TextView(ctx).apply {
                        text = "⚡ Custom Koşul — true/false dönen bir JavaScript ifadesi. Doğruysa \"Ne Yapılacak\" (On True), yanlışsa \"Bulunamazsa\" (On False) çalışır.\n\nÖrnekler:\n  getVar(\"can\") < 30\n  getVar(\"tur\") % 2 == 0\n  findColor(100,200,4,4,\"#FF0000\",0.9)\n\nNOT: Script köprü fonksiyonlarının tamamını kullanabilirsin (Kod menüsündeki ile aynı)."
                        textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 8)
                    })
                    val codeInput = EditText(ctx).apply {
                        setText(region.conditionCustomCode)
                        hint = "örn. getVar(\"can\") < 30"
                        typeface = android.graphics.Typeface.MONOSPACE
                        textSize = 13f
                        isSingleLine = false
                        minLines = 2
                        maxLines = 6
                        setBackgroundColor(SURFACE_ALT_COLOR)
                        setPadding(16, 12, 16, 12)
                    }
                    codeInput.addTextChangedListener(simpleWatcher { region.conditionCustomCode = it })
                    sub.addView(codeInput)
                }
                else -> {
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply { text = String.format(" #%06X", 0xFFFFFF and region.conditionColor) })
                    sub.addView(row)
                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armColorPick(region) }
                    sub.addView(btnPick)
                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.addTextChangedListener(simpleWatcher { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) { region.conditionColor = parsed; swatch.setBackgroundColor(parsed) }
                    })
                    sub.addView(hexInput)
                    addMinScoreControls(ctx, sub, region)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; 4 -> "VARIABLE"; 5 -> "CUSTOM"; else -> "COLOR" }
            renderSub()
            applyFindRegionVisibility()
        }

        // ---- Bekleme süresi (cooldown) + Eşleşme sonrası Delay ----
        content.addView(TextView(ctx).apply {
            text = "ZAMANLAMA"; setPadding(0, 24, 0, 0); setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(TEXT_PRIMARY); textSize = 13f
        })
        content.addView(styledField(
            "BEKLEME SÜRESİ / WAIT NEXT (ms)", "Tetiklendikten sonra tekrar tetiklenmeden önce en az ne kadar beklesin",
            region.cooldownMs.toString(),
            hintTitle = "Wait Next", hintBody = hintText(
                "Wait Next: " to "Bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmesi gerektiğini belirler. Spam/gereksiz tekrarı önler."
            )
        ) { region.cooldownMs = it.toLongOrNull() ?: 300 })
        content.addView(styledField(
            "DELAY (ms)", "Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre",
            region.matchDelayMs.toString(),
            hintTitle = "Delay", hintBody = hintText(
                "Delay: " to "Bu aksiyonun çalıştırılmasını geciktirir (milisaniye). Eşleşme bulunur bulunmaz değil, biraz bekleyip sonra tetiklenmesini istediğinde kullan."
            )
        ) { region.matchDelayMs = it.toLongOrNull() ?: 0 })
        content.addView(styledField(
            "TARAMA SÜRESİ / TIMEOUT (ms)", "Aksiyonu tetiklemeden önce EN AZ bu kadar süre KESİNTİSİZ eşleşmeli (yanlış pozitifleri eler). 0 = anında tetikle",
            region.scanTimeoutMs.toString(),
            hintTitle = "Timeout", hintBody = hintText(
                "Timeout: " to "Bulma işleminin milisaniye cinsinden zaman aşımı. BigBoss'ta bunu 'sürekli doğru kalma' olarak kullanıyoruz: eşleşme, aksiyonu tetiklemeden önce en az bu kadar süre KESİNTİSİZ ekranda kalmalı — kısa titreşim/animasyonların yanlış pozitif üretmesini önler. 0 = anında tetikle."
            )
        ) { region.scanTimeoutMs = it.toLongOrNull()?.coerceAtLeast(0) ?: 0 })
        content.addView(styledField(
            "RASTGELE ŞANS (%)", "Eşleşme bulunsa bile sadece bu yüzdelik ihtimalle tetiklenir. 100 = her zaman (kapalı)",
            region.randomChancePercent.toString()
        ) { region.randomChancePercent = it.toIntOrNull()?.coerceIn(0, 100) ?: 100 })
        content.addView(styledField(
            "TARAMA HIZI / SCAN RATE (saniyede kaç kez)", "Bu alan saniyede en fazla kaç kere kontrol edilsin — pil tasarrufu. 0 = sınırsız/en hızlı",
            region.scanRateHz.toString(), keyboardNumeric = false,
            hintTitle = "Scan Rate", hintBody = hintText(
                "Scan Rate: " to "Saniyede kaç bulma işlemi yapılacağını belirler. Büyük bir sayı girersen uygulama olabildiğince hızlı tarar. 1'den küçük bir sayı girersen yavaşlatırsın — örneğin 0.5, saniyede yarım tarama (2 saniyede 1 tarama) demektir. 0 = sınırsız/en hızlı."
            )
        ) { region.scanRateHz = it.toFloatOrNull()?.coerceAtLeast(0f) ?: 0f })
        content.addView(styledField(
            "OTOMATİK DURDURMA (art arda kaç kez bulunamayınca)", "Bu alan art arda bu kadar kez bulunamazsa kendini devre dışı bırakır. 0 = sınırsız, hiç durmaz",
            region.maxConsecutiveFailures.toString()
        ) { region.maxConsecutiveFailures = it.toIntOrNull()?.coerceAtLeast(0) ?: 0 })

        val disableCheck = android.widget.CheckBox(ctx).apply {
            text = "Devre Dışı Bırak (bu alan hiç çalışmasın)"
            isChecked = !region.enabled
            setTextColor(TEXT_PRIMARY)
            setPadding(0, 20, 0, 0)
        }
        disableCheck.setOnCheckedChangeListener { _, checked -> region.enabled = !checked }
        content.addView(disableCheck)

        // ---- 🔀 Multi Detection: bu koşula EK koşullar ekleyip mantıkla (VE/VEYA/vb) birleştirme ----
        if (region.isMultiDetectionExtraFor == null) {
            content.addView(TextView(ctx).apply {
                text = "🔀 Multi Detection (İsteğe Bağlı — Ek Koşullar)"
                textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ACCENT); setPadding(0, 20, 0, 8)
            })
            if (region.extraConditions.isNotEmpty()) {
                region.extraConditions.forEachIndexed { idx, alt ->
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val kindIcon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
                    row.addView(TextView(ctx).apply {
                        text = "$kindIcon Koşul ${idx + 2} — (${alt.x},${alt.y},${alt.width},${alt.height})"
                        setTextColor(TEXT_PRIMARY); textSize = 12f
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                    btnRemove.setOnClickListener { region.extraConditions.removeAt(idx); dialog.dismiss(); openRegionConfigDialog(region) }
                    row.addView(btnRemove)
                    content.addView(row)
                }
            }
            val btnAddCondition = Button(ctx).apply { text = "➕ Ek Koşul Ekle (başka bölgede)" }
            btnAddCondition.setOnClickListener { dialog.dismiss(); startMultiDetectionCondition(region) }
            content.addView(btnAddCondition)

            if (region.extraConditions.isNotEmpty()) {
                content.addView(TextView(ctx).apply {
                    text = "Mantık — bu koşul VE ek koşullar nasıl birleşsin:"
                    textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 12, 0, 4)
                })
                val logicOptions = listOf(
                    "ONE_SUCCESS" to "VEYA — biri doğruysa yeter",
                    "ALL_SUCCESS" to "VE — hepsi doğru olmalı",
                    "ALL_FAIL" to "Hepsi Yanlış — hiçbiri bulunmamalı",
                    "ONE_FAIL" to "Biri Yanlış — en az biri bulunmamalı",
                    "ALWAYS_SUCCESS" to "Her Zaman Doğru (bu grup dış sonucu etkilemesin)",
                    "ALWAYS_FAIL" to "Her Zaman Yanlış (bu grup dış sonucu etkilemesin)"
                )
                val logicRadio = android.widget.RadioGroup(ctx)
                logicOptions.forEachIndexed { i, (key, label) ->
                    val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1; setTextColor(TEXT_PRIMARY) }
                    if (region.conditionsLogic == key) logicRadio.check(i + 1)
                    logicRadio.addView(rb)
                }
                logicRadio.setOnCheckedChangeListener { _, checkedId -> region.conditionsLogic = logicOptions[checkedId - 1].first }
                content.addView(logicRadio)
            }
        }

        // ---- Find Region: X/Y/Genişlik/Yükseklik — değiştirince alan EKRANDA da taşınır/boyutlanır ----
        // VARIABLE/CUSTOM koşulları ekranı taramadığı için bu bölüm onlarda GİZLENİR (bölge anlamsız).
        val findRegionSection = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(findRegionSection)
        findRegionSection.addView(TextView(ctx).apply {
            text = "Find Region (alanın ekrandaki konumu)"; setPadding(0, 20, 0, 4); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        val r = regionRect(region)
        val etX = EditText(ctx).apply { hint = "X"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[0].toString()) }
        val etY = EditText(ctx).apply { hint = "Y"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[1].toString()) }
        val etW = EditText(ctx).apply { hint = "Genişlik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[2].toString()) }
        val etH = EditText(ctx).apply { hint = "Yükseklik"; inputType = InputType.TYPE_CLASS_NUMBER; setText(r[3].toString()) }
        val findRegionRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etX, etY).forEach { findRegionRow1.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val findRegionRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(etW, etH).forEach { findRegionRow2.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        findRegionSection.addView(findRegionRow1)
        findRegionSection.addView(findRegionRow2)

        var suppressFindRegionSync = false
        fun applyFindRegionToScreen() {
            if (suppressFindRegionSync) return
            val x = etX.text.toString().toIntOrNull() ?: return
            val y = etY.text.toString().toIntOrNull() ?: return
            val w = etW.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            val h = etH.text.toString().toIntOrNull()?.coerceAtLeast(4) ?: return
            moveAndResizeRegion(region, x, y, w, h)
        }
        listOf(etX, etY, etW, etH).forEach { it.addTextChangedListener(simpleWatcher { applyFindRegionToScreen() }) }
        region.onRectChangedListeners.add {
            suppressFindRegionSync = true
            val r2 = regionRect(region)
            etX.setText(r2[0].toString()); etY.setText(r2[1].toString())
            etW.setText(r2[2].toString()); etH.setText(r2[3].toString())
            suppressFindRegionSync = false
        }

        // VARIABLE/CUSTOM seçiliyse: Find Region'ı gizle VE ekrandaki bölge kutusunu da gizle
        // (bu koşullar ekranı taramaz, bölgeyle işleri yoktur). Diğer tiplerde geri göster.
        applyFindRegionVisibility = {
            val screenless = region.conditionKind == "VARIABLE" || region.conditionKind == "CUSTOM"
            findRegionSection.visibility = if (screenless) View.GONE else View.VISIBLE
            region.container.visibility = if (screenless) View.GONE else View.VISIBLE
            region.label.visibility = if (screenless) View.GONE else View.VISIBLE
        }
        applyFindRegionVisibility()
    }

    /** buildGeneralTab içinde koşul tipi değişince Find Region + ekran kutusunu göster/gizle (VARIABLE/CUSTOM için gizli). */
    private var applyFindRegionVisibility: () -> Unit = {}

    private fun addMinScoreControls(ctx: android.content.Context, sub: LinearLayout, region: ActiveRegion) {
        val density = resources.displayMetrics.density
        val label = TextView(ctx).apply {
            text = "MIN SKOR (%)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, (14 * density).toInt(), 0, 0)
        }
        var suppress = false
        val numberInput = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(region.minScore.toString())
            textSize = 15f; setTextColor(TEXT_PRIMARY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        val seek = SeekBar(ctx).apply {
            max = 100; progress = region.minScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    region.minScore = v
                    if (fromUser) { suppress = true; numberInput.setText(v.toString()); suppress = false }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        numberInput.addTextChangedListener(simpleWatcher { text ->
            if (suppress) return@simpleWatcher
            val v = text.toIntOrNull()?.coerceIn(0, 100) ?: return@simpleWatcher
            region.minScore = v; seek.progress = v
        })
        sub.addView(label); sub.addView(numberInput); sub.addView(seek)
    }

    private fun pickFromLibrary(region: ActiveRegion, onDone: () -> Unit) {
        val items = LibraryStorage.load(this)
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        overlayDialog()
            .setTitle("Seç")
            .setItems(labels) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") { region.conditionKind = "IMAGE"; region.conditionTemplatePath = item.templatePath }
                else { region.conditionKind = "COLOR"; region.conditionColor = item.color }
                onDone()
            }
            .create().showOverlay()
    }

    private fun buildActionTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbTap = android.widget.RadioButton(ctx).apply { text = "👆 Dokunma"; id = 1 }
        val rbSwipe = android.widget.RadioButton(ctx).apply { text = "👉 Kaydırma"; id = 2 }
        val rbFunc = android.widget.RadioButton(ctx).apply { text = "🔧 Fonksiyon Çağır"; id = 3 }
        val rbSystem = android.widget.RadioButton(ctx).apply { text = "🔙 Sistem (Geri/Ana Ekran/vb)"; id = 4 }
        listOf(rbTap, rbSwipe, rbFunc, rbSystem).forEach { radioGroup.addView(it) }
        radioGroup.check(when { region.actionType == "SWIPE" -> 2; region.actionType == "CALL_FUNCTION" -> 3; region.actionType.startsWith("SYSTEM_") -> 4; else -> 1 })
        content.addView(radioGroup)
        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        // "Randomize" — Dokunma/Kaydırma noktalarına küçük rastgele sapma (daha insani, tespit-karşıtı).
        // Artık bir değişkene de bağlanabilir (Macrorify: "her input alanında değişken").
        addHoldOrDelayField(ctx, content, "🎲 Rastgele Sapma (px) — her noktaya ± bu kadar rastgele kaydırma (0 = kapalı):",
            region.randomOffsetPx.toLong(), region.randomOffsetVarName,
            { region.randomOffsetPx = it.toInt().coerceAtLeast(0) }, { region.randomOffsetVarName = it })

        fun renderSub() {
            sub.removeAllViews()
            when (region.actionType) {
                "SWIPE" -> {
                    sub.addView(TextView(ctx).apply { text = "Başlangıç: (${region.actionX}, ${region.actionY})" })
                    val btnStart = Button(ctx).apply { text = "📍 Başlangıç Noktasını Seç" }
                    btnStart.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_START") }
                    sub.addView(btnStart)
                    sub.addView(TextView(ctx).apply { text = "Bitiş: (${region.actionX2}, ${region.actionY2})" })
                    val btnEnd = Button(ctx).apply { text = "📍 Bitiş Noktasını Seç" }
                    btnEnd.setOnClickListener { dialog.dismiss(); armActionPoint(region, "SWIPE_END") }
                    sub.addView(btnEnd)

                    // ---- Swipe Path: Başlangıç/Bitiş dışında EK ara noktalar (Macrorify'daki "Swipe Point"ler) ----
                    if (region.swipeExtraPoints.isNotEmpty()) {
                        sub.addView(TextView(ctx).apply {
                            text = "Ara noktalar (sırayla, Başlangıç → bunlar → Bitiş):"
                            textSize = 11f; setPadding(0, 16, 0, 4)
                        })
                        region.swipeExtraPoints.forEachIndexed { idx, pt ->
                            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                            row.addView(TextView(ctx).apply {
                                text = "${idx + 3}. (${pt.x}, ${pt.y}) — hold ${pt.holdMs}ms"
                                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                            })
                            val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                            btnRemove.setOnClickListener { region.swipeExtraPoints.removeAt(idx); renderSub() }
                            row.addView(btnRemove)
                            sub.addView(row)
                        }
                    }
                    val btnAddPoint = Button(ctx).apply { text = "➕ Ara Nokta Ekle" }
                    btnAddPoint.setOnClickListener {
                        dialog.dismiss()
                        val pointNum = (region.swipeExtraPoints.size + 3).toString()
                        pickPointWithMarker(pointNum, null, null) { x, y ->
                            promptTapHold { hold ->
                                region.swipeExtraPoints.add(com.bigboss.app.storage.SwipePointData(x, y, hold))
                                openRegionConfigDialog(region)
                            }
                        }
                    }
                    sub.addView(btnAddPoint)

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD (başlangıç) — hareket etmeden önce kaç ms basılı beklesin (sürükle-bırak için):",
                        region.swipeHoldStartMs, region.swipeHoldStartVarName,
                        { region.swipeHoldStartMs = it }, { region.swipeHoldStartVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD (bitiş) — vardıktan sonra parmağı kaldırmadan önce kaç ms daha beklesin:",
                        region.swipeHoldEndMs, region.swipeHoldEndVarName,
                        { region.swipeHoldEndMs = it }, { region.swipeHoldEndVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ DELAY — kaydırma tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:",
                        region.actionPostDelayMs, region.actionPostDelayVarName,
                        { region.actionPostDelayMs = it }, { region.actionPostDelayVarName = it })
                }
                "CALL_FUNCTION" -> {
                    sub.addView(TextView(ctx).apply { text = if (region.callFunctionName.isNotBlank()) "Seçili: f{} ${region.callFunctionName}" else "Henüz seçilmedi" })
                    val btnPick = Button(ctx).apply { text = "🔧 Fonksiyon Seç/Oluştur" }
                    btnPick.setOnClickListener { pickOrCreateFunction(region) { renderSub() } }
                    sub.addView(btnPick)
                    val repeatInput = EditText(ctx).apply {
                        hint = "Kaç kere çalışsın"; inputType = InputType.TYPE_CLASS_NUMBER
                        setText(region.callFunctionRepeat.toString())
                    }
                    repeatInput.addTextChangedListener(simpleWatcher { region.callFunctionRepeat = it.toIntOrNull() ?: 1 })
                    sub.addView(repeatInput)
                }
                "SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS" -> {
                    sub.addView(TextView(ctx).apply { text = "Hangi sistem aksiyonu çalışsın?"; setPadding(0, 8, 0, 8) })
                    val sysRadio = android.widget.RadioGroup(ctx)
                    val opts = listOf(
                        "SYSTEM_BACK" to "🔙 Geri Tuşu",
                        "SYSTEM_HOME" to "🏠 Ana Ekran",
                        "SYSTEM_RECENTS" to "🗂️ Son Uygulamalar",
                        "SYSTEM_NOTIFICATIONS" to "🔔 Bildirim Paneli",
                        "SYSTEM_QUICK_SETTINGS" to "⚡ Hızlı Ayarlar"
                    )
                    opts.forEachIndexed { i, (type, label) ->
                        val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1 }
                        if (region.actionType == type) sysRadio.check(i + 1)
                        sysRadio.addView(rb)
                    }
                    sysRadio.setOnCheckedChangeListener { _, checkedId -> region.actionType = opts[checkedId - 1].first }
                    sub.addView(sysRadio)
                }
                else -> {
                    val matchRadio = android.widget.RadioGroup(ctx)
                    val rbFixed = android.widget.RadioButton(ctx).apply { text = "📍 Sabit Nokta"; id = 1 }
                    val rbMatch = android.widget.RadioButton(ctx).apply { text = "🎯 Eşleşen Noktaya Tıkla"; id = 2 }
                    listOf(rbFixed, rbMatch).forEach { matchRadio.addView(it) }
                    matchRadio.check(if (region.tapAtMatchLocation) 2 else 1)
                    sub.addView(matchRadio)

                    val pointInfo = TextView(ctx).apply {
                        text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                    }
                    sub.addView(pointInfo)
                    val btnPick = Button(ctx).apply {
                        text = "📍 Dokunulacak Noktayı Seç"
                        visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }
                    btnPick.setOnClickListener { dialog.dismiss(); armActionPoint(region, "TAP") }
                    sub.addView(btnPick)
                    matchRadio.setOnCheckedChangeListener { _, checkedId ->
                        region.tapAtMatchLocation = checkedId == 2
                        pointInfo.text = if (region.tapAtMatchLocation) "Renk/resmin BULUNDUĞU noktaya otomatik tıklanır"
                        else "Nokta: (${region.actionX}, ${region.actionY})"
                        btnPick.visibility = if (region.tapAtMatchLocation) View.GONE else View.VISIBLE
                    }

                    addHoldOrDelayField(ctx, sub, "🔁 Tekrar sayısı (kaç kere tıklansın):",
                        region.actionRepeatCount.toLong(), region.actionRepeatVarName,
                        { region.actionRepeatCount = it.toInt().coerceAtLeast(1) }, { region.actionRepeatVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ HOLD — noktada kaç ms basılı tutulsun (uzun basış için artır):",
                        region.actionHoldMs, region.actionHoldVarName,
                        { region.actionHoldMs = it }, { region.actionHoldVarName = it })

                    addHoldOrDelayField(ctx, sub, "⏱️ DELAY — bu işlem tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:",
                        region.actionPostDelayMs, region.actionPostDelayVarName,
                        { region.actionPostDelayMs = it }, { region.actionPostDelayVarName = it })
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.actionType = when (checkedId) {
                2 -> "SWIPE"
                3 -> "CALL_FUNCTION"
                4 -> if (region.actionType.startsWith("SYSTEM_")) region.actionType else "SYSTEM_BACK"
                else -> "TAP"
            }
            renderSub()
        }
    }

    private fun pickOrCreateFunction(region: ActiveRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        overlayDialog().setItems(options.toTypedArray()) { _, index ->
            if (index == 0) {
                val input = EditText(this).apply { hint = "Fonksiyon adı" }
                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                    .setPositiveButton("Oluştur") { _, _ ->
                        val name = input.text.toString().ifBlank { "fonksiyon" }
                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                        FunctionStorage.upsert(this, fn)
                        region.callFunctionId = fn.id; region.callFunctionName = fn.name
                        onDone()
                    }.create().showOverlay()
            } else if (index <= functions.size) {
                val fn = functions[index - 1]
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            } else {
                val group = groups[index - 1 - functions.size]
                region.callFunctionId = group.id; region.callFunctionName = "📦 ${group.name}"
                onDone()
            }
        }.create().showOverlay()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki bir dokunma/kaydırma adımının HOLD süresini düzenler. */
    private fun showHoldEditDialog(extra: ExtraAction, onDone: () -> Unit) {
        val ctx = this
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        if (extra.type == "TAP") {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD — noktada kaç ms basılı tutulsun:" })
            val input = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.holdMs.toString()) }
            container.addView(input)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süresi").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.holdMs = input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        } else {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (başlangıç) — hareket etmeden önce kaç ms beklesin:" })
            val startInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldStartMs.toString()) }
            container.addView(startInput)
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (bitiş) — vardıktan sonra kaç ms daha beklesin:"; setPadding(0, 16, 0, 0) })
            val endInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldEndMs.toString()) }
            container.addView(endInput)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süreleri").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.swipeHoldStartMs = startInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.swipeHoldEndMs = endInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        }
    }

    /** BAŞARILI OLUNCA / BULUNAMAZSA listeleri için tek kullanımlık kopyala/kes panosu. */
    /**
     * "🔍 Tarama Alanı Ekle" (BAŞARILI/BULUNAMAZSA listesinde): ekrana koşullu bir
     * alan çizdirir, otomatik bir Fonksiyona kaydeder, sonra o Fonksiyonu çağıran
     * bir "🔧 Fonksiyon Çağır" adımını listeye ekler — böylece sıra içinde
     * GERÇEK bir koşullu tespit (iç içe tarama) yapılabilir.
     */
    private fun startExtraTabScan(callerRegion: ActiveRegion, list: MutableList<ExtraAction>, label: String) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val fnName = "🔍 ${callerRegion.name.ifBlank { "Tarama" }} → $label"
        val fn = FunctionDefinition(UUID.randomUUID().toString(), fnName)
        FunctionStorage.upsert(this, fn)
        val scanRegion = addRegionWindow()
        scanRegion.saveScope = SaveScope.Function(fn.id)
        scanRegion.label.text = "🔍 $label → yeni tarama"
        scanRegion.onSavedCallback = {
            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
            com.bigboss.app.storage.EngineAssembler.refresh(this)
            Toast.makeText(this, "Tarama eklendi: ${fn.name}", Toast.LENGTH_SHORT).show()
            openRegionConfigDialog(callerRegion)
        }
        Toast.makeText(this, "Bu alan \"$label\" listesine bir TARAMA (koşullu tespit) olarak eklenecek", Toast.LENGTH_LONG).show()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki dokunma/kaydırma noktalarını VE tarama alanlarını ekranda gösterir (Çalışma Alanı ile aynı mekanizma). */
    private fun showExtraListOnScreen(list: List<ExtraAction>, label: String) {
        clearWorkspace()
        var count = 0
        list.forEachIndexed { i, extra ->
            when (extra.type) {
                "TAP" -> { addWorkspacePointDot(extra.x, extra.y, "👆${i + 1}"); count++ }
                "SWIPE" -> {
                    addWorkspacePointDot(extra.x, extra.y, "1️⃣${i + 1}")
                    addWorkspacePointDot(extra.x2, extra.y2, "2️⃣${i + 1}")
                    count++
                }
                "CALL_FUNCTION" -> {
                    val fnRules = FunctionStorage.load(this).find { it.id == extra.functionId }?.rules
                        ?: ActionGroupStorage.load(this).find { it.id == extra.functionId }?.rules
                    fnRules?.filter { !it.id.endsWith("-fail") && it.alternatives.isNotEmpty() }?.forEach { r ->
                        addWorkspaceBox(r, SaveScope.Function(extra.functionId ?: ""))
                        count++
                    }
                }
            }
        }
        if (count == 0) Toast.makeText(this, "$label listesinde gösterilecek nokta/alan yok", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "$label listesi ekranda gösteriliyor ($count öğe) — 🗺️ Çalışma Alanı'ndan kapatabilirsin", Toast.LENGTH_LONG).show()
    }

    /** Salt-okunur, küçük bir NOKTA işaretçisi (TAP/SWIPE noktalarını göstermek için) — Çalışma Alanı mekanizmasını paylaşır. */
    private fun addWorkspacePointDot(px: Int, py: Int, labelText: String, onTap: (() -> Unit)? = null) {
        val density = resources.displayMetrics.density
        val dotSize = (18 * density).toInt()
        val dot = View(this).apply { background = borderDrawable(Color.parseColor("#FFEB3B"), 4f) }
        val dotFlags = if (onTap != null) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val dotParams = WindowManager.LayoutParams(
            dotSize, dotSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            dotFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px - dotSize / 2; y = py - dotSize / 2 }
        if (onTap != null) {
            dot.setOnTouchListener { _, event -> if (event.action == MotionEvent.ACTION_DOWN) onTap(); true }
        }
        val label = TextView(this).apply {
            text = labelText
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#DDFFEB3B"))
            textSize = 10f
            setPadding(6, 1, 6, 1)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px - dotSize / 2; y = (py - dotSize / 2 - 24 * density).toInt().coerceAtLeast(0) }
        try {
            windowManager?.addView(dot, dotParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(dot, label, dotParams, labelParams))
        } catch (e: Exception) {
            android.util.Log.e("BigBossWorkspace", "Nokta eklenemedi: $labelText", e)
            Toast.makeText(this, "⚠️ '$labelText' gösterilemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private var extraActionClipboard: ExtraAction? = null

    private fun buildExtraTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog, isFail: Boolean) {
        val ctx = this
        val list = if (isFail) region.onFailActions else region.extraActions
        val suffix = if (isFail) "FAIL" else "SUCCESS"
        val listLabel = if (isFail) "Bulunamazsa" else "Başarılı"
        content.addView(TextView(ctx).apply {
            text = if (isFail) "Bu alan BULUNAMAZSA sırayla yapılacaklar:" else "Birincil aksiyondan SONRA sırayla yapılacaklar:"
            textSize = 12f
        })
        val btnShowOnScreen = Button(ctx).apply { text = "🗺️ Bu Listenin Nokta/Alanlarını Ekranda Göster" }
        btnShowOnScreen.setOnClickListener { showExtraListOnScreen(list, listLabel) }
        content.addView(btnShowOnScreen)

        val selectedIndices = mutableSetOf<Int>()
        val inflater = android.view.LayoutInflater.from(ctx)
        val listView = android.widget.ListView(ctx)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val extra = list[position]
                val (icon, desc) = when (extra.type) {
                    "CALL_FUNCTION" -> "🔧" to "f{} ${extra.functionName} x${extra.repeat}"
                    "SWIPE" -> "👉" to "(${extra.x},${extra.y})→(${extra.x2},${extra.y2})"
                    "WAIT" -> "⏱️" to "Bekle ${extra.waitMs}ms"
                    "SET_VARIABLE" -> "(x)" to "${extra.variableName} += ${extra.variableDelta}"
                    "RUN_SCRIPT" -> "🖥️" to extra.scriptName
                    "SYSTEM_BACK" -> "🔙" to "Geri Tuşu"
                    "SYSTEM_HOME" -> "🏠" to "Ana Ekran"
                    "SYSTEM_RECENTS" -> "🗂️" to "Son Uygulamalar"
                    "SYSTEM_NOTIFICATIONS" -> "🔔" to "Bildirim Paneli"
                    "SYSTEM_QUICK_SETTINGS" -> "⚡" to "Hızlı Ayarlar"
                    "READ_TEXT" -> "📖" to "${extra.variableName} = oku(${extra.x},${extra.y},${extra.x2},${extra.y2})"
                    else -> "👆" to "(${extra.x},${extra.y})"
                }
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "${position + 1}. $desc"
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = if (extra.holdMs != 50L || extra.postDelayMs > 0) "⏱️" else ""
                view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                return view
            }
        }
        listView.adapter = adapter
        styleListDividers(listView)
        listView.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.28).toInt()
        )
        // Kısa dokunuş: dokunma/kaydırma ise HOLD/DELAY düzenlemesini doğrudan açar.
        listView.setOnItemClickListener { _, _, position, _ ->
            val extra = list[position]
            if (extra.type == "TAP" || extra.type == "SWIPE") showHoldEditDialog(extra) { adapter.notifyDataSetChanged() }
            else Toast.makeText(ctx, "Bu adım türü için ek ayar yok — silmek/taşımak için basılı tut", Toast.LENGTH_SHORT).show()
        }
        // Basılı tutma: çoklu seçime ekler/çıkarır (toplu işlemler için).
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
            adapter.notifyDataSetChanged()
            true
        }
        content.addView(listView)
        content.addView(TextView(ctx).apply {
            text = "Dokun = ayarları aç · Basılı tut = çoklu seç (toplu işlem için)"
            textSize = 10f; setTextColor(Color.GRAY); setPadding(16, 4, 16, 8)
        })

        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply { text = label; textSize = 14f; setOnClickListener { onClick() } }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val toolbarRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val toolbarRow2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        content.addView(toolbarRow1); content.addView(toolbarRow2)

        fun openAddMenu() {
            overlayDialog().setItems(arrayOf(
                "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                "👆 Dokunma Ekle", "👉 Kaydırma Ekle", "⏱️ Bekleme Ekle",
                "🔧 Fonksiyon Çağırma Ekle", "(x) Değişken Ayarla Ekle", "🖥️ Kod Çalıştır Ekle",
                "🔙 Sistem Aksiyonu Ekle (Geri/Ana Ekran/vb)",
                "📖 Metni Değişkene Oku (OCR ile oku, değişkene yaz)"
            )) { _, indexRaw ->
                if (indexRaw == 8) {
                    // 📖 Metni Değişkene Oku: bir bölge çizdirip okunan metni bir değişkene yazar.
                    dialog.dismiss()
                    startTextReadRegion(list)
                    return@setItems
                }
                val index = indexRaw - 1
                if (indexRaw == 0) {
                    // 🔍 Tarama Alanı: ekrana bir alan çizdirip, otomatik bir Fonksiyona kaydedip listeye "Fonksiyon Çağır" olarak ekler.
                    dialog.dismiss()
                    startExtraTabScan(region, list, if (isFail) "bulunamazsa" else "başarılı")
                    return@setItems
                }
                when (index) {
                    0 -> {
                        list.add(ExtraAction("TAP"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_TAP_$suffix")
                    }
                    1 -> {
                        list.add(ExtraAction("SWIPE"))
                        pendingExtraActionIndex = list.size - 1
                        dialog.dismiss()
                        armActionPoint(region, "EXTRA_SWIPE_START_$suffix")
                    }
                    2 -> {
                        val input = EditText(ctx).apply { hint = "Bekleme (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("500") }
                        overlayDialog().setTitle("Bekleme Süresi").setView(input)
                            .setPositiveButton("Ekle") { _, _ ->
                                list.add(ExtraAction("WAIT", waitMs = input.text.toString().toLongOrNull() ?: 500))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                    }
                    3 -> {
                        val functions = FunctionStorage.load(ctx)
                        val groups = ActionGroupStorage.load(ctx)
                        val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                        opts.addAll(functions.map { "f{} ${it.name}" })
                        opts.addAll(groups.map { "📦 ${it.name}" })
                        overlayDialog().setItems(opts.toTypedArray()) { _, idx2 ->
                            if (idx2 == 0) {
                                val input = EditText(ctx).apply { hint = "Fonksiyon adı" }
                                overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
                                    .setPositiveButton("Oluştur") { _, _ ->
                                        val name = input.text.toString().ifBlank { "fonksiyon" }
                                        val fn = FunctionDefinition(UUID.randomUUID().toString(), name)
                                        FunctionStorage.upsert(ctx, fn)
                                        list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                        adapter.notifyDataSetChanged()
                                    }.create().showOverlay()
                            } else if (idx2 <= functions.size) {
                                val fn = functions[idx2 - 1]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                                adapter.notifyDataSetChanged()
                            } else {
                                val group = groups[idx2 - 1 - functions.size]
                                list.add(ExtraAction("CALL_FUNCTION", functionId = group.id, functionName = "📦 ${group.name}"))
                                adapter.notifyDataSetChanged()
                            }
                        }.create().showOverlay()
                    }
                    4 -> {
                        val nameInput = EditText(ctx).apply { hint = "Değişken/sayaç adı" }
                        val deltaInput = EditText(ctx).apply { hint = "Ne kadar artırılsın (örn. 1, -1)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("1") }
                        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; addView(nameInput); addView(deltaInput) }
                        overlayDialog().setTitle("Değişken Ayarla").setView(box)
                            .setPositiveButton("Ekle") { _, _ ->
                                val vname = nameInput.text.toString().ifBlank { "sayac" }
                                val delta = deltaInput.text.toString().toIntOrNull() ?: 1
                                list.add(ExtraAction("SET_VARIABLE", variableName = vname, variableDelta = delta))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                    }
                    5 -> {
                        val scripts = com.bigboss.app.storage.ScriptStorage.load(ctx)
                        if (scripts.isEmpty()) {
                            Toast.makeText(ctx, "Henüz script yok — önce 🖥️ Kod menüsünden oluştur", Toast.LENGTH_LONG).show()
                        } else {
                            val labels = scripts.map { "🖥️ ${it.name}" }.toTypedArray()
                            overlayDialog().setItems(labels) { _, sIdx ->
                                val s = scripts[sIdx]
                                list.add(ExtraAction("RUN_SCRIPT", scriptId = s.id, scriptName = s.name))
                                adapter.notifyDataSetChanged()
                            }.create().showOverlay()
                        }
                    }
                    6 -> {
                        val sysOpts = arrayOf("🔙 Geri Tuşu", "🏠 Ana Ekran", "🗂️ Son Uygulamalar", "🔔 Bildirim Paneli", "⚡ Hızlı Ayarlar")
                        val sysTypes = arrayOf("SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS")
                        overlayDialog().setItems(sysOpts) { _, sIdx ->
                            list.add(ExtraAction(sysTypes[sIdx]))
                            adapter.notifyDataSetChanged()
                        }.create().showOverlay()
                    }
                }
            }.create().showOverlay()
        }

        toolbarRow1.addView(toolBtn("☑️") {
            if (selectedIndices.size == list.size) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(list.indices) }
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("➕") { openAddMenu() }, toolbarParams)
        toolbarRow1.addView(toolBtn("📋") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            extraActionClipboard = list[idx].copy()
            Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        toolbarRow1.addView(toolBtn("✂️") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            extraActionClipboard = list[idx].copy()
            list.removeAt(idx)
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        }, toolbarParams)

        toolbarRow2.addView(toolBtn("📥") {
            val clip = extraActionClipboard
            if (clip == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            list.add(clip.copy())
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("🗑") {
            if (selectedIndices.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            selectedIndices.sortedDescending().forEach { list.removeAt(it) }
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↑") {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            if (idx > 0) {
                val tmp = list[idx - 1]; list[idx - 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx - 1)
                adapter.notifyDataSetChanged()
            }
        }, toolbarParams)
        toolbarRow2.addView(toolBtn("↓") {
            val idx = selectedIndices.maxOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            if (idx < list.size - 1) {
                val tmp = list[idx + 1]; list[idx + 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx + 1)
                adapter.notifyDataSetChanged()
            }
        }, toolbarParams)
    }

    private fun buildLoopTab(region: ActiveRegion, content: LinearLayout) {
        val ctx = this
        val headerRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        headerRow.addView(TextView(ctx).apply {
            text = "Bu alan nasıl çalışsın?"
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        headerRow.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener {
                showHintDialog("Loop", hintText(
                    "None: " to "Döngü yok, alan bir kere çalışıp durur.",
                    "Loop When Success: " to "Eşleşme bulunup başarılı olduğu SÜRECE tekrar dener (Başarılı Olunca adımları her seferinde çalışır); İLK BULUNAMADIĞINDA durur.",
                    "Loop When Fail: " to "Eşleşme bulunamadığı SÜRECE tekrar dener; İLK BULUNDUĞUNDA (Başarılı Olunca çalışır) durur.",
                    "Loop Always: " to "Sonuçtan bağımsız her zaman devam eder — kendi durdurma mantığını Başarılı/Bulunamazsa adımlarında kurman gerekir.",
                    "Not: " to "Macrorify'ın kendi tanımıyla birebir aynı — bu senin daha önce anlattığın Action Group tanımının TERSİDİR, isimler orada karışmıştı, burada Macrorify'ın gerçek dokümantasyonuna göre düzeltildi."
                ))
            }
        })
        content.addView(headerRow)
        val radioGroup = android.widget.RadioGroup(ctx)
        val rbNone = android.widget.RadioButton(ctx).apply {
            text = "None — tarama yapar ve durur (bir kere dener, biter)"; id = 1
        }
        val rbAlways = android.widget.RadioButton(ctx).apply {
            text = "Loop Always — sonsuz döngü, hep açık kalır"; id = 2
        }
        // ÖNEMLİ DÜZELTME: Macrorify'ın resmi dokümantasyonuna göre etiketler düzeltildi.
        // "Loop when success" = başarılı olduğu SÜRECE tekrarlar (bizim motor-içi "WHILE_FAIL" anahtarımız).
        // "Loop when fail" = başarısız olduğu SÜRECE tekrarlar (bizim motor-içi "WHILE_SUCCESS" anahtarımız).
        // Motor davranışı ve kayıtlı veri AYNI KALDI — sadece hangi ismin hangi davranışa ait olduğu düzeltildi.
        val rbLoopWhenSuccess = android.widget.RadioButton(ctx).apply {
            text = "Loop When Success — başarılı olduğu sürece tekrarlar, ilk bulunamayışta durur"; id = 4
        }
        val rbLoopWhenFail = android.widget.RadioButton(ctx).apply {
            text = "Loop When Fail — bulunamadığı sürece tekrarlar, ilk bulunduğunda durur"; id = 3
        }
        listOf(rbNone, rbAlways, rbLoopWhenSuccess, rbLoopWhenFail).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.loopMode) {
            "NONE" -> 1; "WHILE_SUCCESS" -> 3; "WHILE_FAIL" -> 4; else -> 2
        })
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.loopMode = when (checkedId) {
                1 -> "NONE"; 3 -> "WHILE_SUCCESS"; 4 -> "WHILE_FAIL"; else -> "ALWAYS"
            }
        }
        content.addView(radioGroup)
    }

    /** Macrorify'daki "Text Reader": bir bölge çizdirip, okunan metni bir DEĞİŞKENE yazan adım ekler. */
    private fun startTextReadRegion(targetList: MutableList<ExtraAction>) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isTextReadCapture = true
        region.textReadTargetList = targetList
        region.label.text = "📖 Metin Oku"
        Toast.makeText(this, "Okunacak alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    private fun openTextReadSaveDialog(region: ActiveRegion) {
        val targetList = region.textReadTargetList ?: return
        val r = regionRect(region)
        val ctx = this
        val varNameInput = EditText(ctx).apply { hint = "Değişken adı (örn. altin)" }
        val defaultInput = EditText(ctx).apply { hint = "Okunamazsa varsayılan değer"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("0") }
        val whitelistInput = EditText(ctx).apply { hint = "Whitelist (opsiyonel, örn. 0123456789)" }
        val blacklistInput = EditText(ctx).apply { hint = "Blacklist (opsiyonel)" }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0)
            addView(TextView(ctx).apply { text = "📖 Bu bölgedeki metni oku, İÇİNDEKİ İLK SAYIYI bir değişkene yaz (örn. \"Altın: 1500\" -> 1500)"; textSize = 12f })
            addView(varNameInput); addView(defaultInput); addView(whitelistInput); addView(blacklistInput)
        }
        overlayDialog().setTitle("Metni Değişkene Oku").setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val vname = varNameInput.text.toString().ifBlank { "okunan_deger" }
                targetList.add(ExtraAction(
                    type = "READ_TEXT", x = r[0], y = r[1], x2 = r[2], y2 = r[3],
                    variableName = vname,
                    readDefaultValue = defaultInput.text.toString().toIntOrNull() ?: 0,
                    readWhitelist = whitelistInput.text.toString(),
                    readBlacklist = blacklistInput.text.toString()
                ))
                removeRegionWindow(region)
                Toast.makeText(ctx, "Eklendi: 📖 $vname", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun extraActionToStep(extra: ExtraAction): com.bigboss.app.storage.ActionStep =
        com.bigboss.app.storage.ActionStep(
            type = extra.type, x = extra.x, y = extra.y, x2 = extra.x2, y2 = extra.y2,
            waitMs = extra.waitMs, repeat = extra.repeat, functionId = extra.functionId,
            variableName = extra.variableName, variableDelta = extra.variableDelta,
            scriptId = extra.scriptId,
            scriptCode = extra.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.code },
            holdMs = extra.holdMs, swipeHoldStartMs = extra.swipeHoldStartMs, swipeHoldEndMs = extra.swipeHoldEndMs, postDelayMs = extra.postDelayMs,
            readDefaultValue = extra.readDefaultValue, readWhitelist = extra.readWhitelist, readBlacklist = extra.readBlacklist
        )

    private fun saveRegionAsRule(region: ActiveRegion, silent: Boolean = false): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            if (!silent) Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show()
            return false
        }
        val mainAlt = buildConditionAltFromRegion(region) ?: run {
            if (!silent) {
                val msg = when (region.conditionKind) {
                    "IMAGE" -> "Resim seçilmedi"
                    "TEXT" -> "Metin boş"
                    "VARIABLE" -> "Değişken adı boş"
                    "CUSTOM" -> "Custom kod boş"
                    else -> "Koşul eksik"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
            return false
        }
        val name = region.name.ifBlank { "İsimsiz kural" }
        // ÖNEMLİ: id'yi BİR KERE üretip region'a KALICI olarak yazıyoruz — yoksa her otomatik
        // kaydetmede YENİ bir rastgele id üretilip aynı kuraldan kopyalar oluşurdu.
        val ruleId = region.existingRuleId ?: UUID.randomUUID().toString().also { region.existingRuleId = it }

        // Birincil kural: GENEL/AKSİYON/BAŞARILI/TEKRAR sekmelerindeki her şeyi taşır.
        val def = RuleDefinition(
            id = ruleId, name = name, enabled = region.enabled,
            alternatives = (mutableListOf(mainAlt) + region.extraConditions).toMutableList(),
            alternativesLogic = region.conditionsLogic,
            timeoutMs = region.cooldownMs,
            matchDelayMs = region.matchDelayMs,
            scanTimeoutMs = region.scanTimeoutMs,
            scanRateHz = region.scanRateHz,
            maxConsecutiveFailures = region.maxConsecutiveFailures,
            negateCondition = region.negate,
            loopMode = region.loopMode,
            requireVariableName = region.requireVariableName, requireVariableOp = region.requireVariableOp, requireVariableValue = region.requireVariableValue,
            actionType = region.actionType,
            actionX = region.actionX, actionY = region.actionY, actionX2 = region.actionX2, actionY2 = region.actionY2,
            swipePathPoints = if (region.swipeExtraPoints.isEmpty()) mutableListOf() else mutableListOf(
                com.bigboss.app.storage.SwipePointData(region.actionX, region.actionY, region.swipeHoldStartMs),
                com.bigboss.app.storage.SwipePointData(region.actionX2, region.actionY2, 0)
            ).apply { addAll(region.swipeExtraPoints) }.also { it[it.size - 1].holdMs = region.swipeHoldEndMs },
            tapAtMatchLocation = region.tapAtMatchLocation,
            actionRepeatCount = region.actionRepeatCount,
            actionHoldMs = region.actionHoldMs,
            actionPostDelayMs = region.actionPostDelayMs,
            randomOffsetPx = region.randomOffsetPx,
            randomChancePercent = region.randomChancePercent,
            swipeHoldStartMs = region.swipeHoldStartMs,
            swipeHoldEndMs = region.swipeHoldEndMs,
            actionHoldVarName = region.actionHoldVarName,
            actionPostDelayVarName = region.actionPostDelayVarName,
            swipeHoldStartVarName = region.swipeHoldStartVarName,
            swipeHoldEndVarName = region.swipeHoldEndVarName,
            actionRepeatVarName = region.actionRepeatVarName,
            randomOffsetVarName = region.randomOffsetVarName,
            swipeDurationVarName = region.swipeDurationVarName,
            actionXVarName = region.actionXVarName,
            actionYVarName = region.actionYVarName,
            actionX2VarName = region.actionX2VarName,
            actionY2VarName = region.actionY2VarName,
            callFunctionId = region.callFunctionId, callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName, incrementVariableDelta = region.incrementVariableDelta,
            extraSteps = region.extraActions.map { extraActionToStep(it) }.toMutableList()
        )

        val scope = region.saveScope
        when (scope) {
            is SaveScope.MainFlow -> RuleStorage.upsert(this, def)
            is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, def)
            is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, def)
        }

        // "BULUNAMAZSA" adımları varsa: AYNI koşulun TERSİYLE tetiklenen, sadece bu adımları çalıştıran ayrı bir kural.
        if (region.onFailActions.isNotEmpty()) {
            val failDef = RuleDefinition(
                id = region.existingRuleId?.let { "$it-fail" } ?: UUID.randomUUID().toString(),
                name = "$name → bulunamazsa", enabled = true,
                alternatives = (mutableListOf(mainAlt) + region.extraConditions).toMutableList(),
                alternativesLogic = region.conditionsLogic,
                timeoutMs = region.cooldownMs,
                negateCondition = !region.negate,
                loopMode = region.loopMode,
                actionType = "WAIT", actionX = 0, actionY = 0,
                extraSteps = region.onFailActions.map { extraActionToStep(it) }.toMutableList()
            )
            when (scope) {
                is SaveScope.MainFlow -> RuleStorage.upsert(this, failDef)
                is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, failDef)
                is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, failDef)
            }
        } else {
            // Önceden "bulunamazsa" kuralı vardıysa ve şimdi boşaltıldıysa temizle.
            region.existingRuleId?.let { id ->
                when (scope) {
                    is SaveScope.MainFlow -> RuleStorage.deleteRule(this, "$id-fail")
                    is SaveScope.Group -> ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail")
                    is SaveScope.Function -> FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail")
                }
            }
        }

        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeX = x.coerceIn(0, bitmap.width - 1)
        val safeY = y.coerceIn(0, bitmap.height - 1)
        val safeW = w.coerceAtMost(bitmap.width - safeX)
        val safeH = h.coerceAtMost(bitmap.height - safeY)
        if (safeW < 4 || safeH < 4) return null
        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ==================== Ana Akış ====================

    private data class MenuRow(val icon: String, val name: String, val extra: String, val onClick: () -> Unit)

    private fun showRowListDialog(title: String, rows: List<MenuRow>, closable: Boolean = true) {
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val row = rows[position]
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = row.icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = row.name
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = row.extra
                return view
            }
        }
        val builder = overlayDialog().setTitle(title).setAdapter(adapter) { _, position -> rows[position].onClick() }
        if (closable) builder.setNegativeButton("Kapat", null)
        builder.create().showOverlay()
    }

    /** Ana Akış listesindeki tek bir öğe: ya bir kural ya bir Action Group. */
    private sealed class AnaAkisEntry {
        data class Rule(val rule: RuleDefinition) : AnaAkisEntry()
        data class Group(val group: com.bigboss.app.storage.ActionGroupDefinition) : AnaAkisEntry()
    }

    /**
     * "Ana Akış" artık küçük bir liste penceresi değil, Macrorify'daki gibi TAM BİR
     * SAYFA: üstte kaydırılabilir liste, altta seçili öğe üzerinde çalışan 8 ikonlu
     * araç çubuğu (Görüntüle, Ekle, Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı).
     */
    private fun buildAnaAkisScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer)
        root.addView(footer)

        fun currentEntries(): List<AnaAkisEntry> {
            val entries = mutableListOf<AnaAkisEntry>()
            ActionGroupStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Group(it)) }
            RuleStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Rule(it)) }
            return entries
        }

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz kural/grup yok — alttaki ➕ ile başla"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    when (val entry = entries[position]) {
                        is AnaAkisEntry.Group -> {
                            val g = entry.group
                            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (g.enabled) "📦" else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = g.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "$gateInfo · ${g.rules.size} · x${g.gateRepeat}"
                        }
                        is AnaAkisEntry.Rule -> {
                            val r = entry.rule
                            val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆")
                                else when (r.alternatives.first().conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
                            val extra = if (!r.enabled) "🔕" else if (r.loopMode == "ALWAYS") "" else r.loopMode
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (r.enabled) icon else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = r.groupName?.let { "[$it] " }.orEmpty() + r.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = extra
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.4).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is AnaAkisEntry.Rule -> showRuleOptions(entry.rule)
                    is AnaAkisEntry.Group -> showActionGroupOptions(entry.group)
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<AnaAkisEntry> {
            val entries = currentEntries()
            return selectedIndices.sorted().mapNotNull { entries.getOrNull(it) }
        }

        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply {
            text = label; textSize = 15f
            setOnClickListener { onClick() }
        }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        row1.addView(toolBtn("☑️") {
            val total = currentEntries().size
            if (selectedIndices.size == total) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(0 until total) }
            buildContent()
        }, toolbarParams)
        row1.addView(toolBtn("➕") {
            overlayDialog().setTitle("Ne eklemek istersin?")
                .setItems(arrayOf(
                    "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                    "🔀 Koşul Ekle (Conditional — değişken/custom if-else)",
                    "👆 Sadece Dokunma Ekle (koşulsuz)",
                    "👉 Sadece Kaydırma Ekle (koşulsuz)",
                    "📦 Yeni Action Group",
                    "f{} Yeni Fonksiyon",
                    "🖥️ Yeni Script (Kod)"
                )) { _, idx ->
                    when (idx) {
                        0 -> { closeAppPanel(); startAddRegion() }
                        1 -> { closeAppPanel(); startAddConditional(SaveScope.MainFlow) }
                        2 -> addSimpleStepToMainFlow("TAP")
                        3 -> addSimpleStepToMainFlow("SWIPE")
                        4 -> createActionGroup()
                        5 -> createFunction()
                        6 -> openScriptEditorOverlay(null)
                    }
                }.create().showOverlay()
        }, toolbarParams)
        row1.addView(toolBtn("📋") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                Toast.makeText(ctx, "Kopyalandı: ${sel.rule.name}", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        row1.addView(toolBtn("✂️") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel.rule)
                RuleStorage.deleteRule(ctx, sel.rule.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                refreshThisScreen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        row2.addView(toolBtn("📥") {
            val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            RuleStorage.upsert(ctx, pasted)
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("🗑") {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { entry ->
                when (entry) {
                    is AnaAkisEntry.Rule -> { RuleStorage.deleteRule(ctx, entry.rule.id); RuleStorage.deleteRule(ctx, "${entry.rule.id}-fail") }
                    is AnaAkisEntry.Group -> ActionGroupStorage.delete(ctx, entry.group.id)
                }
            }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↑") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { RuleStorage.moveUp(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↓") {
            val sel = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir KURAL seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { RuleStorage.moveDown(ctx, it.rule.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            refreshThisScreen()
        }, toolbarParams)
        footer.addView(row1)
        footer.addView(row2)

        // ---- ▶️ Unit Test (Macrorify'daki gibi): seçili öğeleri, ya da hiç seçim yoksa TÜMÜNÜ, gerçekten çalıştırır ----
        val testBtn = Button(ctx).apply {
            text = "▶️ Test Et — seçiliyse sadece SEÇİLİLER, seçim yoksa HEPSİ çalışır"
            textSize = 13f
            setOnClickListener {
                val selRules = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule }
                if (selRules.isNotEmpty()) {
                    testSelectedRules(selRules)
                } else {
                    val all = currentEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule }
                    if (all.isEmpty()) { Toast.makeText(ctx, "Çalıştırılacak kural yok", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    overlayDialog().setTitle("Hiçbir şey seçili değil")
                        .setMessage("Seçim yapmadın — TÜM Ana Akış'ı (${all.size} kural) GERÇEKTEN çalıştıracağım. Emin misin?")
                        .setPositiveButton("Evet, hepsini çalıştır") { _, _ -> testSelectedRules(all) }
                        .setNegativeButton("Vazgeç", null)
                        .create().showOverlay()
                }
            }
        }
        footer.addView(testBtn)

        buildContent()
        return root
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog().setTitle("Grup Seç").setItems(groups.toTypedArray()) { _, gIndex ->
            val group = groups[gIndex]
            val filtered = RuleStorage.load(this).filter { it.groupName == group }
            val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
            overlayDialog().setTitle("[$group] (${filtered.size})").setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                .setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showRuleOptions(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle", if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir", "🧪 Test Et",
            "📋 Kopyala", "✂️ Kes", "⬆️ Yukarı Taşı", "⬇️ Aşağı Taşı", "🗑 Sil"
        )
        overlayDialog().setTitle(rule.name).setItems(options) { _, index ->
            when (index) {
                0 -> {
                    if (rule.alternatives.isEmpty()) {
                        RuleStorage.deleteRule(this, rule.id)
                        addSimpleStepToMainFlow(rule.actionType)
                    } else {
                        editExistingRule(rule)
                    }
                }
                1 -> { rule.enabled = !rule.enabled; RuleStorage.upsert(this, rule); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                2 -> testRule(rule)
                3 -> { com.bigboss.app.storage.RuleClipboard.copy(rule); Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show() }
                4 -> {
                    com.bigboss.app.storage.RuleClipboard.copy(rule)
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Kesildi: ${rule.name}", Toast.LENGTH_SHORT).show()
                }
                5 -> { RuleStorage.moveUp(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                6 -> { RuleStorage.moveDown(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                7 -> {
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Var olan bir kuralı düzenlemek için, o kuralın alanını ekranda GERÇEK overlay kutusu olarak geri getirir. */
    private fun stepToExtraAction(step: com.bigboss.app.storage.ActionStep): ExtraAction {
        val fnName = step.functionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        }
        return ExtraAction(
            type = step.type, x = step.x, y = step.y, x2 = step.x2, y2 = step.y2,
            waitMs = step.waitMs, functionId = step.functionId, functionName = fnName ?: "",
            repeat = step.repeat, variableName = step.variableName, variableDelta = step.variableDelta,
            scriptId = step.scriptId, scriptName = step.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.name } ?: "",
            holdMs = step.holdMs, swipeHoldStartMs = step.swipeHoldStartMs, swipeHoldEndMs = step.swipeHoldEndMs, postDelayMs = step.postDelayMs,
            readDefaultValue = step.readDefaultValue, readWhitelist = step.readWhitelist, readBlacklist = step.readBlacklist
        )
    }

    private fun editExistingRule(rule: RuleDefinition, scope: SaveScope = SaveScope.MainFlow) {
        val alt = rule.alternatives.firstOrNull() ?: return
        val region = addRegionWindow(alt.x, alt.y, alt.width, alt.height)
        region.saveScope = scope
        region.existingRuleId = rule.id
        region.name = rule.name
        region.conditionKind = alt.conditionKind
        region.conditionColor = alt.color
        region.conditionTemplatePath = alt.templatePath
        region.conditionText = alt.expectedText ?: ""
        region.conditionTextCaseSensitive = alt.textCaseSensitive
        region.conditionTextWhitelist = alt.textWhitelist
        region.conditionTextBlacklist = alt.textBlacklist
        region.conditionVariableName = alt.variableName
        region.conditionVariableOp = alt.variableOp
        region.conditionCompareValue = alt.compareValue
        region.conditionCustomCode = alt.customCode
        region.minScore = alt.minScore
        region.extraConditions.clear()
        region.extraConditions.addAll(rule.alternatives.drop(1).map { it.copy() })
        region.conditionsLogic = rule.alternativesLogic
        region.actionType = rule.actionType
        region.actionX = rule.actionX; region.actionY = rule.actionY
        region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
        region.swipeExtraPoints.clear()
        if (rule.swipePathPoints.size > 2) {
            region.swipeExtraPoints.addAll(rule.swipePathPoints.drop(2).map { it.copy() })
        }
        region.tapAtMatchLocation = rule.tapAtMatchLocation
        region.actionRepeatCount = rule.actionRepeatCount
        region.actionHoldMs = rule.actionHoldMs
        region.actionPostDelayMs = rule.actionPostDelayMs
        region.randomOffsetPx = rule.randomOffsetPx
        region.randomChancePercent = rule.randomChancePercent
        region.swipeHoldStartMs = rule.swipeHoldStartMs
        region.swipeHoldEndMs = rule.swipeHoldEndMs
        region.actionHoldVarName = rule.actionHoldVarName
        region.actionPostDelayVarName = rule.actionPostDelayVarName
        region.swipeHoldStartVarName = rule.swipeHoldStartVarName
        region.swipeHoldEndVarName = rule.swipeHoldEndVarName
        region.actionRepeatVarName = rule.actionRepeatVarName
        region.randomOffsetVarName = rule.randomOffsetVarName
        region.swipeDurationVarName = rule.swipeDurationVarName
        region.actionXVarName = rule.actionXVarName
        region.actionYVarName = rule.actionYVarName
        region.actionX2VarName = rule.actionX2VarName
        region.actionY2VarName = rule.actionY2VarName
        region.callFunctionId = rule.callFunctionId
        region.callFunctionName = rule.callFunctionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        } ?: ""
        region.callFunctionRepeat = rule.callFunctionRepeat
        region.cooldownMs = rule.timeoutMs
        region.matchDelayMs = rule.matchDelayMs
        region.scanTimeoutMs = rule.scanTimeoutMs
        region.scanRateHz = rule.scanRateHz
        region.maxConsecutiveFailures = rule.maxConsecutiveFailures
        region.enabled = rule.enabled
        region.negate = rule.negateCondition
        region.loopMode = rule.loopMode
        region.requireVariableName = rule.requireVariableName
        region.requireVariableOp = rule.requireVariableOp
        region.requireVariableValue = rule.requireVariableValue
        region.incrementVariableName = rule.incrementVariableName
        region.incrementVariableDelta = rule.incrementVariableDelta
        region.extraActions.clear()
        rule.extraSteps.forEach { region.extraActions.add(stepToExtraAction(it)) }

        // "-fail" eşleniği varsa, BULUNAMAZSA adımlarını da geri yükle (aynı kapsamdan).
        val failRule = when (scope) {
            is SaveScope.MainFlow -> RuleStorage.load(this).find { it.id == "${rule.id}-fail" }
            is SaveScope.Group -> ActionGroupStorage.load(this).find { it.id == scope.groupId }?.rules?.find { it.id == "${rule.id}-fail" }
            is SaveScope.Function -> FunctionStorage.load(this).find { it.id == scope.functionId }?.rules?.find { it.id == "${rule.id}-fail" }
        }
        region.onFailActions.clear()
        failRule?.extraSteps?.forEach { region.onFailActions.add(stepToExtraAction(it)) }

        val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
        region.label.text = "$icon ${region.name}"
        Toast.makeText(this, "Alan geri getirildi — düzenleyip kaydet", Toast.LENGTH_LONG).show()
    }

    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        overlayDialog().setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})")
            .setPositiveButton("Tamam", null).create().showOverlay()
    }

    // ==================== Action Group ====================

    private fun showActionGroupsMenu() {
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Action Group")
        options.addAll(groups.map { g ->
            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
            "📦 ${if (g.enabled) "" else "🔕 "}${g.name} ($gateInfo, ${g.rules.size} tarama)"
        })
        overlayDialog().setTitle("📦 Action Group'lar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createActionGroup() else showActionGroupOptions(groups[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createActionGroup() {
        val input = EditText(this).apply { hint = "Grup adı (örn. \"Savaş Ekranı\")" }
        overlayDialog().setTitle("Yeni Action Group").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "grup" }
                ActionGroupStorage.upsert(this, com.bigboss.app.storage.ActionGroupDefinition(UUID.randomUUID().toString(), name))
                Toast.makeText(this, "Oluşturuldu — şimdi \"🎯 Kapı Koşulunu Ayarla\" ile devam et", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showActionGroupOptions(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val options = arrayOf(
            "🎯 Kapı Koşulunu Ayarla/Değiştir",
            "➕ Bu Gruba Tarama Ekle",
            "📋 Gruptaki Taramaları Listele",
            "⚙️ Grup Ayarları (döngü sayısı, kapı sıklığı)",
            if (group.enabled) "🔕 Grubu Devre Dışı Bırak" else "🔔 Grubu Etkinleştir",
            "🗑 Grubu Sil"
        )
        overlayDialog().setTitle("📦 ${group.name}").setItems(options) { _, index ->
            when (index) {
                0 -> startGateRegion(group)
                1 -> startGroupScan(group)
                2 -> showGroupRulesList(group)
                3 -> showGroupSettingsDialog(group)
                4 -> {
                    group.enabled = !group.enabled
                    ActionGroupStorage.upsert(this, group)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
                5 -> {
                    ActionGroupStorage.delete(this, group.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Gruba özel ayarlar: kapı bulununca kaç kere taransın (döngü sayısı) + kapı ne sıklıkla kontrol edilsin. */
    private fun showGroupSettingsDialog(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply {
            text = "Döngü sayısı — kapı koşulu bulununca gruptaki taramalar kaç kere art arda çalışsın (Infinite Loop AÇIKSA bu yok sayılır):"
            textSize = 12f
        })
        val repeatInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateRepeat.toString())
        }
        container.addView(repeatInput)
        container.addView(TextView(this).apply {
            text = "Kapı kontrol sıklığı (ms) — kapı koşulu en fazla ne kadar sık kontrol edilsin:"
            textSize = 12f; setPadding(0, 16, 0, 0)
        })
        val cooldownInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateCooldownMs.toString())
        }
        container.addView(cooldownInput)

        container.addView(TextView(this).apply {
            text = "🔁 Infinite Loop"; setTypeface(null, android.graphics.Typeface.BOLD); textSize = 13f; setPadding(0, 20, 0, 4)
        })
        val infiniteCheck = android.widget.CheckBox(this).apply {
            text = "Döngü Sayısı yerine, kapı koşulu doğru olduğu SÜRECE sürekli tekrarla"
            isChecked = group.gateInfiniteLoop
        }
        container.addView(infiniteCheck)
        container.addView(TextView(this).apply {
            text = "Time Limit (ms) — Infinite Loop bu süreyi aşınca otomatik durur. 0 = motorun kendi güvenlik sınırı (5 dakika) uygulanır, GERÇEKTEN sınırsız çalışmaz (uygulamanın donmasını önlemek için)."
            textSize = 11f; setPadding(0, 12, 0, 0)
        })
        val timeLimitInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateTimeLimitMs.toString())
        }
        container.addView(timeLimitInput)

        overlayDialog().setTitle("⚙️ ${group.name} Ayarları").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                group.gateRepeat = repeatInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                group.gateCooldownMs = cooldownInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 300
                group.gateInfiniteLoop = infiniteCheck.isChecked
                group.gateTimeLimitMs = timeLimitInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                ActionGroupStorage.upsert(this, group)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Ayarlar kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Grubun KAPI koşulunu ayarlamak için ekrana bir alan çizer. */
    private fun startGateRegion(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val gate = group.gate
        val region = if (gate != null) addRegionWindow(gate.x, gate.y, gate.width, gate.height) else addRegionWindow()
        region.isGateForGroupId = group.id
        if (gate != null) {
            region.conditionKind = gate.conditionKind
            region.conditionColor = gate.color
            region.conditionTemplatePath = gate.templatePath
            region.conditionText = gate.expectedText ?: ""
            region.conditionTextCaseSensitive = gate.textCaseSensitive
            region.conditionTextWhitelist = gate.textWhitelist
            region.conditionTextBlacklist = gate.textBlacklist
            region.minScore = gate.minScore
            region.cooldownMs = group.gateCooldownMs
        }
        region.label.text = "🎯 ${group.name}"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubunun KAPI koşulu — sadece GENEL sekmesi kullanılır", Toast.LENGTH_LONG).show()
    }

    /** Gruba yeni bir tarama (kural) eklemek için ekrana bir alan çizer. */
    private fun startGroupScan(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Group(group.id)
        region.label.text = "📦 ${group.name} → yeni"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showGroupRulesList(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val rules = group.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu grupta henüz tarama yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
        overlayDialog().setTitle("📦 ${group.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                if (action == 0) {
                    editExistingRule(rule, SaveScope.Group(group.id))
                } else {
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, rule.id)
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, "${rule.id}-fail")
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
            }.create().showOverlay()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Fonksiyonlar ====================

    /**
     * "f{} Fonksiyonlar" — Ana Akış için yaptığımız AYNI sayfa+araç çubuğu düzeni:
     * dokun = bilgiyi aç, basılı tut = çoklu seç, altta 8 ikonlu toplu işlem çubuğu.
     */
    private fun buildFonksiyonlarScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun buildContent() {
            listContainer.removeAllViews()
            val functions = FunctionStorage.load(ctx)
            if (functions.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz fonksiyon yok — alttaki ➕ ile oluştur"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = functions.size
                override fun getItem(position: Int): Any = functions[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    val fn = functions[position]
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "f{}"
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = fn.name
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "${fn.rules.size} adım"
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.45).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ -> showFunctionOptions(functions[position]) }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selected(): List<FunctionDefinition> = selectedIndices.sorted().mapNotNull { FunctionStorage.load(ctx).getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }
        fun toolBtn(label: String, onClick: () -> Unit) = Button(ctx).apply { text = label; textSize = 15f; setOnClickListener { onClick() } }
        val toolbarParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        row1.addView(toolBtn("☑️") {
            val total = FunctionStorage.load(ctx).size
            if (selectedIndices.size == total) selectedIndices.clear()
            else { selectedIndices.clear(); selectedIndices.addAll(0 until total) }
            buildContent()
        }, toolbarParams)
        row1.addView(toolBtn("➕") { createFunction(); refreshThisScreen() }, toolbarParams)
        row1.addView(toolBtn("📋") {
            val sel = selected().firstOrNull()
            if (sel != null) { com.bigboss.app.storage.FunctionClipboard.copy(sel); Toast.makeText(ctx, "Kopyalandı: ${sel.name}", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)
        row1.addView(toolBtn("✂️") {
            val sel = selected().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.FunctionClipboard.copy(sel)
                FunctionStorage.delete(ctx, sel.id)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                refreshThisScreen()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir fonksiyon seç", Toast.LENGTH_SHORT).show()
        }, toolbarParams)

        row2.addView(toolBtn("📥") {
            val pasted = com.bigboss.app.storage.FunctionClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@toolBtn }
            FunctionStorage.upsert(ctx, pasted)
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("🗑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.delete(ctx, it.id) }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} fonksiyon silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↑") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.forEach { FunctionStorage.moveUp(ctx, it.id) }
            refreshThisScreen()
        }, toolbarParams)
        row2.addView(toolBtn("↓") {
            val sel = selected()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) fonksiyon seç", Toast.LENGTH_SHORT).show(); return@toolBtn }
            sel.asReversed().forEach { FunctionStorage.moveDown(ctx, it.id) }
            refreshThisScreen()
        }, toolbarParams)
        footer.addView(row1); footer.addView(row2)

        buildContent()
        return root
    }

    private fun createFunction() {
        val input = EditText(this).apply { hint = "Fonksiyon adı" }
        overlayDialog().setTitle("Yeni Fonksiyon").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "fonksiyon" }
                FunctionStorage.upsert(this, FunctionDefinition(UUID.randomUUID().toString(), name))
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showFunctionOptions(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} (${fn.rules.size} kural)")
            .setItems(arrayOf("➕ Bu Fonksiyona Adım Ekle", "📋 Fonksiyondaki Adımları Listele", "🗑 Fonksiyonu Sil")) { _, index ->
                when (index) {
                    0 -> showAddToFunctionMenu(fn)
                    1 -> showFunctionRulesList(fn)
                    2 -> {
                        FunctionStorage.delete(this, fn.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }.create().showOverlay()
    }

    /** Fonksiyona ne eklemek istediğini soran menü — artık sadece "tarama" değil, çeşitlendirildi. */
    private fun showAddToFunctionMenu(fn: FunctionDefinition) {
        overlayDialog().setTitle("f{} ${fn.name} — Ne eklemek istersin?")
            .setItems(arrayOf(
                "🔍 Tarama Alanı Ekle (koşullu — renk/resim/yazı arar)",
                "👆 Sadece Dokunma Ekle (koşulsuz)",
                "👉 Sadece Kaydırma Ekle (koşulsuz)"
            )) { _, index ->
                when (index) {
                    0 -> startFunctionScan(fn)
                    1 -> addSimpleStepToFunction(fn, "TAP")
                    2 -> addSimpleStepToFunction(fn, "SWIPE")
                }
            }.create().showOverlay()
    }

    /** Fonksiyona tam bir tarama alanı YERİNE, sadece koşulsuz bir dokunma/kaydırma adımı ekler. */
    private fun promptTapHold(onDone: (Long) -> Unit) {
        val input = EditText(this).apply { hint = "HOLD (ms) — basılı tutma süresi"; inputType = InputType.TYPE_CLASS_NUMBER; setText("50") }
        overlayDialog().setTitle("⏱️ Basılı Tutma Süresi").setView(input)
            .setPositiveButton("Tamam") { _, _ -> onDone(input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50) }
            .setNegativeButton("Atla (varsayılan 50ms)") { _, _ -> onDone(50) }
            .create().showOverlay()
    }

    private fun promptSwipeHold(onDone: (Long, Long) -> Unit) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply { text = "Başlangıçta bekleme (ms) — sürükle-bırak için:" })
        val startInput = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("0") }
        container.addView(startInput)
        container.addView(TextView(this).apply { text = "Bitişte bekleme (ms):"; setPadding(0, 16, 0, 0) })
        val endInput = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("0") }
        container.addView(endInput)
        overlayDialog().setTitle("⏱️ Basılı Tutma Süreleri (isteğe bağlı)").setView(container)
            .setPositiveButton("Tamam") { _, _ -> onDone(startInput.text.toString().toLongOrNull() ?: 0, endInput.text.toString().toLongOrNull() ?: 0) }
            .setNegativeButton("Atla") { _, _ -> onDone(0, 0) }
            .create().showOverlay()
    }

    /** Ana Akış'a doğrudan, koşulsuz bir dokunma/kaydırma adımı ekler (tarama alanı gerekmeden). */
    private fun addSimpleStepToMainFlow(type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                promptTapHold { holdMs ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👆 Dokunma",
                        alternatives = mutableListOf(),
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "TAP",
                        actionX = x, actionY = y,
                        actionHoldMs = holdMs
                    )
                    RuleStorage.upsert(this, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    addWorkspacePointDot(x, y, "👆 ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.MainFlow) }
                    Toast.makeText(this, "Ana Akışa eklendi: 👆 Dokunma — 🗺️ Çalışma Alanı'ndan gizleyebilirsin", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    promptSwipeHold { holdStart, holdEnd ->
                        val def = RuleDefinition(
                            id = UUID.randomUUID().toString(),
                            name = "👉 Kaydırma",
                            alternatives = mutableListOf(),
                            timeoutMs = 100,
                            loopMode = "ALWAYS",
                            actionType = "SWIPE",
                            actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2,
                            swipeHoldStartMs = holdStart, swipeHoldEndMs = holdEnd
                        )
                        RuleStorage.upsert(this, def)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        addWorkspacePointDot(x1, y1, "1️⃣ ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.MainFlow) }
                        addWorkspacePointDot(x2, y2, "2️⃣ ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.MainFlow) }
                        Toast.makeText(this, "Ana Akışa eklendi: 👉 Kaydırma — 🗺️ Çalışma Alanı'ndan gizleyebilirsin", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun addSimpleStepToFunction(fn: FunctionDefinition, type: String) {
        if (type == "TAP") {
            pickPointWithMarker("👆", null, null) { x, y ->
                promptTapHold { holdMs ->
                    val def = RuleDefinition(
                        id = UUID.randomUUID().toString(),
                        name = "👆 Dokunma",
                        alternatives = mutableListOf(), // boş -> koşulsuz (her zaman doğru)
                        timeoutMs = 100,
                        loopMode = "ALWAYS",
                        actionType = "TAP",
                        actionX = x, actionY = y,
                        actionHoldMs = holdMs
                    )
                    FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    addWorkspacePointDot(x, y, "👆 ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.Function(fn.id)) }
                    Toast.makeText(this, "Eklendi: 👆 Dokunma — 🗺️ Çalışma Alanı'ndan gizleyebilirsin", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            pickPointWithMarker("1", null, null) { x1, y1 ->
                pickPointWithMarker("2", null, null) { x2, y2 ->
                    promptSwipeHold { holdStart, holdEnd ->
                        val def = RuleDefinition(
                            id = UUID.randomUUID().toString(),
                            name = "👉 Kaydırma",
                            alternatives = mutableListOf(),
                            timeoutMs = 100,
                            loopMode = "ALWAYS",
                            actionType = "SWIPE",
                            actionX = x1, actionY = y1, actionX2 = x2, actionY2 = y2,
                            swipeHoldStartMs = holdStart, swipeHoldEndMs = holdEnd
                        )
                        FunctionStorage.upsertRuleInFunction(this, fn.id, def)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        addWorkspacePointDot(x1, y1, "1️⃣ ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.Function(fn.id)) }
                        addWorkspacePointDot(x2, y2, "2️⃣ ${def.name}") { clearWorkspace(); editExistingRule(def, SaveScope.Function(fn.id)) }
                        Toast.makeText(this, "Eklendi: 👉 Kaydırma — 🗺️ Çalışma Alanı'ndan gizleyebilirsin", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    /** Fonksiyona yeni bir tarama (kural) eklemek için ekrana bir alan çizer — tıpkı Action Group'taki gibi. */
    private fun startFunctionScan(fn: FunctionDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Function(fn.id)
        region.label.text = "f{} ${fn.name} → yeni"
        Toast.makeText(this, "Bu alan \"${fn.name}\" fonksiyonuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showFunctionRulesList(fn: FunctionDefinition) {
        val rules = fn.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu fonksiyonda henüz tarama/adım yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r ->
            val icon = if (r.alternatives.isEmpty()) (if (r.actionType == "SWIPE") "👉" else "👆") else "🔍"
            "${i + 1}. $icon ${if (r.enabled) "" else "🔕 "}${r.name}"
        }.toTypedArray()
        overlayDialog().setTitle("f{} ${fn.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            if (rule.alternatives.isEmpty()) {
                // Koşulsuz basit adım (Dokunma/Kaydırma) — tam alan düzenleyici yerine hızlı yeniden-seçim
                overlayDialog().setTitle(rule.name).setItems(arrayOf("🔄 Noktayı/Noktaları Yeniden Seç", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        addSimpleStepToFunction(fn, rule.actionType)
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            } else {
                overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                    if (action == 0) {
                        editExistingRule(rule, SaveScope.Function(fn.id))
                    } else {
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, rule.id)
                        FunctionStorage.deleteRuleFromFunction(this, fn.id, "${rule.id}-fail")
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                    }
                }.create().showOverlay()
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kod (Script) ====================

    private fun showScriptsMenu() {
        val scripts = com.bigboss.app.storage.ScriptStorage.load(this)
        val options = mutableListOf("➕ Yeni Script")
        options.addAll(scripts.map { "🖥️ ${it.name}" })
        overlayDialog().setTitle("🖥️ Kod").setItems(options.toTypedArray()) { _, index ->
            openScriptEditorOverlay(if (index > 0) scripts[index - 1].id else null)
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * Kod editörünü bir Activity yerine GERÇEK bir overlay penceresi olarak açıyoruz.
     * (Geçmişte ayrı Activity'ler kullanılıyordu ama Activity açılınca BigBoss öne
     * geliyor, altındaki oyunun ÜSTÜNDE kalmıyordu — tüm editörler bu yüzden overlay
     * pencerelerine taşındı, o eski Activity'ler artık kaldırıldı.)
     */
    private fun openScriptEditorOverlay(scriptId: String?) {
        val ctx = this
        val density = resources.displayMetrics.density
        val existing = scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(ctx).find { it.id == id } }
        val isNew = existing == null
        val actualId = existing?.id ?: UUID.randomUUID().toString()

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt()) }
        root.addView(TextView(ctx).apply { text = "Script Adı"; textSize = 11f })
        val nameInput = EditText(ctx).apply { setText(existing?.name ?: "") ; hint = "İsimsiz script" }
        root.addView(nameInput)

        root.addView(TextView(ctx).apply { text = "Kod"; textSize = 11f; setPadding(0, (12 * density).toInt(), 0, 0) })
        val defaultCode = "// ==== Basit fonksiyonlar ====\n" +
            "// tap(x, y, {repeat, hold, delay, random})\n" +
            "// swipe(x1, y1, x2, y2, {duration, holdStart, holdEnd, delay, random})\n" +
            "// swipePath([{x,y,hold}, {x,y,hold}, ...], sureHer)  -- çok noktalı kaydırma\n" +
            "// wait(ms)\n" +
            "// back() | home() | recents() | notifications() | quickSettings()\n" +
            "// getVar(ad) | setVar(ad, deger)                -- sayı değişken (birleşik, kalıcı)\n" +
            "// getVarStr(ad) | setVarStr(ad, metin)          -- metin (String) değişken\n" +
            "// Setting.get(key) | Setting.show()             -- özel ayar (Custom Settings)\n" +
            "// colorAt(x, y) | randomInt(min, max)\n" +
            "// findColor(x,y,w,h,\"#RRGGBB\",minSkor) | findImage(x,y,w,h,\"kütüphaneAdi\",minSkor) | findText(x,y,w,h,\"metin\")\n" +
            "// callFunction(\"fonksiyonAdi\", tekrar) | runScript(\"scriptAdi\") | log(mesaj)\n" +
            "//\n" +
            "// ==== Region nesnesi ====\n" +
            "// var r = Region(x, y, w, h)\n" +
            "// r.findColor(\"#RRGGBB\", minSkor) | r.findImage(\"kütüphaneAdi\", minSkor) | r.findText(\"metin\")\n" +
            "// r.findImageMatch(\"kütüphaneAdi\", minSkor)  -> {found, x, y, score} ya da null\n" +
            "// r.tap({hold}) | r.center() -> {x, y}\n\n" +
            "log(\"Merhaba BigBoss\")\n"
        // Dil seçici: JS (Rhino) | EMScript
        val langRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, (6 * density).toInt()) }
        langRow.addView(TextView(ctx).apply { text = "Dil: "; setTextColor(TEXT_SECONDARY); textSize = 12f })
        val langGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.HORIZONTAL }
        val rbJs = android.widget.RadioButton(ctx).apply { text = "JavaScript"; id = 1; setTextColor(TEXT_PRIMARY); textSize = 12f }
        val rbEm = android.widget.RadioButton(ctx).apply { text = "EMScript"; id = 2; setTextColor(TEXT_PRIMARY); textSize = 12f }
        langGroup.addView(rbJs); langGroup.addView(rbEm)
        if ((existing?.language ?: "JS") == "EMSCRIPT") rbEm.isChecked = true else rbJs.isChecked = true
        langRow.addView(langGroup)
        root.addView(langRow)

        val codeInput = EditText(ctx).apply {
            setText(existing?.code ?: defaultCode)
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 12f
            gravity = Gravity.TOP or Gravity.START
            isSingleLine = false
            minLines = 12
            maxLines = 18
            setBackgroundColor(SURFACE_ALT_COLOR)
            setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
        }
        root.addView(codeInput)

        val outputText = TextView(ctx).apply {
            textSize = 11f; setPadding(0, (10 * density).toInt(), 0, 0)
        }
        root.addView(outputText)

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setPositiveButton("💾 Kaydet", null)
            .setNeutralButton("▶️ Test Et", null)
            .setNegativeButton(if (isNew) "Vazgeç" else "🗑 Sil", null)
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameInput.text.toString().ifBlank { "İsimsiz script" }
                val code = codeInput.text.toString()
                val lang = if (langGroup.checkedRadioButtonId == 2) "EMSCRIPT" else "JS"
                com.bigboss.app.storage.ScriptStorage.upsert(ctx, com.bigboss.app.storage.ScriptDefinition(actualId, name, code, lang))
                Toast.makeText(ctx, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val lang = if (langGroup.checkedRadioButtonId == 2) "EMSCRIPT" else "JS"
                if (lang == "EMSCRIPT") {
                    val host = com.bigboss.app.engine.ScriptRuntime.emHost
                    if (host == null) {
                        outputText.text = "⚠️ Şu an çalışan bir motor yok — önce Canlı Test ya da Play Mode'u başlat."
                    } else {
                        val error = com.bigboss.app.emscript.EmScriptRunner.run(codeInput.text.toString(), host)
                        outputText.text = if (error != null) "❌ $error" else "✅ Çalıştı (Logcat \"BigBossEMScript\" etiketinde Con.out çıktılarını görebilirsin)"
                        Toast.makeText(ctx, if (error != null) "EMScript hata verdi" else "EMScript çalıştı", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val engine = com.bigboss.app.engine.ScriptRuntime.engine
                    if (engine == null) {
                        outputText.text = "⚠️ Şu an çalışan bir motor yok — önce Canlı Test ya da Play Mode'u başlat."
                    } else {
                        val error = engine.run(codeInput.text.toString())
                        outputText.text = if (error != null) "❌ Hata: $error" else "✅ Çalıştı (Logcat \"BigBossScript\" etiketinde log() çıktılarını görebilirsin)"
                        Toast.makeText(ctx, if (error != null) "Script hata verdi" else "Script çalıştı", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                if (isNew) { dialog.dismiss(); return@setOnClickListener }
                overlayDialog().setTitle("Sil")
                    .setMessage("Bu script'i silmek istediğine emin misin?")
                    .setPositiveButton("Sil") { _, _ ->
                        com.bigboss.app.storage.ScriptStorage.delete(ctx, actualId)
                        dialog.dismiss()
                    }
                    .setNegativeButton("Vazgeç", null)
                    .create().showOverlay()
            }
        }
        dialog.show()
    }

    // ==================== Kütüphane ====================

    private fun showLibraryMenu() {
        val items = LibraryStorage.load(this)
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size + 1
            override fun getItem(position: Int): Any? = if (position == 0) null else items[position - 1]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_library_dialog, parent, false)
                val ivThumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivThumb)
                val tvName = view.findViewById<TextView>(com.bigboss.app.R.id.tvName)
                if (position == 0) {
                    ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(Color.parseColor("#333333"))
                    tvName.text = "📷 Ekrandan Kırp"
                } else {
                    val item = items[position - 1]
                    if (item.kind == "IMAGE" && !item.templatePath.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(item.templatePath)
                        if (bmp != null) ivThumb.setImageBitmap(bmp) else ivThumb.setBackgroundColor(Color.DKGRAY)
                    } else { ivThumb.setImageDrawable(null); ivThumb.setBackgroundColor(item.color) }
                    tvName.text = "${if (item.kind == "IMAGE") "🖼️" else "🎨"} ${item.name}"
                }
                return view
            }
        }
        overlayDialog().setTitle("📚 Kütüphanem (${items.size})").setAdapter(adapter) { _, position ->
            if (position == 0) startLibraryCaptureRegion()
            else showLibraryItemOptions(items[position - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "📷 Ekrandan Kırp" — GERÇEK bir overlay penceresiyle çalışıyor, Activity açmıyor;
     * böylece başka uygulamaların (oyunlar dahil) üzerinde de sorunsuz çalışır. */
    private fun startLibraryCaptureRegion() {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isLibraryCapture = true
        region.label.text = "📷 Kırp"
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup kaydet", Toast.LENGTH_LONG).show()
    }

    private fun openLibraryCaptureSaveDialog(region: ActiveRegion) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val r = regionRect(region)
        val cropped = safeCrop(frame, r[0], r[1], r[2], r[3])
        if (cropped == null) { Toast.makeText(this, "Alan çok küçük", Toast.LENGTH_SHORT).show(); return }

        val input = EditText(this).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
        overlayDialog().setTitle("Bu resmi kaydet")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = input.text.toString().ifBlank { "İsimsiz görsel" }
                val path = TemplateStorage.save(this, cropped)
                LibraryStorage.add(this, LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, path))
                Toast.makeText(this, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
                removeRegionWindow(region)
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .setNeutralButton("🗑 Alanı Sil") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem) {
        val options = if (item.kind == "IMAGE") arrayOf("🔄 Değiştir (yeni ekran görüntüsüyle güncelle)", "✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog().setTitle(item.name).setItems(options) { _, index ->
            when (options[index]) {
                "🔄 Değiştir (yeni ekran görüntüsüyle güncelle)" -> startReplaceImageRegion(item)
                "✂️ Piksel Kırp" -> startActivity(Intent(this, com.bigboss.app.ui.LibraryCropActivity::class.java).apply {
                    putExtra(com.bigboss.app.ui.LibraryCropActivity.EXTRA_LIBRARY_ITEM_ID, item.id)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                "↻ 90° Döndür" -> rotateLibraryImage(item)
                "✏️ Yeniden Adlandır" -> renameLibraryItem(item)
                "🗑 Sil" -> { LibraryStorage.delete(this, item.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
            }
        }.create().showOverlay()
    }

    /**
     * Macrorify'daki "Replace Image": AYNI dosya yolunun İÇERİĞİNİ değiştirir (yeni dosya
     * oluşturmaz). Bu sayede bu görseli kullanan TÜM kurallar otomatik güncellenir —
     * sil-ve-yeniden-ekle yaparsan bunu her kuralda elle güncellemen gerekirdi.
     */
    private fun startReplaceImageRegion(item: LibraryItem) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isReplaceCaptureItem = item
        region.label.text = "🔄 Değiştir: ${item.name}"
        Toast.makeText(this, "Yeni görseli sürükle/boyutlandır, sonra dokunup onayla — BU İŞLEM GERİ ALINAMAZ", Toast.LENGTH_LONG).show()
    }

    private fun openReplaceImageConfirmDialog(region: ActiveRegion) {
        val item = region.isReplaceCaptureItem ?: return
        val path = item.templatePath
        if (path.isNullOrBlank()) { removeRegionWindow(region); return }
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val r = regionRect(region)
        val cropped = safeCrop(frame, r[0], r[1], r[2], r[3])
        if (cropped == null) { Toast.makeText(this, "Alan çok küçük", Toast.LENGTH_SHORT).show(); return }

        overlayDialog().setTitle("'${item.name}' Değiştirilsin mi?")
            .setMessage("Bu görseli yeni yakaladığınla değiştireceğim. Bunu kullanan TÜM kurallar otomatik güncellenecek. Bu işlem GERİ ALINAMAZ.")
            .setPositiveButton("Değiştir") { _, _ ->
                try {
                    java.io.FileOutputStream(path).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    com.bigboss.app.engine.ImageMatcher.clearCache()
                    Toast.makeText(this, "Değiştirildi — bu görseli kullanan her yer güncellendi", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
                }
                removeRegionWindow(region)
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(Bitmap.CompressFormat.PNG, 100, it) }
            com.bigboss.app.engine.ImageMatcher.clearCache() // aynı yol üzerine yazıldı, eski önbellek geçersiz
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun renameLibraryItem(item: LibraryItem) {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog().setTitle("Yeniden adlandır").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    override fun onDestroy() {
        clearAllRegionWindows()
        clearWorkspace()
        stopLiveMonitor()
        removePointMarker()
        colorPickCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
