package com.bigboss.app.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.ui.MainActivity
import com.bigboss.app.ui.RuleEditorActivity
import kotlin.math.abs

/**
 * Macrorify tarzı Edit Mode / Play Mode kontrolü — ama artık ekranda
 * gereksiz yer kaplamıyor. Varsayılan olarak KÜÇÜK, tek bir daire/ikon
 * hâlinde durur; dokununca tüm panel açılır, tekrar dokununca kapanır.
 * Küçük hâldeyken de sürüklenip istenen köşeye taşınabilir.
 */
class OverlayService : Service() {

    private enum class Mode { EDIT, PLAY }
    private var mode = Mode.EDIT
    private var expanded = false

    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    private lateinit var toggleButton: TextView
    private lateinit var expandedPanel: LinearLayout
    private lateinit var statusLabel: TextView
    private lateinit var modeToggleButton: Button
    private lateinit var addRuleButton: Button
    private lateinit var listButton: Button

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        // Küçük hâldeki tek dokunuşluk simge (dairesel, ~44dp)
        toggleButton = TextView(this).apply {
            text = "✏️"
            textSize = 20f
            setBackgroundColor(Color.parseColor("#DD1F6FEB"))
            setPadding(24, 20, 24, 20)
        }

        statusLabel = TextView(this).apply {
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.parseColor("#CC000000"))
            setTextColor(Color.WHITE)
        }
        modeToggleButton = Button(this).apply { setOnClickListener { toggleMode() } }
        addRuleButton = Button(this).apply {
            text = "+ Kural Ekle"
            setOnClickListener { openRuleEditor() }
        }
        listButton = Button(this).apply {
            text = "📋 Kurallar"
            setOnClickListener { openRulesList() }
        }

        expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(statusLabel)
            addView(modeToggleButton)
            addView(addRuleButton)
            addView(listButton)
        }

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleButton)
            addView(expandedPanel)
        }

        setupDragAndTap(toggleButton)

        windowManager?.addView(rootView, params)
        applyMode()
    }

    /** Küçük simgeye hem sürükleme (taşıma) hem tek dokunuşla aç/kapa özelliği ekler. */
    private fun setupDragAndTap(handle: View) {
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    windowManager?.updateViewLayout(rootView, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExpanded()
                }
            }
            true
        }
    }

    private fun toggleExpanded() {
        expanded = !expanded
        expandedPanel.visibility = if (expanded) View.VISIBLE else View.GONE
    }

    private fun toggleMode() {
        mode = if (mode == Mode.EDIT) Mode.PLAY else Mode.EDIT
        applyMode()
    }

    private fun applyMode() {
        val engine = ScreenCaptureService.ruleEngine
        when (mode) {
            Mode.EDIT -> {
                engine?.paused = true
                toggleButton.text = "✏️"
                statusLabel.text = "✏️ DÜZENLEME MODU — bot dokunmuyor"
                modeToggleButton.text = "▶️ Çalışma Moduna Geç"
                addRuleButton.visibility = View.VISIBLE
                listButton.visibility = View.VISIBLE
            }
            Mode.PLAY -> {
                engine?.paused = false
                toggleButton.text = "▶️"
                statusLabel.text = "▶️ ÇALIŞMA MODU — bot çalışıyor"
                modeToggleButton.text = "✏️ Düzenleme Moduna Geç"
                addRuleButton.visibility = View.GONE
                listButton.visibility = View.GONE
            }
        }
    }

    private fun openRuleEditor() {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        toggleExpanded() // panel açıkken editöre gidince otomatik küçülsün
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    private fun openRulesList() {
        toggleExpanded()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
