package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** "functions.json" içinde tüm Fonksiyonları saklar. */
object FunctionStorage {

    private const val FILE_NAME = "functions.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<FunctionDefinition> {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<FunctionDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, functions: List<FunctionDefinition>) {
        File(context.filesDir, FILE_NAME).writeText(gson.toJson(functions))
    }

    fun upsert(context: Context, function: FunctionDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == function.id }
        if (idx >= 0) all[idx] = function else all.add(function)
        save(context, all)
    }

    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    /** Bir fonksiyonun içine tek bir kural ekler/günceller (RuleEditorActivity buradan çağırır). */
    fun upsertRuleInFunction(context: Context, functionId: String, rule: RuleDefinition) {
        val all = load(context)
        val fn = all.find { it.id == functionId } ?: return
        val idx = fn.rules.indexOfFirst { it.id == rule.id }
        if (idx >= 0) fn.rules[idx] = rule else fn.rules.add(rule)
        save(context, all)
    }

    fun deleteRuleFromFunction(context: Context, functionId: String, ruleId: String) {
        val all = load(context)
        val fn = all.find { it.id == functionId } ?: return
        fn.rules.removeAll { it.id == ruleId }
        save(context, all)
    }
}
