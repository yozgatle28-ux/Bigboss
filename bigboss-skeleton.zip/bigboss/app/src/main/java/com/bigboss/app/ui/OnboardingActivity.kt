package com.bigboss.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityOnboardingBinding
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.util.PermissionUtils

/**
 * Uygulama ilk açıldığında (ya da izinler eksikse her açılışta) zorunlu,
 * sıralı bir kurulum akışı gösterir:
 *  1) Ekran üstü gösterim izni
 *  2) Erişilebilirlik servisi
 * İkisi de tamam olmadan MainActivity'ye geçilmez.
 */
class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGrantOverlay.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        binding.btnGrantAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        checkStepsAndProceed()
    }

    private fun checkStepsAndProceed() {
        if (!Settings.canDrawOverlays(this)) {
            showStep(overlay = true)
            return
        }
        val accessibilityOn = BigBossAccessibilityService.instance != null ||
            PermissionUtils.isAccessibilityServiceEnabled(this, BigBossAccessibilityService::class.java)
        if (!accessibilityOn) {
            showStep(overlay = false)
            return
        }
        // İki izin de tamam -> ana ekrana geç
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun showStep(overlay: Boolean) {
        binding.stepOverlay.visibility = if (overlay) android.view.View.VISIBLE else android.view.View.GONE
        binding.stepAccessibility.visibility = if (overlay) android.view.View.GONE else android.view.View.VISIBLE
    }
}
