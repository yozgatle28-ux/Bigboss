package com.bigboss.app.engine

/**
 * Kullanıcının tanımladığı "THEN" aksiyonları.
 * ActionExecutor bunları gerçek dokunuş/kaydırma olaylarına çevirir.
 */
sealed class Action {
    data class Tap(val x: Int, val y: Int) : Action()

    data class Swipe(
        val x1: Int, val y1: Int,
        val x2: Int, val y2: Int,
        val durationMs: Long = 300
    ) : Action()

    data class Wait(val ms: Long) : Action()

    /** Birden fazla aksiyonu sırayla çalıştırır (örn: tap -> wait -> tap). */
    data class Sequence(val steps: List<Action>) : Action()

    /** Bir sayaç/değişkeni günceller. mode: "INCREMENT" (delta kadar artır/azalt) ya da "SET" (doğrudan ata). */
    data class SetVariable(val name: String, val delta: Int, val mode: String = "INCREMENT") : Action()

    /** Hiçbir şey yapma (örn. sadece log/izleme amaçlı kurallar için). */
    object NoOp : Action()
}
