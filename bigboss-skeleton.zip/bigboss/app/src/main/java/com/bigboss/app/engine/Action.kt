package com.bigboss.app.engine

/**
 * Kullanıcının tanımladığı "THEN" aksiyonları.
 * ActionExecutor bunları gerçek dokunuş/kaydırma olaylarına çevirir.
 */
sealed class Action {
    data class Tap(val x: Int, val y: Int, val repeat: Int = 1, val holdMs: Long = 50, val postDelayMs: Long = 0, val randomOffsetPx: Int = 0) : Action()

    /** "Eşleşen Noktaya Tıkla": koordinat sabit değil, kuralın koşulunun BULDUĞU konuma tıklar. */
    data class TapAtMatch(val repeat: Int = 1, val holdMs: Long = 50, val postDelayMs: Long = 0, val randomOffsetPx: Int = 0) : Action()

    data class Swipe(
        val x1: Int, val y1: Int,
        val x2: Int, val y2: Int,
        val durationMs: Long = 300,
        /** Başlangıç noktasında hareket etmeden önce kaç ms basılı beklensin (sürükle-bırak için). */
        val holdStartMs: Long = 0,
        /** Bitiş noktasına varınca parmağı kaldırmadan önce kaç ms daha basılı tutulsun. */
        val holdEndMs: Long = 0,
        /** İşlem TAMAMLANDIKTAN SONRA, sıradaki işleme geçmeden önce kaç ms beklensin. */
        val postDelayMs: Long = 0,
        /** "Randomize": her noktaya ±bu kadar piksel rastgele sapma eklenir (daha insani/tespit-karşıtı). */
        val randomOffsetPx: Int = 0
    ) : Action()

    data class Wait(val ms: Long) : Action()

    /** Birden fazla aksiyonu sırayla çalıştırır (örn: tap -> wait -> tap). */
    data class Sequence(val steps: List<Action>) : Action()

    /** Bir sayaç/değişkeni günceller. mode: "INCREMENT" (delta kadar artır/azalt) ya da "SET" (doğrudan ata). */
    data class SetVariable(val name: String, val delta: Int, val mode: String = "INCREMENT") : Action()

    /** Bir Fonksiyonu çağırır — o fonksiyonun kuralları sırayla çalışır, bitince (ya da repeat dolunca) buraya geri dönülür. */
    data class CallFunction(val functionId: String, val repeat: Int = 1) : Action()

    /** Kod sistemi: bir Script'i (JavaScript, Rhino ile) çalıştırır. */
    data class RunScript(val code: String) : Action()

    /** Macrorify'daki "Go Back/Home/Recents/Notifications/Quick Settings" sistem aksiyonları. */
    data class SystemAction(val type: String) : Action() // "BACK" | "HOME" | "RECENTS" | "NOTIFICATIONS" | "QUICK_SETTINGS"

    /** Hiçbir şey yapma (örn. sadece log/izleme amaçlı kurallar için). */
    object NoOp : Action()
}
