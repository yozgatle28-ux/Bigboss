package com.bigboss.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityMainBinding

/**
 * Ana ekran artık sadece bir MOD SEÇİCİ:
 *  - ▶️ PLAY MODE: sistem çalışır, hiçbir müdahale/düzenleme imkanı yok.
 *  - ✏️ EDIT MODE: kural/fonksiyon ekleme, düzenleme, kütüphane yönetimi.
 * Gerçek işler bu iki ayrı Activity'de (PlayModeActivity, EditModeActivity).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlayMode.setOnClickListener {
            startActivity(Intent(this, PlayModeActivity::class.java))
        }
        binding.btnEditMode.setOnClickListener {
            startActivity(Intent(this, EditModeActivity::class.java))
        }
    }
}
