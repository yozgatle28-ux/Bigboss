package com.bigboss.app.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bigboss.app.databinding.ActivityMainBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var adapter: RulesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)

        adapter = RulesAdapter(
            onToggle = { rule, checked ->
                rule.enabled = checked
                val all = RuleStorage.load(this)
                val idx = all.indexOfFirst { it.id == rule.id }
                if (idx >= 0) all[idx] = rule
                RuleStorage.save(this, all)
                refreshRunningRules()
            },
            onDelete = { rule ->
                RuleStorage.deleteRule(this, rule.id)
                loadRules()
                refreshRunningRules()
            }
        )
        binding.rvRules.layoutManager = LinearLayoutManager(this)
        binding.rvRules.adapter = adapter

        binding.btnOverlayPermission.setOnClickListener { requestOverlayPermission() }
        binding.btnAccessibilityPermission.setOnClickListener { requestAccessibilityPermission() }
        binding.btnStart.setOnClickListener { requestScreenCapturePermission() }
        binding.btnStop.setOnClickListener { stopBot() }
    }

    override fun onResume() {
        super.onResume()
        loadRules()
    }

    private fun loadRules() {
        adapter.submitList(RuleStorage.load(this))
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun requestAccessibilityPermission() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestScreenCapturePermission() {
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı; ActivityResultContracts'a taşınabilir.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            startBot(resultCode, data)
        }
    }

    private fun startBot(resultCode: Int, data: Intent) {
        val executor = BigBossAccessibilityService.instance
        if (executor == null) {
            binding.tvStatus.text = "Önce Erişilebilirlik servisini aç!"
            return
        }

        val ruleEngine = RuleEngine(executor)
        ruleEngine.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        ScreenCaptureService.ruleEngine = ruleEngine

        startService(Intent(this, OverlayService::class.java))

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(captureIntent)

        binding.tvStatus.text = "BigBoss çalışıyor (${RuleStorage.load(this).size} kural)"
    }

    /** Çalışırken kural listesi değiştiyse (silme/aç-kapa), motoru güncelle. */
    private fun refreshRunningRules() {
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
    }

    private fun stopBot() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        binding.tvStatus.text = "Durduruldu"
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 42
    }
}
