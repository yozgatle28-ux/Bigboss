package com.bigboss.app.ui

import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bigboss.app.databinding.ActivityMainBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var adapter: RulesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)

        adapter = RulesAdapter(
            onToggle = { rule, checked ->
                rule.enabled = checked
                RuleStorage.upsert(this, rule)
                refreshRunningRules()
            },
            onDelete = { rule ->
                RuleStorage.deleteRule(this, rule.id)
                loadRules()
                refreshRunningRules()
            },
            onEdit = { rule -> openEditor(rule) },
            onTest = { rule -> testRule(rule) }
        )
        binding.rvRules.layoutManager = LinearLayoutManager(this)
        binding.rvRules.adapter = adapter

        binding.btnStart.setOnClickListener { requestScreenCapturePermission() }
        binding.btnStop.setOnClickListener { stopBot() }
        binding.btnLibrary.setOnClickListener { showLibraryDialog() }
    }

    @Deprecated("Basitlik için kullanıldı; ActivityResultContracts'a taşınabilir.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            startBot(resultCode, data)
        } else if (requestCode == REQUEST_CODE_GALLERY_PICK && resultCode == RESULT_OK && data?.data != null) {
            handleGalleryImagePicked(data.data!!)
        }
    }

    private fun handleGalleryImagePicked(uri: android.net.Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val bitmap = android.graphics.BitmapFactory.decodeStream(input)
            input.close()
            if (bitmap == null) {
                android.widget.Toast.makeText(this, "Görsel okunamadı", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            val path = com.bigboss.app.storage.TemplateStorage.save(this, bitmap)
            val nameInput = android.widget.EditText(this).apply { hint = "Kütüphanedeki adı (örn. Potion İkonu)" }
            AlertDialog.Builder(this)
                .setTitle("Galeriden Eklendi")
                .setView(nameInput)
                .setPositiveButton("Kaydet") { _, _ ->
                    val name = nameInput.text.toString().ifBlank { "İsimsiz görsel" }
                    com.bigboss.app.storage.LibraryStorage.add(
                        this,
                        com.bigboss.app.storage.LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, path)
                    )
                    android.widget.Toast.makeText(this, "Kütüphaneye eklendi: $name", android.widget.Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Vazgeç", null)
                .show()
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "Görsel yüklenemedi: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun showLibraryDialog() {
        val items = com.bigboss.app.storage.LibraryStorage.load(this)
        val options = mutableListOf("➕ Galeriden Resim Ekle")
        options.addAll(items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" })

        AlertDialog.Builder(this)
            .setTitle("Kütüphanem (${items.size})")
            .setItems(options.toTypedArray()) { _, index ->
                if (index == 0) {
                    pickImageFromGallery()
                } else {
                    val item = items[index - 1]
                    showLibraryItemOptions(item)
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(intent, REQUEST_CODE_GALLERY_PICK)
    }

    private fun showLibraryItemOptions(item: com.bigboss.app.storage.LibraryItem) {
        val options = if (item.kind == "IMAGE") {
            arrayOf("↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        } else {
            arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        }
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, index ->
                val action = options[index]
                when {
                    action.contains("Döndür") -> rotateLibraryImage(item)
                    action.contains("Adlandır") -> renameLibraryItem(item)
                    action.contains("Sil") -> confirmDeleteLibraryItem(item)
                }
            }
            .show()
    }

    private fun rotateLibraryImage(item: com.bigboss.app.storage.LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            android.widget.Toast.makeText(this, "Döndürüldü: ${item.name}", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "Döndürme başarısız: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun renameLibraryItem(item: com.bigboss.app.storage.LibraryItem) {
        val input = android.widget.EditText(this).apply { setText(item.name) }
        AlertDialog.Builder(this)
            .setTitle("Yeniden adlandır")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                val all = com.bigboss.app.storage.LibraryStorage.load(this)
                val idx = all.indexOfFirst { it.id == item.id }
                if (idx >= 0) {
                    all[idx] = all[idx].copy(name = newName)
                    com.bigboss.app.storage.LibraryStorage.save(this, all)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun confirmDeleteLibraryItem(item: com.bigboss.app.storage.LibraryItem) {
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("Bu öğeyi kütüphaneden silmek ister misin?")
            .setPositiveButton("Sil") { _, _ ->
                com.bigboss.app.storage.LibraryStorage.delete(this, item.id)
                android.widget.Toast.makeText(this, "Silindi", android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadRules()
        refreshRunningRules()
    }

    private fun loadRules() {
        adapter.submitList(RuleStorage.load(this))
    }

    private fun openEditor(rule: RuleDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            android.widget.Toast.makeText(this, "Önce Başlat'a bas (ekran görüntüsü lazım)", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            putExtra(RuleEditorActivity.EXTRA_EDIT_RULE_ID, rule.id)
        }
        startActivity(intent)
    }

    /** Botu tam başlatmadan, tek bir kuralı anlık ekran görüntüsüne karşı test eder. */
    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            android.widget.Toast.makeText(this, "Önce Başlat'a bas (ekran görüntüsü lazım)", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        val scorePct = (score * 100).toInt()
        val minPct = (condition.minScore * 100).toInt()

        AlertDialog.Builder(this)
            .setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %$scorePct  (gereken: %$minPct)\n\nAksiyon: ${if (matched) "çalıştırılırdı" else "çalıştırılmazdı"}")
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun requestScreenCapturePermission() {
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    private fun startBot(resultCode: Int, data: Intent) {
        val executor = BigBossAccessibilityService.instance
        if (executor == null) {
            binding.tvStatus.text = "Erişilebilirlik servisi kapalı! Ayarlar > Erişilebilirlik'ten aç."
            return
        }

        val ruleEngine = RuleEngine(executor)
        ruleEngine.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        ScreenCaptureService.ruleEngine = ruleEngine

        startService(Intent(this, OverlayService::class.java))

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(captureIntent)

        binding.tvStatus.text = "✏️ Düzenleme Modu'nda başladı (${RuleStorage.load(this).size} kural) — overlay'den Çalışma Modu'na geç"
    }

    /** Çalışırken kural listesi değiştiyse (silme/aç-kapa/düzenleme), motoru güncelle. */
    private fun refreshRunningRules() {
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
    }

    private fun stopBot() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        binding.tvStatus.text = "Durduruldu"
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 42
        private const val REQUEST_CODE_GALLERY_PICK = 43
    }
}
