package com.bigboss.app.ui

import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bigboss.app.databinding.ActivityMainBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var adapter: RulesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)

        adapter = RulesAdapter(
            onToggle = { rule, checked ->
                rule.enabled = checked
                RuleStorage.upsert(this, rule)
                refreshRunningRules()
            },
            onDelete = { rule ->
                RuleStorage.deleteRule(this, rule.id)
                loadRules()
                refreshRunningRules()
            },
            onEdit = { rule -> openEditor(rule) },
            onTest = { rule -> testRule(rule) }
        )
        binding.rvRules.layoutManager = LinearLayoutManager(this)
        binding.rvRules.adapter = adapter

        binding.btnStart.setOnClickListener { requestScreenCapturePermission() }
        binding.btnStop.setOnClickListener { stopBot() }
        binding.btnLibrary.setOnClickListener { showLibraryDialog() }
    }

    private fun showLibraryDialog() {
        val items = com.bigboss.app.storage.LibraryStorage.load(this)
        if (items.isEmpty()) {
            android.widget.Toast.makeText(this, "Kütüphane boş. Kural editöründe bir renk/resim kaydederek doldurabilirsin.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val labels = items.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kütüphanem (${items.size})")
            .setItems(labels) { _, index ->
                val item = items[index]
                AlertDialog.Builder(this)
                    .setTitle(item.name)
                    .setMessage("Bu öğeyi kütüphaneden silmek ister misin?")
                    .setPositiveButton("Sil") { _, _ ->
                        com.bigboss.app.storage.LibraryStorage.delete(this, item.id)
                        android.widget.Toast.makeText(this, "Silindi", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Vazgeç", null)
                    .show()
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadRules()
        refreshRunningRules()
    }

    private fun loadRules() {
        adapter.submitList(RuleStorage.load(this))
    }

    private fun openEditor(rule: RuleDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            android.widget.Toast.makeText(this, "Önce Başlat'a bas (ekran görüntüsü lazım)", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RuleEditorActivity::class.java).apply {
            putExtra(RuleEditorActivity.EXTRA_EDIT_RULE_ID, rule.id)
        }
        startActivity(intent)
    }

    /** Botu tam başlatmadan, tek bir kuralı anlık ekran görüntüsüne karşı test eder. */
    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            android.widget.Toast.makeText(this, "Önce Başlat'a bas (ekran görüntüsü lazım)", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val condition = RuleDefinitionMapper.toCondition(rule)
        val score = condition.matchScore(frame)
        val matched = score >= condition.minScore
        val scorePct = (score * 100).toInt()
        val minPct = (condition.minScore * 100).toInt()

        AlertDialog.Builder(this)
            .setTitle(if (matched) "✅ Eşleşti" else "❌ Eşleşmedi")
            .setMessage("Skor: %$scorePct  (gereken: %$minPct)\n\nAksiyon: ${if (matched) "çalıştırılırdı" else "çalıştırılmazdı"}")
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun requestScreenCapturePermission() {
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı; ActivityResultContracts'a taşınabilir.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            startBot(resultCode, data)
        }
    }

    private fun startBot(resultCode: Int, data: Intent) {
        val executor = BigBossAccessibilityService.instance
        if (executor == null) {
            binding.tvStatus.text = "Erişilebilirlik servisi kapalı! Ayarlar > Erişilebilirlik'ten aç."
            return
        }

        val ruleEngine = RuleEngine(executor)
        ruleEngine.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
        ScreenCaptureService.ruleEngine = ruleEngine

        startService(Intent(this, OverlayService::class.java))

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(captureIntent)

        binding.tvStatus.text = "✏️ Edit Mode'da başladı (${RuleStorage.load(this).size} kural) — overlay'den Play Mode'a geç"
    }

    /** Çalışırken kural listesi değiştiyse (silme/aç-kapa/düzenleme), motoru güncelle. */
    private fun refreshRunningRules() {
        ScreenCaptureService.ruleEngine?.setRules(RuleDefinitionMapper.toRules(RuleStorage.load(this)))
    }

    private fun stopBot() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        binding.tvStatus.text = "Durduruldu"
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 42
    }
}
