package com.bigboss.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor

/**
 * RuleEngine'in kararlarını gerçek dokunuş/kaydırma jestlerine çeviren servis.
 * Kullanıcının Ayarlar > Erişilebilirlik ekranından elle etkinleştirmesi gerekir
 * (root gerektirmeyen resmi Android yolu).
 */
class BigBossAccessibilityService : AccessibilityService(), ActionExecutor {

    companion object {
        // MainActivity ve diğer servislerin erişebilmesi için basit bir referans.
        var instance: BigBossAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ScreenCaptureService.ruleEngine?.let { /* zaten bağlıysa dokunma */ }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Şu an olayları dinlemiyoruz; yalnızca jest gönderme (gesture dispatch)
        // yeteneğini kullanıyoruz. İleride ekran içeriği okumak gerekirse
        // (canRetrieveWindowContent=true yapılarak) burası genişletilebilir.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---- ActionExecutor ----

    private fun jitter(v: Int, range: Int): Int = if (range <= 0) v else v + (-range..range).random()

    override fun execute(action: Action) {
        when (action) {
            is Action.Tap -> repeat(action.repeat.coerceAtLeast(1)) {
                dispatchTap(jitter(action.x, action.randomOffsetPx), jitter(action.y, action.randomOffsetPx), action.holdMs)
                Thread.sleep(action.holdMs + action.postDelayMs) // jestin kendi süresi + istenen ek gecikme
            }
            is Action.TapAtMatch -> { /* RuleEngine bunu somut bir Tap'e çevirip gönderir, buraya gelmemeli */ }
            is Action.Swipe -> {
                dispatchSwipe(
                    jitter(action.x1, action.randomOffsetPx), jitter(action.y1, action.randomOffsetPx),
                    jitter(action.x2, action.randomOffsetPx), jitter(action.y2, action.randomOffsetPx),
                    action.durationMs, action.holdStartMs, action.holdEndMs
                )
                Thread.sleep(action.holdStartMs + action.durationMs + action.holdEndMs + action.postDelayMs)
            }
            is Action.Wait -> Thread.sleep(action.ms) // basit sürüm; büyük projede coroutine delay tercih edilmeli
            is Action.Sequence -> action.steps.forEach { execute(it) }
            is Action.SetVariable -> when (action.mode) {
                "SET" -> com.bigboss.app.engine.VariableStore.set(action.name, action.delta)
                else -> com.bigboss.app.engine.VariableStore.increment(action.name, action.delta)
            }
            is Action.CallFunction -> { /* RuleEngine bunu kendisi yönetir, buraya gelmemeli */ }
            is Action.RunScript -> com.bigboss.app.engine.ScriptRuntime.engine?.run(action.code)
            is Action.SystemAction -> {
                val globalAction = when (action.type) {
                    "BACK" -> GLOBAL_ACTION_BACK
                    "HOME" -> GLOBAL_ACTION_HOME
                    "RECENTS" -> GLOBAL_ACTION_RECENTS
                    "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
                    "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
                    else -> null
                }
                if (globalAction != null) performGlobalAction(globalAction)
            }
            Action.NoOp -> { /* hiçbir şey yapma */ }
        }
    }

    private fun dispatchTap(x: Int, y: Int, holdMs: Long = 50) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceAtLeast(1))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long, holdStartMs: Long = 0, holdEndMs: Long = 0) {
        // Basit durum: hiç HOLD yoksa, tek segmentlik eski davranış (daha hafif).
        if (holdStartMs <= 0 && holdEndMs <= 0) {
            val path = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            return
        }

        // HOLD var: başlangıçta sabit bekle -> hareket et -> bitişte sabit bekle (sürükle-bırak, "basılı tut" jestleri için).
        var startTime = 0L
        var lastStroke: GestureDescription.StrokeDescription? = null

        if (holdStartMs > 0) {
            val holdPath = Path().apply { moveTo(x1.toFloat(), y1.toFloat()) }
            lastStroke = GestureDescription.StrokeDescription(holdPath, startTime, holdStartMs, true)
            startTime += holdStartMs
        }

        val movePath = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val willContinue = holdEndMs > 0
        lastStroke = if (lastStroke != null) {
            lastStroke.continueStroke(movePath, startTime, durationMs.coerceAtLeast(1), willContinue)
        } else {
            GestureDescription.StrokeDescription(movePath, startTime, durationMs.coerceAtLeast(1), willContinue)
        }
        startTime += durationMs.coerceAtLeast(1)

        if (holdEndMs > 0) {
            val endHoldPath = Path().apply { moveTo(x2.toFloat(), y2.toFloat()) }
            lastStroke = lastStroke!!.continueStroke(endHoldPath, startTime, holdEndMs, false)
        }

        dispatchGesture(GestureDescription.Builder().addStroke(lastStroke!!).build(), null, null)
    }
}
