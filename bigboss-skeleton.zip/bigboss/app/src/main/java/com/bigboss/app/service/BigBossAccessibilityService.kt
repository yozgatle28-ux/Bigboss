package com.bigboss.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor

/**
 * RuleEngine'in kararlarını gerçek dokunuş/kaydırma jestlerine çeviren servis.
 * Kullanıcının Ayarlar > Erişilebilirlik ekranından elle etkinleştirmesi gerekir
 * (root gerektirmeyen resmi Android yolu).
 */
class BigBossAccessibilityService : AccessibilityService(), ActionExecutor {

    companion object {
        // MainActivity ve diğer servislerin erişebilmesi için basit bir referans.
        var instance: BigBossAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ScreenCaptureService.ruleEngine?.let { /* zaten bağlıysa dokunma */ }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Şu an olayları dinlemiyoruz; yalnızca jest gönderme (gesture dispatch)
        // yeteneğini kullanıyoruz. İleride ekran içeriği okumak gerekirse
        // (canRetrieveWindowContent=true yapılarak) burası genişletilebilir.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---- ActionExecutor ----

    override fun execute(action: Action) {
        when (action) {
            is Action.Tap -> repeat(action.repeat.coerceAtLeast(1)) { dispatchTap(action.x, action.y) }
            is Action.TapAtMatch -> { /* RuleEngine bunu somut bir Tap'e çevirip gönderir, buraya gelmemeli */ }
            is Action.Swipe -> dispatchSwipe(action.x1, action.y1, action.x2, action.y2, action.durationMs)
            is Action.Wait -> Thread.sleep(action.ms) // basit sürüm; büyük projede coroutine delay tercih edilmeli
            is Action.Sequence -> action.steps.forEach { execute(it) }
            is Action.SetVariable -> when (action.mode) {
                "SET" -> com.bigboss.app.engine.VariableStore.set(action.name, action.delta)
                else -> com.bigboss.app.engine.VariableStore.increment(action.name, action.delta)
            }
            is Action.CallFunction -> { /* RuleEngine bunu kendisi yönetir, buraya gelmemeli */ }
            is Action.RunScript -> com.bigboss.app.engine.ScriptRuntime.engine?.run(action.code)
            Action.NoOp -> { /* hiçbir şey yapma */ }
        }
    }

    private fun dispatchTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
