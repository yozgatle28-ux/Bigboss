package com.bigboss.app.engine.script

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor
import com.bigboss.app.engine.ImageMatcher
import com.bigboss.app.engine.TextMatcher
import com.bigboss.app.engine.VariableStore
import com.bigboss.app.engine.colorSimilarity
import com.bigboss.app.model.Region
import com.bigboss.app.storage.LibraryStorage

/** Bir script çalıştırıldığında ihtiyaç duyduğu dış bağlamlar. */
class ScriptContext(
    var androidContext: Context,
    var currentFrame: Bitmap? = null,
    var executor: ActionExecutor? = null
) {
    val consoleLog = mutableListOf<String>()
}

/** BigScript'in yerleşik (built-in) fonksiyonlarını global ortama kaydeder. */
object ScriptBridge {

    fun install(env: Environment, ctx: ScriptContext) {
        env.define("click", NativeFunction("click") { args ->
            val x = Interpreter.asNumber(args.getOrNull(0)).toInt()
            val y = Interpreter.asNumber(args.getOrNull(1)).toInt()
            ctx.executor?.execute(Action.Tap(x, y))
            null
        })

        env.define("swipe", NativeFunction("swipe") { args ->
            val x1 = Interpreter.asNumber(args.getOrNull(0)).toInt()
            val y1 = Interpreter.asNumber(args.getOrNull(1)).toInt()
            val x2 = Interpreter.asNumber(args.getOrNull(2)).toInt()
            val y2 = Interpreter.asNumber(args.getOrNull(3)).toInt()
            val ms = args.getOrNull(4)?.let { Interpreter.asNumber(it).toLong() } ?: 300L
            ctx.executor?.execute(Action.Swipe(x1, y1, x2, y2, ms))
            null
        })

        env.define("wait", NativeFunction("wait") { args ->
            val ms = Interpreter.asNumber(args.getOrNull(0)).toLong()
            try { Thread.sleep(ms) } catch (e: InterruptedException) { }
            null
        })

        env.define("Con", NativeNamespace("Con", mapOf(
            "out" to NativeFunction("out") { args ->
                val msg = Interpreter.stringify(args.getOrNull(0))
                ctx.consoleLog.add(msg)
                if (ctx.consoleLog.size > 200) ctx.consoleLog.removeAt(0)
                Log.d("BigScript", msg)
                null
            }
        )))

        env.define("Var", NativeNamespace("Var", mapOf(
            "get" to NativeFunction("get") { args ->
                VariableStore.get(Interpreter.stringify(args.getOrNull(0))).toDouble()
            },
            "set" to NativeFunction("set") { args ->
                VariableStore.set(Interpreter.stringify(args.getOrNull(0)), Interpreter.asNumber(args.getOrNull(1)).toInt())
                null
            },
            "increment" to NativeFunction("increment") { args ->
                val delta = args.getOrNull(1)?.let { Interpreter.asNumber(it).toInt() } ?: 1
                VariableStore.increment(Interpreter.stringify(args.getOrNull(0)), delta)
                null
            }
        )))

        env.define("Detect", NativeNamespace("Detect", mapOf(
            "color" to NativeFunction("color") { args ->
                val frame = ctx.currentFrame ?: return@NativeFunction false
                val x = Interpreter.asNumber(args[0]).toInt()
                val y = Interpreter.asNumber(args[1]).toInt()
                val w = Interpreter.asNumber(args[2]).toInt()
                val h = Interpreter.asNumber(args[3]).toInt()
                val hex = Interpreter.stringify(args[4])
                val minScore = args.getOrNull(5)?.let { Interpreter.asNumber(it) } ?: 0.85
                val target = try { Color.parseColor(hex) } catch (e: Exception) { return@NativeFunction false }
                var best = 0f
                val step = 4
                var yy = y.coerceAtLeast(0)
                val maxY = (y + h).coerceAtMost(frame.height)
                val maxX = (x + w).coerceAtMost(frame.width)
                while (yy < maxY) {
                    var xx = x.coerceAtLeast(0)
                    while (xx < maxX) {
                        val sim = colorSimilarity(frame.getPixel(xx, yy), target)
                        if (sim > best) best = sim
                        xx += step
                    }
                    yy += step
                }
                best >= minScore
            },
            "image" to NativeFunction("image") { args ->
                val frame = ctx.currentFrame ?: return@NativeFunction false
                val name = Interpreter.stringify(args[0])
                val x = Interpreter.asNumber(args[1]).toInt()
                val y = Interpreter.asNumber(args[2]).toInt()
                val w = Interpreter.asNumber(args[3]).toInt()
                val h = Interpreter.asNumber(args[4]).toInt()
                val minScore = args.getOrNull(5)?.let { Interpreter.asNumber(it) } ?: 0.8
                val item = LibraryStorage.load(ctx.androidContext).find { it.name == name && it.kind == "IMAGE" }
                    ?: return@NativeFunction false
                val path = item.templatePath ?: return@NativeFunction false
                val score = ImageMatcher.bestScore(frame, Region(x, y, w, h), path, 8)
                score >= minScore
            },
            "text" to NativeFunction("text") { args ->
                val frame = ctx.currentFrame ?: return@NativeFunction false
                val x = Interpreter.asNumber(args[0]).toInt()
                val y = Interpreter.asNumber(args[1]).toInt()
                val w = Interpreter.asNumber(args[2]).toInt()
                val h = Interpreter.asNumber(args[3]).toInt()
                val text = Interpreter.stringify(args[4])
                TextMatcher.contains(frame, Region(x, y, w, h), text) >= 0.5f
            }
        )))
    }
}
