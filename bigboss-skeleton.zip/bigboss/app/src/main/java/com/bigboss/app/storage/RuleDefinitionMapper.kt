package com.bigboss.app.storage

import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule/Condition/Action nesnelerine çevirir.
 */
object RuleDefinitionMapper {

    fun toCondition(def: RuleDefinition): Condition {
        val region = Region(def.condX, def.condY, def.condWidth.coerceAtLeast(1), def.condHeight.coerceAtLeast(1))
        val minScoreFraction = (def.minScore.coerceIn(0, 100)) / 100f
        return if (def.conditionKind == "IMAGE" && !def.templatePath.isNullOrBlank()) {
            Condition.ImageInRegion(region, def.templatePath!!, minScoreFraction)
        } else {
            Condition.ColorInRegion(region, def.condColor, minScoreFraction)
        }
    }

    fun toAction(def: RuleDefinition): Action = when (def.actionType) {
        "SWIPE" -> Action.Swipe(
            x1 = def.actionX, y1 = def.actionY,
            x2 = def.actionX2, y2 = def.actionY2,
            durationMs = def.swipeDurationMs
        )
        else -> Action.Tap(def.actionX, def.actionY)
    }

    fun toRule(def: RuleDefinition): Rule = Rule(
        id = def.id,
        name = def.name,
        condition = toCondition(def),
        thenAction = toAction(def),
        timeoutMs = def.timeoutMs,
        enabled = def.enabled
    )

    /** Sadece etkin (enabled) kuralları, tanımlandıkları sırayla Rule'a çevirir. */
    fun toRules(definitions: List<RuleDefinition>): List<Rule> =
        definitions.filter { it.enabled }.map { toRule(it) }
}
