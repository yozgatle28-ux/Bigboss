package com.bigboss.app.storage

import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule/Condition/Action nesnelerine çevirir.
 */
object RuleDefinitionMapper {

    private fun toSingleCondition(alt: ConditionAlt): Condition {
        val region = Region(alt.x, alt.y, alt.width.coerceAtLeast(1), alt.height.coerceAtLeast(1))
        val minScoreFraction = alt.minScore.coerceIn(0, 100) / 100f
        return when (alt.conditionKind) {
            "IMAGE" -> Condition.ImageInRegion(region, alt.templatePath ?: "", minScoreFraction)
            "TEXT" -> Condition.TextInRegion(region, alt.expectedText ?: "", 0.5f)
            else -> Condition.ColorInRegion(region, alt.color, minScoreFraction)
        }
    }

    fun toCondition(def: RuleDefinition): Condition {
        val altList = def.alternatives.ifEmpty {
            // Geriye dönük uyumluluk / boş güvenlik: en az bir alternatif olmalı
            listOf(ConditionAlt())
        }
        val mainCondition: Condition = if (altList.size == 1) {
            toSingleCondition(altList[0])
        } else {
            Condition.Group(altList.map { toSingleCondition(it) }, Condition.GroupLogic.ONE_SUCCESS)
        }

        val variableName = def.requireVariableName
        return if (!variableName.isNullOrBlank()) {
            val variableCondition = Condition.VariableCompare(variableName, def.requireVariableOp, def.requireVariableValue)
            Condition.Group(listOf(mainCondition, variableCondition), Condition.GroupLogic.ALL_SUCCESS)
        } else {
            mainCondition
        }
    }

    fun toAction(def: RuleDefinition): Action {
        val baseAction: Action = when (def.actionType) {
            "SWIPE" -> Action.Swipe(
                x1 = def.actionX, y1 = def.actionY,
                x2 = def.actionX2, y2 = def.actionY2,
                durationMs = def.swipeDurationMs
            )
            "WAIT" -> Action.NoOp
            else -> Action.Tap(def.actionX, def.actionY)
        }

        val varName = def.incrementVariableName
        return if (!varName.isNullOrBlank()) {
            Action.Sequence(listOf(
                baseAction,
                Action.SetVariable(varName, def.incrementVariableDelta, def.incrementVariableMode)
            ))
        } else {
            baseAction
        }
    }

    fun toRule(def: RuleDefinition): Rule = Rule(
        id = def.id,
        name = def.name,
        condition = toCondition(def),
        thenAction = toAction(def),
        timeoutMs = def.timeoutMs,
        enabled = def.enabled,
        negate = def.negateCondition,
        loopMode = def.loopMode,
        maxLoopCount = def.maxLoopCount
    )

    /** Sadece etkin (enabled) kuralları, tanımlandıkları sırayla Rule'a çevirir. */
    fun toRules(definitions: List<RuleDefinition>): List<Rule> =
        definitions.filter { it.enabled }.map { toRule(it) }
}
