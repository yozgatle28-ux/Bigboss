package com.bigboss.app.storage

import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule listesine çevirir. Liste sırası = if/else-if önceliği.
 */
object RuleDefinitionMapper {

    fun toRules(definitions: List<RuleDefinition>): List<Rule> {
        return definitions.filter { it.enabled }.map { def ->
            Rule(
                id = def.id,
                name = def.name,
                condition = Condition.ColorInRegion(
                    region = Region(def.condX, def.condY, def.condWidth.coerceAtLeast(1), def.condHeight.coerceAtLeast(1)),
                    targetColor = def.condColor,
                    tolerance = def.tolerance
                ),
                thenAction = when (def.actionType) {
                    "SWIPE" -> Action.Swipe(
                        x1 = def.actionX, y1 = def.actionY,
                        x2 = def.actionX2, y2 = def.actionY2,
                        durationMs = def.swipeDurationMs
                    )
                    else -> Action.Tap(def.actionX, def.actionY)
                },
                elseIf = null // sıra zaten RuleEngine'de üst seviye zincir görevi görüyor
            )
        }
    }
}
