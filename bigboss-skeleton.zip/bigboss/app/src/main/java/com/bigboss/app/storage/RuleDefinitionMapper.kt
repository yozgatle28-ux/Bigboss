package com.bigboss.app.storage

import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule/Condition/Action nesnelerine çevirir.
 */
object RuleDefinitionMapper {

    private fun toSingleCondition(alt: ConditionAlt): Condition {
        val region = Region(alt.x, alt.y, alt.width.coerceAtLeast(1), alt.height.coerceAtLeast(1))
        val minScoreFraction = alt.minScore.coerceIn(0, 100) / 100f
        return when (alt.conditionKind) {
            "IMAGE" -> Condition.ImageInRegion(region, alt.templatePath ?: "", minScoreFraction)
            "TEXT" -> Condition.TextInRegion(region, alt.expectedText ?: "", 0.5f)
            else -> Condition.ColorInRegion(region, alt.color, minScoreFraction)
        }
    }

    fun toCondition(def: RuleDefinition): Condition {
        val altList = def.alternatives.ifEmpty {
            // Geriye dönük uyumluluk / boş güvenlik: en az bir alternatif olmalı
            listOf(ConditionAlt())
        }
        val mainCondition: Condition = if (altList.size == 1) {
            toSingleCondition(altList[0])
        } else {
            Condition.Group(altList.map { toSingleCondition(it) }, Condition.GroupLogic.ONE_SUCCESS)
        }

        val variableName = def.requireVariableName
        return if (!variableName.isNullOrBlank()) {
            val variableCondition = Condition.VariableCompare(variableName, def.requireVariableOp, def.requireVariableValue)
            Condition.Group(listOf(mainCondition, variableCondition), Condition.GroupLogic.ALL_SUCCESS)
        } else {
            mainCondition
        }
    }

    private fun toActionStep(step: com.bigboss.app.storage.ActionStep): Action = when (step.type) {
        "TAP" -> Action.Tap(step.x, step.y, step.repeat.coerceAtLeast(1))
        "SWIPE" -> Action.Swipe(step.x, step.y, step.x2, step.y2, 300)
        "WAIT" -> Action.Wait(step.waitMs)
        "CALL_FUNCTION" -> Action.CallFunction(step.functionId ?: "", step.repeat.coerceAtLeast(1))
        "SET_VARIABLE" -> Action.SetVariable(step.variableName, step.variableDelta)
        "RUN_SCRIPT" -> Action.RunScript(step.scriptCode ?: "")
        else -> Action.NoOp
    }

    fun toAction(def: RuleDefinition): Action {
        val baseAction: Action = when (def.actionType) {
            "SWIPE" -> Action.Swipe(
                x1 = def.actionX, y1 = def.actionY,
                x2 = def.actionX2, y2 = def.actionY2,
                durationMs = def.swipeDurationMs
            )
            "WAIT" -> Action.NoOp
            "CALL_FUNCTION" -> Action.CallFunction(def.callFunctionId ?: "", def.callFunctionRepeat.coerceAtLeast(1))
            else -> if (def.tapAtMatchLocation) {
                Action.TapAtMatch(def.actionRepeatCount.coerceAtLeast(1))
            } else {
                Action.Tap(def.actionX, def.actionY, def.actionRepeatCount.coerceAtLeast(1))
            }
        }

        val steps = mutableListOf(baseAction)
        val varName = def.incrementVariableName
        if (!varName.isNullOrBlank()) steps.add(Action.SetVariable(varName, def.incrementVariableDelta, def.incrementVariableMode))
        def.extraSteps.forEach { steps.add(toActionStep(it)) }

        return if (steps.size == 1) steps[0] else Action.Sequence(steps)
    }

    fun toRule(def: RuleDefinition): Rule = Rule(
        id = def.id,
        name = def.name,
        condition = toCondition(def),
        thenAction = toAction(def),
        cooldownMs = if (def.timeoutMs < 0) 0 else def.timeoutMs,
        enabled = def.enabled,
        negate = def.negateCondition,
        loopMode = def.loopMode,
        matchDelayMs = def.matchDelayMs
    )

    /** Sadece etkin (enabled) kuralları, tanımlandıkları sırayla Rule'a çevirir. */
    fun toRules(definitions: List<RuleDefinition>): List<Rule> =
        definitions.filter { it.enabled }.map { toRule(it) }
}
