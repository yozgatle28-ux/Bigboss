package com.bigboss.app.storage

import android.content.Context
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule/Condition/Action nesnelerine çevirir.
 */
object RuleDefinitionMapper {

    private fun toSingleCondition(alt: ConditionAlt): Condition {
        val region = Region(alt.x, alt.y, alt.width.coerceAtLeast(1), alt.height.coerceAtLeast(1))
        val minScoreFraction = alt.minScore.coerceIn(0, 100) / 100f
        return when (alt.conditionKind) {
            "IMAGE" -> Condition.ImageInRegion(region, alt.templatePath ?: "", minScoreFraction)
            "TEXT" -> Condition.TextInRegion(region, alt.expectedText ?: "", minScoreFraction, alt.textCaseSensitive, alt.textWhitelist, alt.textBlacklist)
            // Macrorify "Conditional" tipleri — ekran taramasından bağımsız mantıksal koşullar:
            "VARIABLE" -> Condition.VariableCompare(alt.variableName, alt.variableOp, alt.compareValue)
            "CUSTOM" -> Condition.Script(alt.customCode)
            else -> Condition.ColorInRegion(region, alt.color, minScoreFraction)
        }
    }

    fun toCondition(def: RuleDefinition): Condition {
        if (def.alternatives.isEmpty()) return Condition.Always // koşulsuz adım (sadece dokunma/kaydırma gibi)
        val altList = def.alternatives
        val mainCondition: Condition = if (altList.size == 1) {
            toSingleCondition(altList[0])
        } else {
            val logic = try { Condition.GroupLogic.valueOf(def.alternativesLogic) } catch (e: Exception) { Condition.GroupLogic.ONE_SUCCESS }
            Condition.Group(altList.map { toSingleCondition(it) }, logic)
        }

        val extraGates = mutableListOf<Condition>()
        val variableName = def.requireVariableName
        if (!variableName.isNullOrBlank()) {
            extraGates.add(Condition.VariableCompare(variableName, def.requireVariableOp, def.requireVariableValue))
        }
        if (def.randomChancePercent in 0..99) {
            extraGates.add(Condition.Random(def.randomChancePercent))
        }

        return if (extraGates.isEmpty()) mainCondition
        else Condition.Group(listOf(mainCondition) + extraGates, Condition.GroupLogic.ALL_SUCCESS)
    }

    /**
     * Bir alan bir değişkene bağlıysa GÜNCEL sayısal değerini, değilse sabit değeri döner.
     * Birleşik değişken sistemi: önce çalışma-zamanı VariableStore'a (setVar/Set Variable ile
     * güncellenen canlı değer), o yoksa kalıcı GlobalVariableStorage'a bakar.
     */
    private fun resolve(context: Context?, varName: String?, fallback: Long): Long {
        if (varName.isNullOrBlank()) return fallback
        // 1) Çalışma zamanı deposu (en güncel — script/aksiyonlarla değişmiş olabilir)
        if (com.bigboss.app.engine.VariableStore.getRaw(varName) != null) {
            return com.bigboss.app.engine.VariableStore.getNumber(varName).toLong()
        }
        // 2) Kalıcı depo (Context varsa)
        if (context != null) {
            com.bigboss.app.storage.GlobalVariableStorage.valueOf(context, varName)?.let { return it }
        }
        return fallback
    }

    private fun toActionStep(step: com.bigboss.app.storage.ActionStep): Action = when (step.type) {
        "TAP" -> Action.Tap(step.x, step.y, step.repeat.coerceAtLeast(1), step.holdMs.coerceAtLeast(1), step.postDelayMs)
        "SWIPE" -> Action.Swipe(step.x, step.y, step.x2, step.y2, 300, step.swipeHoldStartMs, step.swipeHoldEndMs, step.postDelayMs)
        "WAIT" -> Action.Wait(step.waitMs)
        "CALL_FUNCTION" -> Action.CallFunction(step.functionId ?: "", step.repeat.coerceAtLeast(1))
        "SET_VARIABLE" -> Action.SetVariable(step.variableName, step.variableDelta)
        "RUN_SCRIPT" -> Action.RunScript(step.scriptCode ?: "", step.scriptLanguage)
        "SYSTEM_BACK" -> Action.SystemAction("BACK")
        "SYSTEM_HOME" -> Action.SystemAction("HOME")
        "SYSTEM_RECENTS" -> Action.SystemAction("RECENTS")
        "SYSTEM_NOTIFICATIONS" -> Action.SystemAction("NOTIFICATIONS")
        "SYSTEM_QUICK_SETTINGS" -> Action.SystemAction("QUICK_SETTINGS")
        "READ_TEXT" -> Action.ReadTextToVariable(step.x, step.y, step.x2, step.y2, step.variableName, step.readDefaultValue, step.readWhitelist, step.readBlacklist)
        else -> Action.NoOp
    }

    fun toAction(def: RuleDefinition, context: Context? = null): Action {
        val effectiveHold = resolve(context, def.actionHoldVarName, def.actionHoldMs).coerceAtLeast(1)
        val effectivePostDelay = resolve(context, def.actionPostDelayVarName, def.actionPostDelayMs).coerceAtLeast(0)
        val effectiveSwipeHoldStart = resolve(context, def.swipeHoldStartVarName, def.swipeHoldStartMs).coerceAtLeast(0)
        val effectiveSwipeHoldEnd = resolve(context, def.swipeHoldEndVarName, def.swipeHoldEndMs).coerceAtLeast(0)
        // Macrorify "her input alanında değişken" — repeat/randomize/duration/koordinat da bağlanabilir:
        val effectiveRepeat = resolve(context, def.actionRepeatVarName, def.actionRepeatCount.toLong()).toInt().coerceAtLeast(1)
        val effectiveRandom = resolve(context, def.randomOffsetVarName, def.randomOffsetPx.toLong()).toInt().coerceAtLeast(0)
        val effectiveDuration = resolve(context, def.swipeDurationVarName, def.swipeDurationMs)
        val effX = resolve(context, def.actionXVarName, def.actionX.toLong()).toInt()
        val effY = resolve(context, def.actionYVarName, def.actionY.toLong()).toInt()
        val effX2 = resolve(context, def.actionX2VarName, def.actionX2.toLong()).toInt()
        val effY2 = resolve(context, def.actionY2VarName, def.actionY2.toLong()).toInt()

        val baseAction: Action = when (def.actionType) {
            "SWIPE" -> if (def.swipePathPoints.size > 2) {
                Action.MultiPointSwipe(
                    points = def.swipePathPoints.map { Action.SwipePointDef(it.x, it.y, it.holdMs) },
                    segmentDurationMs = effectiveDuration,
                    postDelayMs = effectivePostDelay,
                    randomOffsetPx = effectiveRandom
                )
            } else Action.Swipe(
                x1 = effX, y1 = effY,
                x2 = effX2, y2 = effY2,
                durationMs = effectiveDuration,
                holdStartMs = effectiveSwipeHoldStart,
                holdEndMs = effectiveSwipeHoldEnd,
                postDelayMs = effectivePostDelay,
                randomOffsetPx = effectiveRandom
            )
            "WAIT" -> Action.NoOp
            "SYSTEM_BACK" -> Action.SystemAction("BACK")
            "SYSTEM_HOME" -> Action.SystemAction("HOME")
            "SYSTEM_RECENTS" -> Action.SystemAction("RECENTS")
            "SYSTEM_NOTIFICATIONS" -> Action.SystemAction("NOTIFICATIONS")
            "SYSTEM_QUICK_SETTINGS" -> Action.SystemAction("QUICK_SETTINGS")
            "CALL_FUNCTION" -> Action.CallFunction(def.callFunctionId ?: "", def.callFunctionRepeat.coerceAtLeast(1))
            else -> if (def.tapAtMatchLocation) {
                Action.TapAtMatch(effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
            } else {
                Action.Tap(effX, effY, effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
            }
        }

        val steps = mutableListOf(baseAction)
        val varName = def.incrementVariableName
        if (!varName.isNullOrBlank()) steps.add(Action.SetVariable(varName, def.incrementVariableDelta, def.incrementVariableMode))
        def.extraSteps.forEach { steps.add(toActionStep(it)) }

        return if (steps.size == 1) steps[0] else Action.Sequence(steps)
    }

    fun toRule(def: RuleDefinition, context: Context? = null): Rule = Rule(
        id = def.id,
        name = def.name,
        condition = toCondition(def),
        thenAction = toAction(def, context),
        cooldownMs = if (def.timeoutMs < 0) 0 else def.timeoutMs,
        enabled = def.enabled,
        negate = def.negateCondition,
        loopMode = def.loopMode,
        matchDelayMs = def.matchDelayMs,
        scanTimeoutMs = def.scanTimeoutMs,
        scanRateHz = def.scanRateHz,
        maxConsecutiveFailures = def.maxConsecutiveFailures
    )

    /** Sadece etkin (enabled) kuralları, tanımlandıkları sırayla Rule'a çevirir. */
    fun toRules(definitions: List<RuleDefinition>, context: Context? = null): List<Rule> =
        definitions.filter { it.enabled }.map { toRule(it, context) }
}
