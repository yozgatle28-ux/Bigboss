package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Kurallar RuleEngine tarafından SIRAYLA (script gibi) çalıştırılır —
 * listedeki sıra, kuralların çalışma sırasıdır.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    /** Macrorify'daki "Grouping" fikri: kuralları organize etmek için isteğe bağlı etiket. */
    var groupName: String? = null,

    // ---- Koşul (IF): bir ya da birden fazla (VEYA'lı) alternatif ----
    var alternatives: MutableList<ConditionAlt> = mutableListOf(),
    /** Macrorify'daki "Multi Detection Logic": 2+ alternatif varken bunlar nasıl birleşsin.
     *  "ONE_SUCCESS"(VEYA) | "ALL_SUCCESS"(VE) | "ALL_FAIL" | "ONE_FAIL" | "ALWAYS_SUCCESS" | "ALWAYS_FAIL" */
    var alternativesLogic: String = "ONE_SUCCESS",
    /** "Wait Next": bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmeli (spam önleme). */
    var timeoutMs: Long = 300,
    /** true ise "Wait till vanish": koşul KAYBOLUNCA (eşleşmeyince) tetiklenir. */
    var negateCondition: Boolean = false,
    /** "NONE" | "ALWAYS" | "WHILE_SUCCESS" | "WHILE_FAIL" */
    var loopMode: String = "ALWAYS",
    /** Loop üst sınırı. 0 = sınırsız. (Şu an sadece geriye dönük uyumluluk için tutuluyor.) */
    var maxLoopCount: Int = 0,
    /** Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre (ms). */
    var matchDelayMs: Long = 0,
    /** "Tarama Süresi" (Timeout): koşul tetiklenmeden önce en az bu kadar ms SÜREKLİ doğru kalmalı. 0 = anında. */
    var scanTimeoutMs: Long = 0,
    /** Macrorify'daki "Scan Rate": saniyede en fazla kaç kere kontrol edilsin (pil tasarrufu). 0 = sınırsız. */
    var scanRateHz: Float = 0f,
    /** "Otomatik Durdurma": bu kural art arda kaç kere BULUNAMAZSA (tetiklenmeden) kendini devre dışı bıraksın. 0 = sınırsız. */
    var maxConsecutiveFailures: Int = 0,

    // ---- İsteğe bağlı ek şart: bir değişken/sayaç karşılaştırması ----
    var requireVariableName: String? = null,
    /** ">=", "<=", "==", ">", "<" */
    var requireVariableOp: String = ">=",
    var requireVariableValue: Int = 0,

    // ---- Aksiyon (THEN) ----
    /** "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" */
    var actionType: String = "TAP",
    var actionX: Int = 0,
    var actionY: Int = 0,
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300,
    /** Macrorify'daki "Swipe Path": 2'den FAZLA nokta varsa burası kullanılır. Boşsa (eski kurallar),
     *  aşağıdaki actionX/Y/X2/Y2 + swipeHoldStartMs/EndMs ile eski basit 2-noktalı davranış korunur. */
    var swipePathPoints: MutableList<SwipePointData> = mutableListOf(),
    /** Kaydırma başlangıç noktasında hareket etmeden önce kaç ms basılı beklensin (sürükle-bırak için). */
    var swipeHoldStartMs: Long = 0,
    /** Kaydırma bitiş noktasında parmağı kaldırmadan önce kaç ms daha basılı tutulsun. */
    var swipeHoldEndMs: Long = 0,
    /** true ise sabit koordinat yerine, koşulun BULDUĞU konuma tıklanır ("Eşleşen Noktaya Tıkla"). */
    var tapAtMatchLocation: Boolean = false,
    /** Dokunma kaç kere tekrarlansın. */
    var actionRepeatCount: Int = 1,
    /** "HOLD": eşleşen/sabit noktada kaç ms basılı tutulsun. */
    var actionHoldMs: Long = 50,
    /** "DELAY": işlem TAMAMLANDIKTAN SONRA, sıradaki işleme geçmeden önce kaç ms beklensin. */
    var actionPostDelayMs: Long = 0,
    /** "Randomize": her noktaya ±bu kadar piksel rastgele sapma eklenir (daha insani/tespit-karşıtı). */
    var randomOffsetPx: Int = 0,
    /** "Random Condition": eşleşme bulunsa bile, sadece bu yüzdelik ŞANSLA tetiklenir. 100 = her zaman (kapalı). */
    var randomChancePercent: Int = 100,
    /** Bu alanlar doluysa, yukarıdaki sabit değer YERİNE aşağıdaki isimli Değişkenin GÜNCEL değeri kullanılır. */
    var actionHoldVarName: String? = null,
    var actionPostDelayVarName: String? = null,
    var swipeHoldStartVarName: String? = null,
    var swipeHoldEndVarName: String? = null,
    /** actionType = "CALL_FUNCTION" için: çağrılacak fonksiyonun id'si */
    var callFunctionId: String? = null,
    var callFunctionRepeat: Int = 1,
    /** "BAŞARILI OLUNCA" sekmesinde eklenen, birincil aksiyondan SONRA SIRAYLA çalışacak adımlar. */
    var extraSteps: MutableList<ActionStep> = mutableListOf(),

    // ---- İsteğe bağlı ek etki: bir sayaç değişkenini güncelle ----
    var incrementVariableName: String? = null,
    var incrementVariableDelta: Int = 1,
    /** "INCREMENT" ya da "SET" */
    var incrementVariableMode: String = "INCREMENT"
)
