package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Not: RuleEngine zaten üst-seviye kural listesini sırayla gezip ilk
 * eşleşende durduğu için, ayrı bir "elseIf" alanına gerek yok — listedeki
 * SIRA, senin if/else-if zincirini oluşturuyor. Kuralları yukarı/aşağı
 * taşıyarak önceliği değiştirebilirsin.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    // ---- Koşul (IF): bir BÖLGE içinde bu renk aranıyor ----
    var condX: Int,
    var condY: Int,
    var condWidth: Int = 1,
    var condHeight: Int = 1,
    var condColor: Int,
    var tolerance: Int = 24,

    // ---- Aksiyon (THEN) ----
    /** "TAP" ya da "SWIPE" */
    var actionType: String = "TAP",

    // TAP için tek nokta; SWIPE için başlangıç noktası
    var actionX: Int,
    var actionY: Int,

    // Sadece actionType = "SWIPE" olduğunda kullanılır (bitiş noktası)
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300
)
