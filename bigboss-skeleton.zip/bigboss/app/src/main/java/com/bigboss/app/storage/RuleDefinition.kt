package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Kurallar RuleEngine tarafından SIRAYLA (script gibi) çalıştırılır —
 * listedeki sıra, kuralların çalışma sırasıdır.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    /** Macrorify'daki "Grouping" fikri: kuralları organize etmek için isteğe bağlı etiket. */
    var groupName: String? = null,

    // ---- Koşul (IF): bir ya da birden fazla (VEYA'lı) alternatif ----
    var alternatives: MutableList<ConditionAlt> = mutableListOf(),
    /** "Wait Next": bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmeli (spam önleme). */
    var timeoutMs: Long = 300,
    /** true ise "Wait till vanish": koşul KAYBOLUNCA (eşleşmeyince) tetiklenir. */
    var negateCondition: Boolean = false,
    /** "NONE" | "ALWAYS" | "WHILE_SUCCESS" | "WHILE_FAIL" */
    var loopMode: String = "ALWAYS",
    /** Loop üst sınırı. 0 = sınırsız. (Şu an sadece geriye dönük uyumluluk için tutuluyor.) */
    var maxLoopCount: Int = 0,
    /** Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre (ms). */
    var matchDelayMs: Long = 0,

    // ---- İsteğe bağlı ek şart: bir değişken/sayaç karşılaştırması ----
    var requireVariableName: String? = null,
    /** ">=", "<=", "==", ">", "<" */
    var requireVariableOp: String = ">=",
    var requireVariableValue: Int = 0,

    // ---- Aksiyon (THEN) ----
    /** "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" */
    var actionType: String = "TAP",
    var actionX: Int = 0,
    var actionY: Int = 0,
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300,
    /** true ise sabit koordinat yerine, koşulun BULDUĞU konuma tıklanır ("Eşleşen Noktaya Tıkla"). */
    var tapAtMatchLocation: Boolean = false,
    /** Dokunma kaç kere tekrarlansın. */
    var actionRepeatCount: Int = 1,
    /** "HOLD": eşleşen/sabit noktada kaç ms basılı tutulsun. */
    var actionHoldMs: Long = 50,
    /** actionType = "CALL_FUNCTION" için: çağrılacak fonksiyonun id'si */
    var callFunctionId: String? = null,
    var callFunctionRepeat: Int = 1,
    /** "BAŞARILI OLUNCA" sekmesinde eklenen, birincil aksiyondan SONRA SIRAYLA çalışacak adımlar. */
    var extraSteps: MutableList<ActionStep> = mutableListOf(),

    // ---- İsteğe bağlı ek etki: bir sayaç değişkenini güncelle ----
    var incrementVariableName: String? = null,
    var incrementVariableDelta: Int = 1,
    /** "INCREMENT" ya da "SET" */
    var incrementVariableMode: String = "INCREMENT"
)
