package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak) oluşturulan, JSON'a kolayca çevrilebilen
 * düz (flat) kural modeli. RuleEngine'in kullandığı Condition/Action
 * nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Not: RuleEngine zaten üst-seviye kural listesini sırayla gezip ilk
 * eşleşende durduğu için, ayrı bir "elseIf" alanına gerek yok — listedeki
 * SIRA, senin if/else-if zincirini oluşturuyor. Kuralları yukarı/aşağı
 * taşıyarak önceliği değiştirebilirsin.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    // ---- Koşul (IF) ----
    var condX: Int,
    var condY: Int,
    var condColor: Int,
    var tolerance: Int = 24,

    // ---- Aksiyon (THEN) ----
    var actionX: Int,
    var actionY: Int
)
