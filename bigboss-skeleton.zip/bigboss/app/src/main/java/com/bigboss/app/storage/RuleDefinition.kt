package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Kurallar RuleEngine tarafından SIRAYLA (script gibi) çalıştırılır —
 * listedeki sıra, kuralların çalışma sırasıdır.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    /** Macrorify'daki "Grouping" fikri: kuralları organize etmek için isteğe bağlı etiket. */
    var groupName: String? = null,

    // ---- Koşul (IF): bir ya da birden fazla (VEYA'lı) alternatif ----
    var alternatives: MutableList<ConditionAlt> = mutableListOf(),
    /** Bu koşulu en fazla kaç ms arayacağız. -1 = süresiz. */
    var timeoutMs: Long = 3000,

    // ---- İsteğe bağlı ek şart: bir değişken/sayaç karşılaştırması ----
    var requireVariableName: String? = null,
    /** ">=", "<=", "==", ">", "<" */
    var requireVariableOp: String = ">=",
    var requireVariableValue: Int = 0,

    // ---- Aksiyon (THEN) ----
    /** "TAP" ya da "SWIPE" */
    var actionType: String = "TAP",
    var actionX: Int = 0,
    var actionY: Int = 0,
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300,

    // ---- İsteğe bağlı ek etki: bir sayaç değişkenini güncelle ----
    var incrementVariableName: String? = null,
    var incrementVariableDelta: Int = 1,
    /** "INCREMENT" ya da "SET" */
    var incrementVariableMode: String = "INCREMENT"
)
