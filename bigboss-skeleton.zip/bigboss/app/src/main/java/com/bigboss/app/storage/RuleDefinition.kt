package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Kurallar RuleEngine tarafından SIRAYLA (script gibi) çalıştırılır —
 * listedeki sıra, kuralların çalışma sırasıdır.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    // ---- Koşul (IF): bir BÖLGE içinde renk ya da resim aranıyor ----
    /** "COLOR" ya da "IMAGE" */
    var conditionKind: String = "COLOR",
    var condX: Int,
    var condY: Int,
    var condWidth: Int = 1,
    var condHeight: Int = 1,
    var condColor: Int = 0,
    /** conditionKind = "IMAGE" olduğunda dolu olur: kaydedilmiş şablon PNG dosya yolu */
    var templatePath: String? = null,
    /** 0-100 arası minimum eşleşme skoru (Macrorify'daki "Min Score") */
    var minScore: Int = 85,
    /** Bu koşulu en fazla kaç ms arayacağız. -1 = süresiz. */
    var timeoutMs: Long = 3000,

    // ---- Aksiyon (THEN) ----
    /** "TAP" ya da "SWIPE" */
    var actionType: String = "TAP",
    var actionX: Int,
    var actionY: Int,
    // Sadece actionType = "SWIPE" olduğunda kullanılır (bitiş noktası)
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300
)
