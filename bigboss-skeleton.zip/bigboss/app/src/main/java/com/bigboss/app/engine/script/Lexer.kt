package com.bigboss.app.engine.script

/**
 * BigBoss'un kendi kod sistemi — Macrorify'ın EMScript'inden ilham
 * alınmış, C tarzı söz dizimli, dinamik tipli bir mini dil.
 * Değişken, if/else, while/do-while/for/foreach, fonksiyon, sınıf
 * (alan+metot+static), dizi, ve BigBoss'a özel yerleşik fonksiyonları
 * (click, swipe, wait, Var, Con, Detect) destekler.
 */
enum class TokType {
    NUMBER, STRING, IDENT, TRUE, FALSE, NULL,
    VAR, FUN, CLASS, IF, ELSE, WHILE, DO, FOR, RETURN, BREAK, CONTINUE, NEW, STATIC, THIS,
    PLUS, MINUS, STAR, SLASH, PERCENT,
    ASSIGN, EQEQ, BANGEQ, LT, GT, LE, GE, AND, OR, BANG,
    LPAREN, RPAREN, LBRACE, RBRACE, LBRACKET, RBRACKET,
    COMMA, SEMI, COLON, DOT, QUESTION, ARROW,
    EOF
}

data class Token(val type: TokType, val text: String, val line: Int, val literal: Any? = null)

class ScriptSyntaxError(message: String) : Exception(message)

class Lexer(private val source: String) {
    private var start = 0
    private var current = 0
    private var line = 1
    private val tokens = mutableListOf<Token>()

    private val keywords = mapOf(
        "var" to TokType.VAR, "fun" to TokType.FUN, "class" to TokType.CLASS,
        "if" to TokType.IF, "else" to TokType.ELSE, "while" to TokType.WHILE,
        "do" to TokType.DO, "for" to TokType.FOR, "return" to TokType.RETURN,
        "break" to TokType.BREAK, "continue" to TokType.CONTINUE, "new" to TokType.NEW,
        "static" to TokType.STATIC, "this" to TokType.THIS,
        "true" to TokType.TRUE, "false" to TokType.FALSE, "null" to TokType.NULL
    )

    fun scan(): List<Token> {
        while (!isAtEnd()) {
            start = current
            scanToken()
        }
        tokens.add(Token(TokType.EOF, "", line))
        return tokens
    }

    private fun isAtEnd() = current >= source.length
    private fun advance(): Char = source[current++]
    private fun peek(): Char = if (isAtEnd()) '\u0000' else source[current]
    private fun peekNext(): Char = if (current + 1 >= source.length) '\u0000' else source[current + 1]
    private fun match(expected: Char): Boolean {
        if (isAtEnd() || source[current] != expected) return false
        current++; return true
    }
    private fun add(type: TokType, literal: Any? = null) {
        tokens.add(Token(type, source.substring(start, current), line, literal))
    }

    private fun scanToken() {
        val c = advance()
        when (c) {
            ' ', '\r', '\t' -> {}
            '\n' -> line++
            '(' -> add(TokType.LPAREN)
            ')' -> add(TokType.RPAREN)
            '{' -> add(TokType.LBRACE)
            '}' -> add(TokType.RBRACE)
            '[' -> add(TokType.LBRACKET)
            ']' -> add(TokType.RBRACKET)
            ',' -> add(TokType.COMMA)
            ';' -> add(TokType.SEMI)
            ':' -> add(TokType.COLON)
            '.' -> add(TokType.DOT)
            '?' -> add(TokType.QUESTION)
            '%' -> add(TokType.PERCENT)
            '+' -> add(TokType.PLUS)
            '-' -> add(TokType.MINUS)
            '*' -> add(TokType.STAR)
            '/' -> {
                if (match('/')) { while (peek() != '\n' && !isAtEnd()) advance() }
                else if (match('*')) {
                    while (!(peek() == '*' && peekNext() == '/') && !isAtEnd()) { if (peek() == '\n') line++; advance() }
                    if (!isAtEnd()) { advance(); advance() }
                } else add(TokType.SLASH)
            }
            '=' -> if (match('=')) add(TokType.EQEQ) else if (match('>')) add(TokType.ARROW) else add(TokType.ASSIGN)
            '!' -> if (match('=')) add(TokType.BANGEQ) else add(TokType.BANG)
            '<' -> if (match('=')) add(TokType.LE) else add(TokType.LT)
            '>' -> if (match('=')) add(TokType.GE) else add(TokType.GT)
            '&' -> if (match('&')) add(TokType.AND) else throw ScriptSyntaxError("Satır $line: beklenmeyen '&'")
            '|' -> if (match('|')) add(TokType.OR) else throw ScriptSyntaxError("Satır $line: beklenmeyen '|'")
            '"' -> string()
            else -> {
                if (c.isDigit()) number()
                else if (c.isLetter() || c == '_') identifier()
                else throw ScriptSyntaxError("Satır $line: beklenmeyen karakter '$c'")
            }
        }
    }

    private fun string() {
        val sb = StringBuilder()
        while (peek() != '"' && !isAtEnd()) {
            if (peek() == '\\') {
                advance()
                when (val esc = advance()) {
                    'n' -> sb.append('\n'); 't' -> sb.append('\t'); '"' -> sb.append('"'); '\\' -> sb.append('\\')
                    else -> sb.append(esc)
                }
            } else {
                if (peek() == '\n') line++
                sb.append(advance())
            }
        }
        if (isAtEnd()) throw ScriptSyntaxError("Satır $line: kapatılmamış string")
        advance() // kapanış "
        add(TokType.STRING, sb.toString())
    }

    private fun number() {
        while (peek().isDigit()) advance()
        if (peek() == '.' && peekNext().isDigit()) { advance(); while (peek().isDigit()) advance() }
        add(TokType.NUMBER, source.substring(start, current).toDouble())
    }

    private fun identifier() {
        while (peek().isLetterOrDigit() || peek() == '_') advance()
        val text = source.substring(start, current)
        val type = keywords[text] ?: TokType.IDENT
        add(type)
    }
}
