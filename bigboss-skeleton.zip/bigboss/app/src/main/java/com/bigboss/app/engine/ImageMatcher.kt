package com.bigboss.app.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.bigboss.app.model.Region
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * GÜNCELLENDİ v2: Normalize Edilmiş Çapraz Korelasyon (NCC — OpenCV'nin
 * matchTemplate/TM_CCOEFF_NORMED'inin aynı matematiksel temeli) artık
 * ÇOKLU ÖLÇEKTE arıyor. Bu, "resim algılama güvenilir değil" şikayetinin
 * en yaygın gerçek sebebini çözüyor: ekranda görünen ikon, kaydettiğin
 * şablonla piksel piksel AYNI boyutta olmayabilir (farklı çözünürlük,
 * hafif animasyon/zoom, DPI farkı) — eskiden bu durumda eşleşme
 * TAMAMEN kaçırılıyordu çünkü sadece TEK bir sabit boyutta aranıyordu.
 *
 * Nasıl çalışıyor:
 *  1) Şablonu VE arama bölgesini piksel dizisine (gri tonlama) BİR KERE
 *     çeviriyor — arama döngüsünde hiç Bitmap işlemi yok.
 *  2) Şablonu birkaç farklı ölçekte (85%-115% arası) dener, her ölçek
 *     için ayrı KABA-İNCE (coarse-to-fine) NCC araması yapar.
 *  3) En iyi skoru veren ölçek + konumu döner.
 *  4) Sonuçlar önbelleğe alınıyor (şablon + hazırlanmış ölçek varyantları)
 *     — tekrar tekrar aynı hesaplama yapılmıyor.
 */
object ImageMatcher {

    private const val MAX_WORKING_SIZE = 96 // şablon bundan büyükse hız için küçültülür (arama için, kırpma değil)
    /** Denenecek ölçek çarpanları — ekran/DPI farklarına karşı tolerans sağlar. */
    private val SCALE_FACTORS = floatArrayOf(1.0f, 0.9f, 1.1f, 0.85f, 1.15f, 0.95f, 1.05f)

    private data class PreparedTemplate(val gray: FloatArray, val w: Int, val h: Int, val normDenom: Float)

    private val templateCache = mutableMapOf<String, Bitmap>()
    /** Anahtar: "yol@ölçek" — her şablon için birden fazla ölçek varyantı önbellekte tutulur. */
    private val preparedCache = mutableMapOf<String, PreparedTemplate>()

    fun bestScore(frame: Bitmap, region: Region, templatePath: String, searchStep: Int): Float =
        bestLocation(frame, region, templatePath, searchStep)?.first ?: 0f

    /** En iyi eşleşmenin skorunu (0-1) VE konumunu (şablonun merkezi) birlikte döner. Çoklu ölçekte arar. */
    fun bestLocation(frame: Bitmap, region: Region, templatePath: String, searchStep: Int): Pair<Float, Pair<Int, Int>>? {
        val template = loadTemplate(templatePath) ?: return null

        val left = region.x.coerceIn(0, frame.width - 1)
        val top = region.y.coerceIn(0, frame.height - 1)
        val searchW = min(region.width, frame.width - left)
        val searchH = min(region.height, frame.height - top)
        if (searchW < 4 || searchH < 4) return null
        val regionGray = toGrayArray(frame, left, top, searchW, searchH) ?: return null

        var overallBest = -2f
        var overallX = 0; var overallY = 0
        var overallTw = 0; var overallTh = 0
        var overallScaleX = 1f; var overallScaleY = 1f

        for (scale in SCALE_FACTORS) {
            val prepared = prepareTemplate(templatePath, template, scale) ?: continue
            val tw = prepared.w; val th = prepared.h
            if (tw < 4 || th < 4 || tw > searchW || th > searchH) continue

            val scaleX = (template.width * scale) / tw
            val scaleY = (template.height * scale) / th

            // ---- 1. AŞAMA: Kaba tarama (şablon boyutuyla orantılı, kaçırmayan adım) ----
            val coarseStep = max(1, min(max(searchStep, 4), max(1, min(tw, th) / 2)))
            var best = -2f; var bestLx = 0; var bestLy = 0
            var y = 0
            while (y + th <= searchH) {
                var x = 0
                while (x + tw <= searchW) {
                    val score = ncc(regionGray, searchW, x, y, prepared)
                    if (score > best) { best = score; bestLx = x; bestLy = y }
                    x += coarseStep
                }
                y += coarseStep
            }

            // ---- 2. AŞAMA: En iyi adayın etrafında piksel-piksel ince arama ----
            val refineRadius = coarseStep
            val fineMinX = max(0, bestLx - refineRadius); val fineMaxX = min(searchW - tw, bestLx + refineRadius)
            val fineMinY = max(0, bestLy - refineRadius); val fineMaxY = min(searchH - th, bestLy + refineRadius)
            var fy = fineMinY
            while (fy <= fineMaxY) {
                var fx = fineMinX
                while (fx <= fineMaxX) {
                    val score = ncc(regionGray, searchW, fx, fy, prepared)
                    if (score > best) { best = score; bestLx = fx; bestLy = fy }
                    fx++
                }
                fy++
            }

            if (best > overallBest) {
                overallBest = best; overallX = bestLx; overallY = bestLy
                overallTw = tw; overallTh = th; overallScaleX = scaleX; overallScaleY = scaleY
            }
            if (overallBest > 0.97f) break // yeterince iyi bir eşleşme bulundu, diğer ölçekleri denemeye gerek yok
        }

        if (overallBest < -1f) return null // hiçbir ölçek uygun değildi
        val finalScore = ((overallBest + 1f) / 2f).coerceIn(0f, 1f) // [-1,1] -> [0,1]
        val centerX = left + ((overallX + overallTw / 2) * overallScaleX).toInt()
        val centerY = top + ((overallY + overallTh / 2) * overallScaleY).toInt()
        return finalScore to (centerX to centerY)
    }

    /** Belirtilen (x,y) konumundaki şablon-boyutlu pencere için Normalize Çapraz Korelasyon skorunu (-1..1) hesaplar. */
    private fun ncc(regionGray: FloatArray, regionW: Int, offX: Int, offY: Int, t: PreparedTemplate): Float {
        var windowSum = 0f
        for (ty in 0 until t.h) {
            val rowBase = (offY + ty) * regionW + offX
            for (tx in 0 until t.w) {
                windowSum += regionGray[rowBase + tx]
            }
        }
        val windowMean = windowSum / (t.w * t.h)

        var numerator = 0f
        var windowVarSum = 0f
        for (ty in 0 until t.h) {
            val rowBase = (offY + ty) * regionW + offX
            val tRowBase = ty * t.w
            for (tx in 0 until t.w) {
                val wv = regionGray[rowBase + tx] - windowMean
                val tv = t.gray[tRowBase + tx] // zaten ortalaması çıkarılmış (mean-centered) olarak saklanıyor
                numerator += wv * tv
                windowVarSum += wv * wv
            }
        }
        val denom = sqrt(windowVarSum) * t.normDenom
        if (denom < 1e-5f) return 0f // düz/tek renkli pencere — anlamlı korelasyon yok
        return (numerator / denom).coerceIn(-1f, 1f)
    }

    /** Şablonu belirli bir ölçekte gri tonlamaya çevirip ortalamasını çıkarır (mean-centered), önbelleğe alır. */
    private fun prepareTemplate(path: String, template: Bitmap, scale: Float): PreparedTemplate? {
        val cacheKey = "$path@$scale"
        preparedCache[cacheKey]?.let { return it }

        val baseScale = min(1f, MAX_WORKING_SIZE.toFloat() / max(template.width, template.height))
        val effectiveScale = baseScale * scale
        val tw = max(4, (template.width * effectiveScale).toInt())
        val th = max(4, (template.height * effectiveScale).toInt())
        if (tw < 4 || th < 4) return null

        val working = Bitmap.createScaledBitmap(template, tw, th, true)
        val gray = toGrayArray(working, 0, 0, tw, th) ?: return null

        var sum = 0f
        for (v in gray) sum += v
        val mean = sum / gray.size
        var varSum = 0f
        for (i in gray.indices) { gray[i] -= mean; varSum += gray[i] * gray[i] }
        val prepared = PreparedTemplate(gray, tw, th, sqrt(varSum))
        preparedCache[cacheKey] = prepared
        return prepared
    }

    /** Bir bitmap bölgesini TEK SEFERDE gri tonlama (luminance) FloatArray'e çevirir — döngüde hiç Bitmap işlemi olmaz. */
    private fun toGrayArray(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): FloatArray? {
        if (x < 0 || y < 0 || x + w > bitmap.width || y + h > bitmap.height || w <= 0 || h <= 0) return null
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, x, y, w, h)
        val gray = FloatArray(w * h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
            gray[i] = 0.299f * r + 0.587f * g + 0.114f * b // standart luminance ağırlıkları
        }
        return gray
    }

    private fun loadTemplate(path: String): Bitmap? {
        templateCache[path]?.let { return it }
        val file = File(path)
        if (!file.exists()) return null
        val bmp = BitmapFactory.decodeFile(path) ?: return null
        templateCache[path] = bmp
        return bmp
    }

    fun clearCache() {
        templateCache.clear()
        preparedCache.clear()
    }
}
