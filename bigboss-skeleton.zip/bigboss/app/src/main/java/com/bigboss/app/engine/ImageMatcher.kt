package com.bigboss.app.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.bigboss.app.model.Region
import java.io.File

/**
 * OpenCV kullanmayan, basit ama işlevsel bir "template matching" motoru.
 * Şablonu ve aday pencereleri küçük bir boyuta indirip (COMPARE_SIZE)
 * piksel piksel karşılaştırır. Büyük bölgelerde/şablonlarda yavaş
 * olabileceğinden, region'ı gereğinden büyük seçmemek performansa yardımcı olur.
 */
object ImageMatcher {

    private const val COMPARE_SIZE = 16
    private val templateCache = mutableMapOf<String, Bitmap>()

    fun bestScore(frame: Bitmap, region: Region, templatePath: String, searchStep: Int): Float {
        val template = loadTemplate(templatePath) ?: return 0f
        val templateSmall = Bitmap.createScaledBitmap(template, COMPARE_SIZE, COMPARE_SIZE, true)

        val tw = template.width.coerceAtLeast(1)
        val th = template.height.coerceAtLeast(1)

        val left = region.x.coerceIn(0, frame.width - 1)
        val top = region.y.coerceIn(0, frame.height - 1)
        val maxX = (region.x + region.width - tw).coerceIn(left, frame.width - tw)
        val maxY = (region.y + region.height - th).coerceIn(top, frame.height - th)

        if (frame.width < tw || frame.height < th) return 0f

        var best = 0f
        var y = top
        while (y <= maxY) {
            var x = left
            while (x <= maxX) {
                val crop = safeCrop(frame, x, y, tw, th)
                if (crop != null) {
                    val cropSmall = Bitmap.createScaledBitmap(crop, COMPARE_SIZE, COMPARE_SIZE, true)
                    val score = compare(templateSmall, cropSmall)
                    if (score > best) best = score
                }
                x += searchStep
            }
            y += searchStep
        }
        return best
    }

    private fun safeCrop(frame: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        if (x < 0 || y < 0 || x + w > frame.width || y + h > frame.height) return null
        return Bitmap.createBitmap(frame, x, y, w, h)
    }

    private fun compare(a: Bitmap, b: Bitmap): Float {
        var totalDiff = 0L
        for (y in 0 until COMPARE_SIZE) {
            for (x in 0 until COMPARE_SIZE) {
                val pa = a.getPixel(x, y)
                val pb = b.getPixel(x, y)
                val dr = kotlin.math.abs(((pa shr 16) and 0xFF) - ((pb shr 16) and 0xFF))
                val dg = kotlin.math.abs(((pa shr 8) and 0xFF) - ((pb shr 8) and 0xFF))
                val db = kotlin.math.abs((pa and 0xFF) - (pb and 0xFF))
                totalDiff += dr + dg + db
            }
        }
        val maxDiff = COMPARE_SIZE.toLong() * COMPARE_SIZE.toLong() * 3L * 255L
        return 1f - (totalDiff.toFloat() / maxDiff.toFloat())
    }

    private fun loadTemplate(path: String): Bitmap? {
        templateCache[path]?.let { return it }
        val file = File(path)
        if (!file.exists()) return null
        val bmp = BitmapFactory.decodeFile(path) ?: return null
        templateCache[path] = bmp
        return bmp
    }

    fun clearCache() = templateCache.clear()
}
