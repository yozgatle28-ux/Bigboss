# Bu dosya release build alırken kod küçültme/obfuscation kuralları içindir.
# Şimdilik boş bırakıldı.
