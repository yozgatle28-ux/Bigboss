plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bigboss.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bigboss.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
    }

    // ÖNEMLİ: Sabit bir debug anahtarı kullanıyoruz (app/debug.keystore, repoya dahil).
    // GitHub Actions her seferinde TEMİZ bir sanal makine kullandığı için, bu olmadan
    // her derleme FARKLI/rastgele bir anahtarla imzalanır — bu da telefonun "güncelleme"
    // olarak kabul etmeyip her seferinde önce SİLMENİ zorlamasına sebep olur. Bu sabit
    // anahtarla artık yeni APK'yı eskisinin ÜZERİNE kurabilirsin, veriler de korunur.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.mozilla:rhino:1.7.14")

    // Görüntü tanıma için OpenCV Android kütüphanesi (manuel modül olarak eklenmeli,
    // bkz. README.md -> "OpenCV kurulumu")
    // implementation(project(":opencv"))
}
