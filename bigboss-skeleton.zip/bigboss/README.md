# BigBoss

Royale Online (Android) için, ekranı okuyup senin tanımladığın kurallara
göre otomatik dokunuş/kaydırma yapan bir otomasyon aracı. Macrorify'ın
"Region + Template + Min Score + Timeout" mantığına dayanır, kod yazmadan
tamamen dokunarak kullanılır.

## İlk Açılış (Zorunlu Kurulum)

Uygulama ilk açıldığında, izinler tamamlanana kadar **sırayla zorunlu**
iki adım gösterilir (`OnboardingActivity`):
1. Ekran üstü gösterim izni
2. Erişilebilirlik servisi

İkisi de verilmeden ana ekrana (`MainActivity`) geçilmez. Her `onResume()`'da
kontrol edilir; izin eksikse ilgili adım otomatik olarak tekrar gösterilir.

## Kural Editörü (Macrorify tarzı, kodsuz)

1. Ana ekranda **"▶ Başlat"** → ekran kaydı izni onaylanır, overlay belirir
2. Overlay'deki **"+ Kural Ekle"** → anlık ekran görüntüsü donar
3. **Parmağını sürükleyerek bir ALAN (Region) çiz**
4. **🎨 Renk Ara** ya da **🖼️ Resim Ara** seç:
   - Renk: bölgenin ortalama rengi otomatik hesaplanır
   - Resim: bölge bir "şablon" (template) olarak kırpılıp kaydedilir,
     çalışma zamanında bu şablon o bölgede aranır (OpenCV'siz, basit
     kayan-pencere karşılaştırması — `engine/ImageMatcher.kt`)
5. **👆 Dokunma (Tap)** ya da **👉 Kaydırma (Swipe)** seç, nokta(lar)a dokun
6. İsim, **Min Score (%)** (Macrorify'daki "Min Score" ile aynı — ne kadar
   yüksekse o kadar sıkı eşleşme ister) ve **Arama süresi (ms)** (bu adımı
   en fazla ne kadar aktif arasın; `-1` = sınırsız) gir, kaydet

## Kurallar SIRAYLA çalışır (script mantığı)

Eskiden "ilk eşleşen kural kazanır" mantığı vardı; artık gerçek bir
**senaryo (script)** gibi çalışıyor — tıpkı Macrorify gibi:

- Motor (`RuleEngine`) listedeki 1. kuralda bekler, koşulu en fazla o
  kuralın `timeoutMs` süresi kadar arar.
- **Bulursa:** aksiyonu çalıştırır, 2. kurala geçer.
- **Süre dolarsa:** eşleşmeden 2. kurala geçer.
- Liste biterse başa döner (döngü).

Ana ekrandaki listede sıra numarası, koşul tipi, Min Score, süre ve
aksiyon tipi her kuralın altında özet olarak görünür.

## Kuralları Düzenleme ve Test Etme

- **✏️ Düzenle:** kuralı editörde yeniden açar (bölge/nokta yeniden
  çizilir, isim/skor/süre eski değerlerle önceden doldurulur), kaydedince
  aynı kural güncellenir (yeni kural olarak eklenmez).
- **🧪 Test Et:** botu tam çalıştırmadan, sadece o kuralın koşulunu anlık
  ekran görüntüsüne karşı değerlendirir ve skorunu gösterir
  ("✅ Eşleşti, skor %92" gibi) — böylece her özelliği tek tek,
  hızlıca test edebilirsin. Bunun için "Başlat"a basılmış (ekran
  görüntüsü akıyor) olması yeterli, Erişilebilirlik'in dokunuşu
  gerçekten uygulaması gerekmez.
- **🗑 Sil:** kuralı (ve varsa kayıtlı şablon resmini) siler.

## Klasör Yapısı

```
bigboss/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
└── app/src/main/
    ├── AndroidManifest.xml        (launcher artık OnboardingActivity)
    ├── java/com/bigboss/app/
    │   ├── ui/
    │   │   ├── OnboardingActivity.kt    # zorunlu sıralı izin akışı
    │   │   ├── MainActivity.kt          # kural listesi, başlat/durdur, test
    │   │   ├── RuleEditorActivity.kt    # bölge çiz -> renk/resim -> tap/swipe
    │   │   └── RulesAdapter.kt
    │   ├── service/
    │   │   ├── ScreenCaptureService.kt  # MediaProjection ekran yakalama
    │   │   ├── BigBossAccessibilityService.kt  # dokunuş/kaydırma simülasyonu
    │   │   └── OverlayService.kt        # "+ Kural Ekle" overlay'i
    │   ├── engine/
    │   │   ├── Condition.kt      # ColorInRegion / ImageInRegion, minScore
    │   │   ├── Action.kt         # Tap, Swipe, Wait, Sequence
    │   │   ├── Rule.kt           # id, condition, action, timeoutMs
    │   │   ├── RuleEngine.kt     # SIRALI script motoru (Macrorify tarzı)
    │   │   └── ImageMatcher.kt   # OpenCV'siz basit template matching
    │   ├── storage/
    │   │   ├── RuleDefinition.kt      # JSON'a çevrilebilir düz kural modeli
    │   │   ├── RuleStorage.kt         # rules.json okuma/yazma, upsert
    │   │   ├── RuleDefinitionMapper.kt
    │   │   └── TemplateStorage.kt     # resim şablonlarını PNG olarak kaydeder
    │   ├── util/PermissionUtils.kt
    │   └── model/Region.kt
    └── res/
        ├── drawable-nodpi/app_logo.png   # uygulama logosu (senin gönderdiğin görsel)
        ├── mipmap-anydpi-v26/ic_launcher.xml  # logo, uygulama simgesi olarak
        └── layout/ (activity_main, activity_onboarding, activity_rule_editor, item_rule)
```

## Şu An Eksik / Yapılacaklar

- [ ] **Gerçek OpenCV entegrasyonu** — şu anki `ImageMatcher` saf Kotlin ile
      çalışan basit bir eşleştirici (küçük şablonlarda/bölgelerde iyi,
      büyüklerde yavaş olabilir). İleride gerçek OpenCV `matchTemplate`'e
      geçilebilir.
- [ ] **Sürükle-bırak sıralama** — kural listesinde sırayı değiştirmek için
      RecyclerView'a `ItemTouchHelper` eklenmeli (şu an sıra = ekleme sırası).
- [ ] `ActivityResultContracts` ile `onActivityResult`'ın modern karşılığına
      geçiş (opsiyonel, şu an deprecated API kullanılıyor ama çalışır).
