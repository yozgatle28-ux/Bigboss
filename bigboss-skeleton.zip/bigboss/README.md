# BigBoss

Royale Online (Android) için, ekranı okuyup senin tanımladığın `if / else if`
kurallarına göre otomatik dokunuş yapan bir otomasyon aracı.

Bu araç, oyunun kendi dosyalarına/belleğine dokunmaz. Sadece Android'in resmi
**Erişilebilirlik (Accessibility)** ve **Ekran Yakalama (MediaProjection)**
API'lerini kullanır — yani kullanıcı iki izni elle açtıktan sonra çalışır.

## Klasör Yapısı

```
bigboss/
├── settings.gradle.kts
├── build.gradle.kts
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/bigboss/app/
        │   ├── ui/
        │   │   └── MainActivity.kt          # İzin isteme + başlat/durdur ekranı
        │   ├── service/
        │   │   ├── ScreenCaptureService.kt  # MediaProjection ile ekran yakalama
        │   │   ├── BigBossAccessibilityService.kt  # Dokunuş/kaydırma simülasyonu
        │   │   └── OverlayService.kt        # Ekran üstü kontrol (iskelet)
        │   ├── engine/
        │   │   ├── Condition.kt             # IF koşulları (renk, template match, and/or/not)
        │   │   ├── Action.kt                # THEN aksiyonları (tap, swipe, wait, sequence)
        │   │   ├── Rule.kt                  # if -> elseIf -> elseIf ... zinciri
        │   │   ├── RuleEngine.kt            # Her frame'de kuralları değerlendirip çalıştırır
        │   │   └── TemplateMatcher.kt       # Görsel tanıma köprüsü (OpenCV bekliyor)
        │   └── model/
        │       └── Region.kt                # Ekran üzerinde x,y,w,h bölge tanımı
        └── res/
            ├── layout/activity_main.xml
            ├── values/{strings,colors,themes}.xml
            └── xml/accessibility_service_config.xml
```

## Mimarinin Akışı

1. **ScreenCaptureService** her yeni frame geldiğinde `RuleEngine.onFrame(bitmap)` çağırır.
2. **RuleEngine**, senin tanımladığın `Rule` listesini sırayla dolaşır; her `Rule`
   kendi `elseIf` zincirini kontrol eder (tam senin istediğin if/else-if mantığı).
3. İlk `true` olan koşulun `Action`'ı, **BigBossAccessibilityService** üzerinden
   gerçek bir dokunuş/kaydırma jestine çevrilir (`dispatchGesture`).

## Kural Editörü (Macrorify tarzı, kodsuz)

Artık kod yazmadan kural ekleyebiliyorsun:

1. Botu başlat (overlay ekranda belirir)
2. Overlay'deki **"+ Kural Ekle"** butonuna bas → anlık ekran görüntüsü donar
3. **Parmağını sürükleyerek bir ALAN çiz** (örn. HP barının bulunduğu bölge) →
   o alanın ortalama rengi otomatik hesaplanır. Kural, çalışırken bu bölgenin
   herhangi bir noktasında bu renge yakın bir piksel bulursa tetiklenir
   (tek noktaya değil, tüm alana bakar — daha toleranslı ve pratik).
4. **Aksiyon tipini seç:** 👆 Dokunma (Tap) ya da 👉 Kaydırma (Swipe)
   - Tap seçersen: tek bir noktaya dokun
   - Swipe seçersen: önce başlangıç, sonra bitiş noktasına dokun (kaydırma yönü/mesafesi böyle belirlenir)
5. İsim ver, renk toleransını ayarla, kaydet

Kurallar `RuleDefinition` olarak `rules.json` içinde saklanır
(`storage/RuleStorage.kt`). Ana ekrandaki liste ile kuralları
açıp/kapatabilir veya silebilirsin. Liste satırında aksiyon tipi de
görünür (👆 Tap / ↔ Swipe). **Liste sırası = if/else-if önceliği** —
RuleEngine listeyi sırayla tarar ve ilk eşleşen kuralın aksiyonunu
çalıştırıp durur, tıpkı bir if/else-if zinciri gibi.

> Not: Şu an sadece **bölgede piksel rengi** koşulu destekleniyor. Görsel/ikon
> eşleştirme (TemplateMatch) için OpenCV entegrasyonu hâlâ gerekiyor — aşağıya bak.

## Şu An Eksik / Yapılacaklar (bir sonraki adımlar)

- [ ] **OpenCV entegrasyonu** — `TemplateMatcher.kt` şu an `NotImplementedError`
      fırlatıyor. Görsel tanıma (düşman ikonu, item ikonu vb.) için OpenCV
      Android SDK modülünü projeye eklememiz lazım. Editöre de "renk yerine
      görsel seç" seçeneği eklenmeli (aynı sürükle-bölge-çiz akışı, bölge
      içindeki görüntü referans olarak kaydedilecek).
- [ ] **Sürükle-bırak sıralama** — kural listesinde önceliği değiştirmek için
      RecyclerView'a `ItemTouchHelper` eklenmeli (şu an sadece silme/aç-kapa var).
- [ ] Gerçek launcher ikonu iyileştirilebilir (şu an placeholder bir şekil).
- [ ] `ActivityResultContracts` ile `onActivityResult`'ın modern karşılığına geçiş (opsiyonel, şu an deprecated API kullanılıyor ama çalışır).

## Gerekli İzinler (kullanıcı ilk açılışta elle vermeli)

1. **Ekranın üstünde gösterim** (`SYSTEM_ALERT_WINDOW`) — overlay kontrolü için
2. **Erişilebilirlik servisi** — dokunuş simülasyonu için
3. **Ekran kaydı izni** (MediaProjection) — her oturumda bir kez sorulur

## Sıradaki Adım

Bir sonraki oturumda önerim: kural tanımlama şeklini netleştirip (form mu,
JSON dosyası mı) `RuleEngine`'i gerçek bir örnekle uçtan uca çalıştırmak,
ardından OpenCV'yi bağlamak.
