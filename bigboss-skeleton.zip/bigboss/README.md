# BigBoss

Royale Online (Android) için, ekranı okuyup senin tanımladığın kurallara
göre otomatik dokunuş/kaydırma yapan bir otomasyon aracı. Macrorify'ın
"Region + Template + Min Score + Timeout" mantığına dayanır, kod yazmadan
tamamen dokunarak kullanılır.

## İlk Açılış (Zorunlu Kurulum)

Uygulama ilk açıldığında, izinler tamamlanana kadar **sırayla zorunlu**
iki adım gösterilir (`OnboardingActivity`):
1. Ekran üstü gösterim izni
2. Erişilebilirlik servisi

İkisi de verilmeden ana ekrana (`MainActivity`) geçilmez. Her `onResume()`'da
kontrol edilir; izin eksikse ilgili adım otomatik olarak tekrar gösterilir.

## Kural Editörü (Macrorify tarzı, kodsuz)

1. Ana ekranda **"▶ Başlat"** → ekran kaydı izni onaylanır, overlay belirir
2. Overlay'deki **"+ Kural Ekle"** → anlık ekran görüntüsü donar
3. **Parmağını sürükleyerek bir ALAN (Region) çiz**
4. **🎨 Renk Ara** ya da **🖼️ Resim Ara** seç:
   - Renk: bölgenin ortalama rengi otomatik hesaplanır
   - Resim: bölge bir "şablon" (template) olarak kırpılıp kaydedilir,
     çalışma zamanında bu şablon o bölgede aranır (OpenCV'siz, basit
     kayan-pencere karşılaştırması — `engine/ImageMatcher.kt`)
5. **👆 Dokunma (Tap)** ya da **👉 Kaydırma (Swipe)** seç, nokta(lar)a dokun
6. İsim, **Min Score (%)** (Macrorify'daki "Min Score" ile aynı — ne kadar
   yüksekse o kadar sıkı eşleşme ister) ve **Arama süresi (ms)** (bu adımı
   en fazla ne kadar aktif arasın; `-1` = sınırsız) gir, kaydet

## Kurallar SIRAYLA çalışır (script mantığı)

Eskiden "ilk eşleşen kural kazanır" mantığı vardı; artık gerçek bir
**senaryo (script)** gibi çalışıyor — tıpkı Macrorify gibi:

- Motor (`RuleEngine`) listedeki 1. kuralda bekler, koşulu en fazla o
  kuralın `timeoutMs` süresi kadar arar.
- **Bulursa:** aksiyonu çalıştırır, 2. kurala geçer.
- **Süre dolarsa:** eşleşmeden 2. kurala geçer.
- Liste biterse başa döner (döngü).

Ana ekrandaki listede sıra numarası, koşul tipi, Min Score, süre ve
aksiyon tipi her kuralın altında özet olarak görünür.

## Kuralları Düzenleme ve Test Etme

- **✏️ Düzenle:** kuralı editörde yeniden açar (bölge/nokta yeniden
  çizilir, isim/skor/süre eski değerlerle önceden doldurulur), kaydedince
  aynı kural güncellenir (yeni kural olarak eklenmez).
- **🧪 Test Et:** botu tam çalıştırmadan, sadece o kuralın koşulunu anlık
  ekran görüntüsüne karşı değerlendirir ve skorunu gösterir
  ("✅ Eşleşti, skor %92" gibi) — böylece her özelliği tek tek,
  hızlıca test edebilirsin. Bunun için "Başlat"a basılmış (ekran
  görüntüsü akıyor) olması yeterli, Erişilebilirlik'in dokunuşu
  gerçekten uygulaması gerekmez.
- **🗑 Sil:** kuralı (ve varsa kayıtlı şablon resmini) siler.

## Klasör Yapısı

```
bigboss/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
└── app/src/main/
    ├── AndroidManifest.xml        (launcher artık OnboardingActivity)
    ├── java/com/bigboss/app/
    │   ├── ui/
    │   │   ├── OnboardingActivity.kt    # zorunlu sıralı izin akışı
    │   │   ├── MainActivity.kt          # kural listesi, başlat/durdur, test
    │   │   ├── RuleEditorActivity.kt    # bölge çiz -> renk/resim -> tap/swipe
    │   │   └── RulesAdapter.kt
    │   ├── service/
    │   │   ├── ScreenCaptureService.kt  # MediaProjection ekran yakalama
    │   │   ├── BigBossAccessibilityService.kt  # dokunuş/kaydırma simülasyonu
    │   │   └── OverlayService.kt        # "+ Kural Ekle" overlay'i
    │   ├── engine/
    │   │   ├── Condition.kt      # ColorInRegion / ImageInRegion, minScore
    │   │   ├── Action.kt         # Tap, Swipe, Wait, Sequence
    │   │   ├── Rule.kt           # id, condition, action, timeoutMs
    │   │   ├── RuleEngine.kt     # SIRALI script motoru (Macrorify tarzı)
    │   │   └── ImageMatcher.kt   # OpenCV'siz basit template matching
    │   ├── storage/
    │   │   ├── RuleDefinition.kt      # JSON'a çevrilebilir düz kural modeli
    │   │   ├── RuleStorage.kt         # rules.json okuma/yazma, upsert
    │   │   ├── RuleDefinitionMapper.kt
    │   │   └── TemplateStorage.kt     # resim şablonlarını PNG olarak kaydeder
    │   ├── util/PermissionUtils.kt
    │   └── model/Region.kt
    └── res/
        ├── drawable-nodpi/app_logo.png   # uygulama logosu (senin gönderdiğin görsel)
        ├── mipmap-anydpi-v26/ic_launcher.xml  # logo, uygulama simgesi olarak
        └── layout/ (activity_main, activity_onboarding, activity_rule_editor, item_rule)
```

## Şu An Eksik / Yapılacaklar

- [ ] **Gerçek OpenCV entegrasyonu** — şu anki `ImageMatcher` saf Kotlin ile
      çalışan basit bir eşleştirici (küçük şablonlarda/bölgelerde iyi,
      büyüklerde yavaş olabilir). İleride gerçek OpenCV `matchTemplate`'e
      geçilebilir.
- [ ] **Sürükle-bırak sıralama** — kural listesinde sırayı değiştirmek için
      RecyclerView'a `ItemTouchHelper` eklenmeli (şu an sıra = ekleme sırası).
- [ ] `ActivityResultContracts` ile `onActivityResult`'ın modern karşılığına
      geçiş (opsiyonel, şu an deprecated API kullanılıyor ama çalışır).

## Macrorify Dokümanlarından Eklenenler (bu sürüm)

Kaynak: kok-emm.com/docs — okuyup BigBoss'a uyarladıklarım:

- **Multi Detection → "VEYA Alternatifleri"**: Bir kuralın koşuluna birden
  fazla renk/resim/yazı alternatifi eklenebilir (`ConditionAlt` listesi).
  Herhangi biri eşleşirse kural tetiklenir (Macrorify'daki "One Detection
  Success" mantığı). Motor tarafında `Condition.Group` ile 6 mantık tipi de
  hazır (`ALL_SUCCESS`, `ONE_SUCCESS`, `ALL_FAIL`, `ONE_FAIL`,
  `ALWAYS_SUCCESS`, `ALWAYS_FAIL`) ama editör arayüzü şimdilik sadece VEYA
  (OR) akışını sunuyor.
- **Text Recognition → "📝 Yazı Ara"**: ML Kit'in cihaz-üstü OCR'ı ile bir
  bölgede belirli bir kelime/metin aranabiliyor (`engine/TextMatcher.kt`).
  İnternet/Play Services gerektirir, ilk kullanımda dil modeli inebilir.
- **Variables → Sayaçlar**: `engine/VariableStore.kt` ile isimli, sayısal
  global değişkenler. Bir kural tetiklendiğinde bir sayacı artırabilir
  (`incrementVariableName`), başka bir kural bu sayacın değerini şart
  olarak kontrol edebilir (`requireVariableName`). Örn: "5. kez düşman
  görülünce farklı bir şey yap" gibi senaryolar mümkün. Not: sayaçlar
  sadece uygulama açıkken bellekte tutulur, kalıcı değildir.
- **Grouping → Grup etiketi**: Her kurala isteğe bağlı bir grup adı
  verilebilir ("Savaş", "Toplama" gibi), listede `[Grup] Kural adı` olarak
  görünür. Macrorify'daki tam "collapsible sayfa + grup döngüsü" özelliği
  şimdilik yok, sadece organizasyon/etiketleme var.
- **Color Detection**: zaten vardı (bölge içinde renk arama), Min Score
  terminolojisiyle hizalandı.

**Bilinçli olarak eklemediklerim** (ve neden):
- **Setting Builder / Views / EMScript**: Bunlar Macrorify'da, yaptığın
  makroyu *başka kullanıcılara* dağıtırken onlara özelleştirilebilir bir
  arayüz/kod yazma imkanı sunmak için var. BigBoss şu an senin kişisel
  aracın olduğu için bu katman gereksiz karmaşıklık katardı. İstersen
  ileride "kural setlerini dışa aktar/paylaş" gibi basit bir sürümünü
  ekleyebiliriz.
- **Text Reader** (OCR ile metni bir değişkene okuyup kullanma): Text
  Recognition (arama) ekledim ama "oku ve değişkene ata" kısmını
  eklemedim, zaman/karmaşıklık dengesi için önceliklendirmedim.
- **Nested Logical Group editör arayüzü**: motor destekliyor ama
  dokunarak iç içe VE/VEYA grupları kurmak için ayrı bir görsel editör
  gerekir, sonraki bir iterasyona bıraktım.

## Kütüphane, HEX Renk, Gelişmiş Alan Düzenleme (bu sürüm)

- **📚 Kütüphane (Manage Images)**: Kural editöründe bir renk/resim
  oluştururken, isim vererek kütüphaneye kaydedebilirsin. Sonraki
  kurallarda **"📚 Kütüphaneden Seç"** ile o kayıtlı renk/resmi tekrar
  çağırabilirsin (dosya: `storage/LibraryItem.kt`, `LibraryStorage.kt`).
  Ana ekrandaki **"📚 Kütüphanem"** butonuyla kayıtlı öğeleri görüp
  silebilirsin.
- **# HEX Renk Gir**: Ekrandan örneklemek yerine, bilinen bir renk kodunu
  doğrudan yazabilirsin (`#FF3B30` gibi).
- **Gelişmiş alan düzenleme**: Artık bir bölge çizdikten SONRA onu
  sürükleyip taşıyabilir, sağ-alt köşesindeki beyaz tutamaçtan
  boyutlandırabilirsin — "✓ Alanı Onayla" diyene kadar ince ayar
  yapabilirsin. **Kural düzenlerken** de artık sıfırdan çizmek zorunda
  değilsin: mevcut alan otomatik olarak ekranda beliriyor, sadece
  sürükleyip/boyutlandırıp onaylıyorsun.

## Bu Sürümde Düzeltilen Hata

`RuleStorage.kt` içinde, kuralları alternatif listesine taşırken unutulan
eski bir `templatePath` referansı derlemeyi kırıyordu — düzeltildi.

## Nokta-Bazlı Renk Seçimi (Point-based Color Detection)

Macrorify'ın Color Detection dokümanını okudum: onlar da renk için
**bölge ortalaması değil, tek bir NOKTA**daki rengi kullanıyor (delta-E
metriğiyle karşılaştırıyorlar). BigBoss'ta da aynısını yaptım:

- **"🎨 Renk (Ekrandan)"** artık bölgenin ortalamasını almıyor. Bölgeyi
  çizdikten sonra, o bölge içinde **tam bastığın pikselin rengini**
  alıyor (HEX kodunu da gösteriyor: örn. "nokta: #FF3B30").
- Arama hâlâ tüm bölge içinde yapılıyor (`ColorInRegion`) — yani "bu
  bölgenin HERHANGİ bir noktasında bu TAM renk var mı" mantığı. Nokta
  sadece referans rengi belirlemek için kullanılıyor, aramayı tek
  piksele indirmiyor.
- Not: Biz gerçek **delta-E (CIE)** yerine basit bir RGB kanal-farkı
  benzerliği kullanıyoruz — Macrorify kadar renk-algısal doğru değil ama
  pratikte iyi çalışır. Nokta-bazlı seçimde varsayılan Min Score'u %95'e
  çıkardım (Macrorify'ın önerisiyle aynı: renk için yüksek skor gerekir).

## "Wait till appear" (Sadece Bekle)

Image Detection dokümanındaki 4 aksiyondan (`Click best match`,
`Click multiple matches`, `Wait till appear`, `Wait till vanish`) ilkini
zaten Tap/Swipe ile karşılıyorduk. Şimdi **"⏳ Sadece Bekle"** eklendi:
kural eşleşince hiçbir dokunuş/kaydırma yapmadan sadece bir sonraki
kurala geçer — bu da `Wait till appear`'ın karşılığı (motor zaten
koşulu timeout süresince aktif arıyor).

**Henüz eklemediklerim** (dürüst olmak gerekirse, dokümanı okudum ama
zaman kısıtından uygulamaya koyamadım):
- `Click multiple matches` (bölgedeki TÜM eşleşmelere tıklama — bizim
  basit `ImageMatcher`'ımız tek en-iyi-skor konumu buluyor, çoklu
  konum listesi döndürmüyor)
- `Wait till vanish` (rengin/resmin KAYBOLMASINI bekleme — teknik olarak
  mevcut koşulu `Condition.Group` + `ALL_FAIL` mantığıyla kurup
  yapılabilir ama editöre ayrı bir buton olarak henüz koymadım)
- `Loop` seçenekleri (None / Loop when success / Loop when fail /
  Loop always) — motor şu an her kuralı bir kez deneyip diğerine
  geçiyor, "N kere tekrarla" ayrı bir alan gerektirir
- `On Success` / `On Fail` dallanması (görsel bulunca farklı, bulunamayınca
  farklı bir alt-senaryoya dallanma) — motorumuz tek bir aksiyon
  çalıştırıyor, dallanma için ayrı bir yapı gerekir

İstersen bir sonraki adımda bunlardan hangisine öncelik vermemi istediğini
söyle, sırayla ekleyelim.

## Bu Sürüm: Yeni İkon, Renk Önizleme, Wait till Vanish, Loop

- **Yeni ikon**: Gönderdiğin "BIGBOSS" logosu artık uygulama simgesi.
- **Renk seçimi önizlemesi**: Bir noktaya dokunduğunda artık önce o rengin
  önizlemesini (renk kutusu + HEX kodu) gösteriyor, "Evet, bunu kullan" /
  "Tekrar dokun" diye soruyor — yanlışlıkla komşu pikseli seçme riskini
  azaltır.
- **⏳ Wait till Vanish**: Kural kaydetme ekranında "İleri Seviye" bölümünde
  "Ters mantık: koşul KAYBOLUNCA tetikle" seçeneği var. Açarsan, kural
  normalde eşleşme ARANDIĞI gibi değil, eşleşmenin KAYBOLMASI beklenip
  öyle tetiklenir (Macrorify'daki "Wait till vanish").
- **🔁 Loop**: "Eşleştikçe bu kuralda kal ve tekrar dene" seçeneğini açarsan,
  kural bir sonrakine geçmeden önce (opsiyonel bir üst sınıra kadar)
  kendini tekrar dener — sürekli aynı yerde beliren bir düşmanı art arda
  vurmak gibi senaryolar için.

Motor tarafında `loopMode` aslında 4 değeri destekliyor
(`NONE`, `WHILE_SUCCESS`, `WHILE_FAIL`, `ALWAYS`) ama editör arayüzü
şimdilik sadece en yaygın kullanılanı (`WHILE_SUCCESS`) tek bir
checkbox ile sunuyor; istersen `WHILE_FAIL`/`ALWAYS` için de ayrı
seçenekler ekleyebiliriz.

**Hâlâ eklemediğim** (Image Detection dokümanından): `Click multiple
matches` (bölgedeki TÜM eşleşmelere aynı anda tıklama) ve `On Success`/
`On Fail` dallanması (farklı sonuçlara göre farklı alt-senaryoya geçme).

## Edit Mode / Play Mode (Macrorify referansı)

Gönderdiğin videolarda gördüğüm Macrorify akışını uyguladım:

- **"▶ Başlat"a bastığında bot her zaman ✏️ EDIT MODE'da açılır.** Bu modda
  motor ekranı izler ama **hiçbir dokunuş/kaydırma yapmaz** — güvenle
  kural ekleyip düzenleyebilirsin. Overlay'de "+ Kural Ekle" ve
  "📋 Kurallar" butonları görünür.
- Overlay'deki **"▶️ Play Mode'a Geç"** butonuna basınca motor gerçekten
  çalışmaya başlar (▶️ PLAY MODE). Bu modda düzenleme butonları gizlenir,
  sadece **"✏️ Edit Mode'a Geç"** kalır — istediğin an geri dönebilirsin.
- Bu ayrım, önceki sürümdeki gizli bir riski de çözdü: eskiden kural
  düzenlerken arka planda motor hâlâ çalışıp yanlışlıkla dokunuş
  yapabiliyordu. Artık Edit Mode'dayken motor tamamen duraklatılmış
  oluyor (`RuleEngine.paused`).

Overlay'deki **"📋 Kurallar"** butonu seni ana ekrana (kural listesi,
test/düzenle/sil) götürür; oyuna dönmek için görev değiştiriciden geri
dönebilirsin.

## BÜYÜK GÜNCELLEME: Çoklu Alan (Multi-Region) Editör

Gönderdiğin Macrorify videosunu izleyip mantığını birebir uyguladım —
kural editörü artık tamamen farklı çalışıyor:

**Eski akış (artık yok):** Bir alan çiz → hemen "ne arayacak" menüsü
aç → aksiyon seç → kaydet. Tek seferde tek şey yapabiliyordun.

**Yeni akış (Macrorify tarzı):**
1. **"➕ Alan Ekle"** butonuna her bastığında ekrana sürüklenebilir/
   boyutlandırılabilir gri bir kutu düşer. **Hiçbir menü açılmaz.**
   İstediğin kadar "➕ Alan Ekle"ye basıp aynı anda birden fazla kutu
   yerleştirebilirsin.
2. Her kutuyu **sürükleyerek taşıyabilir**, sağ-alt köşesindeki beyaz
   tutamaçtan **boyutlandırabilirsin**.
3. Bir kutuya **kısa süreli dokunursan** (sürüklemeden) o kutu için bir
   menü açılır:
   - **"🔎 Arama Alanı Yap"** → Renk (ekrandan nokta seç) / HEX / Resim /
     Yazı / Kütüphaneden Seç
   - **"👆 Dokunma Noktası Yap"** / **"👉 Kaydırma Başlangıcı/Bitişi Yap"**
   - **"🗑 Bu Alanı Sil"**
4. Yapılandırdığın her kutu renkle işaretlenir (yeşil = arama alanı,
   kırmızı = dokunma, mavi/mor = kaydırma başlangıç/bitiş) ve üstünde
   küçük bir etiket gösterir.
5. **Birden fazla arama alanı** işaretlersen, bunlar otomatik olarak
   VEYA (OR) alternatifleri olur — ayrı bir "alternatif ekle" adımına
   gerek kalmadı.
6. Her şeyi yerleştirip yapılandırdıktan sonra **"💾 Kaydet"**e basarsın
   — isim/grup/süre/değişken gibi son ayarları giren tanıdık pencere açılır.

**Düzenleme (✏️ Düzenle) de bu yeni sisteme taşındı:** Var olan bir
kuralı açtığında, o kuralın tüm alanları (koşullar + aksiyon noktası)
otomatik olarak ekranda kutular hâlinde belirir, istediğini
sürükleyip/boyutlandırıp/silip yenisini ekleyebilirsin.

## Kütüphaneye Galeriden Resim Ekleme + Döndürme

- Ana ekrandaki **"📚 Kütüphanem"** açılınca artık en üstte
  **"➕ Galeriden Resim Ekle"** seçeneği var — telefonundaki herhangi bir
  görseli kütüphaneye ekleyebilirsin.
- Kütüphanedeki bir öğeye dokununca artık: resimlerde **"↻ 90° Döndür"**,
  ayrıca **"✏️ Yeniden Adlandır"** ve **"🗑 Sil"** seçenekleri çıkıyor.

**Henüz eklemediğim** (dürüstçe belirteyim): kütüphanedeki bir resmi
**yeniden kırpma** (crop) ya da **serbest açıyla döndürme** (sadece
90°'lik döndürme var) ve **boyut değiştirme** editörü. Bunlar ayrı bir
görsel kırpma/döndürme ekranı gerektiriyor, zaman kısıtından bu
sürüme sığdıramadım — istersen bir sonraki adımda onu yapalım.

## Bu Sürümde Düzeltilen Hata

`RuleEditorActivity.kt` içinde, renk noktası seçme akışında yanlışlıkla
tanımsız bir `region` değişkenine referans verilmişti (doğrusu
`pickRegion` olmalıydı) — düzeltildi.

## Overlay Artık Küçük Bir Simge

"▶ Başlat"a basınca ekranda beliren panel eskiden kocaman yer
kaplıyordu. Artık:

- Varsayılan olarak sadece **küçük tek bir simge** duruyor (✏️ ya da
  ▶️, hangi moddaysan onu gösterir)
- Simgeye **dokununca** tüm panel (durum + mod değiştir + kural ekle +
  kural listesi) açılır, **tekrar dokununca** kapanır
- Simgeyi **sürükleyerek** istediğin köşeye taşıyabilirsin (sürükleme
  ile dokunma otomatik ayırt ediliyor — sürüklersen taşır, sadece
  dokunursan açar/kapar)
- Kural editörüne ya da kural listesine gidince panel otomatik küçülür

## Overlay Artık Küçük Bir Simge

Botu başlatınca ekranda büyük bir panel yerine artık **tek, küçük bir
daire simge** duruyor (✏️/▶️ mevcut moda göre değişir):

- **Dokun** → panel açılır (durum, mod değiştir, kural ekle, kural
  listesi butonları görünür)
- **Tekrar dokun** → panel kapanır, yine küçük simgeye döner
- **Sürükle** → simgeyi ekranın istediğin köşesine taşıyabilirsin
- "+ Kural Ekle" ya da "📋 Kurallar"a bastığında panel otomatik küçülür

Böylece oyun ekranından çalınan alan en aza indi.

## BÜYÜK GÜNCELLEME: Ana Akış / Fonksiyonlar Ayrımı + Simge Tabanlı Arayüz

Gönderdiğin üç Macrorify ikonunu (🖼️👆 Aksiyon Ekle, 🏠 Home, f{} Function)
ve Fonksiyonlar dokümanını referans alarak uyguladım:

### Artık iki ayrı "kayıt yeri" var

1. **🏠 Ana Akış**: Botun sürekli döndüğü, tüm işlemlerin otomatik
   sırayla çalıştığı ana liste (eskiden tek listeydi, o bu).
2. **f{} Fonksiyonlar**: İsimlendirilmiş, AYRI kural dizileri. Ana akışta
   otomatik ÇALIŞMAZLAR — sadece bir kuralın aksiyonu **"🔧 Fonksiyon
   Çağır"** olduğunda devreye girerler: o fonksiyonun kuralları sırayla
   çalışır, bitince (ya da belirlediğin tekrar sayısı dolunca) ana akış
   kaldığı yerden devam eder. Tıpkı bir alt-program/subroutine gibi.

Ana ekranda artık üstte **"🏠 Ana Akış"** / **"f{} Fonksiyonlar"** sekmeleri
var. Fonksiyonlar sekmesinde **"➕ Yeni Fonksiyon"** ile isim vererek yeni
bir fonksiyon oluşturursun, üstüne dokunup içine kural eklersin.

### Kural editöründe yeni aksiyon tipi

Bir alanı aksiyon yaparken artık 4 seçenek var: Dokunma, Kaydırma
Başlangıcı, Kaydırma Bitişi, ve **"🔧 Fonksiyon Çağır Yap"** — bu
seçilince hangi fonksiyonun (var olan ya da yeni oluşturulan) kaç kere
çağrılacağını soruyor.

### Simge tabanlı overlay

"+ Kural Ekle" / "📋 Kurallar" yazılı butonlar yerine artık overlay
panelinde üç ikon var: **🖼️👆** (Aksiyon Ekle), **🏠** (Ana Akışı Aç),
**f{}** (Fonksiyonları Aç) — gönderdiğin görsellerdeki ikonlara emoji
karşılıklarıyla sadık kalmaya çalıştım (gerçek özel ikon grafikleri
yerine, zaman kısıtından emoji kullandım — istersen gerçek vektör
ikonlar da ekleyebiliriz).

### Motor tarafında: Çağrı Yığını (Call Stack)

`RuleEngine` artık fonksiyon çağrılarını gerçek bir "alt program çağırma"
mantığıyla yönetiyor: ana akış bir fonksiyonu çağırınca, motor o
fonksiyonun kural listesine geçer, bitirince (repeat sayısı kadar
tekrarladıktan sonra) otomatik olarak ana akışta KALDIĞI YERDEN devam
eder. İç içe fonksiyon çağrıları da (bir fonksiyon başka bir fonksiyonu
çağırabilir) teorik olarak destekleniyor.

**Not:** Bu çok büyük bir mimari değişiklikti — derleme hatası çıkma
ihtimali her zamankinden yüksek. Çıkarsa log'u paylaş, birlikte
düzeltiriz.

## BÜYÜK GÜNCELLEME: PLAY MODE / EDIT MODE Tam Ayrımı

Ana ekran artık sadece iki büyük buton:

- **▶️ PLAY MODE**: Ayrı bir ekran (`PlayModeActivity`). Açılınca izin
  ister, botu **hemen çalışır hâlde** başlatır (motor `paused=false`).
  Bu ekranda kural listesi, düzenleme, hiçbir şey YOK — sadece durum
  yazısı ve **"⏹ Durdur ve Ana Ekrana Dön"** butonu. Oyuna geçtiğinde
  ekranın üstünde küçük bir gösterge kalır (▶️ ikon → dokununca durum +
  durdur butonu açılır), ama düzenleme ikonu yok — sisteme dokunma imkanı
  yok, sadece izleyip durdurabilirsin.

- **✏️ EDIT MODE**: Ayrı bir ekran (`EditModeActivity`). Açılınca
  sessizce ekran görüntüsü akışını başlatır (motor hep `paused=true` —
  yani bu ekrandayken sistem KESİNLİKLE gerçek bir dokunuş/kaydırma
  yapmaz). Burada yapabileceğin her şey var: Ana Akış / Fonksiyonlar
  sekmeleri, Aksiyon Ekle, Kütüphanem. Üstte **"💾 Kaydet ve Çık"**
  butonu var — bastığında "Edit Mode'dan çıkmak istiyor musun?" diye
  sorar, Evet dersen ekran akışını durdurup ana ekrana döner (zaten her
  değişiklik anında diske kaydolduğu için "kaydet" burada aslında bir
  onay adımı, ekstra bir kaydetme işlemi gerekmiyor).

Eski "Başlat/Durdur" butonları ve overlay'deki Edit/Play geçiş anahtarı
kaldırıldı — mod artık ana ekranda SEÇİLİYOR, sonradan overlay'den
değiştirilmiyor. Overlay artık sadece PLAY MODE'dayken görünen minimal
bir durum+durdur göstergesi.

## Image Detection Menüsü Yeniden Tasarlandı (tek pencere)

Gönderdiğin Macrorify videosundaki gibi: artık bir alanı "Arama Alanı
Yap" dediğinde, önce küçük pencere → sonra başka küçük pencere → sonra
başka küçük pencere şeklinde ZİNCİRLEME açılmıyor. Hepsi **TEK bir
pencerede**:

- Üstte radyo düğmeleriyle **Renk / HEX / Resim / Yazı / Kütüphane**
  seçimi
- Seçime göre altta İLGİLİ alanlar anında değişiyor (renk için nokta
  seç + önizleme, HEX için kod kutusu, Resim için canlı kırpma
  önizlemesi, Yazı için metin kutusu, Kütüphane için seçim listesi)
- Min Skor ve kütüphaneye kaydetme alanı da aynı pencerede
- Tek **"✅ Uygula"** butonuyla hepsi bir kerede kaydediliyor

Sadece "Ekrandan Nokta Seç" (renk için) hâlâ ekrana dokunmayı
gerektiriyor — ama noktaya dokununca pencere KALDIĞI AYARLARLA
(seçtiğin renk otomatik dolu) tekrar açılıyor, sıfırdan başlamıyorsun.

## BÜYÜK GÜNCELLEME: Motor artık PARALEL / REAKTİF (gerçek Macrorify mantığı)

Macrorify'ın "Abstract Mode" dokümanını okudum ve önemli bir farkı
keşfettim: gerçek Macrorify **sıralı bir script gibi ÇALIŞMIYOR**.
Bizim eski motorumuz "1. kuralı bekle, bulursa/süre dolarsa 2.'ye geç"
mantığındaydı — bu YANLIŞ bir varsayımdı. Gerçek mantık şu:

> Aksiyonlar birbirinden bağımsızdır, aralarında sıra yoktur. Bir
> koşul doğru olduğu HER an, bağlı aksiyon tetiklenir. Görsel ekranda
> olduğu sürece tıklama devam eder; ekrandan kaybolursa durur, geri
> gelirse tekrar başlar.

Motoru buna göre TAMAMEN yeniden yazdım:

- **`RuleEngine.onFrame()`** artık her frame'de TÜM kuralları bağımsız
  kontrol ediyor — "sıradaki kural" kavramı kalktı.
- **"Arama süresi"** alanı **"Bekleme süresi" (cooldown / Wait Next)**
  oldu: bir kural tetiklendikten sonra, TEKRAR tetiklenebilmesi için en
  az bu kadar ms geçmesi gerekiyor (spam-tıklamayı önler). Koşul
  doğruluğunu korudukça kural bu aralıklarla tetiklenmeye devam eder —
  ayrı bir "tekrar et" ayarına gerek kalmadı, bu yüzden **🔁 Loop
  checkbox'ını kaldırdım** (artık gereksiz, davranış zaten böyle).
- **Yeni: `Condition.ActionResult`** — Macrorify'ın sıra gerektiren
  senaryolar için kullandığı yöntem: "B kuralı, A kuralı yakın zamanda
  tetiklendiyse çalışsın" diyebilmeni sağlıyor (motor seviyesinde hazır,
  editör arayüzüne henüz bağlamadım — istersen ekleyelim).
- **Fonksiyon çağırma** da reaktif modele uyarlandı: bir fonksiyon
  çağrıldığında, o fonksiyonun kuralları AYNI ekran görüntüsüne karşı
  (repeat sayısı kadar tur) değerlendiriliyor.

**Not:** Bu, motorun DAVRANIŞINI kökten değiştiren bir güncelleme.
Eskiden kaydettiğin kurallar yine çalışır (JSON yapısı uyumlu) ama
ARTIK FARKLI davranacaklar — sıralı ilerlemek yerine hepsi paralel,
her an tepki verir hâle geldiler. Test ederken bunu göz önünde bulundur.

## Alan Görünümü: Dolu Blok Yerine Çerçeve + Basılı Tut = Gizle/Sil

- Alanlar artık ekranı kaplayan renkli/saydam bir yüzey değil, **sadece
  ince renkli bir ÇERÇEVE** (Macrorify'daki gibi) — içi tamamen şeffaf,
  altındaki ekran görüntüsü net görünüyor. Varsayılan renk mavi;
  yapılandırınca yeşil (arama alanı), kırmızı (dokunma), mavi/mor
  (kaydırma başlangıç/bitiş), turuncu (fonksiyon çağırma) oluyor.
- **Bir alanın üzerine BASILI TUTUNCA** (kısa dokunuş değil, ~yarım
  saniye basılı tutma) küçük bir menü açılıyor: **"🙈 Gizle"** (alan
  listede/kayıtta kalır ama ekranda görünmez olur) ya da **"🗑 Sil"**
  (tamamen kaldırılır). Kısa dokunuş hâlâ normal ayar menüsünü açıyor,
  sürükleme hâlâ taşıma yapıyor — üç farklı davranış (tıkla/sürükle/
  basılı tut) birbirinden net ayrıldı.

## Kural Editörü Artık CANLI Akıyor (donmuyor)

Önceden "+ Kural Ekle"ye bastığında ekran TEK SEFERLİK bir fotoğraf
gibi donuyordu (SS alıp bekliyordu). Artık öyle değil: ekran görüntüsü
her ~400ms'de bir tazeleniyor, yani oyunun ekranı editördeyken de CANLI
akmaya devam ediyor. Alan çizip/sürükleyip/yapılandırırken arka planda
oyun da normal şekilde oynuyor gibi görünür (gerçekte oyun kendi
akışında zaten devam ediyordu, sadece SEN donmuş bir görüntüye
bakıyordun — artık öyle değil).

Not: Bir alanı "Resim Ara" yaptığında, o alandan kırpılan önizleme
YİNE DE o anki (dialog açıldığı andaki) görüntüden alınıyor — bu
bilinçli, çünkü şablon resmi sabit kalmalı, "canlı" olmamalı.

## BÜYÜK GÜNCELLEME: 4 Sekmeli Kural Penceresi (General / Action / On Success / Loop)

Attığın ekran görüntüsündeki Macrorify yapısını referans aldım. Artık
her alan kendi içinde TAM bir kural — mimari sadeleşti:

**Eskiden:** Önce arama alanı çiz → ayrı bir aksiyon alanı çiz → en
sonda hepsini birleştiren tek bir "Kaydet" penceresi aç.

**Şimdi:** Bir alan çiz, dokun, **4 sekmeli** bir pencere açılır:

- **GENEL**: İsim, grup, ne aranacak (Renk/Resim/Yazı), min skor.
  Renk için hâlâ "📍 Ekrandan Noktayı Seç" ile örnekleyebilir YA DA
  doğrudan HEX kodu yazabilirsin.
- **AKSİYON**: Dokunma / Kaydırma / Fonksiyon Çağırma — "📍 Noktayı Seç"
  butonuyla ekrana dokunup nokta belirlersin, pencere kaldığı sekmeden
  otomatik tekrar açılır.
- **BAŞARILI OLUNCA**: "+ Ekle" ile birincil aksiyondan HEMEN SONRA
  çalışacak EK aksiyonlar ekleyebilirsin — ek bir dokunma noktası YA DA
  başka bir fonksiyon çağırma (fonksiyonun içine de görsel tespiti
  koyabildiğin için, dolaylı olarak "iç içe görsel tespit" de mümkün
  oluyor).
- **TEKRAR**: Bekleme süresi (cooldown), ters mantık (kaybolunca
  tetikle), sayaç/değişken ayarları.

Pencerenin altındaki **"💾 Kaydet"** butonuna basınca o alan HEMEN
kendi kuralı olarak kaydolur — artık ayrı bir genel kaydetme adımı yok,
her alan bağımsız.

**Dürüstçe belirteyim — basitleştirdiğim/yapmadığım kısımlar:**
- **"On Fail" sekmesini eklemedim.** Bizim motorumuzda Dokunma/Kaydırma
  gibi aksiyonlar "başarısız" olmuyor (sadece koşul eşleşmiyor, ki o
  zaman zaten hiçbir şey çalışmıyor) — bu yüzden Macrorify'daki gibi
  ayrı bir "başarısız olunca" dalı bizim modelimizde tam karşılık
  bulmuyor. İstersen bunun için de bir kullanım senaryosu düşünüp
  ekleyebiliriz.
- **"Başarılı olunca" içine gerçek İÇ İÇE görsel tespit koyamıyorsun**
  — onun yerine bir Fonksiyon çağırıyorsun, o fonksiyonun İÇİNDE
  istediğin kadar görsel tespit/alan olabilir. Sonuç olarak aynı işi
  görür ama bir dolaylama katmanı var.
- "Başarılı olunca" eklenen her ek aksiyon, arka planda AYRI bir kural
  olarak kaydediliyor (aynı koşulu paylaşarak) — teknik bir detay,
  senin için görünür değil ama bilmen iyi olur.

## Kütüphaneye Ekrandan Direkt Kırpıp Kaydetme

"📚 Kütüphanem" ekranında artık en üstte **"📷 Ekrandan Kırp"** seçeneği
var (Galeriden Ekle'nin yanında). Buna basınca:

1. Canlı ekran görüntüsü açılır
2. İstediğin alanı sürükleyerek seçersin
3. **"✅ Kırp ve Kaydet"** → isim verirsin → kütüphaneye kaydolur

Herhangi bir kural oluşturmadan, sadece görsel biriktirmek için
kullanabilirsin. Sonra bir kural eklerken, o alanın **GENEL**
sekmesinde **"📚 Kütüphaneden Seç"** ile bu kaydettiğin resmi
istediğin alan için çağırabilirsin.

## "BULUNAMAZSA" (On Fail) Sekmesi Eklendi

5. sekme olarak **"BULUNAMAZSA"** eklendi — "BAŞARILI OLUNCA" ile
aynı arayüz (+ Ekle → Dokunma/Fonksiyon Çağırma), ama mantığı ters:

- **BAŞARILI OLUNCA**: koşul BULUNURSA bu ek aksiyonlar da çalışır
- **BULUNAMAZSA**: koşul BULUNAMAZSA (ekranda yoksa) bu aksiyonlar çalışır

Teknik detay: "Bulunamazsa" için eklediğin her aksiyon, arka planda
AYNI koşulu ama **ters mantıkla** (negate) kullanan ayrı bir kural
olarak kaydediliyor — yani "koşul YOKSA tetiklen" diyen bir kural.
Örnek kullanım: "Devam butonu ekranda yoksa, ekranı kaydırıp tekrar
kontrol et" gibi senaryolar artık doğrudan bu sekmeden kurulabiliyor.
