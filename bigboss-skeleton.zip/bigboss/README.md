# BigBoss

Royale Online (Android) için, ekranı okuyup senin tanımladığın kurallara
göre otomatik dokunuş/kaydırma yapan bir otomasyon aracı. Macrorify'ın
"Region + Template + Min Score + Timeout" mantığına dayanır, kod yazmadan
tamamen dokunarak kullanılır.

## İlk Açılış (Zorunlu Kurulum)

Uygulama ilk açıldığında, izinler tamamlanana kadar **sırayla zorunlu**
iki adım gösterilir (`OnboardingActivity`):
1. Ekran üstü gösterim izni
2. Erişilebilirlik servisi

İkisi de verilmeden ana ekrana (`MainActivity`) geçilmez. Her `onResume()`'da
kontrol edilir; izin eksikse ilgili adım otomatik olarak tekrar gösterilir.

## Kural Editörü (Macrorify tarzı, kodsuz)

1. Ana ekranda **"▶ Başlat"** → ekran kaydı izni onaylanır, overlay belirir
2. Overlay'deki **"+ Kural Ekle"** → anlık ekran görüntüsü donar
3. **Parmağını sürükleyerek bir ALAN (Region) çiz**
4. **🎨 Renk Ara** ya da **🖼️ Resim Ara** seç:
   - Renk: bölgenin ortalama rengi otomatik hesaplanır
   - Resim: bölge bir "şablon" (template) olarak kırpılıp kaydedilir,
     çalışma zamanında bu şablon o bölgede aranır (OpenCV'siz, basit
     kayan-pencere karşılaştırması — `engine/ImageMatcher.kt`)
5. **👆 Dokunma (Tap)** ya da **👉 Kaydırma (Swipe)** seç, nokta(lar)a dokun
6. İsim, **Min Score (%)** (Macrorify'daki "Min Score" ile aynı — ne kadar
   yüksekse o kadar sıkı eşleşme ister) ve **Arama süresi (ms)** (bu adımı
   en fazla ne kadar aktif arasın; `-1` = sınırsız) gir, kaydet

## Kurallar SIRAYLA çalışır (script mantığı)

Eskiden "ilk eşleşen kural kazanır" mantığı vardı; artık gerçek bir
**senaryo (script)** gibi çalışıyor — tıpkı Macrorify gibi:

- Motor (`RuleEngine`) listedeki 1. kuralda bekler, koşulu en fazla o
  kuralın `timeoutMs` süresi kadar arar.
- **Bulursa:** aksiyonu çalıştırır, 2. kurala geçer.
- **Süre dolarsa:** eşleşmeden 2. kurala geçer.
- Liste biterse başa döner (döngü).

Ana ekrandaki listede sıra numarası, koşul tipi, Min Score, süre ve
aksiyon tipi her kuralın altında özet olarak görünür.

## Kuralları Düzenleme ve Test Etme

- **✏️ Düzenle:** kuralı editörde yeniden açar (bölge/nokta yeniden
  çizilir, isim/skor/süre eski değerlerle önceden doldurulur), kaydedince
  aynı kural güncellenir (yeni kural olarak eklenmez).
- **🧪 Test Et:** botu tam çalıştırmadan, sadece o kuralın koşulunu anlık
  ekran görüntüsüne karşı değerlendirir ve skorunu gösterir
  ("✅ Eşleşti, skor %92" gibi) — böylece her özelliği tek tek,
  hızlıca test edebilirsin. Bunun için "Başlat"a basılmış (ekran
  görüntüsü akıyor) olması yeterli, Erişilebilirlik'in dokunuşu
  gerçekten uygulaması gerekmez.
- **🗑 Sil:** kuralı (ve varsa kayıtlı şablon resmini) siler.

## Klasör Yapısı

```
bigboss/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
└── app/src/main/
    ├── AndroidManifest.xml        (launcher artık OnboardingActivity)
    ├── java/com/bigboss/app/
    │   ├── ui/
    │   │   ├── OnboardingActivity.kt    # zorunlu sıralı izin akışı
    │   │   ├── MainActivity.kt          # kural listesi, başlat/durdur, test
    │   │   ├── RuleEditorActivity.kt    # bölge çiz -> renk/resim -> tap/swipe
    │   │   └── RulesAdapter.kt
    │   ├── service/
    │   │   ├── ScreenCaptureService.kt  # MediaProjection ekran yakalama
    │   │   ├── BigBossAccessibilityService.kt  # dokunuş/kaydırma simülasyonu
    │   │   └── OverlayService.kt        # "+ Kural Ekle" overlay'i
    │   ├── engine/
    │   │   ├── Condition.kt      # ColorInRegion / ImageInRegion, minScore
    │   │   ├── Action.kt         # Tap, Swipe, Wait, Sequence
    │   │   ├── Rule.kt           # id, condition, action, timeoutMs
    │   │   ├── RuleEngine.kt     # SIRALI script motoru (Macrorify tarzı)
    │   │   └── ImageMatcher.kt   # OpenCV'siz basit template matching
    │   ├── storage/
    │   │   ├── RuleDefinition.kt      # JSON'a çevrilebilir düz kural modeli
    │   │   ├── RuleStorage.kt         # rules.json okuma/yazma, upsert
    │   │   ├── RuleDefinitionMapper.kt
    │   │   └── TemplateStorage.kt     # resim şablonlarını PNG olarak kaydeder
    │   ├── util/PermissionUtils.kt
    │   └── model/Region.kt
    └── res/
        ├── drawable-nodpi/app_logo.png   # uygulama logosu (senin gönderdiğin görsel)
        ├── mipmap-anydpi-v26/ic_launcher.xml  # logo, uygulama simgesi olarak
        └── layout/ (activity_main, activity_onboarding, activity_rule_editor, item_rule)
```

## Şu An Eksik / Yapılacaklar

- [ ] **Gerçek OpenCV entegrasyonu** — şu anki `ImageMatcher` saf Kotlin ile
      çalışan basit bir eşleştirici (küçük şablonlarda/bölgelerde iyi,
      büyüklerde yavaş olabilir). İleride gerçek OpenCV `matchTemplate`'e
      geçilebilir.
- [ ] **Sürükle-bırak sıralama** — kural listesinde sırayı değiştirmek için
      RecyclerView'a `ItemTouchHelper` eklenmeli (şu an sıra = ekleme sırası).
- [ ] `ActivityResultContracts` ile `onActivityResult`'ın modern karşılığına
      geçiş (opsiyonel, şu an deprecated API kullanılıyor ama çalışır).

## Macrorify Dokümanlarından Eklenenler (bu sürüm)

Kaynak: kok-emm.com/docs — okuyup BigBoss'a uyarladıklarım:

- **Multi Detection → "VEYA Alternatifleri"**: Bir kuralın koşuluna birden
  fazla renk/resim/yazı alternatifi eklenebilir (`ConditionAlt` listesi).
  Herhangi biri eşleşirse kural tetiklenir (Macrorify'daki "One Detection
  Success" mantığı). Motor tarafında `Condition.Group` ile 6 mantık tipi de
  hazır (`ALL_SUCCESS`, `ONE_SUCCESS`, `ALL_FAIL`, `ONE_FAIL`,
  `ALWAYS_SUCCESS`, `ALWAYS_FAIL`) ama editör arayüzü şimdilik sadece VEYA
  (OR) akışını sunuyor.
- **Text Recognition → "📝 Yazı Ara"**: ML Kit'in cihaz-üstü OCR'ı ile bir
  bölgede belirli bir kelime/metin aranabiliyor (`engine/TextMatcher.kt`).
  İnternet/Play Services gerektirir, ilk kullanımda dil modeli inebilir.
- **Variables → Sayaçlar**: `engine/VariableStore.kt` ile isimli, sayısal
  global değişkenler. Bir kural tetiklendiğinde bir sayacı artırabilir
  (`incrementVariableName`), başka bir kural bu sayacın değerini şart
  olarak kontrol edebilir (`requireVariableName`). Örn: "5. kez düşman
  görülünce farklı bir şey yap" gibi senaryolar mümkün. Not: sayaçlar
  sadece uygulama açıkken bellekte tutulur, kalıcı değildir.
- **Grouping → Grup etiketi**: Her kurala isteğe bağlı bir grup adı
  verilebilir ("Savaş", "Toplama" gibi), listede `[Grup] Kural adı` olarak
  görünür. Macrorify'daki tam "collapsible sayfa + grup döngüsü" özelliği
  şimdilik yok, sadece organizasyon/etiketleme var.
- **Color Detection**: zaten vardı (bölge içinde renk arama), Min Score
  terminolojisiyle hizalandı.

**Bilinçli olarak eklemediklerim** (ve neden):
- **Setting Builder / Views / EMScript**: Bunlar Macrorify'da, yaptığın
  makroyu *başka kullanıcılara* dağıtırken onlara özelleştirilebilir bir
  arayüz/kod yazma imkanı sunmak için var. BigBoss şu an senin kişisel
  aracın olduğu için bu katman gereksiz karmaşıklık katardı. İstersen
  ileride "kural setlerini dışa aktar/paylaş" gibi basit bir sürümünü
  ekleyebiliriz.
- **Text Reader** (OCR ile metni bir değişkene okuyup kullanma): Text
  Recognition (arama) ekledim ama "oku ve değişkene ata" kısmını
  eklemedim, zaman/karmaşıklık dengesi için önceliklendirmedim.
- **Nested Logical Group editör arayüzü**: motor destekliyor ama
  dokunarak iç içe VE/VEYA grupları kurmak için ayrı bir görsel editör
  gerekir, sonraki bir iterasyona bıraktım.

## Kütüphane, HEX Renk, Gelişmiş Alan Düzenleme (bu sürüm)

- **📚 Kütüphane (Manage Images)**: Kural editöründe bir renk/resim
  oluştururken, isim vererek kütüphaneye kaydedebilirsin. Sonraki
  kurallarda **"📚 Kütüphaneden Seç"** ile o kayıtlı renk/resmi tekrar
  çağırabilirsin (dosya: `storage/LibraryItem.kt`, `LibraryStorage.kt`).
  Ana ekrandaki **"📚 Kütüphanem"** butonuyla kayıtlı öğeleri görüp
  silebilirsin.
- **# HEX Renk Gir**: Ekrandan örneklemek yerine, bilinen bir renk kodunu
  doğrudan yazabilirsin (`#FF3B30` gibi).
- **Gelişmiş alan düzenleme**: Artık bir bölge çizdikten SONRA onu
  sürükleyip taşıyabilir, sağ-alt köşesindeki beyaz tutamaçtan
  boyutlandırabilirsin — "✓ Alanı Onayla" diyene kadar ince ayar
  yapabilirsin. **Kural düzenlerken** de artık sıfırdan çizmek zorunda
  değilsin: mevcut alan otomatik olarak ekranda beliriyor, sadece
  sürükleyip/boyutlandırıp onaylıyorsun.

## Bu Sürümde Düzeltilen Hata

`RuleStorage.kt` içinde, kuralları alternatif listesine taşırken unutulan
eski bir `templatePath` referansı derlemeyi kırıyordu — düzeltildi.

## Nokta-Bazlı Renk Seçimi (Point-based Color Detection)

Macrorify'ın Color Detection dokümanını okudum: onlar da renk için
**bölge ortalaması değil, tek bir NOKTA**daki rengi kullanıyor (delta-E
metriğiyle karşılaştırıyorlar). BigBoss'ta da aynısını yaptım:

- **"🎨 Renk (Ekrandan)"** artık bölgenin ortalamasını almıyor. Bölgeyi
  çizdikten sonra, o bölge içinde **tam bastığın pikselin rengini**
  alıyor (HEX kodunu da gösteriyor: örn. "nokta: #FF3B30").
- Arama hâlâ tüm bölge içinde yapılıyor (`ColorInRegion`) — yani "bu
  bölgenin HERHANGİ bir noktasında bu TAM renk var mı" mantığı. Nokta
  sadece referans rengi belirlemek için kullanılıyor, aramayı tek
  piksele indirmiyor.
- Not: Biz gerçek **delta-E (CIE)** yerine basit bir RGB kanal-farkı
  benzerliği kullanıyoruz — Macrorify kadar renk-algısal doğru değil ama
  pratikte iyi çalışır. Nokta-bazlı seçimde varsayılan Min Score'u %95'e
  çıkardım (Macrorify'ın önerisiyle aynı: renk için yüksek skor gerekir).

## "Wait till appear" (Sadece Bekle)

Image Detection dokümanındaki 4 aksiyondan (`Click best match`,
`Click multiple matches`, `Wait till appear`, `Wait till vanish`) ilkini
zaten Tap/Swipe ile karşılıyorduk. Şimdi **"⏳ Sadece Bekle"** eklendi:
kural eşleşince hiçbir dokunuş/kaydırma yapmadan sadece bir sonraki
kurala geçer — bu da `Wait till appear`'ın karşılığı (motor zaten
koşulu timeout süresince aktif arıyor).

**Henüz eklemediklerim** (dürüst olmak gerekirse, dokümanı okudum ama
zaman kısıtından uygulamaya koyamadım):
- `Click multiple matches` (bölgedeki TÜM eşleşmelere tıklama — bizim
  basit `ImageMatcher`'ımız tek en-iyi-skor konumu buluyor, çoklu
  konum listesi döndürmüyor)
- `Wait till vanish` (rengin/resmin KAYBOLMASINI bekleme — teknik olarak
  mevcut koşulu `Condition.Group` + `ALL_FAIL` mantığıyla kurup
  yapılabilir ama editöre ayrı bir buton olarak henüz koymadım)
- `Loop` seçenekleri (None / Loop when success / Loop when fail /
  Loop always) — motor şu an her kuralı bir kez deneyip diğerine
  geçiyor, "N kere tekrarla" ayrı bir alan gerektirir
- `On Success` / `On Fail` dallanması (görsel bulunca farklı, bulunamayınca
  farklı bir alt-senaryoya dallanma) — motorumuz tek bir aksiyon
  çalıştırıyor, dallanma için ayrı bir yapı gerekir

İstersen bir sonraki adımda bunlardan hangisine öncelik vermemi istediğini
söyle, sırayla ekleyelim.

## Bu Sürüm: Yeni İkon, Renk Önizleme, Wait till Vanish, Loop

- **Yeni ikon**: Gönderdiğin "BIGBOSS" logosu artık uygulama simgesi.
- **Renk seçimi önizlemesi**: Bir noktaya dokunduğunda artık önce o rengin
  önizlemesini (renk kutusu + HEX kodu) gösteriyor, "Evet, bunu kullan" /
  "Tekrar dokun" diye soruyor — yanlışlıkla komşu pikseli seçme riskini
  azaltır.
- **⏳ Wait till Vanish**: Kural kaydetme ekranında "İleri Seviye" bölümünde
  "Ters mantık: koşul KAYBOLUNCA tetikle" seçeneği var. Açarsan, kural
  normalde eşleşme ARANDIĞI gibi değil, eşleşmenin KAYBOLMASI beklenip
  öyle tetiklenir (Macrorify'daki "Wait till vanish").
- **🔁 Loop**: "Eşleştikçe bu kuralda kal ve tekrar dene" seçeneğini açarsan,
  kural bir sonrakine geçmeden önce (opsiyonel bir üst sınıra kadar)
  kendini tekrar dener — sürekli aynı yerde beliren bir düşmanı art arda
  vurmak gibi senaryolar için.

Motor tarafında `loopMode` aslında 4 değeri destekliyor
(`NONE`, `WHILE_SUCCESS`, `WHILE_FAIL`, `ALWAYS`) ama editör arayüzü
şimdilik sadece en yaygın kullanılanı (`WHILE_SUCCESS`) tek bir
checkbox ile sunuyor; istersen `WHILE_FAIL`/`ALWAYS` için de ayrı
seçenekler ekleyebiliriz.

**Hâlâ eklemediğim** (Image Detection dokümanından): `Click multiple
matches` (bölgedeki TÜM eşleşmelere aynı anda tıklama) ve `On Success`/
`On Fail` dallanması (farklı sonuçlara göre farklı alt-senaryoya geçme).

## Edit Mode / Play Mode (Macrorify referansı)

Gönderdiğin videolarda gördüğüm Macrorify akışını uyguladım:

- **"▶ Başlat"a bastığında bot her zaman ✏️ EDIT MODE'da açılır.** Bu modda
  motor ekranı izler ama **hiçbir dokunuş/kaydırma yapmaz** — güvenle
  kural ekleyip düzenleyebilirsin. Overlay'de "+ Kural Ekle" ve
  "📋 Kurallar" butonları görünür.
- Overlay'deki **"▶️ Play Mode'a Geç"** butonuna basınca motor gerçekten
  çalışmaya başlar (▶️ PLAY MODE). Bu modda düzenleme butonları gizlenir,
  sadece **"✏️ Edit Mode'a Geç"** kalır — istediğin an geri dönebilirsin.
- Bu ayrım, önceki sürümdeki gizli bir riski de çözdü: eskiden kural
  düzenlerken arka planda motor hâlâ çalışıp yanlışlıkla dokunuş
  yapabiliyordu. Artık Edit Mode'dayken motor tamamen duraklatılmış
  oluyor (`RuleEngine.paused`).

Overlay'deki **"📋 Kurallar"** butonu seni ana ekrana (kural listesi,
test/düzenle/sil) götürür; oyuna dönmek için görev değiştiriciden geri
dönebilirsin.

## BÜYÜK GÜNCELLEME: Çoklu Alan (Multi-Region) Editör

Gönderdiğin Macrorify videosunu izleyip mantığını birebir uyguladım —
kural editörü artık tamamen farklı çalışıyor:

**Eski akış (artık yok):** Bir alan çiz → hemen "ne arayacak" menüsü
aç → aksiyon seç → kaydet. Tek seferde tek şey yapabiliyordun.

**Yeni akış (Macrorify tarzı):**
1. **"➕ Alan Ekle"** butonuna her bastığında ekrana sürüklenebilir/
   boyutlandırılabilir gri bir kutu düşer. **Hiçbir menü açılmaz.**
   İstediğin kadar "➕ Alan Ekle"ye basıp aynı anda birden fazla kutu
   yerleştirebilirsin.
2. Her kutuyu **sürükleyerek taşıyabilir**, sağ-alt köşesindeki beyaz
   tutamaçtan **boyutlandırabilirsin**.
3. Bir kutuya **kısa süreli dokunursan** (sürüklemeden) o kutu için bir
   menü açılır:
   - **"🔎 Arama Alanı Yap"** → Renk (ekrandan nokta seç) / HEX / Resim /
     Yazı / Kütüphaneden Seç
   - **"👆 Dokunma Noktası Yap"** / **"👉 Kaydırma Başlangıcı/Bitişi Yap"**
   - **"🗑 Bu Alanı Sil"**
4. Yapılandırdığın her kutu renkle işaretlenir (yeşil = arama alanı,
   kırmızı = dokunma, mavi/mor = kaydırma başlangıç/bitiş) ve üstünde
   küçük bir etiket gösterir.
5. **Birden fazla arama alanı** işaretlersen, bunlar otomatik olarak
   VEYA (OR) alternatifleri olur — ayrı bir "alternatif ekle" adımına
   gerek kalmadı.
6. Her şeyi yerleştirip yapılandırdıktan sonra **"💾 Kaydet"**e basarsın
   — isim/grup/süre/değişken gibi son ayarları giren tanıdık pencere açılır.

**Düzenleme (✏️ Düzenle) de bu yeni sisteme taşındı:** Var olan bir
kuralı açtığında, o kuralın tüm alanları (koşullar + aksiyon noktası)
otomatik olarak ekranda kutular hâlinde belirir, istediğini
sürükleyip/boyutlandırıp/silip yenisini ekleyebilirsin.

## Kütüphaneye Galeriden Resim Ekleme + Döndürme

- Ana ekrandaki **"📚 Kütüphanem"** açılınca artık en üstte
  **"➕ Galeriden Resim Ekle"** seçeneği var — telefonundaki herhangi bir
  görseli kütüphaneye ekleyebilirsin.
- Kütüphanedeki bir öğeye dokununca artık: resimlerde **"↻ 90° Döndür"**,
  ayrıca **"✏️ Yeniden Adlandır"** ve **"🗑 Sil"** seçenekleri çıkıyor.

**Henüz eklemediğim** (dürüstçe belirteyim): kütüphanedeki bir resmi
**yeniden kırpma** (crop) ya da **serbest açıyla döndürme** (sadece
90°'lik döndürme var) ve **boyut değiştirme** editörü. Bunlar ayrı bir
görsel kırpma/döndürme ekranı gerektiriyor, zaman kısıtından bu
sürüme sığdıramadım — istersen bir sonraki adımda onu yapalım.

## Bu Sürümde Düzeltilen Hata

`RuleEditorActivity.kt` içinde, renk noktası seçme akışında yanlışlıkla
tanımsız bir `region` değişkenine referans verilmişti (doğrusu
`pickRegion` olmalıydı) — düzeltildi.

## Overlay Artık Küçük Bir Simge

"▶ Başlat"a basınca ekranda beliren panel eskiden kocaman yer
kaplıyordu. Artık:

- Varsayılan olarak sadece **küçük tek bir simge** duruyor (✏️ ya da
  ▶️, hangi moddaysan onu gösterir)
- Simgeye **dokununca** tüm panel (durum + mod değiştir + kural ekle +
  kural listesi) açılır, **tekrar dokununca** kapanır
- Simgeyi **sürükleyerek** istediğin köşeye taşıyabilirsin (sürükleme
  ile dokunma otomatik ayırt ediliyor — sürüklersen taşır, sadece
  dokunursan açar/kapar)
- Kural editörüne ya da kural listesine gidince panel otomatik küçülür

## Overlay Artık Küçük Bir Simge

Botu başlatınca ekranda büyük bir panel yerine artık **tek, küçük bir
daire simge** duruyor (✏️/▶️ mevcut moda göre değişir):

- **Dokun** → panel açılır (durum, mod değiştir, kural ekle, kural
  listesi butonları görünür)
- **Tekrar dokun** → panel kapanır, yine küçük simgeye döner
- **Sürükle** → simgeyi ekranın istediğin köşesine taşıyabilirsin
- "+ Kural Ekle" ya da "📋 Kurallar"a bastığında panel otomatik küçülür

Böylece oyun ekranından çalınan alan en aza indi.

## BÜYÜK GÜNCELLEME: Ana Akış / Fonksiyonlar Ayrımı + Simge Tabanlı Arayüz

Gönderdiğin üç Macrorify ikonunu (🖼️👆 Aksiyon Ekle, 🏠 Home, f{} Function)
ve Fonksiyonlar dokümanını referans alarak uyguladım:

### Artık iki ayrı "kayıt yeri" var

1. **🏠 Ana Akış**: Botun sürekli döndüğü, tüm işlemlerin otomatik
   sırayla çalıştığı ana liste (eskiden tek listeydi, o bu).
2. **f{} Fonksiyonlar**: İsimlendirilmiş, AYRI kural dizileri. Ana akışta
   otomatik ÇALIŞMAZLAR — sadece bir kuralın aksiyonu **"🔧 Fonksiyon
   Çağır"** olduğunda devreye girerler: o fonksiyonun kuralları sırayla
   çalışır, bitince (ya da belirlediğin tekrar sayısı dolunca) ana akış
   kaldığı yerden devam eder. Tıpkı bir alt-program/subroutine gibi.

Ana ekranda artık üstte **"🏠 Ana Akış"** / **"f{} Fonksiyonlar"** sekmeleri
var. Fonksiyonlar sekmesinde **"➕ Yeni Fonksiyon"** ile isim vererek yeni
bir fonksiyon oluşturursun, üstüne dokunup içine kural eklersin.

### Kural editöründe yeni aksiyon tipi

Bir alanı aksiyon yaparken artık 4 seçenek var: Dokunma, Kaydırma
Başlangıcı, Kaydırma Bitişi, ve **"🔧 Fonksiyon Çağır Yap"** — bu
seçilince hangi fonksiyonun (var olan ya da yeni oluşturulan) kaç kere
çağrılacağını soruyor.

### Simge tabanlı overlay

"+ Kural Ekle" / "📋 Kurallar" yazılı butonlar yerine artık overlay
panelinde üç ikon var: **🖼️👆** (Aksiyon Ekle), **🏠** (Ana Akışı Aç),
**f{}** (Fonksiyonları Aç) — gönderdiğin görsellerdeki ikonlara emoji
karşılıklarıyla sadık kalmaya çalıştım (gerçek özel ikon grafikleri
yerine, zaman kısıtından emoji kullandım — istersen gerçek vektör
ikonlar da ekleyebiliriz).

### Motor tarafında: Çağrı Yığını (Call Stack)

`RuleEngine` artık fonksiyon çağrılarını gerçek bir "alt program çağırma"
mantığıyla yönetiyor: ana akış bir fonksiyonu çağırınca, motor o
fonksiyonun kural listesine geçer, bitirince (repeat sayısı kadar
tekrarladıktan sonra) otomatik olarak ana akışta KALDIĞI YERDEN devam
eder. İç içe fonksiyon çağrıları da (bir fonksiyon başka bir fonksiyonu
çağırabilir) teorik olarak destekleniyor.

**Not:** Bu çok büyük bir mimari değişiklikti — derleme hatası çıkma
ihtimali her zamankinden yüksek. Çıkarsa log'u paylaş, birlikte
düzeltiriz.

## BÜYÜK GÜNCELLEME: PLAY MODE / EDIT MODE Tam Ayrımı

Ana ekran artık sadece iki büyük buton:

- **▶️ PLAY MODE**: Ayrı bir ekran (`PlayModeActivity`). Açılınca izin
  ister, botu **hemen çalışır hâlde** başlatır (motor `paused=false`).
  Bu ekranda kural listesi, düzenleme, hiçbir şey YOK — sadece durum
  yazısı ve **"⏹ Durdur ve Ana Ekrana Dön"** butonu. Oyuna geçtiğinde
  ekranın üstünde küçük bir gösterge kalır (▶️ ikon → dokununca durum +
  durdur butonu açılır), ama düzenleme ikonu yok — sisteme dokunma imkanı
  yok, sadece izleyip durdurabilirsin.

- **✏️ EDIT MODE**: Ayrı bir ekran (`EditModeActivity`). Açılınca
  sessizce ekran görüntüsü akışını başlatır (motor hep `paused=true` —
  yani bu ekrandayken sistem KESİNLİKLE gerçek bir dokunuş/kaydırma
  yapmaz). Burada yapabileceğin her şey var: Ana Akış / Fonksiyonlar
  sekmeleri, Aksiyon Ekle, Kütüphanem. Üstte **"💾 Kaydet ve Çık"**
  butonu var — bastığında "Edit Mode'dan çıkmak istiyor musun?" diye
  sorar, Evet dersen ekran akışını durdurup ana ekrana döner (zaten her
  değişiklik anında diske kaydolduğu için "kaydet" burada aslında bir
  onay adımı, ekstra bir kaydetme işlemi gerekmiyor).

Eski "Başlat/Durdur" butonları ve overlay'deki Edit/Play geçiş anahtarı
kaldırıldı — mod artık ana ekranda SEÇİLİYOR, sonradan overlay'den
değiştirilmiyor. Overlay artık sadece PLAY MODE'dayken görünen minimal
bir durum+durdur göstergesi.

## Image Detection Menüsü Yeniden Tasarlandı (tek pencere)

Gönderdiğin Macrorify videosundaki gibi: artık bir alanı "Arama Alanı
Yap" dediğinde, önce küçük pencere → sonra başka küçük pencere → sonra
başka küçük pencere şeklinde ZİNCİRLEME açılmıyor. Hepsi **TEK bir
pencerede**:

- Üstte radyo düğmeleriyle **Renk / HEX / Resim / Yazı / Kütüphane**
  seçimi
- Seçime göre altta İLGİLİ alanlar anında değişiyor (renk için nokta
  seç + önizleme, HEX için kod kutusu, Resim için canlı kırpma
  önizlemesi, Yazı için metin kutusu, Kütüphane için seçim listesi)
- Min Skor ve kütüphaneye kaydetme alanı da aynı pencerede
- Tek **"✅ Uygula"** butonuyla hepsi bir kerede kaydediliyor

Sadece "Ekrandan Nokta Seç" (renk için) hâlâ ekrana dokunmayı
gerektiriyor — ama noktaya dokununca pencere KALDIĞI AYARLARLA
(seçtiğin renk otomatik dolu) tekrar açılıyor, sıfırdan başlamıyorsun.

## BÜYÜK GÜNCELLEME: Motor artık PARALEL / REAKTİF (gerçek Macrorify mantığı)

Macrorify'ın "Abstract Mode" dokümanını okudum ve önemli bir farkı
keşfettim: gerçek Macrorify **sıralı bir script gibi ÇALIŞMIYOR**.
Bizim eski motorumuz "1. kuralı bekle, bulursa/süre dolarsa 2.'ye geç"
mantığındaydı — bu YANLIŞ bir varsayımdı. Gerçek mantık şu:

> Aksiyonlar birbirinden bağımsızdır, aralarında sıra yoktur. Bir
> koşul doğru olduğu HER an, bağlı aksiyon tetiklenir. Görsel ekranda
> olduğu sürece tıklama devam eder; ekrandan kaybolursa durur, geri
> gelirse tekrar başlar.

Motoru buna göre TAMAMEN yeniden yazdım:

- **`RuleEngine.onFrame()`** artık her frame'de TÜM kuralları bağımsız
  kontrol ediyor — "sıradaki kural" kavramı kalktı.
- **"Arama süresi"** alanı **"Bekleme süresi" (cooldown / Wait Next)**
  oldu: bir kural tetiklendikten sonra, TEKRAR tetiklenebilmesi için en
  az bu kadar ms geçmesi gerekiyor (spam-tıklamayı önler). Koşul
  doğruluğunu korudukça kural bu aralıklarla tetiklenmeye devam eder —
  ayrı bir "tekrar et" ayarına gerek kalmadı, bu yüzden **🔁 Loop
  checkbox'ını kaldırdım** (artık gereksiz, davranış zaten böyle).
- **Yeni: `Condition.ActionResult`** — Macrorify'ın sıra gerektiren
  senaryolar için kullandığı yöntem: "B kuralı, A kuralı yakın zamanda
  tetiklendiyse çalışsın" diyebilmeni sağlıyor (motor seviyesinde hazır,
  editör arayüzüne henüz bağlamadım — istersen ekleyelim).
- **Fonksiyon çağırma** da reaktif modele uyarlandı: bir fonksiyon
  çağrıldığında, o fonksiyonun kuralları AYNI ekran görüntüsüne karşı
  (repeat sayısı kadar tur) değerlendiriliyor.

**Not:** Bu, motorun DAVRANIŞINI kökten değiştiren bir güncelleme.
Eskiden kaydettiğin kurallar yine çalışır (JSON yapısı uyumlu) ama
ARTIK FARKLI davranacaklar — sıralı ilerlemek yerine hepsi paralel,
her an tepki verir hâle geldiler. Test ederken bunu göz önünde bulundur.

## Alan Görünümü: Dolu Blok Yerine Çerçeve + Basılı Tut = Gizle/Sil

- Alanlar artık ekranı kaplayan renkli/saydam bir yüzey değil, **sadece
  ince renkli bir ÇERÇEVE** (Macrorify'daki gibi) — içi tamamen şeffaf,
  altındaki ekran görüntüsü net görünüyor. Varsayılan renk mavi;
  yapılandırınca yeşil (arama alanı), kırmızı (dokunma), mavi/mor
  (kaydırma başlangıç/bitiş), turuncu (fonksiyon çağırma) oluyor.
- **Bir alanın üzerine BASILI TUTUNCA** (kısa dokunuş değil, ~yarım
  saniye basılı tutma) küçük bir menü açılıyor: **"🙈 Gizle"** (alan
  listede/kayıtta kalır ama ekranda görünmez olur) ya da **"🗑 Sil"**
  (tamamen kaldırılır). Kısa dokunuş hâlâ normal ayar menüsünü açıyor,
  sürükleme hâlâ taşıma yapıyor — üç farklı davranış (tıkla/sürükle/
  basılı tut) birbirinden net ayrıldı.

## Kural Editörü Artık CANLI Akıyor (donmuyor)

Önceden "+ Kural Ekle"ye bastığında ekran TEK SEFERLİK bir fotoğraf
gibi donuyordu (SS alıp bekliyordu). Artık öyle değil: ekran görüntüsü
her ~400ms'de bir tazeleniyor, yani oyunun ekranı editördeyken de CANLI
akmaya devam ediyor. Alan çizip/sürükleyip/yapılandırırken arka planda
oyun da normal şekilde oynuyor gibi görünür (gerçekte oyun kendi
akışında zaten devam ediyordu, sadece SEN donmuş bir görüntüye
bakıyordun — artık öyle değil).

Not: Bir alanı "Resim Ara" yaptığında, o alandan kırpılan önizleme
YİNE DE o anki (dialog açıldığı andaki) görüntüden alınıyor — bu
bilinçli, çünkü şablon resmi sabit kalmalı, "canlı" olmamalı.

## BÜYÜK GÜNCELLEME: 4 Sekmeli Kural Penceresi (General / Action / On Success / Loop)

Attığın ekran görüntüsündeki Macrorify yapısını referans aldım. Artık
her alan kendi içinde TAM bir kural — mimari sadeleşti:

**Eskiden:** Önce arama alanı çiz → ayrı bir aksiyon alanı çiz → en
sonda hepsini birleştiren tek bir "Kaydet" penceresi aç.

**Şimdi:** Bir alan çiz, dokun, **4 sekmeli** bir pencere açılır:

- **GENEL**: İsim, grup, ne aranacak (Renk/Resim/Yazı), min skor.
  Renk için hâlâ "📍 Ekrandan Noktayı Seç" ile örnekleyebilir YA DA
  doğrudan HEX kodu yazabilirsin.
- **AKSİYON**: Dokunma / Kaydırma / Fonksiyon Çağırma — "📍 Noktayı Seç"
  butonuyla ekrana dokunup nokta belirlersin, pencere kaldığı sekmeden
  otomatik tekrar açılır.
- **BAŞARILI OLUNCA**: "+ Ekle" ile birincil aksiyondan HEMEN SONRA
  çalışacak EK aksiyonlar ekleyebilirsin — ek bir dokunma noktası YA DA
  başka bir fonksiyon çağırma (fonksiyonun içine de görsel tespiti
  koyabildiğin için, dolaylı olarak "iç içe görsel tespit" de mümkün
  oluyor).
- **TEKRAR**: Bekleme süresi (cooldown), ters mantık (kaybolunca
  tetikle), sayaç/değişken ayarları.

Pencerenin altındaki **"💾 Kaydet"** butonuna basınca o alan HEMEN
kendi kuralı olarak kaydolur — artık ayrı bir genel kaydetme adımı yok,
her alan bağımsız.

**Dürüstçe belirteyim — basitleştirdiğim/yapmadığım kısımlar:**
- **"On Fail" sekmesini eklemedim.** Bizim motorumuzda Dokunma/Kaydırma
  gibi aksiyonlar "başarısız" olmuyor (sadece koşul eşleşmiyor, ki o
  zaman zaten hiçbir şey çalışmıyor) — bu yüzden Macrorify'daki gibi
  ayrı bir "başarısız olunca" dalı bizim modelimizde tam karşılık
  bulmuyor. İstersen bunun için de bir kullanım senaryosu düşünüp
  ekleyebiliriz.
- **"Başarılı olunca" içine gerçek İÇ İÇE görsel tespit koyamıyorsun**
  — onun yerine bir Fonksiyon çağırıyorsun, o fonksiyonun İÇİNDE
  istediğin kadar görsel tespit/alan olabilir. Sonuç olarak aynı işi
  görür ama bir dolaylama katmanı var.
- "Başarılı olunca" eklenen her ek aksiyon, arka planda AYRI bir kural
  olarak kaydediliyor (aynı koşulu paylaşarak) — teknik bir detay,
  senin için görünür değil ama bilmen iyi olur.

## Kütüphaneye Ekrandan Direkt Kırpıp Kaydetme

"📚 Kütüphanem" ekranında artık en üstte **"📷 Ekrandan Kırp"** seçeneği
var (Galeriden Ekle'nin yanında). Buna basınca:

1. Canlı ekran görüntüsü açılır
2. İstediğin alanı sürükleyerek seçersin
3. **"✅ Kırp ve Kaydet"** → isim verirsin → kütüphaneye kaydolur

Herhangi bir kural oluşturmadan, sadece görsel biriktirmek için
kullanabilirsin. Sonra bir kural eklerken, o alanın **GENEL**
sekmesinde **"📚 Kütüphaneden Seç"** ile bu kaydettiğin resmi
istediğin alan için çağırabilirsin.

## "BULUNAMAZSA" (On Fail) Sekmesi Eklendi

5. sekme olarak **"BULUNAMAZSA"** eklendi — "BAŞARILI OLUNCA" ile
aynı arayüz (+ Ekle → Dokunma/Fonksiyon Çağırma), ama mantığı ters:

- **BAŞARILI OLUNCA**: koşul BULUNURSA bu ek aksiyonlar da çalışır
- **BULUNAMAZSA**: koşul BULUNAMAZSA (ekranda yoksa) bu aksiyonlar çalışır

Teknik detay: "Bulunamazsa" için eklediğin her aksiyon, arka planda
AYNI koşulu ama **ters mantıkla** (negate) kullanan ayrı bir kural
olarak kaydediliyor — yani "koşul YOKSA tetiklen" diyen bir kural.
Örnek kullanım: "Devam butonu ekranda yoksa, ekranı kaydırıp tekrar
kontrol et" gibi senaryolar artık doğrudan bu sekmeden kurulabiliyor.

## BÜYÜK EKLEME: Kod Sistemi (EMScript'ten ilham alan, gerçek JavaScript)

Kendi programlama dilimi sıfırdan yazmak yerine (bu ayrı bir proje
kadar büyük olurdu), saf-Java **Rhino** JavaScript motorunu uygulamaya
gömdüm. Bu sayede **gerçek** değişken, if/else, döngü (for/while),
fonksiyon, hatta class söz dizimi çalışıyor — EMScript'in kendisi
değil ama JavaScript, kavramsal olarak istediğin her şeyi karşılıyor.

### Nasıl kullanılır

EDIT MODE ekranında yeni bir sekme: **"🖥️ Kod"**. "➕ Yeni Script" ile
bir kod editörü açılır (isim + kod kutusu + "▶️ Test Et" + "💾 Kaydet").

### Kullanılabilir köprü fonksiyonları

```javascript
tap(x, y)                                    // dokun
swipe(x1, y1, x2, y2, ms)                    // kaydır
wait(ms)                                     // bekle
getVar("sayac")                              // değişken oku
setVar("sayac", 5)                           // değişken yaz
colorAt(x, y)                                // "#RRGGBB" döner
findColor(x, y, w, h, "#FF3B30", 0.9)        // true/false
findImage(x, y, w, h, "sablonYolu", 0.8)     // true/false
findText(x, y, w, h, "Devam")                // true/false
callFunction("fonksiyonAdi", 3)              // bir Fonksiyonu 3 kere çağır
log("mesaj")                                 // Logcat'e yaz (tag: BigBossScript)
```

### Örnek script

```javascript
var hp = getVar("hp")
if (hp < 50) {
    tap(950, 1800)  // potion butonu
    setVar("hp", hp + 20)
    log("Potion içildi, HP: " + (hp + 20))
} else {
    log("HP yeterli: " + hp)
}

for (var i = 0; i < 3; i = i + 1) {
    tap(900, 1700)
    wait(200)
}
```

### Güvenlik

**EDIT MODE'dayken `tap()`/`swipe()` çağrıları GERÇEK dokunuşa
ÇEVRİLMEZ** — sadece Logcat'e "(Düzenleme Modu — engellendi)" yazar.
Bu, "Edit Mode'da sisteme asla dokunulmaz" garantimizin script sistemi
için de geçerli olmasını sağlıyor. `findColor()`/`findText()`/`log()`
gibi salt-okunur fonksiyonlar Edit Mode'da da normal çalışır, test
edebilirsin.

### Henüz yapmadığım (dürüstçe)

- **Script'i bir kuralın koşulu/aksiyonu olarak görsel editöre bağlamadım.**
  Motor seviyesinde `Condition.Script` ve `Action.RunScript` hazır
  (bir script true/false dönerek koşul olabilir, ya da bir aksiyon
  olarak çalıştırılabilir) ama `RuleEditorActivity`'nin GENEL/AKSİYON
  sekmelerine "Script Seç" seçeneği eklemedim — o dosya zaten çok büyük
  ve kırılgan, bu yüzden riski azaltmak için bu sürümde sadece
  BAĞIMSIZ script'leri (yazıp test edip `callFunction()` ile
  birbirinden çağırabileceğin) sağlam bir şekilde teslim ettim.
  İstersen bir sonraki adımda görsel editöre bağlayalım.
- Script içinde `class` söz dizimini test etmedim (Rhino 1.7.14 ES6
  class desteği kısmi olabilir) — temel değişken/if/for/fonksiyon
  kesin çalışır.

## KRİTİK MİMARİ DÜZELTME: Artık Gerçekten Oyunun Üzerinde Çalışıyor

Attığın ekran görüntüsü gerçek bir hatayı ortaya çıkardı: **MediaProjection
(ekran yakalama) sadece o an EKRANDA GERÇEKTEN GÖRÜNENİ yakalar.**
BigBoss'un kendi "Edit Mode" ekranı açıkken, yakalanan görüntü de
BigBoss'un kendi arayüzüydü — oyun değil. Bu yüzden alan eklerken
kendi butonlarımızın fotoğrafını görüyordun.

**Kök sebep + çözüm:**

1. **RuleEditorActivity ve LibraryCaptureActivity artık ŞEFFAF.**
   Kendi çektiğimiz ekran görüntüsünü çizmeyi bıraktım — bu aktiviteler
   artık kendi arka planını göstermiyor, **altındaki GERÇEK uygulama
   (oyun) şeffaflık sayesinde doğal olarak görünüyor.** Alan kutuları
   ve pencereler onun ÜSTÜNE biniyor.

2. **Overlay'e "✏️ Alan Ekle" geri geldi (Macrorify'ın "floating
   control panel"ı gibi).** Play Store sayfasını okudum, doğruladım:
   Macrorify da tam olarak böyle çalışıyor — küçük bir simge oyunun
   üzerinde durur, ona dokununca pencereler açılır, hiçbir zaman ayrı
   bir "uygulama ekranına" geçmezsin.

### Yeni akış

1. **✏️ EDIT MODE**'a bas → izin ver → **"Hazır! Şimdi oyuna geç"** yazısını gör
2. **Oyuna geç** (görev değiştiriciden ya da oyunun simgesine dokunarak)
3. Ekranın üstünde küçük bir **✏️ simge** duruyor olacak
4. Ona dokun → **"🖼️👆 Alan Ekle"** → alan editörü **oyunun TAM
   ÜSTÜNE, şeffaf olarak** açılır — oyunu hâlâ görüyorsun
5. Alanı çiz, yapılandır, kaydet — **hiç oyundan ayrılmadan**
6. **"📋 Yönet"** ile istediğinde Ana Akış/Fonksiyonlar/Kod listesine
   göz atabilirsin (bu, ayrı bir yönetim ekranı — Macrorify'ın "macro
   listesi" ekranı gibi, canlı düzenleme için değil, gözden geçirmek için)

Artık gerçekten "arka planda kesintisiz" — BigBoss'un kendi ekranına
hiç geçmeden, oyunun içinde kalarak kural ekleyip düzenleyebiliyorsun.

## BÜYÜK DÜZELTME: Gerçek Macrorify Deneyimi — Hiç Ekran Açılmıyor

Dört sorunu birden çözdüm, hepsi aslında tek bir kök sebebe bağlıydı:
**EditModeActivity tam ekran bir sayfa olarak kalıyordu**, bu yüzden
başka uygulamaya geçince çalışmıyordu ve şeffaflık düzgün işlemiyordu.

### 1 & 2. Edit Mode artık HİÇ ekran açmıyor

"✏️ EDIT MODE"a bastığında: izin ister → overlay'i başlatır → **HEMEN
kendini kapatır** (`finish()`). Ekranda kalan tek şey küçük ✏️ simgesi.
Bu, hem "başka uygulamaya girince çalışmıyor" sorununu hem de "saydam
siyah alan" sorununu KÖKTEN çözüyor — çünkü artık RuleEditorActivity
şeffaf açıldığında altında GERÇEKTEN oyun oluyor, kendi eski
EditModeActivity ekranımız değil. Ayrıca kod seviyesinde de şeffaflığı
zorunlu kıldım (`window.setBackgroundDrawable(TRANSPARENT)`) — sadece
temaya güvenmek yerine.

PLAY MODE de aynı mantığa geçti: izin al, başlat, hemen kapan.

### 3. 👁️ Gizli Alanları Geri Getir

Kural editöründeki araç çubuğuna **"👁️"** butonu eklendi — tek
dokunuşla gizlediğin TÜM alanları geri getiriyor.

### 4. Overlay artık Macrorify'ın kendisi gibi: HER ŞEY oradan yönetiliyor

✏️ simgesine dokununca artık şu menü açılıyor:

- 🖼️👆 **Alan Ekle** — oyunun üstüne şeffaf editör açar
- 🏠 **Ana Akış** — kuralları listeler, dokununca Düzenle/Etkinleştir-
  Devre Dışı/Test Et/Sil seçenekleri çıkar
- f{} **Fonksiyonlar** — listeler, yeni oluşturur, içine kural ekletir
- 🖥️ **Kod** — script'leri listeler, yeni oluşturur, düzenlemeye götürür
- 📚 **Kütüphane** — ekrandan kırpma, döndürme, yeniden adlandırma, silme
- ▶️/✏️ **Mod Değiştir** — Ana Ekrana hiç dönmeden Play/Edit arasında geçiş
- ✕ **Kapat** — sistemi tamamen durdurur

Hepsi Service üzerinden (overlay pencere tipiyle) gösteriliyor —
hiçbiri ayrı bir uygulama ekranı açmıyor, oyunun üstünde kalıyor.

**Not:** "📚 Kütüphane"deki "Galeriden Resim Ekle" bu overlay menüsünden
kaldırıldı (Servisler galeri seçici sonucunu alamıyor, sadece
Activity'ler alabiliyor) — "📷 Ekrandan Kırp" hâlâ tam çalışıyor. İstersen
galeriden ekleme için ayrı, minik bir ekran ekleyebiliriz.

## Macrorify'ın Liste Düzenleyici İkonlarından Öğrenip Eklediklerim

Anlattığın 8 ikondan (Grup Göster, Aksiyon Ekle, Kopyala, Kes,
Yapıştır, Sil, Yukarı Taşı, Aşağı Taşı) karşılığını **🏠 Ana Akış**
menüsüne ekledim:

- **📋 Kopyala / ✂️ Kes / 📥 Yapıştır**: Bir kurala dokunup "Kopyala"
  ya da "Kes" seçersin, sonra Ana Akış menüsünün en üstünde beliren
  "📥 Yapıştır (kural adı)" ile istediğin an (aynı kuralı birden fazla
  kez bile) tekrar ekleyebilirsin.
- **⬆️ Yukarı Taşı / ⬇️ Aşağı Taşı**: Kuralın listedeki sırasını
  değiştirir (organizasyon amaçlı — motorumuz paralel/reaktif olduğu
  için sıra çalışma önceliğini etkilemiyor, ama listede düzenli
  görünmesini sağlıyor).
- **🔍 Gruba Göre Filtrele**: Kurallara verdiğin grup adına göre
  (örn. "Savaş", "Toplama") listeyi daraltıp sadece o gruptakileri
  görebiliyorsun — bu, "Grup Göster/Değiştir" ikonunun karşılığı.

Devam et — 2. görseldeki "Aksiyon Ekle" menüsünden bizde eksik olanları
(Play Record, Action Group/Loop, Conditional if-else kutusu, Text
Reader, System) da anlatmaya devam edersen sırayla ekleyelim.

## Kütüphanede Piksel-Hassas Kırpma

Kütüphanedeki bir resme dokunduğunda artık **"✂️ Piksel Kırp"**
seçeneği var. Açılan ekranda:

- Resmi büyütülmüş hâlde görürsün, üstünde mavi bir kırpma kutusu var
- Kutuyu **sürükleyip/köşeden boyutlandırabilirsin** (görsel)
- Altındaki **X / Y / Genişlik / Yükseklik** kutularına **tam piksel
  sayısı yazarak** kesin ayarlayabilirsin (ikisi birbirini canlı
  günceller — birini değiştirince diğeri de değişir)
- **"✅ Kırp ve Kaydet"** ile aynı dosyanın üzerine kaydeder

Bu, ekrandan ilk kırptığın görüntüyü sonradan daha da hassas hâle
getirmene (fazla boşlukları temizlemene, tam ikonu yakalamana) izin
veriyor.

## KÖKTEN MİMARİ DÜZELTME: Alan Çizme Artık Gerçek Overlay Penceresi

Gönderdiğin videoyu inceledim ve gerçek sebebi buldum: **şeffaf temalı
bir Activity, çoğu oyunun kullandığı SurfaceView/GLSurfaceView tabanlı
çizimle düzgün bindirilmiyor** — bu, Android'in bilinen bir kısıtı.
Bu yüzden RuleEditorActivity oyunun üstünde değil, koyu bir katmanın
üstünde görünüyordu (senin "sağ ve alt kısımlarında saydam karanlık
filtre" dediğin şey de muhtemelen bununla ilgiliydi).

**Çözüm: Alan çizme sistemini TAMAMEN Activity'den çıkarıp
OverlayService'e (gerçek WindowManager pencerelerine) taşıdım.**
Artık "Alan Ekle" bir Activity AÇMIYOR — doğrudan ekrana, tıpkı bizim
küçük ✏️ simgemiz gibi, GERÇEK bir pencere ekliyor. Bu tür pencereler
(TYPE_APPLICATION_OVERLAY) her uygulamanın (oyunlar dahil) üzerinde
güvenilir şekilde çalışır çünkü onlar da tıpkı senin ekranındaki diğer
"balon" tarzı uygulamalar (Messenger head'leri gibi) mantığıyla çalışır.

### Değişenler

- Her alan artık kendi bağımsız overlay penceresi — sürükleme,
  boyutlandırma, kısa dokunuşla ayar penceresi açma, basılı tutup
  gizleme/silme hepsi aynı şekilde çalışıyor, ama artık GERÇEKTEN
  oyunun üstünde.
- Renk seçerken "ekrana dokun" dediğimizde artık tam ekran GEÇİCİ bir
  yakalayıcı pencere açılıp bir dokunuşluk konumu alıyor, sonra kendini
  kaldırıyor — oyunun kendisine dokunmuş gibi olmuyorsun.
- 5 sekmeli ayar penceresi (Genel/Aksiyon/Başarılı/Bulunamazsa/Tekrar)
  aynen korundu, sadece artık Service üzerinden (overlay dialog olarak)
  açılıyor.
- Bir kuralı "✏️ Düzenle" dediğinde, o kuralın alanı GERÇEK bir overlay
  kutusu olarak ekrana geri geliyor, düzenleyip tekrar kaydedebiliyorsun.

### Dürüstçe bir sınırlama

**"f{} Fonksiyonlar" içine YENİ kural ekleme, bu overlay sürümüne henüz
taşınmadı** — RuleEditorActivity'deki o özellik (fonksiyona özel alan
çizme) çok büyük bir port gerektirdiği için bu turda atladım, bir Toast
ile durumu bildiriyor. Fonksiyonları SİLMEK hâlâ çalışıyor. İstersen bir
sonraki adımda onu da taşıyalım.

Bu, oturumun en büyük tek mimari değişikliğiydi — RuleEditorActivity'nin
~900 satırlık mantığının neredeyse tamamı OverlayService'e taşındı.
Derleme hatası çıkma ihtimali normalden yüksek, çıkarsa log'u paylaş.

## 5 Maddelik Büyük Güncelleme (GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR)

İstediğin 5 değişikliği uyguladım, ayrıca kod incelemesinde 2 gerçek
hata bulup düzelttim:

1. **GENEL**: Grup adı kaldırıldı. Min Skor artık hem kaydırma çubuğu
   HEM sayı kutusu (ikisi birbirini günceller). Bekleme süresi buraya
   taşındı + yeni **Delay** alanı (eşleşme bulunduktan SONRA, aksiyon
   çalışmadan önce beklenen süre). **Find Region** (X/Y/Genişlik/
   Yükseklik) eklendi — buraya yazdığın sayılar alanı EKRANDA da
   canlı taşıyıp boyutlandırıyor.
2. **AKSİYON**: "📍 Sabit Nokta" / "🎯 Eşleşen Noktaya Tıkla" seçimi
   eklendi — ikincisi seçilirse, koşulun ekranda BULDUĞU yere otomatik
   tıklanıyor. Tekrar sayısı (kaç kere tıklansın) eklendi.
3-4. **BAŞARILI / BULUNAMAZSA**: "+ Ekle" artık 6 seçenek sunuyor:
   Dokunma, Kaydırma, Bekleme, Fonksiyon Çağırma, Değişken Ayarlama,
   Kod Çalıştırma (kütüphanendeki script'lerden seçiyorsun) — Macrorify'daki
   çeşitliliğe yaklaştı.
5. **TEKRAR**: Tam istediğin 4 seçenek — None (tarar ve durur), Loop
   Always (sonsuz), Loop When Success (yakalayana kadar bekler, sonra
   durur), Loop When Fail (kayboluncaya kadar devam eder, sonra durur).

**Kod incelemesinde bulup düzelttiğim hatalar:** Kaydetme fonksiyonu
hâlâ kaldırdığımız "grup adı" alanına atıf yapıyordu (derleme hatası
verirdi) ve BAŞARILI/BULUNAMAZSA adımlarını doğru formatta kaydetmiyordu
— düzelttim. Ayrıca "Kod Çalıştır" seçeneği aslında hiçbir şey
yapmıyordu (sessizce no-op'a düşüyordu) — gerçekten script'i çalıştıracak
şekilde bağladım.

## YENİ ÖZELLİK: Action Group (Performans Gruplandırması)

Macrorify'ın grouping dokümantasyonunu okudum — onların "Action
Group"u daha çok organizasyon/döngü aracı, ama senin asıl ihtiyacın
(50 taramayı gereksiz yere sürekli kontrol etmemek) için daha güçlü
bir şey kurdum: **kapı koşuluna bağlı gruplar**.

### Nasıl çalışıyor

1. Overlay menüsünde yeni **"📦 Action Group"** seçeneği var
2. **"➕ Yeni Action Group"** ile grup oluştur (örn. "Savaş Ekranı")
3. **"🎯 Kapı Koşulunu Ayarla"** — bir alan çiz, bu grubun ne zaman
   "aktif" sayılacağını belirleyen KAPI koşulu (örn. savaş ekranındaki
   bir simge)
4. **"➕ Bu Gruba Tarama Ekle"** ile o grup içine istediğin kadar tarama
   (25 tane bile) ekleyebilirsin — bunlar normal "Alan Ekle" ile aynı
   şekilde çalışır (GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR sekmeleri)

### Performans kazancı burada

Sistemde artık Ana Akışta 50 ayrı tarama YERİNE, sadece **2 "kapı"
kuralı** çalışıyor (grup A'nın kapısı + grup B'nin kapısı). Kapı A
ekranda YOKSA, o gruptaki 25 tarama **hiç kontrol edilmiyor bile** —
motor onlara hiç bakmıyor. Kapı bulununca, o grubun İÇİNDEKİ taramalar
devreye giriyor (bizim mevcut "Fonksiyon çağırma" mekanizmasını
kullanarak, arka planda).

Grubu **"🔕 Devre Dışı Bırak"** ile tamamen kapatabilir, **"📋 Gruptaki
Taramaları Listele"** ile içindekileri görüp düzenleyebilir/silebilirsin.

### Teknik not

Bu özelliği eklerken, motoru her yerde tutarlı kurmak için tüm dağınık
kodu tek bir merkezi yardımcıya (`EngineAssembler`) topladım — bu hem
Action Group'ları hem mevcut Fonksiyonları aynı mekanizmayla (Fonksiyon
Çağırma) çalıştırıyor, hiçbir motor değişikliği gerekmedi.

## Fonksiyonlara Tam Tarama Ekleme + Fonksiyon↔Grup Çağırma

1. **"f{} Fonksiyonlar" artık Action Group ile birebir aynı güçte.**
   Bir fonksiyona dokunup **"➕ Bu Fonksiyona Tarama Ekle"** dediğinde,
   tıpkı "Alan Ekle"deki gibi tam bir alan çiziyorsun — 5 sekmeli
   (Genel/Aksiyon/Başarılı/Bulunamazsa/Tekrar) ayar penceresiyle:
   ekrana dokunma, kaydırma, kod çalıştırma, değişken ayarlama —
   hepsi artık fonksiyonların içinde de kullanılabiliyor. **"📋
   Fonksiyondaki Taramaları Listele"** ile içindekileri görüp
   düzenleyebilir/silebilirsin (önceki "henüz taşınmadı" sınırlamasını
   kaldırdım).

2. **Fonksiyonlar ve Action Group'lar artık birbirini çağırabiliyor.**
   "🔧 Fonksiyon Çağır" dediğin her yerde (Aksiyon sekmesi, Başarılı/
   Bulunamazsa'daki "+ Ekle") artık liste hem **f{} Fonksiyonları**
   hem **📦 Action Group'ları** birlikte gösteriyor — bir fonksiyonun
   içinden bir grubu, ya da bir grubun içinden bir fonksiyonu
   çağırabilirsin. İkisi de aynı mekanizmayı (isimden id'ye çözümleme)
   paylaştığı için bu, motor tarafında hiçbir ek karmaşıklık
   gerektirmedi.

## YENİ: 🗺️ Çalışma Alanı (Macrorify'daki "Draw selected/change working group")

Bahsettiğin karışıklık sorununu çözmek için overlay menüsüne **"🗺️
Çalışma Alanı"** butonu ekledim. Buna basınca:

1. **"Ana Akış"**, herhangi bir **Fonksiyon**, ya da herhangi bir
   **Action Group** seçiyorsun
2. O kapsamdaki TÜM alanlar, ekranda **turuncu kutucuklar** olarak
   aynı anda beliriyor — hangi alanın hangi işleme ait olduğunu
   görebiliyorsun
3. Bir kutucuğa dokununca, o kural direkt **düzenleme penceresine**
   açılıyor (bonus: sadece gösterim değil, hızlı erişim de sağlıyor)
4. Tekrar **"🗺️ Çalışma Alanı"** → **"🧹 Çalışma Alanı Görünümünü
   Kapat"** ile hepsini tek seferde temizliyorsun

Bu kutular salt-okunur/görüntüleme amaçlı — sürüklenmiyor,
boyutlandırılmıyor (karışıklığı önlemek için). Play Mode'a geçince ya
da overlay kapanınca otomatik temizleniyor.

## Play Mode Yeniden Tasarlandı: Play / Pause / Stop / Kapat

Play Mode artık tamamen ayrı, sade bir menüye sahip:

- **▶️ Play**: makroyu çalıştırır
- **⏸️ Pause / ▶️ Devam Et** (tek buton, iki hâl): duraklatır, tekrar
  basınca KALDIĞI YERDEN devam eder (durum sıfırlanmaz)
- **⏹ Stop**: durdurur VE sıfırlar — "None/Loop When Success/Loop When
  Fail" gibi "bir kere çalışıp biten" kuralların durumu temizlenir,
  bir sonraki Play tamamen baştan başlar
- **✕ Kapat**: Play Mode'u komple kapatır, ekrandaki simgeler gider

## YENİ: 👁️ Canlı İzleme (yeşil/kırmızı geri bildirim)

Play Mode menüsüne **"👁️ Canlı İzleme"** eklendi. Açtığında, Ana
Akıştaki TÜM alanlar ekranda kutucuklar olarak beliriyor ve her ~400ms'de
bir güncelleniyor:

- **🟢 Yeşil**: o an eşleşme yakalandı
- **🔴 Kırmızı**: o an eşleşme yok

Böylece makron çalışırken hangi taramaların tuttuğunu, hangilerinin
tutmadığını CANLI olarak görebiliyorsun — test/hata ayıklama için
tam istediğin gibi. Tekrar "👁️ Canlı İzlemeyi Kapat" ile kapatılıyor,
Stop/Kapat'a basınca da otomatik kapanıyor.

## OCR (Yazı) için Tolerans/Min Skor Eklendi

Haklıydın — OCR bazen harfleri yanlış okuyabiliyor, ama sistemimiz o
ana kadar SADECE tam eşleşme arıyordu (ya birebir aynı ya hiç). Şimdi
düzelttim:

- **`TextMatcher`** artık gerçek bir **benzerlik skoru** (0-100) hesaplıyor
  (Levenshtein/düzenleme mesafesi tabanlı) — "aranan metne ne kadar
  yakın" diye ölçüyor, sadece "var mı yok mu" demiyor.
- **GENEL sekmesi → Yazı (OCR)** seçeneğine artık **Min Skor** kontrolü
  (hem kaydırma çubuğu hem sayı kutusu) eklendi — "Tolerans" olarak
  etiketledim. Düşük değer = daha esnek (OCR'ın küçük hatalarını
  tolere eder), yüksek değer = daha katı (neredeyse birebir eşleşme ister).
- Ayrıca fark ettim: motor kodunda Min Skor değerin her zaman
  sabit %50'ye ayarlanıyordu, senin verdiğin değeri hiç kullanmıyordu
  — bunu da düzelttim, artık gerçekten ayarladığın toleransı kullanıyor.

## Üç Düzeltme: Basılı Tutma, Grup Entegrasyonu, Kütüphane Kırpma

### 1. Basılı tutma (uzun basış) artık güvenilir çalışıyor

Gerçek sebebi buldum: uzun basışı iptal eden hareket toleransı sadece
**18 ham piksel**di — bu, elin doğal titremesiyle bile kolayca aşılan
bir değer, bu yüzden basılı tutma çoğu zaman hiç tetiklenmiyordu.
Toleransı **24dp** (yoğunluğa göre ölçekli, çok daha makul) yaptım.

Ayrıca gerçek bir veri hatası da buldum: "🗑 Sil" daha önce sadece
ekrandaki kutuyu kaldırıyordu, ama **kayıtlı kural/kural verisini
silmiyordu** — yani zaten kaydedilmiş bir alanı silmeye çalışınca
kutu kayboluyor ama kural arka planda kalmaya devam ediyordu. Artık
kapsamına göre (Ana Akış/Grup/Fonksiyon) doğru depodan da siliyor.

### 2. Action Group'lar artık "🏠 Ana Akış" içinde

Ayrı bir "📦 Action Group" menüsü kaldırıldı — gruplar artık Ana Akış
listesinin İÇİNDE (📦 simgesiyle) görünüyor, kurallarla birlikte.
Yeni bir grup oluşturmak da Ana Akış'tan yapılıyor.

**Her grubun kendine özel ayarı var:** bir gruba dokunup **"⚙️ Grup
Ayarları"** ile:
- **Döngü sayısı**: kapı koşulu bulununca gruptaki taramalar kaç kere
  art arda çalışsın
- **Kapı kontrol sıklığı**: kapı koşulu en fazla ne kadar sık kontrol
  edilsin

### 3. Kütüphanedeki "Ekrandan Kırp" artık her uygulamada çalışıyor

Bu, RuleEditorActivity'de yaşadığımız AYNI sorundu — LibraryCaptureActivity
de bir Activity olduğu için, oyun gibi SurfaceView kullanan uygulamaların
üzerinde düzgün görünmüyordu (izin sorunu değildi, Android'in Activity/
SurfaceView bindirme kısıtıydı). Şimdi bunu da RuleEditorActivity'de
yaptığımız gibi GERÇEK bir overlay penceresine taşıdım — artık hangi
uygulamanın (oyun dahil) üzerinde olursan ol çalışıyor.

## YENİ: Görünür, Sürüklenebilir Nokta İşaretçileri (Macrorify'daki gibi)

Macrorify'ın dokümantasyonunu araştırdım — dokunma/kaydırma noktalarını
her zaman ekranda GÖRÜNÜR, sürüklenebilir işaretçiler olarak gösteriyor
("Swipe Point", numaralı 1-2-3 gibi). Bizim eski sistemimiz "kör
dokunuş"tu (görünmeyen bir yakalayıcıyla tek dokunuş alıp hemen
kapanıyordu) — şimdi aynı Macrorify mantığına geçirdim:

- **Dokunma noktası seçerken**: ekranda sürüklenebilir bir **👆
  işaretçi** beliriyor, istediğin yere sürükleyip ayrı duran **"✓
  Onayla"** butonuna basıyorsun
- **Kaydırma seçerken**: SIRAYLA iki işaretçi çıkıyor — önce **"1"**
  etiketli (başlangıç), onu onaylayınca **"2"** etiketli (bitiş) —
  ikisini de görüp ayarlayarak yerleştiriyorsun

Bu, hem Fonksiyonlar hem Action Group'lar hem Ana Akış'ta, hem
Aksiyon sekmesinde hem "Başarılı Olunca/Bulunamazsa" sekmelerindeki
ek dokunma/kaydırma adımlarında GEÇERLİ — artık nereye dokunacağını
tam olarak görerek karar veriyorsun, kör tıklama kalmadı.

(Renk seçimi hâlâ eski "ekrana dokun" yöntemiyle — çünkü o bir NOKTA
İŞARETLEMEK değil, o pikseldeki RENGİ ÖRNEKLEMEK için, farklı bir iş.)

## Edit Mode'dan Çıkmadan Test Edebilme

Sorunu buldum: test etmek istediğinde tek yol "▶️ Çalışmayı Başlat"tı,
bu da seni tamamen Play Mode'un ayrı menüsüne (Play/Pause/Stop/Kapat)
geçiriyordu — Edit Mode'un kural/fonksiyon/grup menülerini kaybediyordun.

Artık Edit Mode menüsüne **"🧪 Canlı Test (Edit Mode'da kal)"**
eklendi. Buna basınca:

- Motor GERÇEKTEN çalışmaya başlıyor (kurallar tetikleniyor,
  dokunuşlar/kaydırmalar GERÇEKLEŞİYOR)
- Ama **overlay menüsü Edit Mode'da kalıyor** — "Alan Ekle", "Ana
  Akış", "Çalışma Alanı" gibi tüm düzenleme seçeneklerine hâlâ
  erişebiliyorsun
- Üst durum yazısı **"🧪 CANLI TEST"** olarak değişiyor, unutmaman için
- Tekrar basıp **"⏸️ Canlı Testi Durdur"** ile güvenli düzenleme moduna
  dönüyorsun

"▶️ Play Mode'a Geç" butonu hâlâ duruyor — o, kalıcı/gerçek çalıştırma
için (Play/Pause/Stop menüsüyle). Yeni "🧪 Canlı Test" ise hızlı,
Edit Mode'dan hiç ayrılmadan doğrulama yapmak için.

## KRİTİK HATA DÜZELTMESİ: Aksiyonlar Neden Hiç Çalışmıyordu

Gerçek sebebi buldum — ciddi bir hataydı:

**EditModeActivity, erişilebilirlik servisini SADECE BİR KERE**
(`val executor = BigBossAccessibilityService.instance`) **yakalayıp
motoru onunla sarmalıyordu.** Eğer o an (Edit Mode ilk açıldığında)
servis henüz bağlanmamışsa — ki bu çok yaygın bir zamanlama durumu,
izin verdikten hemen sonra servisin bağlanması birkaç saniye
sürebiliyor — motor **KALICI OLARAK boş bir çalıştırıcıya** bağlanmış
oluyordu. Servis birkaç saniye sonra bağlansa bile, motor bunu asla
öğrenmiyordu çünkü değişkeni bir kere okuyup unutmuştu.

Daha da kötüsü: bu AYNI motor örneği "🧪 Canlı Test" ve "▶️ Play
Mode" tarafından da (yeniden oluşturulmadan) kullanılıyordu — yani bir
kere bu duruma düşünce, **uygulamayı tamamen kapatıp yeniden
açmadan** hiçbir komut çalışmıyordu. Koşul eşleşiyordu (yeşil
yanıyordu, Test Et "✅ Eşleşti" diyordu) ama aksiyon hiç tetiklenmiyordu.

**Düzeltme:** Artık motor, komut her çalıştırılacağında erişilebilirlik
servisinin GÜNCEL durumuna bakıyor (bir kere okuyup saklamak yerine).
Servis ne zaman bağlanırsa bağlansın, komutlar o andan itibaren
çalışmaya başlıyor. Play Mode tarafında da aynı güçlendirmeyi yaptım
(servis herhangi bir sebeple yeniden bağlanırsa diye).

## Artık Silmeden Güncelleyebilirsin

Sabit bir debug imza anahtarı (`app/debug.keystore`) oluşturup projeye
ekledim ve `build.gradle.kts`'i bunu her zaman kullanacak şekilde
ayarladım. Daha önce GitHub Actions her derlemede FARKLI/rastgele bir
anahtar kullanıyordu (temiz sanal makine olduğu için), bu da Android'in
"imza uyuşmuyor" diyip seni her seferinde önce silmeye zorlamasına
sebep oluyordu.

**Bundan sonraki akış:**
1. Değişiklik iste → ben kodu güncelleyip zip'i tekrar veririm
2. GitHub'da eski zip'i sil, yenisini yükle, Actions → Run workflow
3. Yeni APK'yı indir, telefonda **DOĞRUDAN** (silmeden) kur — dosya
   yöneticisinden APK'ya dokun, "Güncelle" diyecek, kurallar/
   fonksiyonlar/ayarların hepsi KALACAK

Sadece bir istisna var: bir zip yükleme hatası ya da çok büyük bir
mimari değişiklik olursa (nadiren) yine de silmen gerekebilir, ama
normal geliştirme akışında artık gerek yok.

## Üç Ek Düzeltme

**1. ⏱️ HOLD (basılı tutma süresi)** — Aksiyon sekmesinde, Dokunma
seçiliyken artık "Tekrar sayısı"nın yanında **HOLD** alanı var: noktada
kaç ms basılı tutulsun. Uzun basış gerektiren yerler için artırabilirsin.

**2. Canlı Test artık otomatik yeşil/kırmızı + sıralı gösteriyor** —
"🧪 Canlı Test"i başlattığında, ayrı bir seçenek AÇMANA gerek kalmadan
otomatik olarak: tüm alanlar yeşil/kırmızı renkleniyor VE o anda hangi
alanın kontrol edildiğini **kalın çerçeve + isim etiketiyle** sırayla
gösteriyor ("🔍 Taranıyor: [kural adı] (3/12)" gibi). Testi durdurunca
otomatik kapanıyor.

**3. Resim arama artık kütüphane-merkezli** — "Kırpma önizlemesi"
kaldırıldı (artık alan hareket ettikçe otomatik güncellenmiyordu,
kafa karıştırıyordu). Yerine: **"📚 Kütüphaneden Seç"** ve **"✂️
Ekrandan Kendim Kırpacağım"** — ikincisiyle kırptığın HER resim
otomatik olarak kütüphaneye ekleniyor VE o kuralda seçili oluyor, tek
adımda hem kaydediyor hem kullanıyorsun.

## Ana Akış: Macrorify Tarzı Temiz Liste Görünümü

Attığın ekran görüntüsündeki gibi: her satır artık **ikon solda +
isim ortada + ek bilgi sağda**, düz metin liste değil. Kurallar için
ikon türe göre değişiyor (🎨 renk, 🖼️ resim, 📝 yazı, 👆/👉 koşulsuz
dokunma/kaydırma), gruplar için 📦, sağ tarafta kısa özet bilgi
(kapı durumu, tekrar sayısı, vb.) görünüyor.

## Fonksiyonlara Çeşitlilik: Artık Sadece "Tarama" Değil

"➕ Bu Fonksiyona Adım Ekle" artık 3 seçenek sunuyor:

- **🔍 Tarama Alanı Ekle** — eskisi gibi, koşullu (renk/resim/yazı arar)
- **👆 Sadece Dokunma Ekle** — YENİ, koşulsuz — sadece işaretçiyle
  nereye dokunacağını seçiyorsun, hiçbir tarama/koşul gerekmiyor
- **👉 Sadece Kaydırma Ekle** — YENİ, koşulsuz — "1" ve "2" işaretçileriyle
  başlangıç/bitiş noktalarını seçiyorsun

Bu, Macrorify'daki gibi bir Fonksiyonun/Job'ın hem koşullu taramalar
HEM basit dokunma/kaydırma adımları içerebilmesini sağlıyor — artık
her adımın bir "arama alanı" olması zorunlu değil.

## KÖKTEN DEĞİŞİM: Resim Algılama Motoru Yeniden Yazıldı

Haklıydın — eski sistem gerçekten zayıftı. Sebep: her aday noktada
**Bitmap kırpıp yeniden ölçekliyordu** (ağır bellek/çöp toplama yükü)
ve sadece ham piksel farkına bakıyordu (parlaklık/kontrast değişimlerine
karşı çok kırılgan). Tamamen yeniden yazdım:

### Artık gerçek bilgisayarlı görü tekniği kullanıyor

**Normalize Edilmiş Çapraz Korelasyon (NCC)** — OpenCV'nin
`matchTemplate` (TM_CCOEFF_NORMED) fonksiyonuyla AYNI matematiksel
temel. Ortalama ve varyans normalize edildiği için parlaklık/kontrast
farklarına çok daha dayanıklı — aynı ikon biraz farklı ışıkta/animasyon
karesinde bile artık tanınabiliyor.

### Çok daha hızlı

- Şablon ve arama bölgesi **piksel dizisine bir kere** çevriliyor —
  arama döngüsünde hiç Bitmap kırpma/ölçekleme yok (bunlar en pahalı
  işlemlerdi)
- **Kaba-ince (coarse-to-fine) arama**: önce büyük adımlarla kaba bir
  tarama yapıp en olası bölgeyi buluyor, sonra SADECE o bölgenin
  etrafında piksel piksel ince arama yapıyor — eskiden TÜM bölgeyi
  piksel piksel taramak gerekiyordu

### Ayrıca bir hata da düzelttim

Yeni sistem, şablonları dosya yoluna göre önbelleğe alıyor (hız için).
Ama "✂️ Piksel Kırp" ve "↻ 90° Döndür" özellikleri resmi AYNI dosya
yolunun üzerine yazıyordu — bu da önbelleğin eski/yanlış veriyle
kalmasına sebep olabilirdi. Her iki işlemden sonra önbelleği otomatik
temizleyecek şekilde düzelttim.

## Resim Algılama: Çoklu Ölçek Arama Eklendi (Çok Daha Güvenilir)

Motoru inceledim — zaten OpenCV'nin `matchTemplate`'iyle AYNI matematiksel
temele sahip gerçek bir teknik (Normalize Çapraz Korelasyon / NCC)
kullanıyordu, ama **TEK BİR sabit boyutta** arıyordu. "Resim algılama
düzgün çalışmıyor" şikayetinin en yaygın gerçek sebebi de tam bu:
ekrandaki ikon, kaydettiğin şablonla PİKSEL PİKSEL aynı boyutta
olmayabilir (farklı çözünürlük, hafif animasyon, DPI farkı) — bu
durumda eski sistem eşleşmeyi TAMAMEN kaçırıyordu.

**Şimdi:** Şablon **7 farklı ölçekte** (%85 - %115 arası) deneniyor,
en iyi skoru veren ölçek kullanılıyor. Ayrıca:
- Çalışma çözünürlüğünü 64px'den **96px'e** çıkardım (daha çok detay,
  daha isabetli eşleşme)
- Yeterince iyi bir eşleşme (>%97) bulununca diğer ölçekleri denemeyi
  bırakıyor (hız kaybı yaşamadan güvenilirlik kazandırıyor)
- Kaba tarama adımı artık şablon boyutuna göre otomatik ayarlanıyor
  (küçük şablonlarda adım çok büyük olup eşleşmeyi atlamıyor)

**Dürüstçe bir not:** Bu, tam OpenCV kütüphanesini ya da bir ML
modelini (örn. TensorFlow Lite tabanlı nesne tanıma) projeye dahil
etmiyor — o seçenek gerçek anlamda "yapay zeka" olurdu ama APK boyutunu
ciddi büyütür (30-100MB+) ve derleme/kurulum karmaşıklığını artırır.
Şu anki çözüm, aynı matematiksel temeli (NCC) kullanıp ona ÖLÇEK
TOLERANSI ekleyerek pratikte çok benzer bir güvenilirlik sağlıyor.
İstersen gerçek OpenCV/ML entegrasyonunu da konuşabiliriz — ama bu
büyük bir proje kararı, seninle netleştirmemiz gerekir.

## Ana Akış Artık TAM BİR SAYFA — 8 İkonlu Araç Çubuğuyla

Attığın 2. görseldeki (Macrorify'ın alt araç çubuğu) mantığı birebir
kurdum. "🏠 Ana Akış"a bastığında artık küçük bir liste penceresi
DEĞİL, tam bir sayfa açılıyor:

- **Üstte**: kaydırılabilir liste (kurallar + Action Group'lar birlikte)
- **Bir öğeye dokununca**: SEÇİLİ hâle geliyor (mavi vurgu) — tekrar
  dokununca seçim kalkıyor
- **Altta 8 ikonlu araç çubuğu**, SEÇİLİ öğe üzerinde çalışıyor:
  - 🗺️ Görüntüle/Aç — seçilinin tam ayar/detay penceresini açar
  - ➕ Ekle — yeni Alan ya da Action Group ekler
  - 📋 Kopyala · ✂️ Kes · 📥 Yapıştır
  - 🗑 Sil
  - ↑ Yukarı Taşı · ↓ Aşağı Taşı

Bu, senin daha önce tek tek anlattığın 8 ikonun (Draw selected/Add
action/Copy/Cut/Paste/Delete/Move up/Move down) gerçek karşılığı —
artık her işlem için ayrı bir alt-menüye girmene gerek yok, seç ve
alttaki ikona bas.

## "➕ Ekle" Artık Tüm Ekleme Özelliklerini Kapsıyor

Ana Akış sayfasındaki "➕ Ekle" butonu eskiden sadece 2 seçenek
sunuyordu, şimdi bugüne kadar eklediğimiz HER ŞEY burada:

- 🔍 **Tarama Alanı Ekle** — koşullu (renk/resim/yazı arar)
- 👆 **Sadece Dokunma Ekle** — koşulsuz, direkt Ana Akışa
- 👉 **Sadece Kaydırma Ekle** — koşulsuz, direkt Ana Akışa
- 📦 **Yeni Action Group**
- f{} **Yeni Fonksiyon**
- 🖥️ **Yeni Script (Kod)**

Artık "önce Fonksiyonlar menüsüne git, sonra oradan ekle" gibi dolambaçlı
yollara gerek yok — Ana Akış sayfasından tek dokunuşla her türünü
ekleyebiliyorsun. Koşulsuz dokunma/kaydırma adımlarını da (Fonksiyonlardaki
gibi) artık düzenleyebiliyorsun ("✏️ Düzenle" basit adımlar için hızlı
yeniden-seçim açıyor).

## Üç İstek Birden

### 1. Çalışma Alanı artık KALICI + Gizle/Göster

"🗺️ Çalışma Alanı" ile gösterdiğin alanlar artık başka bir işlem
yapınca kaybolmuyor — ekranda kalıyor. Menüye **"🙈 Öğeleri Gizle"**
eklendi: aktif edince ekrandaki tüm kutular/etiketler gizleniyor
(ama durumu korunuyor), tekrar basınca **"👁️ Öğeleri Göster"** ile
geri geliyor.

### 2. Ana Akış: Dokun = Bilgi, Basılı Tut = Çoklu Seç

- **Kısa dokunuş** artık DOĞRUDAN o kuralın/grubun ayar penceresini
  açıyor (bilgilerine hemen erişiyorsun)
- **Basılı tutma** çoklu seçime ekliyor/çıkarıyor (mavi vurgu)
- Araç çubuğundaki 🗑 Sil / ↑↓ Taşı artık SEÇİLİ TÜM öğeler üzerinde
  TOPLU çalışıyor (çoklu görev seçme tam istediğin gibi)
- 🗺️ simgesi yerine **☑️ Tümünü Seç/Kaldır** geldi (artık gerek yok,
  dokunuş zaten bilgiyi açıyor)
- 📋 Kopyala / ✂️ Kes hâlâ tek kural üzerinde çalışıyor (pano şu an
  sadece 1 öğe tutabiliyor)

### 3. Fonksiyonlara da AYNI Sayfa Düzeni Geldi

"f{} Fonksiyonlar" artık Ana Akış ile birebir aynı yapı: liste +
8 ikonlu araç çubuğu (☑️ Tümünü Seç, ➕ Ekle, 📋 Kopyala, ✂️ Kes,
📥 Yapıştır, 🗑 Sil, ↑↓ Taşı), dokun/basılı-tut aynı mantık. Fonksiyonlar
için de artık Kopyala/Kes/Yapıştır çalışıyor (yeni eklenen
FunctionClipboard ile), ve sıralama değiştirebiliyorsun.

## Kaydırmada da HOLD Süresi Eklendi

Daha önce sadece Dokunma'da HOLD vardı, Kaydırma'da hiç yoktu. Şimdi:

- **AKSİYON sekmesi → Kaydırma**: "⏱️ HOLD (başlangıç)" ve "⏱️ HOLD
  (bitiş)" alanları eklendi — başlangıç noktasında hareket etmeden önce
  ne kadar beklesin, bitiş noktasına varınca parmağı kaldırmadan önce
  ne kadar beklesin. Bu, sürükle-bırak gibi jestler için gerekli
  (Macrorify'ın "Drag and Drop" örneğiyle aynı mantık: başlangıçta
  uzun bir HOLD tutup öyle sürüklemek).
- **Başarılı Olunca/Bulunamazsa listesi**: her dokunma/kaydırma
  adımının yanına **⏱️** butonu eklendi — HOLD süresini oradan da
  ayarlayabiliyorsun.
- **"Sadece Dokunma/Kaydırma Ekle"**: artık noktaları seçtikten sonra
  HOLD süresini soruyor (atlayıp varsayılanı da kullanabilirsin).

Teknik detay: Kaydırma artık gerçek çok-parçalı bir jest kullanıyor
(sabit bekle → hareket et → sabit bekle), Android'in Accessibility
API'sindeki `continueStroke` mekanizmasıyla — bu, gerçek bir "parmağı
kaldırmadan bekle" davranışı, sadece süre uzatma değil.

## Üç Büyük Ekleme: DELAY, Çalışma Alanı Kalıcılığı, Değişkenler

### 1. DELAY (işlem sonrası bekleme) eklendi

HOLD'un yanına artık **DELAY** var — "işlem TAMAMLANDIKTAN SONRA,
sıradaki işleme geçmeden önce ne kadar beklesin." Bu, AKSİYON
sekmesinde (Dokunma ve Kaydırma için), Başarılı Olunca/Bulunamazsa
listesindeki her adımda (⏱️ butonuyla), ve "Sadece Dokunma/Kaydırma
Ekle" akışında geçerli. Ayrıca artık jestler gerçekten SIRAYLA
çalışıyor (öncekinde arka arkaya gönderilen dokunuşlar üst üste
binebiliyordu, şimdi her biri kendi süresini + gecikmesini bekleyip
sıradakine geçiyor).

### 2. Çalışma Alanı kalıcılığı doğrulandı

Bunu kontrol ettim — zaten önceki güncellemede doğru kurulmuştu:
seçtiğin grup/fonksiyon/Ana Akış ekranda KALIYOR, sadece başka bir
grup/dizi SEÇTİĞİNDE ya da "🧹 Kapat" dediğinde değişiyor. Normal
düzenleme işlemleri (Alan Ekle, Ana Akış'ı açma, vb.) onu etkilemiyor.

### 3. YENİ: 🔢 Değişkenler — Toplu Hold/Delay Yönetimi

Tam istediğin gibi: artık Hold/Delay alanlarına SABİT sayı yazmak
YERİNE bir **Değişkene bağlayabiliyorsun**. Overlay menüsüne **"🔢
Değişkenler"** eklendi:

1. **"➕ Yeni Değişken"** → isim + başlangıç değeri (örn.
   "bekleme_suresi" = 25)
2. Herhangi bir Hold/Delay alanının yanındaki **"🔗 Bağla"** butonuna
   basıp bu değişkeni seçiyorsun — o alan artık SABİT değer yerine
   değişkenin GÜNCEL değerini kullanıyor
3. 20 farklı yerde bu değişkene bağladıysan, **"🔢 Değişkenler"**
   menüsünden değişkenin değerini 25'ten 30'a değiştirdiğinde,
   **hepsi otomatik güncelleniyor** — tek tek gezmene gerek yok

**Dürüstçe bir not:** Bu turda değişken-bağlama özelliğini AKSİYON
sekmesindeki (birincil) Hold/Delay/Kaydırma-Hold alanlarına ekledim —
"Başarılı Olunca/Bulunamazsa" listesindeki ek adımların Hold/Delay'i
şimdilik hâlâ sabit sayı (değişkene bağlanamıyor). Zaman kısıtından bu
turda önceliklendirdim; istersen oraya da genişletebiliriz.

## BAŞARILI OLUNCA / BULUNAMAZSA: Aynı 8 İkonlu Araç Çubuğu

Haklısın, bu kısımlar çok önemli — attığın 2. görseldeki (Ana Akış/
Fonksiyonlar'da zaten kullandığımız) araç çubuğunun AYNISINI buraya
da getirdim:

- **Kısa dokunuş**: Dokunma/Kaydırma adımıysa HOLD/DELAY ayarlarını
  direkt açar
- **Basılı tutma**: çoklu seçime ekler/çıkarır (mavi vurgu)
- **☑️** Tümünü Seç/Kaldır
- **➕** Ekle (Dokunma/Kaydırma/Bekleme/Fonksiyon/Değişken/Kod — 6 tür)
- **📋 Kopyala / ✂️ Kes / 📥 Yapıştır** — bir adımı kopyalayıp başka
  bir BAŞARILI/BULUNAMAZSA listesine (hatta başka bir alanın listesine)
  yapıştırabiliyorsun
- **🗑 Sil** — seçili TÜM adımları toplu siler
- **↑ ↓** — seçili adımı sırada yukarı/aşağı taşır (adımlar sırayla
  çalıştığı için sıralama önemli)

Artık şu ana kadar sunduğumuz TÜM liste yönetimi özellikleri (çoklu
seçim, toplu silme, kopyala/kes/yapıştır, sıralama) — Ana Akış,
Fonksiyonlar, ve şimdi Başarılı Olunca/Bulunamazsa'da tutarlı şekilde
mevcut.

## BAŞARILI/BULUNAMAZSA'ya "Tarama Alanı" + Ekranda Görselleştirme

### 🔍 Tarama Alanı Ekle (gerçek iç içe koşullu tespit)

"➕ Ekle" menüsüne artık **"🔍 Tarama Alanı Ekle"** de var. Seçince:

1. Ekrana koşullu bir alan çiziyorsun (renk/resim/yazı arayan, TAM
   5 sekmeli ayar penceresiyle — GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/
   TEKRAR, yani içine bile başka tarama/dokunma/kaydırma koyabilirsin)
2. Kaydedince otomatik olarak arka planda küçük bir Fonksiyona
   kaydediliyor
3. O Fonksiyonu çağıran bir **"🔧 Fonksiyon Çağır"** adımı, listene
   otomatik ekleniyor

Sonuç: "Başarılı Olunca" sırasında artık gerçek bir KOŞUL kontrolü
yapıp (örn. "bu ikinci ekranda X görseli var mı") ona göre devam
edebiliyorsun — düz bir aksiyon listesi olmaktan çıkıp gerçek bir
komut dizisi/karar mekanizmasına dönüştü.

### 🗺️ Bu Listenin Nokta/Alanlarını Ekranda Göster

Listenin üstüne yeni bir buton eklendi. Basınca:

- Her **Dokunma** adımı, ekranda **sarı bir nokta** (👆1, 👆2...) olarak
- Her **Kaydırma** adımı, **iki** sarı nokta (1️⃣, 2️⃣) olarak
- Her **Tarama Alanı**, turuncu bir KUTU olarak (Çalışma Alanı'ndaki
  gibi — dokununca düzenlemeye açılıyor)

...aynı anda ekranda beliriyor. Böylece sıralı komut dizini "havada"
değil, GERÇEKTEN nerede neyin olduğunu görerek kuruyorsun. Kapatmak
için 🗺️ Çalışma Alanı menüsündeki "🙈 Gizle"/"🧹 Kapat" kullanılabilir
(aynı mekanizmayı paylaşıyor).

## KRİTİK PERFORMANS DÜZELTMESİ: Yavaş Tarama ve Döngü Sorunları

Gerçek sebebi buldum: **kural değerlendirmesi (ve bir aksiyonun HOLD/
DELAY'indeki `Thread.sleep()` çağrıları) doğrudan ekran YAKALAMA
thread'inin İÇİNDE, senkron çalışıyordu.**

Bunun anlamı: bir kuralın aksiyonu (örn. 300ms HOLD'lu bir dokunma)
tetiklendiğinde, o 300ms boyunca **yeni ekran görüntüsü hiç
gelmiyordu** — çünkü aynı thread hem görüntü yakalıyor hem de o
görüntüyü işleyip aksiyonu çalıştırıyordu. Bu da:

- "Bekleme süresi (tarama süresi) 0" ayarını anlamsız kılıyordu —
  darboğaz cooldown değil, THREAD'İN KİLİTLENMESİYDİ
- Loop modlarının (özellikle "Loop When Fail" — koşulun KAYBOLMASINI
  beklemesi gereken) tepkisiz/bozuk görünmesine sebep oluyordu, çünkü
  koşulun kaybolduğunu fark edecek YENİ görüntü gelmiyordu

**Düzeltme:** Ekran YAKALAMA ile kural DEĞERLENDİRME artık tamamen
AYRI iki thread. Yakalama thread'i sadece bitmap üretmeye devam
ediyor (asla bloklanmıyor); kural motoru kendi bağımsız döngüsünde,
her turda o an mevcut en güncel görüntüyü işliyor. Bir aksiyonun HOLD/
DELAY'i artık sadece BİR SONRAKİ değerlendirme turunu geciktiriyor,
ekran yakalamayı asla durdurmuyor.

Loop modlarının (None/Always/While Success/While Fail) kod mantığını
da satır satır tekrar inceledim — kendi başına bir hata bulamadım;
büyük ihtimalle bu thread kilitlenmesi onları da "çalışmıyormuş gibi"
gösteriyordu. Bu düzeltmeden sonra da hâlâ bir sorun görürsen (örn.
belirli bir mod hâlâ beklediğin gibi davranmıyorsa), hangi modda tam
olarak ne beklediğini örnekle anlatırsan daha derin bakarım.

## Çalışma Alanı: Tanı Amaçlı Güncelleme

Sen "kutular hiç görünmüyor / anında kayboluyor" dedin, ama kodu satır
satır inceledim — mantık doğru görünüyor (`showWorkspaceFor` her
seferinde önce temizleyip sonra çiziyor). Kesin sebebi göremediğim
için, artık pencere ekleme (`addView`) başarısız olursa **sessizce
yutmak yerine kırmızı bir uyarı gösteriyor** ve Logcat'e yazıyor.

**Lütfen tekrar dener misin** — "🗺️ Çalışma Alanı" ile bir grup/
fonksiyon seçtiğinde:
- Kırmızı bir "⚠️ ... gösterilemedi: ..." mesajı çıkıyor mu? Çıkarsa
  tam metnini paylaş, kesin sebebi görürüz.
- Hiç mesaj çıkmıyor ama kutular da görünmüyorsa, bu bana "sorun
  addView'da değil, başka bir yerde" bilgisini verir — o zaman
  farklı bir yöne bakarım.

## Sürüklerken Yanlışlıkla "Gizle/Sil" Menüsü Açılması Düzeltildi

Gerçek sebebi buldum: geçen sefer "basılı tutma hiç tetiklenmiyor"
sorununu çözerken, sürüklemeyi iptal eden mesafe eşiğini 24dp'ye
(oldukça geniş) çıkarmıştım. Ama bu da TERSİNE bir soruna yol açtı:
**yavaş bir sürükleme**, 500ms dolmadan bu 24dp'yi aşamıyor, bu yüzden
sistem hâlâ "basılı tutuyor" sanıp menüyü açıyordu.

**Düzeltme:** Kendi sabit değerimiz yerine, Android'in TAM OLARAK bu
ayrımı (durağan basılı tutma ile gerçek sürükleme başlangıcını
ayırt etmek) yapmak için tasarladığı sistem değerini
(`ViewConfiguration.scaledTouchSlop`) kullanıyorum artık. Bu, hem
cihaza göre doğru ölçekleniyor hem de Android'in her yerde (listeler,
sürükle-bırak, vb.) kullandığı standart davranışla eşleşiyor —
sürüklemeye başlar başlamaz basılı tutma iptal oluyor, ama gerçekten
durağan basılı tutunca menü hâlâ güvenilir şekilde açılıyor.

## YENİ: ⏱️ Tarama Süresi (Timeout)

GENEL sekmesine, Delay'in hemen altına **"⏱️ Tarama Süresi"** eklendi.

**Ne işe yarıyor:** Bu değeri 0'dan büyük yaparsan, koşul (renk/resim/
yazı) aksiyonu tetiklemeden önce EN AZ o kadar süre **KESİNTİSİZ**
doğru kalmalı. Örneğin 1000ms (1 saniye) verirsen: eşleşme bir anlığına
görünüp kaybolursa (ekran geçişi, animasyon, kısa flicker) SAYILMAZ —
ancak 1 saniye boyunca kesintisiz orada kalırsa tetiklenir.

Bu, yanlış-pozitif tetiklenmeleri (örn. bir yükleme ekranında anlık
görünen bir renk/ikonun yanlışlıkla eşleşme sayılması) önlemek için
kullanışlı — "gerçekten orada mı, yoksa bir anlık mı" diye emin olmak
istediğin her yerde 0'dan büyük bir değer ver.

0 (varsayılan) = eski davranış, anında tetikler, bekleme yok.

## BÜYÜK YENİDEN TASARIM — Faz 1: Gerçek Panel Sistemi

Haklıydın — sistem AlertDialog yığınına dönüşmüştü. Bunu kökten
değiştirmeye başladım:

### Ne değişti

- ✏️ simgesine dokununca artık küçük bir buton listesi AÇILMIYOR —
  **"📱 Paneli Aç"** ile ekranın büyük bir kısmını kaplayan, TEK ve
  KALICI bir panel açılıyor
- Panelin üstünde HER ZAMAN **"neredeyim"** yazıyor (örn. "🏠 BigBoss ›
  Ana Akış") — breadcrumb, gerçek bir uygulama gibi
- **← Geri butonu** var — bir önceki ekrana dönüyorsun, dialog'lar gibi
  üst üste yığılmıyor
- **✕ Kapat** paneli tek seferde kapatıyor
- Ana ekran (Hub) artık büyük, dokunması kolay KARTLAR halinde: Ana
  Akış, Fonksiyonlar, Kütüphane, Kod, Değişkenler, Çalışma Alanı, Alan
  Ekle, Canlı Test, Play Mode — hepsi tek dokunuşla

### Bu fazda panele taşınanlar

- **Ana Akış** — artık panelin İÇİNDE bir "ekran", ayrı pencere değil
- **Fonksiyonlar** — aynı şekilde panelin içinde

### Dürüstçe: Bu fazda HENÜZ taşınmayanlar

Alan ayarları (GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR), Kütüphane,
Kod, Değişkenler, Action Group ayarları — bunlar hâlâ eski
AlertDialog'lar (ama panel açıkken de üstüne binip çalışıyorlar, kırık
değiller). Bu, TEK seferde her şeyi değiştirip riske atmamak için
bilinçli bir karar — önce en çok kullandığın 2 yeri (Ana Akış,
Fonksiyonlar) sağlam bir temele oturttum. Nasıl gittiğini görüp onay
verirsen, sıradaki adımda geri kalanları da aynı panel sistemine
taşırım.

## Tarama Alanı Artık Anlık Kaydediyor — "Kaydet"e Basmaya Gerek Yok

Tam istediğin gibi:

- Sekme değiştirdiğinde, alanı sürükleyip boyutlandırdığında — HER
  değişiklik **anında, arka planda, sessizce** kaydediliyor. Üstte
  küçük yeşil bir "💾 Otomatik kaydediliyor…" yazısı bunu hatırlatıyor.
- **"💾 Kaydet" artık "✓ Bitir" oldu** — bastığında alan ekrandan
  kalkıyor (işin bittiğini söylüyorsun). Ama bastığında ZATEN her şey
  kayıtlı olduğu için, bu artık sadece "temizle" anlamına geliyor.
- **"Kapat"a bassan ya da geri tuşuna bassan bile** — veriler kayıp
  gitmiyor, otomatik kaydediliyor VE alan ekranda kalıyor, istediğin
  zaman tekrar dokunup devam edebiliyorsun.

**Kod incelemesinde bulduğum gerçek bir hata:** Otomatik kaydetmeyi
kurarken fark ettim — yeni bir alan için her kaydetmede FARKLI, rastgele
bir kimlik üretiliyordu, bu da (otomatik kaydetme sık sık tetiklendiği
için) aynı kuraldan sürekli KOPYALAR oluşturabilirdi. Bunu da düzelttim
— artık kimlik bir kere üretilip alana kalıcı olarak yazılıyor, her
kaydetme AYNI kuralı güncelliyor.

## Daha Pratik Hale Getirme — Devam Ediyor

Panel sistemini beğendiğini duymak güzel. "Daha pratik/kullanışlı"
konusunda devam etmemiz gerekiyor — bu geniş bir hedef, bu yüzden
spesifik olman (örn. "X ekranında Y çok tıklama istiyor" gibi) bana
en çok yardımcı olacak şey. Şu an panel sistemini Alan Ayarları
(GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/TEKRAR), Kütüphane, Kod ve
Değişkenler'e de taşımayı planlıyorum — bu da genel akıcılığı
artıracak. Test ettikçe hangi noktaların hâlâ can sıktığını
paylaşırsan, sırayla hallederiz.

## YENİ: 🛑 Otomatik Durdurma (Art Arda Hata Güvenlik Ağı)

Macrorify'daki "hata olunca dur" mantığının bizdeki karşılığı: makro
çalışırken (Play Mode), **hiçbir kural belirlediğin süre boyunca hiç
tetiklenmezse**, sistem otomatik olarak durur ve seni bilgilendirir.

**Nerede ayarlanır:** Hub ekranındaki **"⚙️ Ayarlar"** kartından, ya
da doğrudan Play Mode menüsünden. Dakika cinsinden bir süre giriyorsun
(0 = kapalı, varsayılan). Örneğin "5" girersen: 5 dakika boyunca
hiçbir şey tetiklenmezse (bağlantı koptu, oyun dondu, beklenmedik bir
ekrana düşüldü gibi), makro kendini durdurur ve neden durduğunu
söyleyen bir mesaj gösterir — böylece telefonun boşuna saatlerce
"hiçbir şey olmayan" bir ekranda dönüp durmaz.

Play/Pause/Stop ile uyumlu çalışıyor: Pause'a basınca kontrol duruyor
(zaten bekliyorsun, sorun yok), Play/Devam Et'e basınca sayaç sıfırdan
başlıyor (hemen yanlış alarm vermesin diye).

## Arayüz: En Çok Kullandığın Ekran Büyütüldü + YENİ: 🎲 Rastgeleleştirme

### Tarama Alanı ayar penceresi artık daha rahat

- Sekmeler artık İKİ SATIR, İKON+İSİM ile (9sp küçük yazı yerine
  okunaklı boyut), seçili sekme MAVİ arka planla net görünüyor
- Pencere artık ekranın %94'ü genişliğinde — eskiden AlertDialog'un
  standart dar boyutuna sıkışıyordu, şimdi alanlara nefes payı var

Bu, sana "arayüz yorucu" dedirten en büyük etken olduğunu düşündüğüm
ekrandı (her alan eklerken/düzenlerken kullanıyorsun) — bu yüzden
önce buna odaklandım. Kütüphane/Kod/Değişkenler de sırada.

### YENİ: 🎲 Rastgele Sapma (Randomize)

Macrorify'ın "randomize every coordinate" özelliğinin karşılığı.
AKSİYON sekmesinde artık **"🎲 Rastgele Sapma (px)"** var — hem
Dokunma hem Kaydırma için. Bir değer girersen (örn. 8), her tetiklenişte
nokta ± o kadar piksel rastgele kayıyor — hep AYNI pikselden değil,
insan eli gibi biraz oynayarak dokunuyor. Botların tespit edilmesini
zorlaştırır ve daha doğal görünür. 0 = kapalı (tam nokta).

## Gece Araştırması: Macrorify'ın Derin Dokümantasyonunu Taradım

Sana söz verdiğim gibi araştırmaya devam ettim — Macrorify'ın Action,
Condition, Swipe, Multi Detection ve Abstract Mode dokümantasyon
sayfalarını tek tek okudum. Bulduğum GERÇEK eksiklerden ikisini bu
oturumda tamamladım:

### YENİ: 🔙 Sistem Aksiyonları

Macrorify'da var, bizde HİÇ yoktu: Geri Tuşu, Ana Ekran, Son
Uygulamalar, Bildirim Paneli, Hızlı Ayarlar — artık AKSİYON sekmesinde
4. seçenek olarak var, hem birincil aksiyon hem Başarılı Olunca/
Bulunamazsa listelerinde. "Bulunamadıysa geri tuşuna bas ve tekrar
dene" gibi kurtarma senaryoları artık mümkün.

### YENİ: 🎲 Rastgele Şans (%)

Macrorify'ın "Random Condition" özelliği: eşleşme bulunsa BİLE, sadece
belirlediğin yüzdelik ihtimalle tetiklensin. GENEL sekmesinde. Örnek
kullanım: bir ödülü her seferinde değil, %70 ihtimalle al (daha az
tahmin edilebilir davranış için).

### Araştırmada bulduğum, henüz eklemediğim diğer gerçek eksikler
(bir sonraki oturumda sırayla ekleyebiliriz):

- **Çoklu Eşleşmede Aksiyon** — birden fazla aynı görsel bulunduğunda
  "ilkine tıkla / sonuncusuna tıkla / hepsi arasında sırayla kaydır"
- **Çift/Üçlü Tık Stilleri** — hazır "Double Click", "Triple Click"
  önayarları (şu an sadece Tekrar Sayısı ile taklit ediliyor)
- **Job/Fonksiyon durumu koru-devam et** — bir fonksiyonu çağırınca
  eskisinin state'ini kaydedip sonra kaldığı yerden devam etme
- **Action Result koşulu arayüzü** — motor seviyesinde zaten var ama
  arayüze hiç bağlanmamış: "sadece X kuralı yakın zamanda tetiklendiyse
  çalış" gibi sıralı senaryolar

Sabah devam ederken hangisini istediğini söylemen yeterli.

## Kod Sistemi Kütüphanesi Ciddi Şekilde Genişletildi (EMScript Araştırması)

Önce dürüst olayım: **Bu uygulamayı gerçek bir cihazda/emülatörde çalıştırıp test edemedim** —
sadece statik kod incelemesi yapabiliyorum (parantez dengesi, mantık
kontrolü, tip uyuşmazlığı taraması). Gerçek derleme/çalışma testini
sen GitHub Actions üzerinden yapıyorsun — bir hata çıkarsa log'u
paylaş, hemen düzeltirim.

### Araştırma: EMScript'in Region/Point/Match/CParam ekosistemi

Macrorify'ın EMScript Reference sayfalarını (Region, Match, CParam,
SwipePoint, MultiSwipe) taradım. Önemli bulgu: EMScript kendileri
sıfırdan yazdıkları "iskelet" bir dil — biz zaten GERÇEK JavaScript
(Rhino) kullandığımız için dilin KENDİSİ (for/while, fonksiyon, class,
array, obje) zaten EMScript'ten güçlü. Eksik olan, ÇEVRESİNDEKİ
KÜTÜPHANEYDİ — onu genişlettim:

**Yeni eklenenler:**
- `tap(x, y, {repeat, hold, delay, random})` — opsiyonlar objesiyle
- `swipe(x1,y1,x2,y2, {duration, holdStart, holdEnd, delay, random})`
- `swipePath([{x,y,hold}, ...])` — EMScript'teki SwipePoint dizisi
  gibi, ÇOK NOKTALI kaydırma (eskiden sadece 2 nokta destekleniyordu)
- `back()`, `home()`, `recents()`, `notifications()`, `quickSettings()`
- `getGlobalVar()`/`setGlobalVar()` — kalıcı "Değişkenler" sistemine
  script'ten erişim
- `randomInt(min, max)`, `runScript("isim")` — başka bir script'i çağırma
- **`Region(x,y,w,h)` nesnesi** — EMScript'in Region class'ının
  karşılığı: `.findColor()`, `.findImage()`, `.findText()`,
  **`.findImageMatch()`** (bulunan KONUMU {x,y,score} olarak döner —
  eskiden sadece true/false vardı, artık "nerede bulundu" bilgisine
  de erişebiliyorsun), `.tap()`, `.center()`
- `findImage()` artık kütüphanedeki İSİMDEN de arayabiliyor (eskiden
  sadece dosya yolu kabul ediyordu)

Kod editöründeki varsayılan şablon da bu yeni kütüphaneyi gösterecek
şekilde güncellendi — yeni bir script oluşturduğunda örnek kullanım
göreceksin.

## Arayüz: MacroDroid Araştırmasına Dayalı Kökten Basitleştirme

Bu sefer somut bir kanıtlanmış modele dayandım. MacroDroid'i araştırdım
(10 milyon+ kurulum, 4.3/5 puan, özellikle "kullanılabilirlik" için
övülüyor — Tasker'ın "karmaşık canavar" imajının tam tersi). Sırrı:
**3 adımlı sihirbaz** — Tetikleyici → Aksiyon → Kısıt (opsiyonel).
Bizim 5 eşit-ağırlıklı sekmemiz (GENEL/AKSİYON/BAŞARILI/BULUNAMAZSA/
TEKRAR) bu kanıtlanmış modelden uzaktı — hepsi "aynı önemde" görünüp
kafa karıştırıyordu.

### Yeni yapı: 3 büyük adım, hiçbir özellik kaybolmadan

1. **🔍 1. Ne Aranacak** — eskisi gibi (renk/resim/yazı, min skor,
   delay, tarama süresi, rastgele şans, find region)
2. **⚡ 2. Ne Yapılacak** — Aksiyon (dokunma/kaydırma/fonksiyon/sistem)
   VE "Başarılı Olunca" ek adımları ARTIK TEK SEKMEDE, net başlıklarla
   ayrılmış ("⚡ Aksiyon" / "✅ Ardından sırayla")
3. **⚙️ Gelişmiş** — "Bulunamazsa" VE "Tekrar/Döngü" tek sekmede (ikisi
   de İSTEĞE BAĞLI olduğu için mantıklı bir grup — MacroDroid'in
   "Kısıt" (Constraint) adımıyla birebir aynı mantık)

Sekmeler artık tek satır, büyük ve net ("1. Ne Aranacak" gibi rakamlı
etiketlerle sırayı gösteriyor), aralarında bölüm başlıkları (mavi,
kalın) var — hangi bilginin nereye ait olduğu artık çok daha açık.
