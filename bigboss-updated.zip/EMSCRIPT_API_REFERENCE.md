# EMScript Host API — Referans Notları (Macrorify docs'tan)

Bu dosya, EMScript motorunun host köprüsünü (Aşama 2) kurarken kullanılacak
resmi API referansıdır. Kaynak: https://www.kok-emm.com/docs/reference/*
Sadece çekirdek/öncelikli sınıflar çekildi; kalan sınıflar ihtiyaç oldukça eklenecek.

## Öncelik sırası (host bridge)
1. Con, Sys (çıktı, sistem) — en basit, hemen
2. Point, SwipePoint — koordinat nesneleri
3. Region — EN BÜYÜK ve merkezi (find/click/wait/read/dönüşümler)
4. Match — find sonucu
5. Setting — Custom Settings entegrasyonu (bizde zaten var)
6. Str, Num, Math, Color, DateTime, Stopwatch — yardımcı sınıflar
7. Diğerleri (Template, *Param, Dialog view'ları, File, Clipboard...) sonra

---

## Con — Konsol (çıktı/giriş)
- `static void out(message)` — konsola yaz (bizim log/Con.out)
- `static string in()` — konsoldan oku (kullanıcı girişi)

## Point — ekranda bir nokta
- Constructor: `Point(x=0, y=0)`
- Sabitler: LEFT=1, TOP=2, RIGHT=4, BOTTOM=8
- Static: `scale(x, y, edges=0)` -> Point (makro->cihaz ölçekleme)
- `getX()` -> number
- `getY()` -> number
- `offset(dx, dy=0, noScale=false)` -> yeni Point
- `noScale()` -> this

## Match — bir find operasyonunun sonucu
- Constructor YOK (sadece find sonucu üretir)
- `getRegion()` -> Region (eşleşmenin bulunduğu bölge, noScale=true)
- `getPoint()` -> Point (eşleşmenin orta noktası, noScale=true)
- `getScore()` -> number (eşleşme skoru 0..1)
- `click(param: CParam)` -> void (eşleşmenin ortasına tıkla)

## Region — arama alanı (dikdörtgen). EN BÜYÜK SINIF.
- Constructor: `Region(x=0, y=0, w=0, h=0)` veya `Region(region)` (kopya)
- Sabitler: LEFT=1, TOP=2, RIGHT=4, BOTTOM=8

### Static fabrikalar
- `deviceReg(padL%=0, padT%=0, padR%=0, padB%=0)` -> cihaz boyutlu bölge (noScale=true)
- `macroReg(padL%=0, padT%=0, padR%=0, padB%=0)` -> makro boyutlu bölge (noScale=false)
- `scale(x, y, w, h, edges=0)` -> makro->cihaz ölçeklenmiş bölge
- `highlightOff()` -> tüm vurguları kapat

### Getter/Setter
- getX/getY/getW/getH() -> number
- getMiddlePoint() -> Point
- getLastMatch() -> Match ; getLastMatches() -> Match[]
- setX/setY/setW/setH(v) -> this (zincirlenebilir)
- noScale() -> this

### Bölge dönüşümleri (hepsi YENİ Region döner, percent varsayılan 0.5)
- left/top/right/bottom(percent=0.5) — o yönden %percent küçült (negatif=büyüt)
- horizontal/vertical/middle(percent=0.5) — iki/dört yönden küçült
- pad(padL%, padT%=0, padR%=0, padB%=0)
- *Pixel varyantları: leftPixel/topPixel/.../middlePixel/padPixel (yüzde yerine piksel)
- offset(dx, dy=0, w=null, h=null, noScale=false) -> yeni Region
- (Deprecated: moveLeft/Up/Right/Down + pixel — offset kullan)

### Tespit — Görüntü (hepsi timeout ms alır, FParam opsiyonel)
- find(image, timeout|FParam) -> Match | null  (en yüksek skorlu)
- findMulti(image, timeout) -> Match[] (min skor üstü hepsi)
- findAll(imageNames[], timeout) -> Match[] (HEPSİ görününce; hepsi non-null ya da null)
- findAny(imageNames[], timeout) -> Match[] (BİRİ görününce; en az biri non-null)
- click/clickMulti/clickAll/clickAny(...) -> find + tıkla (repeat, CParam opsiyonel)
- wait(image, timeout) -> bool (KAYBOLMASINI bekle)
- waitAll(imageNames[], timeout) -> bool

### Tespit — Metin (OCR), TParam opsiyonel
- findText/findMultiText/findAllText/findAnyText(text(s), timeout)
- clickText/clickMultiText/clickAllText/clickAnyText(...)
- waitText/waitAllText(text(s), timeout) -> bool

### Diğer
- highlight(color="#e74c3c", width, opacity=1) -> void
- highlightOff() -> void
- capture(imageName) -> bool (ekranı yakala, bu bölgeye kırp, bellekte sakla)
- read(param|TParam) -> MatchText[]
- readAsString(param|TParam, defaultValue) -> string
- readAsNumber(param|TParam, defaultValue) -> number
- (Deprecated: readPlain -> readAsString kullan)

---

## Bizim mevcut motordaki karşılıklar (ScriptEngine.kt — Rhino tarafı)
Not: Şu an Rhino/JS tarafında basitleştirilmiş bir `Region(x,y,w,h)` nesnesi var
(center/findColor/findImage/findImageMatch/findText/tap). EMScript tarafında bunu
tam API'ye yakınlaştıracağız. Motor eylem yürütücüsü (ActionExecutor), ImageMatcher,
TextMatcher, ScreenCaptureService zaten mevcut — host köprüsü bunları çağıracak.

## Aşama 2 planı (EMScript host bridge)
EMScript Interpreter'a bir "EmHost" verilecek. Bu host:
- Con.out -> uygulamanın log'una
- tap/swipe/swipePath/back/home... -> ActionExecutor
- Region fabrikaları + find/click/wait -> ImageMatcher/TextMatcher + ScreenCaptureService.latestFrame
- Match/Point/SwipePoint nesneleri EmInstance benzeri host-nesneleri olarak
- Setting.get/show -> mevcut SettingStorage/showCustomSettingsDialog
Çekirdek saf-Kotlin kaldığı için host, Android tarafında ayrı bir dosyada (EmScriptHost.kt)
kurulacak ve interpreter'ın globals'ına inject edilecek.
