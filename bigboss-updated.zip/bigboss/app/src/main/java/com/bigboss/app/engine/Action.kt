package com.bigboss.app.engine

/**
 * Kullanıcının tanımladığı "THEN" aksiyonları.
 * ActionExecutor bunları gerçek dokunuş/kaydırma olaylarına çevirir.
 */
sealed class Action {
    data class Tap(val x: Int, val y: Int, val repeat: Int = 1, val holdMs: Long = 50, val postDelayMs: Long = 0, val randomOffsetPx: Int = 0) : Action()

    /** "Eşleşen Noktaya Tıkla": koordinat sabit değil, kuralın koşulunun BULDUĞU konuma tıklar. */
    data class TapAtMatch(val repeat: Int = 1, val holdMs: Long = 50, val postDelayMs: Long = 0, val randomOffsetPx: Int = 0) : Action()

    /**
     * Macrorify'daki "Relative Coordinates" aksiyon tarafı: sabit koordinat YERİNE, başka bir
     * kuralın (anchorRuleId) [com.bigboss.app.engine.MatchLocationRegistry]'deki EN SON bulunduğu
     * NOKTA + offset'e dokunur. Kaydırılan listelerde satın-al/fiyat gibi konumu sürekli değişen
     * öğelere tıklamak için — TapAtMatch'ten farkı, KENDİ koşulunun değil BAŞKA bir kuralın
     * konumunu kullanması (o kural sadece "arama/anchor" amaçlı, bu kural ayrı bir aksiyon
     * olabilir). Anchor hiç bulunmadıysa (ya da çok eskiyse) hiçbir şey yapmaz (güvenli varsayılan).
     */
    data class TapRelative(
        val anchorRuleId: String,
        val offsetX: Int = 0, val offsetY: Int = 0,
        val repeat: Int = 1, val holdMs: Long = 50, val postDelayMs: Long = 0, val randomOffsetPx: Int = 0,
        val maxAnchorAgeMs: Long = 5000
    ) : Action()

    data class Swipe(
        val x1: Int, val y1: Int,
        val x2: Int, val y2: Int,
        val durationMs: Long = 300,
        /** Başlangıç noktasında hareket etmeden önce kaç ms basılı beklensin (sürükle-bırak için). */
        val holdStartMs: Long = 0,
        /** Bitiş noktasına varınca parmağı kaldırmadan önce kaç ms daha basılı tutulsun. */
        val holdEndMs: Long = 0,
        /** İşlem TAMAMLANDIKTAN SONRA, sıradaki işleme geçmeden önce kaç ms beklensin. */
        val postDelayMs: Long = 0,
        /** "Randomize": her noktaya ±bu kadar piksel rastgele sapma eklenir (daha insani/tespit-karşıtı). */
        val randomOffsetPx: Int = 0
    ) : Action()

    /** Macrorify'daki "Swipe Point": tek bir noktada, o noktada ne kadar basılı beklenip sonrakine geçileceği. */
    data class SwipePointDef(val x: Int, val y: Int, val holdMs: Long = 0, val speed: Int = 20)

    /**
     * Macrorify'daki "Swipe Path": TEK PARMAKLA, art arda birden fazla noktadan geçen kaydırma
     * (2 nokta ile sınırlı eski Swipe'ın YERİNE — Swipe hâlâ basit 2 noktalı durumlar için duruyor,
     * bu, "sürükleyip birkaç yerden geçirme" gibi karmaşık jestler için).
     */
    data class MultiPointSwipe(
        val points: List<SwipePointDef>,
        /** İki nokta arasında hareket etme süresi (ms) — basitlik için tüm segmentlerde aynı. */
        val segmentDurationMs: Long = 300,
        val postDelayMs: Long = 0,
        /** Her NOKTAYA ayrı ayrı ± bu kadar piksel dairesel rastgele sapma eklenir. */
        val randomOffsetPx: Int = 0
    ) : Action()

    data class Wait(val ms: Long) : Action()

    /** Birden fazla aksiyonu sırayla çalıştırır (örn: tap -> wait -> tap). */
    data class Sequence(val steps: List<Action>) : Action()

    /** Bir sayaç/değişkeni günceller. mode: "INCREMENT" (delta kadar artır/azalt) ya da "SET" (doğrudan ata). */
    data class SetVariable(val name: String, val delta: Int, val mode: String = "INCREMENT") : Action()

    /** Bir Fonksiyonu çağırır — o fonksiyonun kuralları sırayla çalışır, bitince (ya da repeat dolunca) buraya geri dönülür. */
    data class CallFunction(
        val functionId: String,
        val repeat: Int = 1,
        /** Macrorify'daki "Infinite Loop": true ise 'repeat' yok sayılır, timeLimitMs dolana kadar sürekli tekrarlar. */
        val infiniteLoop: Boolean = false,
        /** Infinite Loop için üst süre sınırı (ms). 0 = kullanıcı sınırsız dedi, ama GÜVENLİK için motor yine de bir üst sınır uygular. */
        val timeLimitMs: Long = 0
    ) : Action()

    /** Kod sistemi: bir Script'i (JavaScript, Rhino ile) çalıştırır. */
    data class RunScript(val code: String, val language: String = "JS") : Action()

    /** Macrorify'daki "Go Back/Home/Recents/Notifications/Quick Settings" sistem aksiyonları. */
    data class SystemAction(val type: String) : Action() // "BACK" | "HOME" | "RECENTS" | "NOTIFICATIONS" | "QUICK_SETTINGS"

    /**
     * Macrorify'daki "Text Reader": bir bölgeyi OKUYUP sonucu bir DEĞİŞKENE yazar
     * (eşleştirme değil, okuma). Metinden İLK SAYIYI çıkarıp yazar (örn. "Altın: 1500" -> 1500);
     * hiç sayı bulunamazsa/okuma başarısız olursa defaultValue kullanılır.
     */
    data class ReadTextToVariable(
        val regionX: Int, val regionY: Int, val regionW: Int, val regionH: Int,
        val variableName: String,
        val defaultValue: Int = 0,
        val whitelist: String = "",
        val blacklist: String = ""
    ) : Action()

    /** Hiçbir şey yapma (örn. sadece log/izleme amaçlı kurallar için). */
    object NoOp : Action()
}
