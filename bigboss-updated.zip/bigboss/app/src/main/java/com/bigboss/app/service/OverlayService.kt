package com.bigboss.app.service

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.bigboss.app.R.drawable as Ic
import com.bigboss.app.storage.ActionGroupStorage
import com.bigboss.app.storage.ConditionAlt
import com.bigboss.app.storage.FunctionDefinition
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.LibraryItem
import com.bigboss.app.storage.LibraryStorage
import com.bigboss.app.storage.RuleDefinition
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage
import com.bigboss.app.storage.TemplateStorage
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "floating control panel" — TÜM işlemleri buradan
 * yapabiliyorsun, hiçbir zaman ayrı bir uygulama ekranına geçmeden.
 *
 * ÖNEMLİ MİMARİ NOT: Alan çizme/düzenleme artık bir Activity DEĞİL —
 * doğrudan WindowManager ile eklenen GERÇEK overlay pencereleri.
 * Bunun sebebi: şeffaf temalı bir Activity, çoğu oyunun kullandığı
 * SurfaceView/GLSurfaceView tabanlı çizimle düzgün bindirilmiyor
 * (Android'in bilinen bir kısıtı) — bu yüzden oyunun üstünde değil,
 * koyu bir katmanın üstünde görünüyordu. Gerçek overlay pencereleri
 * (bizim küçük ✏️ simgemiz gibi) HER TÜRLÜ uygulamanın (oyunlar dahil)
 * üzerinde güvenilir şekilde çalışır.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_MODE = "mode" // "EDIT" | "PLAY"
        /** KULLANICI İSTEĞİ: Canlı Test oturumu en fazla 5 dakika çalışabilir, süre dolunca
         * hata verip kendini otomatik durdurmalı — sonsuza kadar açık unutulup pil/etkileşim
         * sorunu yaratmasın diye sert bir güvenlik üst sınırı. */
        const val TEST_SESSION_MAX_MS = 5 * 60_000L
        /** Ekrandaki tarama alanlarının yeşil/kırmızı çerçeve geri bildirimini ne sıklıkla tazeleyeceğimiz. */
        const val TEST_FEEDBACK_POLL_MS = 350L
        /** Bir kuralın son değerlendirmesi bu süreden eskiyse "henüz taranmadı" (nötr/gri) sayılır. */
        const val TEST_FEEDBACK_MAX_AGE_MS = 2500L
    }

    private var mode = "PLAY"
    private var windowManager: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null
    private var rootView: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: mode
        if (mode == "PLAY") {
            val engine = ScreenCaptureService.ruleEngine
            playState = if (engine != null && !engine.paused) "PLAYING" else if (playState == "STOPPED") "STOPPED" else "PAUSED"
        } else if (mode == "EDIT") {
            // güvenlik: Edit Mode'a her girişte varsayılan olarak canlı test KAPALI başlar — önceki
            // oturumdan kalma zamanlayıcı/geri bildirim/filtre izi kalmasın diye TAM temizlik.
            if (editTestRunning) stopLiveTestSession(errorReason = null) else editTestRunning = false
        }
        if (rootView == null) buildOverlay() else rebuildPanel()
        // Script'ten Setting.show() çağrıldığında UI thread'de diyaloğu açan köprüyü kur.
        ScreenCaptureService.ruleEngine // (motorun kurulu olduğundan emin ol)
        com.bigboss.app.engine.ScriptRuntime.engine?.settingShowRequester = {
            val def = com.bigboss.app.storage.SettingStorage.load(this)
            if (def.views.isNotEmpty()) {
                rootView?.post { showCustomSettingsDialog() }
                true
            } else false
        }
        // EMScript SettingBuilder.build().show() / Setting.show(): programatik diyaloğu UI thread'de
        // gösterip Kaydet/İptal'e kadar (latch ile) bloke bekler; script thread'e sonucu döndürür.
        (com.bigboss.app.engine.ScriptRuntime.emHost as? AndroidEmHost)?.settingDialogRequester = { spec, preview ->
            val def = spec.toSettingDefinition()
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                // Ana thread'de bloke bekleyemeyiz (post edilen iş çalışamaz -> deadlock). Diyaloğu
                // doğrudan göster ve false dön; EMScript motoru normalde arka thread'de çalışır.
                showCustomSettingsDialog(def = def, preview = preview, persist = !preview, positiveText = spec.positiveText, negativeText = spec.negativeText)
                false
            } else {
                val latch = java.util.concurrent.CountDownLatch(1)
                val saved = java.util.concurrent.atomic.AtomicBoolean(false)
                val posted = rootView?.post {
                    showCustomSettingsDialog(def = def, preview = preview, persist = !preview, positiveText = spec.positiveText, negativeText = spec.negativeText) { s ->
                        saved.set(s); latch.countDown()
                    }
                } ?: false
                if (!posted) latch.countDown()
                try { latch.await(180, java.util.concurrent.TimeUnit.SECONDS) } catch (e: InterruptedException) { Thread.currentThread().interrupt() }
                saved.get()
            }
        }
        // Macrorify "Show at start up": Play Mode'a İLK geçişte, ayarlanmışsa özel ayar
        // diyaloğunu otomatik göster (sadece bir kez).
        if (mode == "PLAY" && !startupSettingsShown) {
            startupSettingsShown = true
            val def = com.bigboss.app.storage.SettingStorage.load(this)
            if (def.showAtStartup && def.views.isNotEmpty()) {
                rootView?.postDelayed({ showCustomSettingsDialog() }, 600)
            }
        }
        return START_STICKY
    }

    /** Play Mode başlangıç ayar diyaloğunun bu oturumda gösterilip gösterilmediği. */
    private var startupSettingsShown = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        isDarkMode = com.bigboss.app.storage.AppSettings.isDarkMode(this)
    }

    // ==================== Overlay pencere iskeleti (küçük simge) ====================

    private var sidebarCollapsed = false

    private fun buildOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        windowManager?.addView(rootView, params)
        rebuildPanel()
    }

    private var playState = "STOPPED" // PLAYING | PAUSED | STOPPED
    private var editTestRunning = false // Edit Mode'dan ÇIKMADAN motoru geçici çalıştırma anahtarı

    // ==================== Canlı Test Oturumu (Live Test Session) — BAŞTAN YAZILDI ====================
    // KULLANICI İSTEĞİ: (1) en fazla 5 dakika çalışsın, süre dolunca HATA VERİP kendini kapatsın;
    // (2) ekrandaki AKTİF tarama alanları, test SÜRESİ boyunca gerçek zamanlı geri bildirim
    // versin — başarılıysa ince YEŞİL çerçeve, değilse ince KIRMIZI çerçeve; (3) test başlarken
    // ekrandaki TÜM araçlar (bölge kutuları, tutamaçlar, işaretçiler) KAYDEDİLİP dokunuşa
    // KAPATILMALI (gerçek uygulamaya giden dokunuşların önüne geçmesinler), test bitince bu
    // filtre KALDIRILMALI. Eski sistem (`editTestRunning` sadece motoru aç/kapat ediyordu, süre
    // sınırı YOK, sürekli geri bildirim YOK, bölge kutuları hâlâ dokunuşu YUTUYORDU) bu üçünü de
    // karşılamıyordu — bu yüzden baştan yazıldı.
    private var testSessionDeadlineHandler: android.os.Handler? = null
    private var testSessionDeadlineRunnable: Runnable? = null
    private var testSessionFeedbackHandler: android.os.Handler? = null
    private var testSessionFeedbackRunnable: Runnable? = null
    /** ruleId -> o kuralın ekranda test sırasında gösterilen ince çerçeve view'ı (frameContainer'a EK olarak eklenir, box'ın KENDİ çizimine dokunmaz). */
    private val testSessionFeedbackViews = mutableMapOf<String, View>()
    private var testSessionStartedAt: Long = 0L

    /** Panel'i doğrudan HUB yerine belirli bir ekrana açar (Hub yine ← ile bir tık geride durur). */
    private fun openPanelDirectTo(title: String, build: () -> View) {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
        pushScreen(title, build)
    }

    private fun rebuildPanel() {
        rootView?.removeAllViews()
        val density = resources.displayMetrics.density
        // Kullanıcı isteği: ana menünün boyu 3/2 oranında küçültüldü (46dp→31dp, 22dp→15dp — ~%33 küçülme).
        val btnSize = (31 * density).toInt()
        val iconSize = (15 * density).toInt()

        if (sidebarCollapsed) {
            val expandArrow = android.widget.ImageView(this).apply {
                setImageResource(com.bigboss.app.R.drawable.ic_chevron_right)
                setBackgroundColor(Color.parseColor("#F0F7F7F9"))
                layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
                setPadding((7 * density).toInt(), (7 * density).toInt(), (7 * density).toInt(), (7 * density).toInt())
                setColorFilter(C_PURPLE)
                setOnClickListener { sidebarCollapsed = false; rebuildPanel() }
            }
            rootView?.addView(expandArrow)
            return
        }

        val sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Macrorify gibi AYDINLIK zemin + renkli ikonlar (koyu tek-renk yerine).
            setBackgroundColor(Color.parseColor("#F7F7F9"))
        }

        val collapseArrow = android.widget.ImageView(this).apply {
            setImageResource(com.bigboss.app.R.drawable.ic_chevron_left)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (19 * density).toInt())
            setPadding(0, (3 * density).toInt(), 0, (3 * density).toInt())
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setColorFilter(Color.parseColor("#9B59F6")) // mor navigasyon
            setOnClickListener { sidebarCollapsed = true; rebuildPanel() }
        }
        sidebar.addView(collapseArrow)

        // Macrorify'daki gibi: TEK dokunuşla direkt çalışan, AYDINLIK zeminde RENKLİ vektör
        // ikonlu küçük kare butonlar. Her ikon işlevine göre renk taşır (tint ile).
        // color=null ise ikon kendi rengini kullanır (play/pause/stop gibi dolgu ikonlar).
        fun iconBtn(drawableRes: Int, color: Int? = null, onClick: () -> Unit) = android.widget.ImageView(this).apply {
            setImageResource(drawableRes)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            val pad = (btnSize - iconSize) / 2
            setPadding(pad, pad, pad, pad)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            if (color != null) setColorFilter(color)
            isClickable = true
            setOnClickListener { onClick() }
            // Basılı tutunca isim balonu göster (Android'in KENDİ tooltip mekanizması, API 26+).
            val tooltip = defaultIconName(drawableRes)
            if (tooltip.isNotBlank()) tooltipText = tooltip
        }
        fun row(vararg buttons: View) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.forEach { r.addView(it) }
            sidebar.addView(r)
        }

        if (mode == "EDIT") {
            row(
                iconBtn(Ic.ic_scan, C_ORANGE) { startAddRegion() },
                iconBtn(Ic.ic_tap, C_GREEN) { addSimpleStep(SaveScope.MainFlow, "TAP") },
                iconBtn(Ic.ic_swipe, C_GREEN) { addSimpleStep(SaveScope.MainFlow, "SWIPE") }
            )
            row(
                iconBtn(Ic.ic_home, C_ORANGE) { openPanelDirectTo("🏠 Ana Akış") { buildAnaAkisScreen() } },
                iconBtn(Ic.ic_function, C_GREEN) { openPanelDirectTo("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } },
                iconBtn(Ic.ic_library, C_ORANGE) { openPanelDirectTo("📚 Resources") { buildResourcesScreen() } }
            )
            row(
                iconBtn(Ic.ic_variable, C_PURPLE) { openPanelDirectTo("(x) Variables") { buildVariablesScreen() } }
            )
            row(
                iconBtn(Ic.ic_record) { showRecordsMenu() },
                iconBtn(if (editTestRunning) Ic.ic_pause else Ic.ic_test, C_GREEN) { toggleEditTest() },
                iconBtn(Ic.ic_play) { switchToPlayMode() }
            )
            row(
                iconBtn(if (allOverlaysHidden) Ic.ic_eye_off else Ic.ic_eye, C_GREEN) { toggleAllOverlays() },
                iconBtn(Ic.ic_chevron_left, C_PURPLE) { clickMarkersPrevPage() },
                iconBtn(Ic.ic_chevron_right, C_PURPLE) { clickMarkersNextPage() }
            )
            row(
                iconBtn(Ic.ic_settings, C_BLUE) { showAutoStopSettingsDialog() },
                iconBtn(Ic.ic_save, C_BLUE) {
                    // KULLANICI RAPORU: sidebar'da "save" ikonu eksikti. Her şey zaten OTOMATİK
                    // kaydediliyor — ama bu buton EK OLARAK motoru DEPOLAMADAN TAZE baştan kurar
                    // (EngineAssembler.refresh), yani bir düzenlemeden sonra motor "takılı" gibi
                    // görünürse elle bir KURTARMA/YENİLEME yolu da sağlıyor.
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "💾 Kaydedildi ve motor yenilendi", Toast.LENGTH_SHORT).show()
                },
                iconBtn(Ic.ic_close, C_RED) { shutdown() }
            )
        } else {
            // ---- PLAY MODE: Play / Pause / Stop / İzle / Ayarlar / Kapat ----
            row(
                iconBtn(Ic.ic_play) { playMacro() },
                iconBtn(if (playState == "PAUSED") Ic.ic_play else Ic.ic_pause) { togglePause() },
                iconBtn(Ic.ic_stop) { stopMacro() }
            )
            row(
                iconBtn(Ic.ic_settings, C_BLUE) { showPlayModeSettingsMenu() },
                iconBtn(Ic.ic_close, C_RED) { shutdown() }
            )
            sidebar.addView(TextView(this).apply {
                text = when (playState) { "PLAYING" -> "▶ Çalışıyor"; "PAUSED" -> "⏸ Duraklı"; else -> "⏹ Durdu" }
                setTextColor(Color.parseColor("#444444")); textSize = 10f; gravity = Gravity.CENTER
                setPadding(4, (4 * density).toInt(), 4, (4 * density).toInt())
            })
        }
        rootView?.addView(sidebar)
    }

    /**
     * Macrorify'daki "Unit Test": seçili kuralları (ya da hiç seçim yoksa hepsini) GERÇEKTEN
     * çalıştırır — tüm makroyu baştan sona test etmek yerine sadece ilgilendiğin parçayı.
     *
     * KULLANICI İSTEĞİ: "HAYIR kayıt edilsin, sadece TEST etmek istediğimde uyarı versin" —
     * artık kayıt sırasında değil, TAM burada (gerçekten test/çalıştırma anında) eksik koşullu
     * (resim/metin/renk seçilmemiş) kurallar için AÇIK bir uyarı gösteriliyor.
     */
    private fun testSelectedRules(ruleDefs: List<RuleDefinition>) {
        val engine = ScreenCaptureService.ruleEngine
        val frame = ScreenCaptureService.latestFrame
        if (engine == null || frame == null) {
            Toast.makeText(this, "Motor/ekran görüntüsü hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        val incompleteCount = ruleDefs.count { isRuleIncomplete(it) }
        if (incompleteCount > 0) {
            Toast.makeText(this, "⚠️ $incompleteCount tane henüz ayarlanmamış tarama alanı — resim/metin/renk seçilmedi (bu kural(lar) hiçbir zaman eşleşmeyecek)", Toast.LENGTH_LONG).show()
        }
        val rules = RuleDefinitionMapper.toRules(ruleDefs, this, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        val wasPaused = engine.paused
        engine.paused = false
        try {
            engine.evaluateRulesOnce(rules, frame)
        } finally {
            engine.paused = wasPaused
        }
        Toast.makeText(this, "▶️ Test edildi: ${rules.size} kural", Toast.LENGTH_SHORT).show()
    }

    /**
     * Edit Mode'dan Play Mode'a — OTURUM/İZİN/SERVİS yeniden başlamadan, TEK bir OverlayService
     * içinde SADECE modu değiştirir (mode="PLAY" + rebuildPanel). Ekran kaydı, erişilebilirlik
     * servisi ZATEN çalışıyor — hiçbiri kapatılıp yeniden açılmıyor. Panel açık kalmışsa
     * (Edit Mode'un bir ekranını gösteriyorsa) o da kapatılır ki geçiş NET olsun.
     */
    private fun switchToPlayMode() {
        closeAppPanel()
        mode = "PLAY"
        clearAllRegionWindows(); clearWorkspace(); clearClickMarkers(); clearRecordMode(); clearTestFeedback()
        playMacro()
    }

    /** Edit Mode'dan hiç çıkmadan motoru geçici çalıştırır — sadece izlemek/test etmek için. */
    private var errorPollHandler: android.os.Handler? = null
    private var errorPollRunnable: Runnable? = null

    /**
     * KULLANICI RAPORU: swipe hold'unu değiştirince test "çalışmıyor" gibi görünüyordu.
     * İzole bir testle `RuleDefinitionMapper`'ın DOĞRU çalıştığını KANITLADIM — sorun (varsa)
     * çalıştırma (dispatchGesture) katmanında olmalı. Artık "🧪 Canlı Test" AÇIKKEN, motorun
     * SESSİZCE yakaladığı HERHANGİ bir çalıştırma hatasını (varsa) HER SANİYE kontrol edip
     * doğrudan Toast olarak gösteriyoruz — "motor bir hata mı alıyor yoksa gerçekten hiçbir
     * şey mi olmuyor" sorusuna KESİN bir cevap.
     */
    private fun startErrorPolling() {
        stopErrorPolling()
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                com.bigboss.app.engine.ActionResultRegistry.consumeLastActionError()?.let { err ->
                    Toast.makeText(this@OverlayService, "⚠️ Motor hatası yakaladı: $err", Toast.LENGTH_LONG).show()
                }
                handler.postDelayed(this, 1000)
            }
        }
        errorPollHandler = handler; errorPollRunnable = runnable
        handler.postDelayed(runnable, 1000)
    }

    private fun stopErrorPolling() {
        errorPollRunnable?.let { errorPollHandler?.removeCallbacks(it) }
        errorPollHandler = null; errorPollRunnable = null
    }

    /**
     * KULLANICI RAPORU + EKRAN GÖRÜNTÜSÜ İLE DOĞRULANDI: "swipe için herhangi bir değeri
     * değiştirirsem çalışmıyor" — kök neden BULUNDU. Ekran görüntüsünde "1"/"2" işaretçileri
     * (sürüklenebilir, yani DOKUNULABİLİR BigBoss overlay pencereleri) swipe'ın TAM başlangıç/
     * bitiş koordinatlarının ÜZERİNDE duruyor. `dispatchGesture` o TAM koordinatlara SENTETİK
     * bir dokunuş gönderirken, BigBoss'un KENDİ dokunulabilir penceresi ORADA oturuyor — bu
     * ÇAKIŞMA Android'in jesti "İPTAL EDİLDİ" olarak işaretlemesine yol açıyor (kullanıcının
     * gönderdiği uyarı BUNU kanıtlıyor). Düzenleme YAPILMADAN önce (yani markörler HENÜZ hiç
     * gösterilmemişken/Play Mode'dayken) test etmek bu çakışmayı YAŞAMIYORDU — ama bir noktayı
     * DÜZENLEYİP "Kaydet" deyince `showClickMarkers()` işaretçileri YENİDEN ekliyor, ve "🧪
     * Canlı Test" AÇIKKEN bu işaretçiler DOKUNULABİLİR kalmaya devam ediyordu.
     *
     * Çözüm: "🧪 Canlı Test" (ya da Play Mode) AKTİFKEN TÜM sürüklenebilir işaretçileri
     * GEÇİCİ olarak DOKUNULAMAZ (FLAG_NOT_TOUCHABLE) yapıyoruz — GÖRÜNÜR kalıyorlar (nerede
     * olduklarını hâlâ görebiliyorsun) ama artık motorun gönderdiği GERÇEK dokunuşların
     * ÖNÜNE GEÇMİYORLAR. Test durunca (ya da Play Mode duraklayınca) tekrar DOKUNULABİLİR
     * (sürüklenebilir) hâle getiriyoruz.
     */
    /**
     * HATA DÜZELTMESİ (kullanıcı raporu: "test sırasında ekrandaki araçlar hatalı işlemlere
     * yol açıyor"): bu fonksiyon eskiden SADECE işaretçileri (clickMarkers/workspaceLiveMarkers/
     * swipeFrameViews/actionPointMarkers) dokunuşa kapatıyordu — bölge kutularının KENDİSİ
     * (activeRegions'ın container'ı, sürükleme/boyutlandırma/tıkla-düzenle dokunuşunu YUTAR) ve
     * "draw select" ile çizilen workspaceBoxes HÂLÂ dokunuşu yutuyordu; bu da test sırasında
     * gerçek uygulamaya gitmesi gereken dokunuşların yanlışlıkla BigBoss'un kendi düzenleme
     * araçları tarafından yakalanmasına (hatalı işlem) yol açıyordu. Artık TÜM ekran araçları
     * (bölge kutuları + workspaceBoxes DAHİL) burada tek yerden kaydedilip filtreleniyor.
     */
    private fun setAllMarkersTouchable(touchable: Boolean) {
        val extraFlags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        fun apply(params: WindowManager.LayoutParams, view: View) {
            params.flags = if (touchable) (params.flags and extraFlags.inv()) else (params.flags or extraFlags)
            try { windowManager?.updateViewLayout(view, params) } catch (e: Exception) {}
        }
        clickMarkers.forEach { apply(it.params, it.view) }
        (workspaceLiveMarkers + swipeFrameViews).forEach { v ->
            (v.layoutParams as? WindowManager.LayoutParams)?.let { apply(it, v) }
        }
        activeRegions.forEach { region ->
            region.actionPointMarkers.forEach { v ->
                (v.layoutParams as? WindowManager.LayoutParams)?.let { apply(it, v) }
            }
            // Bölgenin KENDİ kutusu (sürükle/boyutlandır/tıkla-düzenle) — test sırasında bu da
            // dokunuşu yutmamalı, aksi halde gerçek uygulamaya gidecek dokunuşları çalar.
            apply(region.containerParams, region.container)
        }
        workspaceBoxes.forEach { wb -> apply(wb.boxParams, wb.box) }
    }

    private fun toggleEditTest() {
        if (editTestRunning) stopLiveTestSession(errorReason = null) else startLiveTestSession()
    }

    /**
     * "🧪 Canlı Test" oturumunu başlatır — BAŞTAN YAZILDI (bkz. yukarıdaki alan tanımları):
     * motoru gerçekten çalıştırır, ekrandaki TÜM araçları dokunuşa kapatır (kayıt altına
     * alıp filtreler), ekrandaki her aktif tarama alanı için sürekli güncellenen yeşil/kırmızı
     * ince çerçeve geri bildirimi başlatır ve 5 dakikalık sert bir güvenlik sınırı kurar.
     */
    private fun startLiveTestSession() {
        val engine = ScreenCaptureService.ruleEngine
        if (engine == null) {
            Toast.makeText(this, "Motor hazır değil", Toast.LENGTH_SHORT).show()
            return
        }
        if (ScreenCaptureService.latestFrame == null) {
            // Aynı tanı: motor kurulu ama HİÇ kare almıyor — sessizce "çalışıyor gibi görünüp
            // hiçbir şey yapmama" yerine baştan uyarıyoruz.
            Toast.makeText(this, "⚠️ Ekran görüntüsü YOK — izin düşmüş olabilir. Edit Mode'u YENİDEN başlat.", Toast.LENGTH_LONG).show()
            return
        }
        editTestRunning = true
        testSessionStartedAt = System.currentTimeMillis()
        engine.resetLoopState()
        engine.paused = false
        clearTestFeedback() // eski tek-seferlik (3sn'lik) yeşil/kırmızı kutu varsa temizle
        setAllMarkersTouchable(false) // KRİTİK: test sırasında TÜM araçlar (bölge kutuları DAHİL) dokunuşun ÖNÜNE GEÇMESİN
        attachTestFeedbackBorders()
        startErrorPolling()
        startTestFeedbackPolling()
        startTestSessionDeadline()
        rebuildPanel()
        // KULLANICI İSTEĞİ: kayıt sırasında değil, TAM test başlarken eksik-koşul uyarısı.
        val incompleteCount = RuleStorage.load(this).count { isRuleIncomplete(it) }
        if (incompleteCount > 0) {
            Toast.makeText(this, "⚠️ $incompleteCount tane henüz ayarlanmamış tarama alanı — resim/metin/renk seçilmedi (bu kural(lar) hiçbir zaman eşleşmeyecek)", Toast.LENGTH_LONG).show()
        }
        Toast.makeText(
            this,
            "🧪 Canlı test başladı (en fazla 5 dakika) — motor gerçekten dokunacak/kaydıracak, aktif alanlar yeşil/kırmızı çerçeveyle gösterilecek",
            Toast.LENGTH_LONG
        ).show()
    }

    /**
     * Canlı Test oturumunu durdurur. [errorReason] doluysa (örn. 5 dakika sınırı), test bir
     * HATA olarak sonlanmıştır — kullanıcıya bunu açıkça bildiririz; null ise kullanıcı
     * kendi isteğiyle durdurmuştur (sessiz/nötr mesaj).
     */
    private fun stopLiveTestSession(errorReason: String?) {
        editTestRunning = false
        ScreenCaptureService.ruleEngine?.let { it.paused = true; it.resetLoopState() }
        stopErrorPolling()
        stopTestFeedbackPolling()
        stopTestSessionDeadline()
        detachTestFeedbackBorders()
        setAllMarkersTouchable(true) // KRİTİK: filtre KALDIRILIYOR — araçlar tekrar dokunulabilir olmalı
        rebuildPanel()
        Toast.makeText(
            this,
            errorReason ?: "⏸️ Canlı test durdu — düzenlemeye devam edebilirsin",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun startTestSessionDeadline() {
        stopTestSessionDeadline()
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val runnable = Runnable {
            // Süre doldu — bu bir KULLANICI durdurması DEĞİL, bir HATA durumu: açıkça bildir.
            stopLiveTestSession(errorReason = "⛔ Test 5 dakikalık süre sınırına ulaştı ve otomatik olarak durduruldu")
        }
        testSessionDeadlineHandler = handler
        testSessionDeadlineRunnable = runnable
        handler.postDelayed(runnable, TEST_SESSION_MAX_MS)
    }

    private fun stopTestSessionDeadline() {
        testSessionDeadlineRunnable?.let { testSessionDeadlineHandler?.removeCallbacks(it) }
        testSessionDeadlineHandler = null; testSessionDeadlineRunnable = null
    }

    /**
     * Ekranda AÇIK olan her tarama alanı (existingRuleId'si olan activeRegion) için, alanın
     * KENDİ çizim view'ının (box) TAM ÜSTÜNE, aynı boyutta AYRI bir ince çerçeve view'ı ekler.
     * Bilinçli tercih: box'ın kendi Paint/onDraw'ına dokunmuyoruz (renk kalıcı değişmesin,
     * test bitince eski hâline dönmesi garanti olsun) — sadece test süresi boyunca üstüne
     * GEÇİCİ bir katman koyup kaldırıyoruz.
     */
    private fun attachTestFeedbackBorders() {
        testSessionFeedbackViews.clear()
        activeRegions.forEach { region ->
            val ruleId = region.existingRuleId ?: return@forEach
            val overlayParams = android.widget.FrameLayout.LayoutParams(region.boxParams.width, region.boxParams.height)
            val overlay = View(this).apply { background = borderDrawable(Color.parseColor("#9E9E9E"), 3f) } // başlangıç: nötr gri ("henüz taranmadı")
            try {
                region.frameContainer.addView(overlay, overlayParams)
                testSessionFeedbackViews[ruleId] = overlay
            } catch (e: Exception) {}
        }
    }

    private fun detachTestFeedbackBorders() {
        activeRegions.forEach { region ->
            val ruleId = region.existingRuleId ?: return@forEach
            testSessionFeedbackViews[ruleId]?.let { v ->
                try { region.frameContainer.removeView(v) } catch (e: Exception) {}
            }
        }
        testSessionFeedbackViews.clear()
    }

    private fun startTestFeedbackPolling() {
        stopTestFeedbackPolling()
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                testSessionFeedbackViews.forEach { (ruleId, view) ->
                    val result = com.bigboss.app.engine.RuleEvaluationRegistry.get(ruleId, TEST_FEEDBACK_MAX_AGE_MS)
                    val color = when (result) {
                        true -> Color.parseColor("#00E676") // başarılı: ince YEŞİL çerçeve
                        false -> Color.parseColor("#FF5252") // başarısız: ince KIRMIZI çerçeve
                        null -> Color.parseColor("#9E9E9E") // henüz taranmadı / sırası gelmedi: nötr gri
                    }
                    view.background = borderDrawable(color, 3f)
                }
                handler.postDelayed(this, TEST_FEEDBACK_POLL_MS)
            }
        }
        testSessionFeedbackHandler = handler
        testSessionFeedbackRunnable = runnable
        handler.postDelayed(runnable, TEST_FEEDBACK_POLL_MS)
    }

    private fun stopTestFeedbackPolling() {
        testSessionFeedbackRunnable?.let { testSessionFeedbackHandler?.removeCallbacks(it) }
        testSessionFeedbackHandler = null; testSessionFeedbackRunnable = null
    }

    /**
     * TANI EKLENDİ (kullanıcı raporu: "her şey sessizce çalışmıyor, hem eski hem yeni
     * kurallarda"): motor kodunun TÜM katmanlarını (RuleEngine/Mapper/Condition/ImageMatcher/
     * Storage/EngineAssembler) tek tek inceledim, mantıksal bir hata BULAMADIM — bu, kural
     * VERİSİNDEN bağımsız bir MOTOR DURUMU sorununa işaret ediyor. En olası neden: ekran
     * yakalama (MediaProjection) izni/oturumu SESSİZCE geçersiz hâle gelmiş (pil optimizasyonu,
     * uzun süre arka planda kalma vb) — motor VAR ama hiç KARE almıyor, bu yüzden HİÇBİR koşul
     * DEĞERLENDİRİLMİYOR (ne bulma ne tıklama). Artık bunu SESSİZCE geçmek yerine AÇIKÇA
     * uyarıyoruz.
     */
    private fun playMacro() {
        val engine = ScreenCaptureService.ruleEngine
        val frame = ScreenCaptureService.latestFrame
        if (engine == null) {
            Toast.makeText(this, "⚠️ Motor kurulu değil — Edit/Play Mode'u YENİDEN başlatmayı dene (izin isteyecek)", Toast.LENGTH_LONG).show()
            return
        }
        if (frame == null) {
            Toast.makeText(this, "⚠️ Ekran görüntüsü YOK — ekran yakalama izni düşmüş olabilir (pil tasarrufu/uzun arka plan). Edit ya da Play Mode'u YENİDEN başlat, izni tekrar ver.", Toast.LENGTH_LONG).show()
            return
        }
        engine.paused = false
        com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
        playState = "PLAYING"
        startAutoStopWatcher()
        startErrorPolling()
        rebuildPanel()
        // KULLANICI İSTEĞİ: kayıt sırasında değil, TAM çalıştırma başlarken eksik-koşul uyarısı.
        val incompleteCount = RuleStorage.load(this).count { isRuleIncomplete(it) }
        if (incompleteCount > 0) {
            Toast.makeText(this, "⚠️ $incompleteCount tane henüz ayarlanmamış tarama alanı — resim/metin/renk seçilmedi (bu kural(lar) hiçbir zaman eşleşmeyecek)", Toast.LENGTH_LONG).show()
        }
        Toast.makeText(this, "▶️ Çalışıyor", Toast.LENGTH_SHORT).show()
    }

    private fun togglePause() {
        val engine = ScreenCaptureService.ruleEngine ?: return
        if (playState == "PAUSED") {
            engine.paused = false
            com.bigboss.app.engine.ActionResultRegistry.markAliveNow()
            playState = "PLAYING"
            startAutoStopWatcher()
            startErrorPolling()
            Toast.makeText(this, "▶️ Devam ediyor", Toast.LENGTH_SHORT).show()
        } else {
            engine.paused = true
            playState = "PAUSED"
            stopAutoStopWatcher()
            stopErrorPolling()
            Toast.makeText(this, "⏸️ Duraklatıldı — kaldığı yerden devam edecek", Toast.LENGTH_SHORT).show()
        }
        rebuildPanel()
    }

    private fun stopMacro() {
        val engine = ScreenCaptureService.ruleEngine
        engine?.paused = true
        engine?.resetLoopState()
        playState = "STOPPED"
        clearTestFeedback()
        stopAutoStopWatcher()
        rebuildPanel()
        Toast.makeText(this, "⏹ Durduruldu — Play'e basınca baştan başlar", Toast.LENGTH_SHORT).show()
    }

    // ==================== 🛑 Otomatik Durdurma (art arda hata / donma güvenlik ağı) ====================
    // "Play"deyken, HİÇBİR kural belirli bir süre boyunca hiç tetiklenmezse (bağlantı koptu,
    // oyun dondu, beklenmedik bir ekrana düşüldü vb.) makro sonsuza kadar boşa dönmesin diye
    // kendini otomatik durdurur.

    private val autoStopHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var autoStopRunnable: Runnable? = null

    private fun startAutoStopWatcher() {
        stopAutoStopWatcher()
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        if (minutes <= 0) return // kapalı
        val thresholdMs = minutes * 60_000L
        val tick = object : Runnable {
            override fun run() {
                if (playState != "PLAYING") return
                val elapsed = com.bigboss.app.engine.ActionResultRegistry.msSinceAnyFire()
                if (elapsed >= thresholdMs) {
                    stopMacro()
                    Toast.makeText(
                        this@OverlayService,
                        "🛑 Otomatik durduruldu — $minutes dakikadır hiçbir kural tetiklenmedi (bağlantı/donma olabilir)",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                autoStopHandler.postDelayed(this, 15_000L)
            }
        }
        autoStopRunnable = tick
        autoStopHandler.postDelayed(tick, 15_000L)
    }

    private fun stopAutoStopWatcher() {
        autoStopRunnable?.let { autoStopHandler.removeCallbacks(it) }
        autoStopRunnable = null
    }

    private fun autoStopSubtitle(): String {
        val minutes = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(this)
        return if (minutes <= 0) "Otomatik Durdurma: kapalı" else "Otomatik Durdurma: $minutes dk hareketsizlikte dur"
    }

    /** Play Mode'daki ⚙️ ikonunun menüsü: Otomatik Durdurma + Custom Settings (Macrorify "Setting" sekmesi). */
    /**
     * DÜZELTME (kullanıcı isteği): eskiden "Custom Settings" burada tanımsız olsa bile
     * (henüz hiç view yokken) EDİTÖRE (Setting Builder ekranına) yönlendiriyordu — bu YANLIŞ,
     * çünkü DÜZENLEME sadece Edit Mode'a ait olmalı (Macrorify'da da öyle). Play Mode SADECE
     * zaten TANIMLANMIŞ bir Custom Settings'i ÇALIŞMA-ANI diyaloğu olarak AÇABİLİR
     * (`Setting.show()`/"Setting tab" ile AYNI davranış) — tanımlı değilse burada HİÇ
     * gösterilmez (oluşturmak için Edit Mode'daki "⚙️ Setting Builder"a gidilir).
     */
    private fun showPlayModeSettingsMenu() {
        val ctx = this
        val hasCustom = com.bigboss.app.storage.SettingStorage.hasViews(ctx)
        val items = mutableListOf("🛑 Otomatik Durdurma Ayarı")
        if (hasCustom) items.add("⚙️ Custom Settings")
        overlayDialog().setTitle("Ayarlar")
            .setItems(items.toTypedArray()) { _, idx ->
                when (idx) {
                    0 -> showAutoStopSettingsDialog()
                    1 -> showCustomSettingsDialog()
                }
            }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun showAutoStopSettingsDialog() {
        val ctx = this
        val current = com.bigboss.app.storage.AppSettings.getAutoStopMinutes(ctx)
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }

        container.addView(TextView(ctx).apply {
            text = "🌗 Görünüm"
            setTypeface(null, android.graphics.Typeface.BOLD); textSize = 13f
        })
        val darkModeCheck = android.widget.CheckBox(ctx).apply {
            text = "Karanlık Mod"
            isChecked = isDarkMode
            setPadding(0, 8, 0, 16)
        }
        darkModeCheck.setOnCheckedChangeListener { _, checked ->
            isDarkMode = checked
            com.bigboss.app.storage.AppSettings.setDarkMode(ctx, checked)
            rebuildPanel() // sidebar'ı da hemen güncelle
            if (panelRoot != null) { closeAppPanel(); showAppPanel() } // panel açıksa yeni temayla yeniden çiz
        }
        container.addView(darkModeCheck)

        container.addView(TextView(ctx).apply {
            text = "🛑 Otomatik Durdurma\n\nPlay Mode'dayken, kaç dakika boyunca HİÇBİR kural tetiklenmezse (bağlantı koptu, oyun dondu, beklenmedik ekran vb.) makro kendini otomatik durdursun? 0 = kapalı (asla otomatik durmaz)."
            textSize = 12f
        })
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
            hint = "Dakika (0 = kapalı)"
        }
        container.addView(input)
        overlayDialog().setTitle("⚙️ Ayarlar").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                val minutes = input.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
                com.bigboss.app.storage.AppSettings.setAutoStopMinutes(ctx, minutes)
                if (playState == "PLAYING") startAutoStopWatcher() // yeni değeri hemen uygula
                Toast.makeText(ctx, if (minutes <= 0) "Otomatik durdurma kapatıldı" else "Otomatik durdurma: $minutes dakika", Toast.LENGTH_SHORT).show()
                refreshCurrentScreen()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir Hold/Delay alanı için: sabit sayı GİR ya da bir "🔢 Değişken"e BAĞLA seçeneği sunan birleşik alan. */
    /**
     * Macrorify'daki 💡 (sarı ampul) alan tipi: bir sayı kutusunun İÇİNDE, sağ kenarında duran
     * küçük bir ampul ikonu. Dokununca menü açılır: Variables (kayıtlı bir değişkene bağla —
     * Setting Builder alanları da BİRLEŞİK değişken deposunu kullandığı için aynı listede
     * görünür), Current Time (milisaniye, ANLIK değer olarak yazılır), Random Number (ANLIK
     * rastgele değer), ve (sadece allowForever=true ise) Forever (-1). Bir değişkene bağlanınca
     * kutu SALT-OKUNUR olur ve değişkenin güncel değerini gösterir.
     *
     * NOT (dürüstçe belirtelim): Current Time / Random Number şu an ANLIK bir DEĞER yazıyor
     * (Macrorify'daki gibi her çalıştırmada YENİDEN hesaplanan canlı bir REFERENCE değil) —
     * gerçek canlı yeniden-hesaplama için VariableStore'un REFERENCE tipini otomatik bir
     * değişkene bağlamak gerekir, bu henüz yapılmadı.
     */
    private fun addHoldOrDelayField(
        ctx: android.content.Context, container: LinearLayout, label: String,
        currentValue: Long, currentVarName: String?,
        onValueChanged: (Long) -> Unit, onVarNameChanged: (String?) -> Unit,
        allowForever: Boolean = false
    ) {
        val density = resources.displayMetrics.density
        container.addView(TextView(ctx).apply { text = label; textSize = 12f; setPadding(0, (14 * density).toInt(), 0, 0) })
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
        }
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(if (currentVarName != null) "{$currentVarName}" else currentValue.toString())
            isEnabled = currentVarName == null
            textSize = 15f; setTextColor(TEXT_PRIMARY); background = null
            setPadding((12 * density).toInt(), (10 * density).toInt(), (4 * density).toInt(), (10 * density).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        input.addTextChangedListener(simpleWatcher { onValueChanged(it.toLongOrNull() ?: 0) })
        row.addView(input)
        val bulb = TextView(ctx).apply {
            text = "💡"; textSize = 17f
            setPadding((10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt(), (8 * density).toInt())
            setOnClickListener {
                val options = mutableListOf<String>()
                if (currentVarName != null) options.add("❌ Bağlantıyı Kaldır (sabit değer kullan)")
                options.add("Variables")
                options.add("Current Time (milliseconds)")
                options.add("Random Number")
                if (allowForever) options.add("Forever")
                overlayDialog().setItems(options.toTypedArray()) { _, idxRaw ->
                    var idx = idxRaw
                    if (currentVarName != null) {
                        if (idx == 0) { onVarNameChanged(null); input.isEnabled = true; input.setText(currentValue.toString()); return@setItems }
                        idx -= 1
                    }
                    when (idx) {
                        0 -> { // Variables (Setting Builder alanları da BİRLEŞİK depoda, aynı listede)
                            val vars = com.bigboss.app.storage.GlobalVariableStorage.load(this@OverlayService).filter { !it.disabled }
                            if (vars.isEmpty()) {
                                Toast.makeText(this@OverlayService, "Henüz değişken yok — önce 🔢 Değişkenler'den ya da ⚙️ Setting Builder'dan oluştur", Toast.LENGTH_LONG).show()
                                return@setItems
                            }
                            overlayDialog().setItems(vars.map { "${it.name} (${it.raw()})" }.toTypedArray()) { _, vi ->
                                val v = vars[vi]
                                onVarNameChanged(v.name); input.isEnabled = false; input.setText("{${v.name}}")
                            }.setNegativeButton("Kapat", null).create().showOverlay()
                        }
                        1 -> { val v = System.currentTimeMillis(); onValueChanged(v); input.setText(v.toString()) } // Current Time
                        2 -> { val v = (0..1000).random().toLong(); onValueChanged(v); input.setText(v.toString()) } // Random Number
                        3 -> { onValueChanged(-1); input.setText("-1") } // Forever
                    }
                }.setNegativeButton("Kapat", null).create().showOverlay()
            }
        }
        row.addView(bulb)
        container.addView(row)
    }

    // ==================== ⚙️ Custom Settings (Macrorify "Setting Builder") ====================

    /**
     * Kayıtlı özel ayar diyaloğunu GERÇEK bir arayüz olarak gösterir. Kullanıcı "Kaydet"e
     * basınca her view'ın (TextView hariç) değeri, key'iyle aynı isimli bir DEĞİŞKENe yazılır.
     * onDone: diyalog kapandığında çağrılır (true=Kaydet, false=İptal) — Play Mode başlangıç
     * akışı için (Kaydet'ten sonra botu başlat gibi).
     */
    private fun showCustomSettingsDialog(
        def: com.bigboss.app.storage.SettingDefinition = com.bigboss.app.storage.SettingStorage.load(this),
        preview: Boolean = false,
        persist: Boolean = true,
        positiveText: String = "Kaydet",
        negativeText: String = "İptal",
        onDone: ((saved: Boolean) -> Unit)? = null
    ) {
        val ctx = this
        if (def.views.isEmpty()) {
            Toast.makeText(ctx, "Henüz özel ayar yok — '⚙️ Setting Builder' editöründen ekle", Toast.LENGTH_LONG).show()
            onDone?.invoke(false)
            return
        }
        // Her view için, girilen değeri okuyan bir lambda toplayacağız.
        val valueReaders = LinkedHashMap<String, () -> String>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 8) }

        // Macrorify'daki "Tab Layout": kendinden SONRAKİ view'ları sekmelere ayırır.
        var tabContainers: List<LinearLayout> = emptyList()
        // id-tabanlı (programatik) TabLayout için: view referans-id -> (kapsayıcı, başlangıç, bitiş çocuk indeksi).
        val idRanges = LinkedHashMap<String, Triple<LinearLayout, Int, Int>>()
        val idBasedTabs = mutableListOf<Pair<com.bigboss.app.storage.SettingViewDef, List<TextView>>>()

        def.views.forEach { v ->
            // Bu view bir TABLAYOUT'un sekmesine atanmışsa (tabIndex>=0) hedef o sekmenin
            // kutusu, değilse doğrudan kök (untabbed / henüz TabLayout yok).
            val target = if (v.type != "TABLAYOUT" && v.tabIndex >= 0 && v.tabIndex < tabContainers.size) tabContainers[v.tabIndex] else root
            val startChild = target.childCount
            when (v.type) {
                "TEXTVIEW" -> {
                    target.addView(TextView(ctx).apply {
                        text = v.label; setTextColor(TEXT_PRIMARY); textSize = 15f; setPadding(0, 16, 0, 4)
                        setTypeface(null, android.graphics.Typeface.BOLD)
                    })
                }
                "CHECKBOX" -> {
                    val cb = android.widget.CheckBox(ctx).apply {
                        text = v.label.ifBlank { v.key }
                        isChecked = v.defaultValue == "true"
                        setTextColor(TEXT_PRIMARY); setPadding(0, 16, 0, 0)
                    }
                    target.addView(cb)
                    if (v.helper.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    valueReaders[v.key] = { if (cb.isChecked) "true" else "false" }
                }
                "RADIO" -> {
                    if (v.label.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.label; setTextColor(TEXT_PRIMARY); setPadding(0, 16, 0, 2)
                    })
                    val rg = android.widget.RadioGroup(ctx)
                    val selectedIdx = v.defaultValue.toIntOrNull() ?: 0
                    v.radioOptions.forEachIndexed { i, opt ->
                        val rb = android.widget.RadioButton(ctx).apply { text = opt; id = i + 1; setTextColor(TEXT_PRIMARY) }
                        if (i == selectedIdx) rb.isChecked = true
                        rg.addView(rb)
                    }
                    target.addView(rg)
                    if (v.helper.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    // Değer: seçili radyonun index'i (0 tabanlı). Seçili yoksa 0.
                    valueReaders[v.key] = { (rg.checkedRadioButtonId - 1).coerceAtLeast(0).toString() }
                }
                "IMAGEPICKER" -> {
                    if (v.label.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.label; textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 16, 0, 2)
                    })
                    var currentPath = v.defaultValue
                    val preview = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(120, 120)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    fun refreshPreview() {
                        if (currentPath.isNotBlank()) android.graphics.BitmapFactory.decodeFile(currentPath)?.let { preview.setImageBitmap(it) }
                    }
                    refreshPreview()
                    target.addView(preview)
                    val btnPick = Button(ctx).apply { text = "🖼️ Kütüphaneden Seç" }
                    btnPick.setOnClickListener {
                        val items = LibraryStorage.load(ctx).filter { it.kind == "IMAGE" } + com.bigboss.app.storage.GlobalLibraryStorage.load(ctx).filter { it.kind == "IMAGE" }
                        if (items.isEmpty()) { Toast.makeText(ctx, "Kütüphanede resim yok", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                        overlayDialog().setItems(items.map { it.name }.toTypedArray()) { _, idx ->
                            currentPath = items[idx].templatePath ?: ""; refreshPreview()
                        }.setNegativeButton("Kapat", null).create().showOverlay()
                    }
                    target.addView(btnPick)
                    if (v.helper.isNotBlank()) target.addView(TextView(ctx).apply { text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY) })
                    valueReaders[v.key] = { currentPath }
                }
                "RECORDER" -> {
                    if (v.label.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.label; textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 16, 0, 2)
                    })
                    var currentRecordId = v.defaultValue
                    val statusTv = TextView(ctx).apply { setTextColor(TEXT_PRIMARY) }
                    fun refreshStatus() {
                        val allRecs = com.bigboss.app.storage.RecordStorage.load(ctx) + com.bigboss.app.storage.GlobalRecordStorage.load(ctx)
                        statusTv.text = allRecs.find { it.id == currentRecordId || it.name == currentRecordId }?.let { "🎬 ${it.name}" } ?: "Henüz kayıt seçilmedi"
                    }
                    refreshStatus()
                    target.addView(statusTv)
                    val btnPick = Button(ctx).apply { text = "🎬 Kayıt Seç" }
                    btnPick.setOnClickListener {
                        val recs = com.bigboss.app.storage.RecordStorage.load(ctx) + com.bigboss.app.storage.GlobalRecordStorage.load(ctx)
                        if (recs.isEmpty()) { Toast.makeText(ctx, "Henüz kayıt yok", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                        overlayDialog().setItems(recs.map { "🎬 ${it.name}" }.toTypedArray()) { _, idx ->
                            currentRecordId = recs[idx].id; refreshStatus()
                        }.setNegativeButton("Kapat", null).create().showOverlay()
                    }
                    target.addView(btnPick)
                    if (v.helper.isNotBlank()) target.addView(TextView(ctx).apply { text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY) })
                    valueReaders[v.key] = { currentRecordId }
                }
                "TABLAYOUT" -> if (v.tabs.isNotEmpty()) {
                    // id-tabanlı (programatik) sekmeler: görünürlük tüm view'lar render edildikten sonra uygulanır.
                    val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 16, 0, 4) }
                    val idTabButtons = v.tabs.mapIndexed { i, t ->
                        TextView(ctx).apply {
                            text = t.label; textSize = 12f; setTypeface(null, android.graphics.Typeface.BOLD)
                            setPadding(16, 8, 16, 8)
                            setTextColor(if (i == v.tabSelected) ACCENT else Color.DKGRAY)
                            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        }
                    }
                    idTabButtons.forEach { tabRow.addView(it) }
                    target.addView(tabRow)
                    idBasedTabs.add(v to idTabButtons)
                } else {
                    val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 16, 0, 4) }
                    val newContainers = v.radioOptions.map { LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE } }
                    val tabButtons = v.radioOptions.mapIndexed { i, tabName ->
                        TextView(ctx).apply {
                            text = tabName; textSize = 12f; setTypeface(null, android.graphics.Typeface.BOLD)
                            setPadding(16, 8, 16, 8)
                            setTextColor(if (i == 0) ACCENT else Color.DKGRAY)
                            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        }
                    }
                    tabButtons.forEachIndexed { i, btn ->
                        tabRow.addView(btn)
                        btn.setOnClickListener {
                            tabButtons.forEachIndexed { j, b -> b.setTextColor(if (i == j) ACCENT else Color.DKGRAY) }
                            newContainers.forEachIndexed { j, c -> c.visibility = if (i == j) View.VISIBLE else View.GONE }
                        }
                    }
                    if (newContainers.isNotEmpty()) newContainers[0].visibility = View.VISIBLE
                    target.addView(tabRow)
                    newContainers.forEach { target.addView(it) }
                    tabContainers = newContainers
                }
                else -> { // EDITTEXT
                    if (v.label.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.label; textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 16, 0, 2)
                    })
                    val et = EditText(ctx).apply {
                        setText(v.defaultValue)
                        hint = v.hint
                        setTextColor(TEXT_PRIMARY)
                        if (v.inputMethod == "NUMBER") inputType = InputType.TYPE_CLASS_NUMBER
                    }
                    target.addView(et)
                    if (v.helper.isNotBlank()) target.addView(TextView(ctx).apply {
                        text = v.helper; textSize = 11f; setTextColor(TEXT_SECONDARY)
                    })
                    valueReaders[v.key] = { et.text.toString() }
                }
            }
            val refId = v.viewId.ifBlank { v.key }
            if (v.type != "TABLAYOUT" && refId.isNotBlank()) {
                idRanges[refId] = Triple(target, startChild, target.childCount)
            }
        }

        // id-tabanlı TabLayout: tüm view'lar render edildikten SONRA görünürlüğü uygula + sekme tıklamalarını bağla.
        idBasedTabs.forEach { (tv, buttons) ->
            fun applyTab(sel: Int) {
                val tab = tv.tabs.getOrNull(sel) ?: return
                val visible = tab.visibleIds.toHashSet()
                val hidden = tab.hiddenIds?.toHashSet()
                idRanges.forEach { (rid, range) ->
                    val show = when {
                        visible.contains(rid) -> true
                        hidden == null -> false          // hiddenIds null => diğer TÜM view'ları gizle
                        hidden.contains(rid) -> false
                        else -> true
                    }
                    for (i in range.second until range.third) range.first.getChildAt(i)?.visibility = if (show) View.VISIBLE else View.GONE
                }
                buttons.forEachIndexed { j, b -> b.setTextColor(if (j == sel) ACCENT else Color.DKGRAY) }
                if (tv.tabSaveSelected && tv.viewId.isNotBlank()) com.bigboss.app.engine.VariableStore.setRaw(tv.viewId, sel.toString(), "STRING")
            }
            buttons.forEachIndexed { i, b -> b.setOnClickListener { applyTab(i) } }
            val rawInitial = if (tv.tabSaveSelected && tv.viewId.isNotBlank())
                (com.bigboss.app.engine.VariableStore.getString(tv.viewId).toIntOrNull() ?: tv.tabSelected)
            else tv.tabSelected
            // Geçersiz (negatif / sekme sayısını aşan) index'te görünürlük hiç uygulanmasın diye kırp.
            val initial = rawInitial.coerceIn(0, (tv.tabs.size - 1).coerceAtLeast(0))
            applyTab(initial)
        }

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }
        overlayDialog().setTitle("⚙️ ${def.title}").setView(scroll)
            .setPositiveButton(positiveText) { _, _ ->
                // preview: Kaydet etkisizdir ama sonuç 1 (true) döner (doküman: Dialog.preview()).
                if (!preview) {
                    val values = LinkedHashMap<String, String>()
                    valueReaders.forEach { (key, reader) -> if (key.isNotBlank()) values[key] = reader() }
                    // persist=false (programatik diyalog): settings.json'a YAZMA, sadece değişkenleri güncelle.
                    if (persist) com.bigboss.app.storage.SettingStorage.applyValues(ctx, values)
                    else com.bigboss.app.storage.SettingStorage.applyValuesRuntimeOnly(ctx, values)
                    com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                    Toast.makeText(ctx, "Ayarlar kaydedildi — değişkenler güncellendi", Toast.LENGTH_SHORT).show()
                }
                onDone?.invoke(true)
            }
            .setNegativeButton(negativeText) { _, _ -> onDone?.invoke(false) }
            .setOnCancelListener { onDone?.invoke(false) }
            .create().showOverlay()
    }

    /** EMScript spec'ini (saf-Kotlin) render edilebilir SettingDefinition'a çevirir. */
    private fun com.bigboss.app.emscript.EmSettingSpec.toSettingDefinition(): com.bigboss.app.storage.SettingDefinition {
        val outDef = com.bigboss.app.storage.SettingDefinition(title = this.title)
        this.views.forEach { v ->
            outDef.views.add(
                com.bigboss.app.storage.SettingViewDef(
                    id = java.util.UUID.randomUUID().toString(),
                    type = v.type,
                    key = v.key,
                    label = v.label,
                    defaultValue = v.defaultValue,
                    hint = v.hint,
                    helper = v.helper,
                    inputMethod = v.inputMethod,
                    radioOptions = v.radioOptions.toMutableList(),
                    viewId = v.viewId,
                    tabs = v.tabs.map { com.bigboss.app.storage.SettingTabDef(it.label, it.visibleIds.toMutableList(), it.hiddenIds?.toMutableList()) }.toMutableList(),
                    tabSelected = v.tabSelected,
                    tabSaveSelected = v.tabSaveSelected
                )
            )
        }
        return outDef
    }

    /** Setting Builder editörü — özel ayar diyaloğundaki view'ları ekle/düzenle/sil/sırala. */
    /** Setting Builder ekranındaki Kopyala/Kes/Yapıştır için — tek kullanımlık bellek panosu. */
    private var settingViewClipboard: com.bigboss.app.storage.SettingViewDef? = null

    /**
     * Macrorify'daki "Setting Builder" ekranıyla BİREBİR: üstte OPTION (sol, başlık +
     * Başlangıçta Göster) / Setting Builder (başlık, panel üst çubuğunda) / PREVIEW (sağ,
     * diyaloğu şimdi gösterir), altta view listesi, en altta 9 ikonlu araç çubuğu.
     */
    private fun buildSettingBuilderScreen(): View {
        val ctx = this
        val def = com.bigboss.app.storage.SettingStorage.load(ctx)
        val selectedIndices = mutableSetOf<Int>()
        val density = resources.displayMetrics.density

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }

        // ---- OPTION (sol) / PREVIEW (sağ) ----
        val topRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val btnOption = TextView(ctx).apply {
            text = "OPTION"; textSize = 12f; isAllCaps = true; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(ACCENT)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnPreview = TextView(ctx).apply {
            text = "PREVIEW"; textSize = 12f; isAllCaps = true; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(ACCENT)
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        topRow.addView(btnOption); topRow.addView(btnPreview)
        root.addView(topRow)
        root.addView(TextView(ctx).apply {
            text = if (def.showAtStartup) "🚀 Başlangıçta Göster: AÇIK" else "🚀 Başlangıçta Göster: KAPALI"
            textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, 4, 0, 8)
        })

        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun buildContent() {
            listContainer.removeAllViews()
            if (def.views.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz view yok — alttaki ➕ ile ekle"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = def.views.size
                override fun getItem(position: Int): Any = def.views[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    val v = def.views[position]
                    val icon = when (v.type) {
                        "TEXTVIEW" -> "🏷️"; "CHECKBOX" -> "☑️"; "RADIO" -> "🔘"
                        "IMAGEPICKER" -> "🖼️"; "RECORDER" -> "🎬"; "TABLAYOUT" -> "📑"; else -> "✏️"
                    }
                    val keyPart = if (v.type == "TEXTVIEW" || v.type == "TABLAYOUT") "" else " [${v.key}]"
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = icon
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "${v.label.ifBlank { v.key.ifBlank { v.type } }}$keyPart"
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = if (v.tabIndex >= 0) "Tab ${v.tabIndex + 1}" else ""
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.45).toInt())
            listView.setOnItemClickListener { _, _, position, _ -> editSettingView(def, def.views[position]) }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged(); true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = düzenle · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedViews(): List<com.bigboss.app.storage.SettingViewDef> = selectedIndices.sorted().mapNotNull { def.views.getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }
        fun persist() { com.bigboss.app.storage.SettingStorage.save(ctx, def); com.bigboss.app.storage.EngineAssembler.refresh(ctx) }

        btnOption.setOnClickListener {
            overlayDialog().setItems(arrayOf(
                "📝 Başlık: ${def.title}",
                if (def.showAtStartup) "🚀 Başlangıçta Göster: AÇIK (kapatmak için dokun)" else "🚀 Başlangıçta Göster: KAPALI (açmak için dokun)"
            )) { _, idx ->
                when (idx) {
                    0 -> {
                        val input = EditText(ctx).apply { setText(def.title) }
                        overlayDialog().setTitle("Diyalog başlığı").setView(input)
                            .setPositiveButton("Kaydet") { _, _ -> def.title = input.text.toString().ifBlank { "Ayarlar" }; persist(); refreshCurrentScreen() }
                            .setNegativeButton("Vazgeç", null).create().showOverlay()
                    }
                    1 -> { def.showAtStartup = !def.showAtStartup; persist(); refreshCurrentScreen() }
                }
            }.setNegativeButton("Kapat", null).create().showOverlay()
        }
        btnPreview.setOnClickListener { showCustomSettingsDialog() }

        // ---- Macrorify'daki 9 ikonlu araç çubuğu ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        // 1) ➕ View Ekle
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_add, C_GREEN) { addSettingView(def) })
        // 2) 📑 Sekme Özeti — hangi view hangi Tab'de, tek bakışta.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_select_frame, C_BLUE) {
            val tabLayouts = def.views.filter { it.type == "TABLAYOUT" }
            if (tabLayouts.isEmpty()) { Toast.makeText(ctx, "Henüz bir Tab Layout eklenmedi", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            val summary = tabLayouts.joinToString("\n\n") { tl ->
                val myIdx = def.views.indexOfFirst { it.id == tl.id }
                "📑 ${tl.label.ifBlank { "Tab Layout" }}:\n" + tl.radioOptions.mapIndexed { i, name ->
                    val count = def.views.count { it.tabIndex == i && def.views.indexOfFirst { x -> x.id == it.id } > myIdx }
                    "  • $name ($count view)"
                }.joinToString("\n")
            }
            overlayDialog().setTitle("Sekme Özeti").setMessage(summary).setNegativeButton("Kapat", null).create().showOverlay()
        })
        // 3) </> Code Equivalent — mevcut tanımın ham (JSON) karşılığını gösterir.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_code, C_BLUE) {
            val json = com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(def)
            overlayDialog().setTitle("Code Equivalent (JSON)").setMessage(json).setNegativeButton("Kapat", null).create().showOverlay()
        })
        // 4) Kopyala
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            val sel = selectedViews().firstOrNull()
            if (sel == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir view seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            settingViewClipboard = sel.copy()
            Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
        })
        // 5) Kes
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            val sel = selectedViews().firstOrNull()
            if (sel == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir view seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            settingViewClipboard = sel.copy()
            def.views.removeAll { it.id == sel.id }
            persist(); refreshThisScreen()
        })
        // 6) Yapıştır
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val clip = settingViewClipboard
            if (clip == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            def.views.add(clip.copy(id = UUID.randomUUID().toString()))
            persist(); refreshThisScreen()
        })
        // 7) Sil
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            val sel = selectedViews()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) view seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            def.views.removeAll { v -> sel.any { it.id == v.id } }
            persist()
            Toast.makeText(ctx, "${sel.size} view silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        // 8) Yukarı
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) view seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            if (idx > 0) {
                val tmp = def.views[idx - 1]; def.views[idx - 1] = def.views[idx]; def.views[idx] = tmp
                persist(); selectedIndices.clear(); selectedIndices.add(idx - 1); buildContent()
            }
        })
        // 9) Aşağı
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            val idx = selectedIndices.maxOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) view seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            if (idx < def.views.size - 1) {
                val tmp = def.views[idx + 1]; def.views[idx + 1] = def.views[idx]; def.views[idx] = tmp
                persist(); selectedIndices.clear(); selectedIndices.add(idx + 1); buildContent()
            }
        })
        footer.addView(toolbarRow)

        buildContent()
        return root
    }

    /** Yeni view eklemek için tip seçtirir. */
    private fun addSettingView(def: com.bigboss.app.storage.SettingDefinition) {
        val ctx = this
        // Macrorify'daki 7 view tipiyle BİREBİR sıra.
        val types = listOf(
            "🏷️ TextView (sadece metin)" to "TEXTVIEW",
            "✏️ EditText (metin/sayı girişi)" to "EDITTEXT",
            "☑️ CheckBox (açık/kapalı)" to "CHECKBOX",
            "🔘 Radio Group (seçenekler)" to "RADIO",
            "🖼️ ImagePicker (çalışırken resim seç)" to "IMAGEPICKER",
            "🎬 Recorder (çalışırken kayıt seç)" to "RECORDER",
            "📑 Tab Layout (sekmelere ayır)" to "TABLAYOUT"
        )
        overlayDialog().setTitle("Hangi view?")
            .setItems(types.map { it.first }.toTypedArray()) { _, i ->
                val newView = com.bigboss.app.storage.SettingViewDef(java.util.UUID.randomUUID().toString(), type = types[i].second)
                def.views.add(newView)
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                editSettingView(def, newView)
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Bir view'ın alanlarını düzenler (tipine göre). */
    private fun editSettingView(def: com.bigboss.app.storage.SettingDefinition, view: com.bigboss.app.storage.SettingViewDef) {
        val ctx = this
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }

        val keyInput = EditText(ctx).apply { setText(view.key); hint = "key (değişken adı)" }
        val labelInput = EditText(ctx).apply { setText(view.label); hint = if (view.type == "TEXTVIEW") "gösterilecek metin" else "etiket (üst başlık)" }
        val defaultInput = EditText(ctx).apply { setText(view.defaultValue); hint = "varsayılan değer" }
        val hintInput = EditText(ctx).apply { setText(view.hint); hint = "kutu içi ipucu (hint)" }
        val helperInput = EditText(ctx).apply { setText(view.helper); hint = "yardımcı açıklama (helper)" }

        if (view.type != "TEXTVIEW") {
            box.addView(TextView(ctx).apply { text = "Key (değişken adı — makro her yerinde {bu} olarak kullanılır)"; textSize = 11f; setTextColor(TEXT_SECONDARY) })
            box.addView(keyInput)
        }
        box.addView(TextView(ctx).apply { text = if (view.type == "TEXTVIEW") "Metin" else "Etiket"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
        box.addView(labelInput)

        // Bu view'dan ÖNCE bir TABLAYOUT varsa, hangi sekmede gösterileceğini seçtir.
        var selectedTabIndex = view.tabIndex
        if (view.type != "TABLAYOUT") {
            val myIdx = def.views.indexOfFirst { it.id == view.id }
            val precedingTabLayout = def.views.take(myIdx.coerceAtLeast(0)).lastOrNull { it.type == "TABLAYOUT" }
            if (precedingTabLayout != null) {
                box.addView(TextView(ctx).apply { text = "Sekme (Tab)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                val tabRadio = android.widget.RadioGroup(ctx)
                val rbNone = android.widget.RadioButton(ctx).apply { text = "Sekmesiz (her zaman görünür)"; id = 1 }
                tabRadio.addView(rbNone)
                if (view.tabIndex < 0) rbNone.isChecked = true
                precedingTabLayout.radioOptions.forEachIndexed { i, tabName ->
                    val rb = android.widget.RadioButton(ctx).apply { text = tabName; id = i + 2 }
                    if (view.tabIndex == i) rb.isChecked = true
                    tabRadio.addView(rb)
                }
                tabRadio.setOnCheckedChangeListener { _, checkedId -> selectedTabIndex = checkedId - 2 }
                box.addView(tabRadio)
            }
        }

        // Tipe özel alanlar
        when (view.type) {
            "EDITTEXT" -> {
                box.addView(TextView(ctx).apply { text = "Varsayılan metin"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                box.addView(defaultInput)
                box.addView(hintInput)
                box.addView(helperInput)
                val numCheck = android.widget.CheckBox(ctx).apply {
                    text = "Sayı girişi (Number)"; isChecked = view.inputMethod == "NUMBER"; setTextColor(TEXT_PRIMARY); setPadding(0, 8, 0, 0)
                }
                box.addView(numCheck)
                box.tag = numCheck // sonradan okumak için
            }
            "CHECKBOX" -> {
                val defCheck = android.widget.CheckBox(ctx).apply {
                    text = "Varsayılan: işaretli"; isChecked = view.defaultValue == "true"; setTextColor(TEXT_PRIMARY); setPadding(0, 8, 0, 0)
                }
                box.addView(defCheck)
                box.addView(helperInput)
                box.tag = defCheck
            }
            "RADIO" -> {
                box.addView(TextView(ctx).apply { text = "Seçenekler (her satır bir seçenek)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                val optsInput = EditText(ctx).apply {
                    setText(view.radioOptions.joinToString("\n")); isSingleLine = false; minLines = 2; maxLines = 6
                }
                box.addView(optsInput)
                box.addView(helperInput)
                box.tag = optsInput
            }
            "IMAGEPICKER" -> {
                box.addView(TextView(ctx).apply { text = "Varsayılan resim yolu (boş bırakılabilir — çalışırken 'Kütüphaneden Seç' ile seçilir)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                box.addView(defaultInput)
                box.addView(helperInput)
                box.tag = null
            }
            "RECORDER" -> {
                box.addView(TextView(ctx).apply { text = "Varsayılan kayıt id'si (boş bırakılabilir — çalışırken 'Kayıt Seç' ile seçilir)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                box.addView(defaultInput)
                box.addView(helperInput)
                box.tag = null
            }
            "TABLAYOUT" -> {
                box.addView(TextView(ctx).apply { text = "Sekme isimleri (her satır bir sekme) — SONRAKİ view'lar bu sekmelere atanabilir"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0) })
                val tabsInput = EditText(ctx).apply {
                    setText(view.radioOptions.joinToString("\n")); isSingleLine = false; minLines = 2; maxLines = 6
                }
                box.addView(tabsInput)
                box.tag = tabsInput
            }
        }

        overlayDialog().setTitle("${view.type} düzenle").setView(android.widget.ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("Kaydet") { _, _ ->
                if (view.type != "TEXTVIEW") {
                    val k = keyInput.text.toString().trim()
                    if (!isValidVariableName(k)) {
                        Toast.makeText(ctx, "Geçersiz key: harf/rakam/_ kullan, sayıyla başlama", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                    view.key = k
                }
                view.label = labelInput.text.toString()
                view.helper = helperInput.text.toString()
                if (view.type != "TABLAYOUT") view.tabIndex = selectedTabIndex
                when (view.type) {
                    "EDITTEXT" -> {
                        view.defaultValue = defaultInput.text.toString()
                        view.hint = hintInput.text.toString()
                        view.inputMethod = if ((box.tag as? android.widget.CheckBox)?.isChecked == true) "NUMBER" else "TEXT"
                    }
                    "CHECKBOX" -> {
                        view.defaultValue = if ((box.tag as? android.widget.CheckBox)?.isChecked == true) "true" else "false"
                    }
                    "RADIO" -> {
                        val lines = (box.tag as? EditText)?.text?.toString()?.split("\n")?.map { it.trim() }?.filter { it.isNotBlank() }
                        if (!lines.isNullOrEmpty()) view.radioOptions = lines.toMutableList()
                        if (view.defaultValue.toIntOrNull() == null) view.defaultValue = "0"
                    }
                    "IMAGEPICKER", "RECORDER" -> {
                        view.defaultValue = defaultInput.text.toString()
                    }
                    "TABLAYOUT" -> {
                        val lines = (box.tag as? EditText)?.text?.toString()?.split("\n")?.map { it.trim() }?.filter { it.isNotBlank() }
                        if (!lines.isNullOrEmpty()) view.radioOptions = lines.toMutableList()
                    }
                }
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                refreshCurrentScreen()
            }
            .setNeutralButton("🗑 Sil") { _, _ ->
                def.views.removeAll { it.id == view.id }
                com.bigboss.app.storage.SettingStorage.save(ctx, def)
                refreshCurrentScreen()
            }
            .setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    // ==================== 🔢 Değişkenler (Hold/Delay gibi alanların toplu değiştirilmesi için) ====================

    // ==================== 💡 Ampul Menüsü (Değişken/İfade Ekleyici) ====================
    // Macrorify: her değer alanının sonundaki sarı ampul → o alana sabit değer yerine
    // Variables / Setting Builder / Current Time / Random Number / Forever eklemeyi sağlar.
    // Alanlar {isim} biçiminde bir değişken/ifade referansı tutar; motor çalışırken çözer.

    /**
     * Bir EditText'i, sonunda 💡 ampul butonu olan yatay bir satıra sarar ve döndürür.
     * Ampule basınca değişken/ifade ekleme menüsü açılır (alanın metnini değiştirir).
     * Editör düzenine bu döndürülen satır eklenmelidir (EditText'in kendisi yerine).
     */
    private fun wrapWithBulb(field: EditText): LinearLayout {
        val ctx = this
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        field.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(field)
        val bulb = TextView(ctx).apply {
            text = "💡"; textSize = 18f
            setPadding((10 * resources.displayMetrics.density).toInt(), 0, (6 * resources.displayMetrics.density).toInt(), 0)
            isClickable = true
            setOnClickListener { showBulbMenu(field) }
        }
        row.addView(bulb)
        return row
    }

    /** Ampul menüsü: seçilen kaynağı alana {isim} / değer olarak yazar. */
    private fun showBulbMenu(field: EditText) {
        val options = arrayOf(
            "🔢 Değişkenler (Variables)",
            "⚙️ Setting Builder",
            "🕐 Şu Anki Zaman (ms)",
            "🎲 Rastgele Sayı",
            "♾️ Forever (-1)"
        )
        overlayDialog().setTitle("💡 Değer Ekle").setItems(options) { _, which ->
            when (which) {
                0 -> bulbPickVariable(field)
                1 -> bulbPickSetting(field)
                2 -> bulbInsertCurrentTime(field)
                3 -> bulbInsertRandom(field)
                4 -> field.setText("-1")
            }
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Variables: mevcut değişkenlerden birini seç → alana {isim} yaz. */
    private fun bulbPickVariable(field: EditText) {
        val ctx = this
        val vars = com.bigboss.app.storage.GlobalVariableStorage.load(ctx).filter { !it.disabled }
        if (vars.isEmpty()) {
            Toast.makeText(ctx, "Henüz değişken yok — önce 🔢 Değişkenler'den oluştur", Toast.LENGTH_LONG).show()
            return
        }
        val names = vars.map { v ->
            val icon = when (v.type) { "STRING" -> "🔤"; "REFERENCE" -> "🔗"; else -> "🔢" }
            "$icon ${v.name} = ${v.raw()}"
        }.toTypedArray()
        overlayDialog().setTitle("Değişken Seç").setItems(names) { _, i ->
            field.setText("{${vars[i].name}}")
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Setting Builder: özel ayar anahtarlarından birini seç → alana {key} yaz. */
    private fun bulbPickSetting(field: EditText) {
        val ctx = this
        val def = com.bigboss.app.storage.SettingStorage.load(ctx)
        val keys = def.views.mapNotNull { it.key.takeIf { k -> k.isNotBlank() } }
        if (keys.isEmpty()) {
            Toast.makeText(ctx, "Setting Builder'da anahtarlı bir alan yok", Toast.LENGTH_LONG).show()
            return
        }
        overlayDialog().setTitle("Ayar Anahtarı Seç").setItems(keys.toTypedArray()) { _, i ->
            field.setText("{${keys[i]}}")
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /**
     * Current Time: bir REFERENCE değişken (SystemTime) oluşturur (yoksa) ve alana {SystemTime} yazar.
     * Çalışırken script motorunda güncel zaman (ms) olarak değerlendirilir.
     */
    private fun bulbInsertCurrentTime(field: EditText) {
        ensureReferenceVariable("SystemTime", "Date.now()")
        field.setText("{SystemTime}")
        Toast.makeText(this, "Eklendi: {SystemTime} (çalışırken güncel zaman-ms)", Toast.LENGTH_SHORT).show()
    }

    /** Random Number: min/max sorar, bir REFERENCE değişken oluşturur ve alana {isim} yazar. */
    private fun bulbInsertRandom(field: EditText) {
        val ctx = this
        val minInput = EditText(ctx).apply { hint = "min"; setText("0"); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val maxInput = EditText(ctx).apply { hint = "max"; setText("100"); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(TextView(ctx).apply { text = "Rastgele sayı aralığı"; textSize = 12f; setTextColor(TEXT_SECONDARY) })
            addView(minInput); addView(maxInput)
        }
        overlayDialog().setTitle("🎲 Rastgele Sayı").setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val mn = minInput.text.toString().toIntOrNull() ?: 0
                val mx = maxInput.text.toString().toIntOrNull() ?: 100
                val varName = "Random_${mn}_${mx}"
                ensureReferenceVariable(varName, "randomInt($mn, $mx)")
                field.setText("{$varName}")
                Toast.makeText(ctx, "Eklendi: {$varName} (çalışırken $mn-$mx arası)", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** Verilen isimde bir REFERENCE değişken yoksa oluşturur (ampul ifadeleri için). */
    private fun ensureReferenceVariable(name: String, expression: String) {
        val existing = com.bigboss.app.storage.GlobalVariableStorage.load(this).find { it.name == name }
        if (existing == null) {
            com.bigboss.app.storage.GlobalVariableStorage.upsert(
                this, com.bigboss.app.storage.GlobalVariableDefinition(
                    UUID.randomUUID().toString(), name, type = "REFERENCE", textValue = expression
                )
            )
            com.bigboss.app.storage.EngineAssembler.refresh(this)
        }
    }

    /** "Variables" listesindeki tek bir öğe: ya bir Değişken ((x), Number/String/Reference) ya bir Script (</>, kod). */
    private sealed class VariablesEntry {
        data class Var(val v: com.bigboss.app.storage.GlobalVariableDefinition) : VariablesEntry()
        data class Scr(val script: com.bigboss.app.storage.ScriptDefinition) : VariablesEntry()
    }

    /**
     * Macrorify'daki "Variables" sayfasıyla BİREBİR: (x) Değişken VE `</>` Kod aynı listede,
     * tek satır 8 ikonlu araç çubuğu ((x) Ekle, `</>` Ekle, Kopyala, Kes, Yapıştır, Sil,
     * Yukarı, Aşağı) — "Functions" sayfasıyla AYNI mimari, sadece f{} yerine (x).
     */
    private fun buildVariablesScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun currentEntries(): List<VariablesEntry> {
            val entries = mutableListOf<VariablesEntry>()
            com.bigboss.app.storage.GlobalVariableStorage.load(ctx).forEach { entries.add(VariablesEntry.Var(it)) }
            com.bigboss.app.storage.ScriptStorage.load(ctx).forEach { entries.add(VariablesEntry.Scr(it)) }
            return entries
        }

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz değişken/kod yok — alttaki (x) ya da </> ile oluştur"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    when (val entry = entries[position]) {
                        is VariablesEntry.Var -> {
                            val icon = when (entry.v.type) { "STRING" -> "🔤"; "REFERENCE" -> "🔗"; else -> "(x)" }
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (entry.v.disabled) "🔕" else icon
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "${entry.v.name} = ${entry.v.raw()}"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = entry.v.type
                        }
                        is VariablesEntry.Scr -> {
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "</>"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = entry.script.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = entry.script.language
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.45).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is VariablesEntry.Var -> showVariableOptions(entry.v)
                    is VariablesEntry.Scr -> pushScreen("</> ${entry.script.name}") { buildCodeEditorContent(entry.script.id) }
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<VariablesEntry> = selectedIndices.sorted().mapNotNull { currentEntries().getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        // ---- Macrorify'daki TEK SATIR, 8 gerçek vektör ikonlu araç çubuğu: (x) (Değişken Ekle),
        // </> (Kod Ekle), Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı. ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_variable, C_PURPLE) { createVariable(); refreshThisScreen() })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_code, C_BLUE) { addScriptEntry() })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            when (val sel = selectedEntries().firstOrNull()) {
                is VariablesEntry.Var -> { variableClipboard = sel.v.copy(); Toast.makeText(ctx, "Kopyalandı: ${sel.v.name}", Toast.LENGTH_SHORT).show() }
                is VariablesEntry.Scr -> copyScriptEntry(sel.script)
                null -> Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            when (val sel = selectedEntries().firstOrNull()) {
                is VariablesEntry.Var -> {
                    variableClipboard = sel.v.copy()
                    com.bigboss.app.storage.GlobalVariableStorage.delete(ctx, sel.v.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(ctx); refreshThisScreen()
                }
                is VariablesEntry.Scr -> { cutScriptEntry(sel.script); refreshThisScreen() }
                null -> Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val pastedVar = variableClipboard
            if (pastedVar != null) {
                com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, pastedVar.copy(id = UUID.randomUUID().toString()))
                com.bigboss.app.storage.EngineAssembler.refresh(ctx); refreshThisScreen(); return@makeToolIcon
            }
            if (tryPasteScriptEntry()) { refreshThisScreen(); return@makeToolIcon }
            Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { entry ->
                when (entry) {
                    is VariablesEntry.Var -> com.bigboss.app.storage.GlobalVariableStorage.delete(ctx, entry.v.id)
                    is VariablesEntry.Scr -> deleteScriptEntry(entry.script)
                }
            }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { entry ->
                when (entry) {
                    is VariablesEntry.Var -> com.bigboss.app.storage.GlobalVariableStorage.moveUp(ctx, entry.v.id)
                    is VariablesEntry.Scr -> com.bigboss.app.storage.ScriptStorage.moveUp(ctx, entry.script.id)
                }
            }
            refreshThisScreen()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.asReversed().forEach { entry ->
                when (entry) {
                    is VariablesEntry.Var -> com.bigboss.app.storage.GlobalVariableStorage.moveDown(ctx, entry.v.id)
                    is VariablesEntry.Scr -> com.bigboss.app.storage.ScriptStorage.moveDown(ctx, entry.script.id)
                }
            }
            refreshThisScreen()
        })
        footer.addView(toolbarRow)

        buildContent()
        return root
    }

    /** Macrorify isimlendirme kuralı: sadece a-z A-Z 0-9 ve _ ; sayıyla başlayamaz. */
    private fun isValidVariableName(name: String): Boolean =
        name.isNotBlank() && name.matches(Regex("^[A-Za-z_][A-Za-z0-9_]*$"))

    /** Tip seçici (Number/String/Reference) radyo grubu üretir; seçili tipi callback ile bildirir. */
    private fun buildTypeSelector(ctx: android.content.Context, current: String, onChange: (String) -> Unit): LinearLayout {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(ctx).apply { text = "Tip"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
        val rg = android.widget.RadioGroup(ctx)
        val types = listOf("NUMBER" to "🔢 Number (sayı)", "STRING" to "🔤 String (metin)", "REFERENCE" to "🔗 Reference (ifade)")
        types.forEachIndexed { i, (key, label) ->
            val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1 }
            if (current == key) rb.isChecked = true
            rg.addView(rb)
        }
        rg.setOnCheckedChangeListener { _, id -> onChange(types[id - 1].first) }
        box.addView(rg)
        return box
    }

    private fun createVariable() {
        val ctx = this
        var selectedType = "NUMBER"
        val nameInput = EditText(ctx).apply { hint = "Değişken adı (örn. beklemeSuresi) — harf/rakam/_ , sayıyla başlamaz" }
        val valueInput = EditText(ctx).apply { hint = "Başlangıç değeri"; setText("0") }
        val hintTv = TextView(ctx).apply {
            text = "🔢 Number: sayı (10) · 🔤 String: metin (merhaba) · 🔗 Reference: ifade (getVar(\"a\")+5, çalışırken hesaplanır)"
            textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0)
        }
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(nameInput)
        container.addView(buildTypeSelector(ctx, selectedType) { selectedType = it })
        container.addView(TextView(ctx).apply { text = "Değer"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
        container.addView(valueInput)
        container.addView(hintTv)
        overlayDialog().setTitle("Yeni Değişken").setView(container)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (!isValidVariableName(name)) {
                    Toast.makeText(ctx, "Geçersiz ad: sadece harf/rakam/_ kullan, sayıyla başlama (örn. topRegion)", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val value = valueInput.text.toString()
                com.bigboss.app.storage.GlobalVariableStorage.upsert(
                    ctx, com.bigboss.app.storage.GlobalVariableDefinition(UUID.randomUUID().toString(), name, type = selectedType, textValue = value)
                )
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                Toast.makeText(ctx, "Oluşturuldu: $name = $value ($selectedType)", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showVariableOptions(variable: com.bigboss.app.storage.GlobalVariableDefinition) {
        val ctx = this
        val typeLabel = when (variable.type) { "STRING" -> "🔤 String"; "REFERENCE" -> "🔗 Reference"; else -> "🔢 Number" }
        overlayDialog().setTitle("$typeLabel — ${variable.name} = ${variable.raw()}")
            .setItems(arrayOf(
                "✏️ Değeri/Tipi Değiştir (buna bağlı HER ŞEY güncellenir)",
                if (variable.disabled) "🔔 Etkinleştir" else "🔕 Devre Dışı Bırak",
                "🗑 Sil"
            )) { _, index ->
                when (index) {
                    0 -> {
                        var selectedType = variable.type
                        val input = EditText(ctx).apply { setText(variable.raw()) }
                        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
                        box.addView(buildTypeSelector(ctx, selectedType) { selectedType = it })
                        box.addView(TextView(ctx).apply { text = "Değer"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 2) })
                        box.addView(input)
                        overlayDialog().setTitle("Değiştir: ${variable.name}").setView(box)
                            .setPositiveButton("Kaydet") { _, _ ->
                                variable.textValue = input.text.toString()
                                variable.type = selectedType
                                com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, variable)
                                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                                com.bigboss.app.storage.EngineAssembler.setupVariableStore(ctx) { com.bigboss.app.engine.ScriptRuntime.engine }
                                Toast.makeText(ctx, "Güncellendi: ${variable.name} = ${variable.raw()} — buna bağlı tüm alanlar etkilendi", Toast.LENGTH_LONG).show()
                            }.setNegativeButton("Vazgeç", null).create().showOverlay()
                    }
                    1 -> {
                        variable.disabled = !variable.disabled
                        com.bigboss.app.storage.GlobalVariableStorage.upsert(ctx, variable)
                        com.bigboss.app.storage.EngineAssembler.setupVariableStore(ctx) { com.bigboss.app.engine.ScriptRuntime.engine }
                        Toast.makeText(ctx, if (variable.disabled) "Devre dışı" else "Etkin", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        com.bigboss.app.storage.GlobalVariableStorage.delete(ctx, variable.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                        Toast.makeText(ctx, "Silindi (buna bağlı alanlar artık kendi sabit değerlerini kullanır)", Toast.LENGTH_LONG).show()
                    }
                }
            }.create().showOverlay()
    }

    // ==================== 🧪 Test Geri Bildirimi (eskiden "Canlı İzleme" — TÜM kuralları sürekli
    // izleyen, elle açılıp kapatılan bir sistemdi; kullanıcı bunun yerine SADECE "Test Et"
    // basılan TEK alan için OTOMATİK yeşil/kırmızı geri bildirim istedi. Elle açma/kapama
    // ikonu kaldırıldı — artık testRule() her çağrıldığında kendiliğinden gösterip kendiliğinden
    // birkaç saniye sonra kayboluyor, canlı motoru ÇALIŞTIRMIYOR (salt-okunur bir kontrol,
    // gerçek dokunuş/kaydırma YAPMIYOR — bu yüzden test sırasında ekranla senin etkileşimini
    // ENGELLEMİYOR). ====================
    private var testFeedbackBox: View? = null
    private var testFeedbackLabel: TextView? = null
    private var testFeedbackLabelParams: WindowManager.LayoutParams? = null
    private var testFeedbackClearRunnable: Runnable? = null
    private val testFeedbackHandler = android.os.Handler(android.os.Looper.getMainLooper())

    /** Ekrandaki test geri bildirim kutusunu/etiketini temizler (yeni bir test başlarken ya da mod değişiminde çağrılır). */
    private fun clearTestFeedback() {
        testFeedbackClearRunnable?.let { testFeedbackHandler.removeCallbacks(it) }
        testFeedbackClearRunnable = null
        testFeedbackBox?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        testFeedbackBox = null
        testFeedbackLabel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        testFeedbackLabel = null; testFeedbackLabelParams = null
    }

    // ==================== 🎨 Tasarım Sistemi — Macrorify'ın attığın ekran görüntülerine göre ====================
    // Fark ettiğim şeyler: (1) dolgulu renkli üst çubuk yerine CLOSE/Başlık/SAVE metin-linkli
    // hafif "sayfa" hissi (2) bol boşluklu liste satırları + ince gri ayırıcılar (3) her alanın
    // üstünde etiket + kutulu kenarlık + altında açıklama metni (4) MOR vurgu rengi, beyaz zemin.

    /** Karanlık/Aydınlık Mod: panel/ekranların rengi buna göre değişir. */
    private var isDarkMode: Boolean = false
    private val ACCENT: Int get() = if (isDarkMode) Color.parseColor("#B39DFF") else Color.parseColor("#7C4DFF")

    // Macrorify tarzı panel ikon renkleri (aydınlık zeminde okunaklı, işleve göre).
    private val C_GREEN = Color.parseColor("#27C46B")   // tap/swipe/function/test/eye
    private val C_ORANGE = Color.parseColor("#F5871F")  // scan/image/home/library
    private val C_BLUE = Color.parseColor("#3B9EE8")    // settings/workspace/save
    private val C_PURPLE = Color.parseColor("#9B59F6")  // variable/navigation
    private val C_RED = Color.parseColor("#E8503B")     // close/stop
    private val TEXT_PRIMARY: Int get() = if (isDarkMode) Color.parseColor("#F0F0F0") else Color.parseColor("#212121")
    private val TEXT_SECONDARY: Int get() = if (isDarkMode) Color.parseColor("#AAAAAA") else Color.parseColor("#757575")
    private val DIVIDER_COLOR: Int get() = if (isDarkMode) Color.parseColor("#3A3A3A") else Color.parseColor("#E0E0E0")
    /** Panel/kart arka planı — Aydınlık modda beyaz, Karanlık modda koyu gri. */
    private val SURFACE_COLOR: Int get() = if (isDarkMode) Color.parseColor("#1E1E1E") else Color.WHITE
    /** Hafif vurgulu satır arka planı (kart, liste satırı vb.) */
    private val SURFACE_ALT_COLOR: Int get() = if (isDarkMode) Color.parseColor("#2A2A2A") else Color.parseColor("#F5F5F5")

    /** Macrorify'daki "CLOSE ... Başlık ... SAVE" üst çubuğu — dolgulu renk yerine beyaz zemin + mor metin linkler. */
    private fun buildSheetHeader(title: String, onClose: () -> Unit, rightLabel: String? = null, onRight: (() -> Unit)? = null): LinearLayout {
        val density = resources.displayMetrics.density
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt())
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setOnClickListener { onClose() }
        }
        val titleTv = TextView(this).apply {
            text = title; textSize = 15f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val rightTv = TextView(this).apply {
            text = rightLabel ?: ""
            textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            visibility = if (rightLabel != null) View.VISIBLE else View.INVISIBLE
            if (onRight != null) setOnClickListener { onRight() }
        }
        header.addView(closeBtn)
        header.addView(titleTv)
        header.addView(rightTv)
        return header
    }

    /** Macrorify'daki Ayarlar ekranındaki "etiket + kutulu alan + altında açıklama" deseni. */
    /** Macrorify'daki "?" ipucu balonlarının karşılığı: temiz beyaz pencere, kalın etiketli açıklamalar, "ANLADIM" butonu. */
    private fun showHintDialog(title: String, body: CharSequence) {
        val ctx = this
        val density = resources.displayMetrics.density
        val content = TextView(ctx).apply {
            text = body
            textSize = 13f
            setTextColor(TEXT_PRIMARY)
            setPadding((20 * density).toInt(), (16 * density).toInt(), (20 * density).toInt(), (8 * density).toInt())
            setLineSpacing(6f, 1.1f)
        }
        val scroll = android.widget.ScrollView(ctx).apply { addView(content) }
        overlayDialog().setTitle(title).setView(scroll)
            .setPositiveButton("ANLADIM", null)
            .create().showOverlay()
    }

    /** Kalın etiket + açıklama satırlarından bir SpannableStringBuilder oluşturur (hint metinleri için). */
    private fun hintText(vararg parts: Pair<String, String>): CharSequence {
        val sb = android.text.SpannableStringBuilder()
        parts.forEach { (bold, rest) ->
            val start = sb.length
            sb.append(bold)
            sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, sb.length, 0)
            sb.append(rest).append("\n\n")
        }
        return sb
    }

    private fun styledField(label: String, helper: String?, value: String, keyboardNumeric: Boolean = true, hintTitle: String? = null, hintBody: CharSequence? = null, onChange: (String) -> Unit): LinearLayout {
        val density = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (14 * density).toInt(), 0, 0)
        }
        val labelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val labelTv = TextView(this).apply { text = label; textSize = 11f; setTextColor(TEXT_SECONDARY) }
        labelRow.addView(labelTv)
        if (hintTitle != null && hintBody != null) {
            labelRow.addView(TextView(this).apply {
                text = "  ⓘ"; textSize = 11f; setTextColor(ACCENT)
                setOnClickListener { showHintDialog(hintTitle, hintBody) }
            })
        }
        val input = EditText(this).apply {
            setText(value)
            textSize = 15f
            setTextColor(TEXT_PRIMARY)
            if (keyboardNumeric) inputType = InputType.TYPE_CLASS_NUMBER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke((1 * density).toInt(), DIVIDER_COLOR)
                cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        input.addTextChangedListener(simpleWatcher { onChange(it) })
        container.addView(labelRow)
        container.addView(input)
        if (helper != null) {
            container.addView(TextView(this).apply {
                text = helper; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (4 * density).toInt(), 0, 0)
            })
        }
        return container
    }

    /** ListView satırları arasına Macrorify'daki gibi ince gri ayırıcı çizgi ekler. */
    private fun styleListDividers(listView: android.widget.ListView) {
        listView.divider = android.graphics.drawable.ColorDrawable(DIVIDER_COLOR)
        listView.dividerHeight = (1 * resources.displayMetrics.density).toInt()
    }

    // ==================== 📱 App Panel — Macrorify tarzı TEK, KALICI, gezinme yığınlı panel ====================
    // Eskiden HER işlem ayrı bir AlertDialog açıyordu (üst üste yığılıyordu, "neredeyim" belli değildi).
    // Şimdi TEK bir pencere var; içinde "ekranlar" (screen) arasında GERÇEK gezinme yapıyoruz —
    // üstte her zaman "neredeyim" (breadcrumb) + geri butonu görünüyor, tıpkı normal bir uygulama gibi.

    private data class NavEntry(val title: String, val build: () -> View)
    private val navStack = mutableListOf<NavEntry>()
    private var panelRoot: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelContent: android.widget.FrameLayout? = null
    private var panelTitle: TextView? = null
    private var panelBackBtn: TextView? = null

    private fun showAppPanel() {
        if (panelRoot == null) buildAppPanelWindow()
        navStack.clear()
        pushScreen("🏠 BigBoss") { buildHubScreen() }
    }

    private fun buildAppPanelWindow() {
        val metrics = resources.displayMetrics
        val panelW = (metrics.widthPixels * 0.94).toInt()
        val panelH = (metrics.heightPixels * 0.82).toInt()
        val density = metrics.density

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            setPadding((12 * density).toInt(), (16 * density).toInt(), (12 * density).toInt(), (16 * density).toInt())
        }
        val backBtn = TextView(this).apply {
            text = "← GERİ"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((8 * density).toInt(), 0, (16 * density).toInt(), 0)
            visibility = View.INVISIBLE
        }
        val titleTv = TextView(this).apply {
            textSize = 13f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "KAPAT"; textSize = 12f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((16 * density).toInt(), 0, (8 * density).toInt(), 0)
        }
        val headerDivider = View(this).apply {
            setBackgroundColor(DIVIDER_COLOR)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt())
        }
        header.addView(backBtn); header.addView(titleTv); header.addView(closeBtn)

        val content = android.widget.FrameLayout(this)
        val contentScroll = android.widget.ScrollView(this).apply { addView(content) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(SURFACE_COLOR)
            addView(header)
            addView(headerDivider)
            addView(contentScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        backBtn.setOnClickListener { popScreen() }
        closeBtn.setOnClickListener { closeAppPanel() }

        val params = WindowManager.LayoutParams(
            panelW, panelH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager?.addView(root, params)
            panelRoot = root; panelParams = params
            panelContent = content; panelTitle = titleTv; panelBackBtn = backBtn
        } catch (e: Exception) {
            Toast.makeText(this, "Panel açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun pushScreen(title: String, build: () -> View) {
        navStack.add(NavEntry(title, build))
        renderCurrentScreen()
    }

    /** Aynı ekranı, güncel verilerle YENİDEN çizer (bir işlem sonrası liste tazelensin diye). */
    private fun refreshCurrentScreen() = renderCurrentScreen()

    private fun popScreen() {
        if (navStack.size <= 1) { closeAppPanel(); return }
        navStack.removeAt(navStack.size - 1)
        renderCurrentScreen()
    }

    private fun renderCurrentScreen() {
        val entry = navStack.lastOrNull() ?: return
        panelTitle?.text = navStack.joinToString("  ›  ") { it.title }
        panelBackBtn?.visibility = if (navStack.size > 1) View.VISIBLE else View.INVISIBLE
        panelContent?.removeAllViews()
        panelContent?.addView(entry.build())
    }

    private fun closeAppPanel() {
        panelRoot?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        panelRoot = null; panelParams = null; panelContent = null; panelTitle = null; panelBackBtn = null
        navStack.clear()
    }

    /** Panel açıkken bir alt-diyalog (AlertDialog) açmadan önce çağrılır — ikisi karışmasın diye paneli GEÇİCİ gizler. */
    private fun hidePanelTemporarily() { panelRoot?.visibility = View.GONE }
    private fun showPanelAgain() { panelRoot?.visibility = View.VISIBLE }

    // ---- Ana ekran (Hub): büyük kart-butonlar ----
    private fun buildHubScreen(): View {
        val ctx = this
        val density = resources.displayMetrics.density
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt()) }

        fun card(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (18 * density).toInt(), (16 * density).toInt(), (18 * density).toInt())
                setBackgroundColor(SURFACE_ALT_COLOR)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, (10 * density).toInt())
                layoutParams = lp
                isClickable = true
                setOnClickListener { onClick() }
            }
            row.addView(TextView(ctx).apply { text = icon; textSize = 24f; setPadding(0, 0, (16 * density).toInt(), 0) })
            val textCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            textCol.addView(TextView(ctx).apply { text = title; textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
            textCol.addView(TextView(ctx).apply { text = subtitle; textSize = 11f; setTextColor(TEXT_SECONDARY) })
            row.addView(textCol)
            grid.addView(row)
        }

        val rules = RuleStorage.load(ctx).size
        val groups = ActionGroupStorage.load(ctx).size
        val fns = FunctionStorage.load(ctx).size

        card("🏠", "Ana Akış", "$rules kural, $groups grup") { pushScreen("🏠 Ana Akış") { buildAnaAkisScreen() } }
        card("f{}", "Fonksiyonlar", "$fns fonksiyon") { pushScreen("f{} Fonksiyonlar") { buildFonksiyonlarScreen() } }
        card("📚", "Kütüphane", "Görsel/renk/kayıt (Resources)") { pushScreen("📚 Resources") { buildResourcesScreen() } }
        card("(x)", "Değişkenler", "Number/String/Reference") { pushScreen("(x) Variables") { buildVariablesScreen() } }
        card("⚙️", "Setting Builder", "Çalışma-anı ayar arayüzü") { pushScreen("Setting Builder") { buildSettingBuilderScreen() } }
        card("🖼️👆", "Alan Ekle", "Yeni tarama başlat") { closeAppPanel(); startAddRegion() }
        card("🧪", if (editTestRunning) "Canlı Testi Durdur" else "Canlı Test", "Edit Mode'da kalarak test et") { toggleEditTest(); refreshCurrentScreen() }
        card("▶️", "Play Mode'a Geç", "Kalıcı çalıştır") { closeAppPanel(); switchToPlayMode() }
        if (activeRegions.isNotEmpty()) {
            card("🧹", "Ekrandaki Kutuları Temizle", "${activeRegions.size} açık alan") { clearAllRegionWindows(); refreshCurrentScreen() }
        }
        card("⚙️", "Ayarlar", autoStopSubtitle()) { showAutoStopSettingsDialog() }
        card("✕", "Kapat", "Uygulamayı tamamen kapat") { shutdown() }

        return grid
    }

    private fun shutdown() {
        stopErrorPolling()
        stopTestFeedbackPolling()
        stopTestSessionDeadline()
        detachTestFeedbackBorders()
        editTestRunning = false
        clearAllRegionWindows()
        clearWorkspace()
        clearClickMarkers()
        clearRecordMode()
        clearTestFeedback()
        stopAutoStopWatcher()
        removePointMarker()
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopSelf()
    }

    // ==================== Overlay üzerinden Dialog gösterme yardımcıları ====================

    /**
     * TÜM overlay dialoglarının (ana akış "+"-menüsü, ON SUCCESS/ON FAIL, şablon seçici, vb.)
     * ORTAK açılış noktası. ÖNEMLİ DÜZELTME: eskiden Theme_DeviceDefault_Dialog_Alert kullanıyordu
     * — bu, CİHAZIN SİSTEM temasına (kullanıcının telefonundaki açık/koyu mod) göre arka planı
     * DEĞİŞTİRİYORDU. Koyu sistem temasında, menülerdeki SABİT koyu renkli ikon/yazılar (örn.
     * item_icon_menu_row.xml'deki #212121) neredeyse siyah arka plan üzerinde GÖRÜNMEZ oluyordu —
     * "On Success" gibi ekranlarda "+" ile koşul eklenemez hâle geliyordu. Artık HER ZAMAN AÇIK
     * TEMA kullanıyoruz (Theme_DeviceDefault_Light_Dialog_Alert) — cihazın sistem temasından
     * BAĞIMSIZ, HER ZAMAN açık arka plan + koyu yazı garantisi.
     */
    private fun overlayDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)

    private fun AlertDialog.showOverlay() {
        window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        show()
    }

    // ==================== ALAN ÇİZME SİSTEMİ (gerçek overlay pencereleri) ====================

    private data class ExtraAction(
        val type: String, // "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT"
        var x: Int = 0, var y: Int = 0,
        var x2: Int = 0, var y2: Int = 0,
        var waitMs: Long = 500,
        var functionId: String? = null,
        var functionName: String = "",
        var repeat: Int = 1,
        var variableName: String = "",
        var variableDelta: Int = 1,
        var scriptId: String? = null,
        var scriptName: String = "",
        /** "PLAY_RECORD" için: RecordStorage'daki hangi kaydın oynatılacağı. */
        var recordId: String? = null,
        var recordName: String = "",
        var holdMs: Long = 50,
        var swipeHoldStartMs: Long = 0,
        var swipeHoldEndMs: Long = 0,
        var swipeDurationMs: Long = 300,
        var postDelayMs: Long = 0,
        /** "READ_TEXT" için: x,y,x2,y2 alanları BÖLGE (x,y,w,h) olarak kullanılır. */
        var readDefaultValue: Int = 0,
        var readWhitelist: String = "",
        var readBlacklist: String = ""
    )

    private inner class ActiveRegion(
        val id: String, val container: LinearLayout, val containerParams: WindowManager.LayoutParams,
        val label: TextView, val labelParams: WindowManager.LayoutParams,
        val frameContainer: android.widget.FrameLayout, val boxParams: android.widget.FrameLayout.LayoutParams,
        val handleParams: android.widget.FrameLayout.LayoutParams, val handleSizePx: Int
    ) {
        var existingRuleId: String? = null
        var name = ""
        var conditionKind = "COLOR"
        var conditionColor = Color.BLACK
        var conditionTemplatePath: String? = null
        var conditionText = ""
        var conditionTextCaseSensitive: Boolean = false
        var conditionTextWhitelist: String = ""
        var conditionTextBlacklist: String = ""
        // ---- Macrorify "Conditional" koşul tipleri (ekran taramasından bağımsız) ----
        /** conditionKind = "VARIABLE" için: karşılaştırılacak değişkenin adı. */
        var conditionVariableName: String = ""
        /** conditionKind = "VARIABLE" için operatör: ">=", "<=", "==", "!=", ">", "<" */
        var conditionVariableOp: String = ">="
        /** conditionKind = "VARIABLE" için karşılaştırılacak sabit sayı. */
        var conditionCompareValue: Int = 0
        /** conditionKind = "CUSTOM" için: true/false dönen JavaScript ifadesi. */
        var conditionCustomCode: String = ""
        /** Macrorify'daki "Multi Detection": bu koşula EK olarak eklenen başka koşullar (her biri kendi bölgesinde). */
        val extraConditions: MutableList<com.bigboss.app.storage.ConditionAlt> = mutableListOf()
        /** extraConditions doluysa, hepsi (ana koşulla birlikte) nasıl birleşsin: VE/VEYA/vb. */
        var conditionsLogic: String = "ONE_SUCCESS"
        var minScore = 90
        var actionType = "TAP"
        var tapAtMatchLocation = false
        /** Macrorify'daki "Click Multiple Matches": tapAtMatchLocation=true İKEN ek olarak bu da true ise TÜM eşleşmelere tıklanır. */
        var tapAllMatches = false
        var actionRepeatCount = 1
        var actionHoldMs: Long = 50
        var actionPostDelayMs: Long = 0
        var randomOffsetPx: Int = 0
        var randomChancePercent: Int = 100
        var swipeHoldStartMs: Long = 0
        var swipeHoldEndMs: Long = 0
        var actionHoldVarName: String? = null
        var actionPostDelayVarName: String? = null
        var swipeHoldStartVarName: String? = null
        var swipeHoldEndVarName: String? = null
        // Macrorify "her input alanında değişken" — yeni bağlanabilir alanlar:
        var actionRepeatVarName: String? = null
        var randomOffsetVarName: String? = null
        var swipeDurationVarName: String? = null
        var actionXVarName: String? = null
        var actionYVarName: String? = null
        var actionX2VarName: String? = null
        var actionY2VarName: String? = null
        /** Macrorify'daki "Swipe Path": Başlangıç/Bitiş dışındaki EK ara noktalar (x, y, o noktada bekleme). */
        val swipeExtraPoints: MutableList<com.bigboss.app.storage.SwipePointData> = mutableListOf()
        var actionX = 0; var actionY = 0
        var actionX2 = 0; var actionY2 = 0
        var callFunctionId: String? = null
        var callFunctionName = ""
        var callFunctionRepeat = 1
        val extraActions = mutableListOf<ExtraAction>()
        val onFailActions = mutableListOf<ExtraAction>()
        var cooldownMs: Long = 100
        var matchDelayMs: Long = 0
        /** 💡 Ampul: Wait Next/Delay bir değişkene bağlıysa sabit değer yerine onun güncel değeri kullanılır. */
        var cooldownVarName: String? = null
        var matchDelayVarName: String? = null
        var scanTimeoutMs: Long = 0
        var scanRateHz: Float = 0f
        /** 💡 Ampul ile bağlanabilir: Timeout/Scan rate bir değişkene bağlıysa sabit değer yerine onun güncel değeri kullanılır. */
        var scanTimeoutVarName: String? = null
        var scanRateVarName: String? = null
        var maxConsecutiveFailures: Int = 0
        var enabled: Boolean = true
        var negate = false
        var loopMode = "NONE" // NONE | ALWAYS | WHILE_SUCCESS | WHILE_FAIL — Macrorify'da varsayılan "None"
        var requireVariableName: String? = null
        var requireVariableOp: String = ">="
        var requireVariableValue: Int = 0
        var incrementVariableName: String? = null
        var incrementVariableDelta: Int = 1
        // ---- Macrorify "Region Scaling" (Basic → Region Scaling): Fixed / Dynamic / Sticky ----
        /** Bu alan HANGİ ekran çözünürlüğünde çizildi — addRegionWindow() otomatik doldurur, kaydederken RuleDefinition'a yazılır. */
        var baseScreenW: Int = 0
        var baseScreenH: Int = 0
        /** "FIXED" | "DYNAMIC" | "STICKY" */
        var regionScaleMode: String = "FIXED"
        var stickyLeft = false
        var stickyTop = false
        var stickyRight = false
        var stickyBottom = false
        // ---- Macrorify "Relative Coordinates" (Locatable Detection) — koşul (arama bölgesi) tarafı ----
        /** Doluysa, bu alanın arama bölgesi SABİT değil, bu ID'li kuralın SON bulunduğu konuma göre hesaplanır. */
        var relativeAnchorRuleId: String? = null
        var relativeAnchorRuleName: String = ""
        var relativeOffsetX: Int = 0
        var relativeOffsetY: Int = 0
        /** null ise alanın kendi genişlik/yüksekliği korunur, doluysa bölge bu boyuta yeniden boyutlandırılır. */
        var relativeResizeW: Int? = null
        var relativeResizeH: Int? = null
        // ---- Macrorify "Relative Coordinates" — aksiyon (dokunma noktası) tarafı ----
        var actionRelativeAnchorRuleId: String? = null
        var actionRelativeAnchorRuleName: String = ""
        var actionRelativeOffsetX: Int = 0
        var actionRelativeOffsetY: Int = 0
        /** GENEL sekmesindeki Find Region alanlarını, alan sürüklenince canlı güncellemek için — BİRDEN FAZLA dinleyici destekler. */
        val onRectChangedListeners: MutableList<() -> Unit> = mutableListOf()
        /** Bu alan bir Action Group'un İÇİNE mi kaydedilecek, yoksa Ana Akışa mı? */
        var saveScope: SaveScope = SaveScope.MainFlow
        /** Bu alan bir Action Group'un KAPI koşulunu mu ayarlıyor (true ise sadece koşul kaydedilir)? */
        var isGateForGroupId: String? = null
        /** Bu alan Kütüphaneye "Ekrandan Kırp" için mi kullanılıyor (true ise dokununca kural penceresi değil, kaydetme sorulur)? */
        var isLibraryCapture: Boolean = false
        /** isLibraryCapture=true iken: "LOCAL" ya da "GLOBAL" — Resources ekranının hangi sekmesinden başlatıldığı. */
        var libraryCaptureScope: String = "LOCAL"
        /**
         * KULLANICI İSTEĞİ: "renk için seçtiğim bir alan olmalı, o alandan pixel pixel renk
         * belirlemeliyim" — Renk seçimi artık EKRANIN HERHANGİ bir yerine kör dokunuş yerine,
         * ÖNCE bu ÇİZİLEBİLİR/boyutlandırılabilir alanla kabaca bir BÖLGE seçtiriyor, SONRA o
         * bölgenin merkezinden başlayarak büyüteç+piksel-adım editörünü açıyor.
         */
        var isColorPickRegion: Boolean = false
        /** KULLANICI İSTEĞİ: piksel-piksel ince ayar paneli — bu bölgeye bağlıysa `removeRegionWindow` bunu da temizler. */
        var nudgePanelView: View? = null
        var nudgePanelParams: WindowManager.LayoutParams? = null
        /**
         * KULLANICI RAPORU: "X ile Edit Mode'dan çıktım ama ekranda işaretçiler kalıcı kaldı" —
         * kök neden: bölgenin KENDİ aksiyon noktası (ACTION sekmesindeki TAP/SWIPE_START/END,
         * `armActionPoint` ile oluşturulan 👆/1/2 işaretçileri + swipe çerçevesi) HİÇBİR yerde
         * takip edilmiyordu, bu yüzden `shutdown()`/`removeRegionWindow` dahil HİÇBİR temizleme
         * fonksiyonu onları GÖREMİYORDU. Artık bu bölgeye bağlı TÜM aksiyon-noktası işaretçileri
         * burada tutuluyor — `removeRegionWindow` çağrıldığında (ki `shutdown()`/
         * `clearAllRegionWindows()` bunu HER bölge için çağırıyor) hepsi birlikte temizleniyor.
         */
        val actionPointMarkers: MutableList<View> = mutableListOf()
        var colorPickScope: String = "LOCAL"
        var colorPickExisting: LibraryItem? = null
        var colorPickOnSaved: (() -> Unit)? = null
        var isTextReadCapture: Boolean = false
        /** Macrorify Ana Akış "+" menüsündeki BAĞIMSIZ "Text Reader" — extraSteps listesine değil, DOĞRUDAN Ana Akış'a bir READ_TEXT kuralı ekler. */
        var isTopLevelTextRead: Boolean = false
        /** "Metni Değişkene Oku" hangi Başarılı/Bulunamazsa listesine ekleniyor. */
        var textReadTargetList: MutableList<ExtraAction>? = null
        /** "🔄 Değiştir" ile hangi Kütüphane öğesinin görselini AYNI dosya yoluna güncelleyeceğiz. */
        var isReplaceCaptureItem: LibraryItem? = null
        /** Bu alan bir "Multi Detection" EK koşulu olarak çiziliyorsa, hangi ana alana ait olduğu. */
        var isMultiDetectionExtraFor: ActiveRegion? = null
        /** Kaydedildikten SONRA çalıştırılacak ekstra işlem (örn. Başarılı/Bulunamazsa listesine "Fonksiyon Çağır" eklemek için). */
        var onSavedCallback: (() -> Unit)? = null
    }

    private sealed class SaveScope {
        object MainFlow : SaveScope()
        data class Group(val groupId: String) : SaveScope()
        data class Function(val functionId: String) : SaveScope()
    }

    private val activeRegions = mutableListOf<ActiveRegion>()
    private var regionCounter = 0

    private sealed class PendingPick {
        data class ColorPick(val region: Any) : PendingPick()
    }
    private var pendingPick: PendingPick? = null
    private var pendingExtraActionIndex = -1
    private var colorPickCatcher: View? = null

    private fun startAddRegion(scope: SaveScope = SaveScope.MainFlow) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.saveScope = scope
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    /**
     * Macrorify'daki "Conditional" (✛): ekranı taramayan, saf mantıksal bir koşul (Değişken/Custom)
     * ekler. Bir region kutusu oluşturur ama koşul tipi VARIABLE olduğu için o kutu ekranda GİZLENİR;
     * kullanıcı doğrudan ayar penceresinde koşulu (On True → Ne Yapılacak, On False → Bulunamazsa) kurar.
     */
    private fun startAddConditional(scope: SaveScope) {
        // Ekran görüntüsü olmasa bile Conditional kurulabilir (ekranı taramaz); yine de motor/servis
        // hazır değilse aksiyon noktası seçimi vb. çalışmayabilir, o yüzden yalnızca uyarı veriyoruz.
        val region = addRegionWindow()
        region.saveScope = scope
        region.conditionKind = "VARIABLE"
        region.name = "🔀 Koşul"
        // Kutuyu hemen gizle (bölgesiz koşul); ayar penceresi açıkken zaten görünmesine gerek yok.
        region.container.visibility = View.GONE
        region.label.visibility = View.GONE
        openRegionConfigDialog(region)
        Toast.makeText(this, "🔀 Koşul: bir değişkeni karşılaştır ya da custom kod yaz — doğruysa \"Ne Yapılacak\", yanlışsa \"Bulunamazsa\" çalışır", Toast.LENGTH_LONG).show()
    }

    private fun addRegionWindow(initX: Int? = null, initY: Int? = null, initW: Int? = null, initH: Int? = null): ActiveRegion {
        val id = "r${regionCounter++}"
        val density = resources.displayMetrics.density
        val defaultSize = (130 * density).toInt()
        val handleSize = (22 * density).toInt()
        val offset = (regionCounter % 6) * (24 * density).toInt()

        // Macrorify'daki gibi: sağ-alt köşede AYRI, kendi kare-şeklinde görünür alanı olan
        // rahatsız edici bir "tutamaç" YOK — kutunun kendisi, KENDİ sınırları İÇİNDE (taşmadan)
        // ince bir "kıvrık köşe" (dog-ear) ipucu çiziyor. Boyutlandırma için dokunma alanı hâlâ
        // var (handleView, aşağıda) ama TAMAMEN GÖRÜNMEZ — sadece parmağın "yakalayacağı" bir
        // bölge, gözle görülür hiçbir kare/şekil YOK.
        val box = object : View(this) {
            private val borderPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#2196F3"); style = android.graphics.Paint.Style.STROKE
                strokeWidth = 2.5f * density
            }
            private val foldFillPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#552196F3"); style = android.graphics.Paint.Style.FILL
            }
            private val foldEdgePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#2196F3"); style = android.graphics.Paint.Style.STROKE
                strokeWidth = 1.5f * density
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val w = width.toFloat(); val h = height.toFloat()
                val inset = borderPaint.strokeWidth / 2
                canvas.drawRect(inset, inset, w - inset, h - inset, borderPaint)
                // Köşe kıvrımı: kutunun KENDİ sınırları İÇİNDE, küçük ve sade (Macrorify'daki gibi).
                val fold = 12f * density
                if (w > fold * 2 && h > fold * 2) {
                    val path = android.graphics.Path().apply {
                        moveTo(w - inset, h - inset - fold)
                        lineTo(w - inset, h - inset)
                        lineTo(w - inset - fold, h - inset)
                        close()
                    }
                    canvas.drawPath(path, foldFillPaint)
                    canvas.drawLine(w - inset, h - inset - fold, w - inset - fold, h - inset, foldEdgePaint)
                }
            }
        }
        val handleView = View(this) // TAMAMEN görünmez — sadece boyutlandırma için dokunma hedefi

        val container = LinearLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        val boxParams = android.widget.FrameLayout.LayoutParams(defaultSize, defaultSize)
        val handleParams = android.widget.FrameLayout.LayoutParams(handleSize, handleSize).apply {
            leftMargin = defaultSize - handleSize / 2
            topMargin = defaultSize - handleSize / 2
        }
        val frameContainer = android.widget.FrameLayout(this)
        frameContainer.addView(box, boxParams)
        frameContainer.addView(handleView, handleParams)
        container.addView(frameContainer)
        container.clipChildren = false

        val containerParams = WindowManager.LayoutParams(
            defaultSize + handleSize, defaultSize + handleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // HATA DÜZELTMESİ (ekran görüntüsü yanlış alan alıyordu): FLAG_LAYOUT_IN_SCREEN +
            // FLAG_LAYOUT_NO_LIMITS eklendi. Bunlar OLMADAN overlay penceresinin (x,y) başlangıcı
            // DURUM ÇUBUĞUNUN ALTI oluyordu; oysa MediaProjection karesi TÜM fiziksel ekranı
            // (durum çubuğu DAHİL) yakalar → kırpma, kutunun GÖRÜNDÜĞÜ yerden durum-çubuğu
            // yüksekliği kadar YUKARIDAN alınıyordu. Bu bayraklarla overlay koordinatları artık
            // fiziksel ekranla (kare pikselleriyle) BİREBİR hizalı — kırpma da doğru yeri alır.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX ?: ((60 * density).toInt() + offset)
            y = initY ?: ((220 * density).toInt() + offset)
            width = (initW ?: defaultSize) + handleSize
            height = (initH ?: defaultSize) + handleSize
        }
        boxParams.width = initW ?: defaultSize
        boxParams.height = initH ?: defaultSize
        handleParams.leftMargin = (initW ?: defaultSize) - handleSize / 2
        handleParams.topMargin = (initH ?: defaultSize) - handleSize / 2

        // KULLANICI İSTEĞİ: "tarama alanının üzerinde yer alan isim yazısı kaldırılsın, isim
        // çerçevenin İÇİNDE küçük bir kısımda yazsın" — eskiden kutunun ÜSTÜNDE AYRI, büyükçe
        // bir etiket vardı; artık kutunun KENDİ sınırları İÇİNDE, sol-alt köşede küçük bir
        // etiket olarak duruyor (region.label hâlâ AYNI TextView nesnesi — mevcut TÜM
        // `region.label.text = ...` çağrıları HİÇBİR değişiklik gerekmeden çalışmaya devam eder,
        // sadece KONUMU/görünümü değişti).
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            textSize = 9f
            text = "?"
            setPadding(4, 1, 4, 1)
            maxWidth = (defaultSize * 0.9f).toInt()
            ellipsize = android.text.TextUtils.TruncateAt.END
            maxLines = 1
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Kutu penceresiyle AYNI koordinat başlangıcını (fiziksel ekran) kullansın diye aynı
            // yerleşim bayrakları — aksi halde etiket, kutuya göre durum-çubuğu kadar kayardı.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = containerParams.x + (2 * density).toInt()
            y = containerParams.y + boxParams.height - (16 * density).toInt()
        }

        windowManager?.addView(container, containerParams)
        windowManager?.addView(label, labelParams)

        val region = ActiveRegion(id, container, containerParams, label, labelParams, frameContainer, boxParams, handleParams, handleSize)
        // Region Scaling: bu alanın ÇİZİLDİĞİ ekran çözünürlüğünü kaydet — farklı bir cihazda
        // (ya da yeniden kurulumda farklı çözünürlükte) çalıştırıldığında RegionScaler bunu kullanır.
        ScreenCaptureService.latestFrame?.let { frame -> region.baseScreenW = frame.width; region.baseScreenH = frame.height }
        activeRegions.add(region)

        setupRegionTouch(region, frameContainer, box, boxParams, handleView, handleParams, containerParams, handleSize)
        return region
    }

    private fun borderDrawable(color: Int, strokeDp: Float = 2.5f): android.graphics.drawable.GradientDrawable {
        val density = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke((strokeDp * density).toInt(), color)
        }
    }

    private fun updateLabelPosition(region: ActiveRegion) {
        val density = resources.displayMetrics.density
        region.labelParams.x = region.containerParams.x + (2 * density).toInt()
        region.labelParams.y = region.containerParams.y + region.boxParams.height - (16 * density).toInt()
        try { windowManager?.updateViewLayout(region.label, region.labelParams) } catch (e: Exception) {}
        // KÖK NEDEN DÜZELTMESİ (kullanıcı raporu: "kırpmak istediğim alan ile kırptığım alan
        // uyuşmuyor" — Kütüphane "Ekrandan Kırp" akışı): kutuyu PARMAKLA sürükleyerek taşımak
        // (setupRegionTouch ACTION_MOVE) ya da tutamaçla (handleView) yeniden boyutlandırmak bu
        // fonksiyonu ÇAĞIRIYORDU ama piksel-adım panelini (nudgePanelParams) GÜNCELLEMİYORDU —
        // panel sadece kendi ok/+/- düğmelerine tıklanınca (repositionEverything) senkronize
        // oluyordu. Sonuç: kutu ekranda parmakla/tutamaçla taşınıp yeniden boyutlandırıldığında
        // GERÇEK kırpma kutusu (containerParams, regionRect() burayı okur) doğru yere gidiyordu
        // ama "Kırp" etiketi VE piksel-adım paneli ESKİ konumunda asılı kalıyordu — kullanıcı
        // kutunun asıl nerede olduğunu göremiyor, etiket+panelin durduğu (yanlış) yeri kutunun
        // konumu sanıp kafası karışıyordu. Artık BU fonksiyon (her iki sürükleme yolundan da
        // çağrılıyor) paneli de senkron tutuyor.
        region.nudgePanelParams?.let { p ->
            p.x = region.containerParams.x + region.containerParams.width + (6 * density).toInt()
            p.y = region.containerParams.y
            try { windowManager?.updateViewLayout(region.nudgePanelView, p) } catch (e: Exception) {}
        }
    }

    private fun setupRegionTouch(
        region: ActiveRegion, frameContainer: android.widget.FrameLayout, box: View, boxParams: android.widget.FrameLayout.LayoutParams,
        handleView: View, handleParams: android.widget.FrameLayout.LayoutParams, containerParams: WindowManager.LayoutParams, handleSize: Int
    ) {
        var downRawX = 0f; var downRawY = 0f; var downTime = 0L
        var startX = 0; var startY = 0
        var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { longPressFired = true; openHideDeleteMenu(region) }

        box.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; downTime = System.currentTimeMillis()
                    startX = containerParams.x; startY = containerParams.y
                    longPressFired = false
                    longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    // Android'in kendi sistem "dokunma toleransı" (touch slop) değeri: doğal parmak
                    // titremesini görmezden gelirken, GERÇEK bir sürükleme başlangıcını hemen fark eder.
                    // (Önceki sabit 24dp değeri, yavaş bir sürüklemenin 500ms içinde bu eşiği aşamayıp
                    // yanlışlıkla "basılı tutma" menüsünü açmasına sebep oluyordu.)
                    val cancelThreshold = android.view.ViewConfiguration.get(this@OverlayService).scaledTouchSlop
                    if (abs(dx) > cancelThreshold || abs(dy) > cancelThreshold) longPressHandler.removeCallbacks(longPressRunnable)
                    containerParams.x = startX + dx
                    containerParams.y = startY + dy
                    windowManager?.updateViewLayout(region.container, containerParams)
                    updateLabelPosition(region)
                    region.onRectChangedListeners.forEach { it() }
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!longPressFired) {
                        val dist = hypot((event.rawX - downRawX).toDouble(), (event.rawY - downRawY).toDouble())
                        val dt = System.currentTimeMillis() - downTime
                        if (dist < 18 && dt < 350) {
                            when {
                                region.isColorPickRegion -> openColorPickFromRegion(region)
                                region.isTextReadCapture -> openTextReadSaveDialog(region)
                                region.isTopLevelTextRead -> openTopLevelTextReadSaveDialog(region)
                                else -> openRegionConfigDialog(region)
                            }
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }

        handleView.setOnTouchListener { _, event ->
            if (pendingPick != null) return@setOnTouchListener false
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                // KULLANICI İSTEĞİ: "çok küçük pixelde resim çekebilmeliyiz" — eski 40dp minimum
                // ÇOK büyüktü (çoğu cihazda 80-100px demekti). Artık sadece 8dp — dokunarak KABA
                // boyutlandırma için yeterli, hassas küçültme YENİ piksel-adım paneliyle yapılıyor.
                val minSize = (8 * resources.displayMetrics.density).toInt()
                val localX = (event.rawX - containerParams.x).toInt().coerceAtLeast(minSize)
                val localY = (event.rawY - containerParams.y).toInt().coerceAtLeast(minSize)
                boxParams.width = localX
                boxParams.height = localY
                handleParams.leftMargin = localX - handleSize / 2
                handleParams.topMargin = localY - handleSize / 2
                frameContainer.requestLayout()
                containerParams.width = localX + handleSize
                containerParams.height = localY + handleSize
                windowManager?.updateViewLayout(region.container, containerParams)
                // KÖK NEDEN DÜZELTMESİ: tutamaçla (bu handler) boyutlandırırken etiket VE
                // piksel-adım paneli hiç senkronize EDİLMİYORDU (bkz. updateLabelPosition
                // yorumu) — artık burası da çağırıyor.
                updateLabelPosition(region)
                region.onRectChangedListeners.forEach { it() }
            }
            true
        }
    }

    private fun regionRect(region: ActiveRegion): IntArray {
        // Overlay pencere koordinatları GERÇEK ekran piksel koordinatlarıdır — MediaProjection
        // yakalaması da aynı çözünürlükte olduğu için doğrudan (ölçekleme gerekmeden) kullanılabilir.
        val p = region.containerParams
        val handleSize = (22 * resources.displayMetrics.density).toInt()
        return intArrayOf(p.x, p.y, (p.width - handleSize).coerceAtLeast(4), (p.height - handleSize).coerceAtLeast(4))
    }

    /** "Find Region" kutularına tam sayı yazınca, alanı EKRANDA da o konuma taşır/boyutlandırır. */
    private fun moveAndResizeRegion(region: ActiveRegion, x: Int, y: Int, w: Int, h: Int) {
        region.containerParams.x = x
        region.containerParams.y = y
        region.containerParams.width = w + region.handleSizePx
        region.containerParams.height = h + region.handleSizePx
        region.boxParams.width = w
        region.boxParams.height = h
        region.handleParams.leftMargin = w - region.handleSizePx / 2
        region.handleParams.topMargin = h - region.handleSizePx / 2
        try {
            region.frameContainer.requestLayout()
            windowManager?.updateViewLayout(region.container, region.containerParams)
        } catch (e: Exception) {}
        updateLabelPosition(region)
    }

    private fun openHideDeleteMenu(region: ActiveRegion) {
        overlayDialog()
            .setTitle("Bu alan")
            .setItems(arrayOf("🙈 Gizle (kaydı kalır, ekranda görünmez)", "🗑 Sil")) { _, index ->
                if (index == 0) {
                    region.container.visibility = View.GONE
                    region.label.visibility = View.GONE
                    Toast.makeText(this, "Gizlendi", Toast.LENGTH_SHORT).show()
                } else {
                    deleteRegionCompletely(region)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /** Bir alanı hem ekrandan hem (kaydedilmiş bir kuralsa) kayıtlı veriden tamamen siler. */
    private fun deleteRegionCompletely(region: ActiveRegion) {
        val gateGroupId = region.isGateForGroupId
        if (gateGroupId != null) {
            val group = ActionGroupStorage.load(this).find { it.id == gateGroupId }
            if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
        } else {
            region.existingRuleId?.let { id ->
                when (val scope = region.saveScope) {
                    is SaveScope.MainFlow -> { RuleStorage.deleteRule(this, id); RuleStorage.deleteRule(this, "$id-fail") }
                    is SaveScope.Group -> { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, id); ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail") }
                    is SaveScope.Function -> { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, id); FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail") }
                }
            }
        }
        removeRegionWindow(region)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
    }

    private fun removeRegionWindow(region: ActiveRegion, reRender: Boolean = true) {
        try { windowManager?.removeView(region.container) } catch (e: Exception) {}
        try { windowManager?.removeView(region.label) } catch (e: Exception) {}
        region.nudgePanelView?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        region.nudgePanelView = null; region.nudgePanelParams = null
        region.actionPointMarkers.forEach { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        region.actionPointMarkers.clear()
        activeRegions.remove(region)
        // Bir bölge editörü kapanınca (kaydet/iptal/sil) KALICI kapsamı yeniden çiz — böylece
        // düzenlemeden sonra ekran "boş" kalmaz, seçili çalışma-grubu geri gelir. Toplu temizlemede
        // (teardown) reRender=false ile atlanır.
        if (reRender) renderNow()
    }

    private fun clearAllRegionWindows() {
        activeRegions.toList().forEach { removeRegionWindow(it, reRender = false) }
    }

    // ==================== ÇALIŞMA ALANI (workspace) — Macrorify'daki "Draw selected/change working group" ====================

    private data class WorkspaceBox(val box: View, val label: TextView, val boxParams: WindowManager.LayoutParams, val labelParams: WindowManager.LayoutParams)
    private val workspaceBoxes = mutableListOf<WorkspaceBox>()
    /** `showWorkspaceFor`'un YENİ (sürüklenebilir daire + taşıma çerçevesi) işaretçileri — clearWorkspace()'te AYRICA temizlenir. */
    private val workspaceLiveMarkers = mutableListOf<View>()
    private var workspaceHidden = false

    /**
     * Macrorify Hide/Show: ekrandaki TÜM görünen öğeleri (click işaretçileri, swipe okları,
     * çalışma alanı kutuları, bölge pencereleri) tek seferde gizler/gösterir. Görünürlük
     * değişir ama öğeler kayıtlı kalır (silinmez). Panel göz ikonu bu durumu yansıtır.
     */
    private var allOverlaysHidden = false
    private fun toggleAllOverlays() {
        allOverlaysHidden = !allOverlaysHidden
        if (allOverlaysHidden) {
            // Gizle: tüm çizim view'larını kaldır + bölgeleri gizle (durum KALICI kalır).
            clearRenderViews()
            activeRegions.forEach { region ->
                region.container.visibility = View.GONE
                region.label.visibility = View.GONE
            }
        } else {
            // Göster: TEK motor KALICI kapsamı yeniden çizer (bölge görünürlüğü kapsama göre ayarlanır).
            renderNow()
        }
        workspaceHidden = allOverlaysHidden
        rebuildPanel() // göz ikonu durumunu güncelle
        Toast.makeText(this, if (allOverlaysHidden) "🙈 Tüm öğeler gizlendi" else "👁️ Tüm öğeler gösteriliyor", Toast.LENGTH_SHORT).show()
    }

    // ============================================================
    // TEK ÇİZİM MOTORU (unified render engine)
    // ------------------------------------------------------------
    // KALICI çalışma-kapsamı: en son "draw select" edilen kapsam ekranda kalır (panel
    // kapansa da), kullanıcı başka bir kapsam seçene kadar. Varsayılan = Ana Akış.
    // TÜM çizim (Ana Akış / Grup / Fonksiyon / seçili kurallar / On Success-Fail) TEK
    // `renderNow()` yolundan, TEK view listesi ve TEK temizleme ile geçer. Eskiden
    // birbirini tanımayan clickMarkers + workspaceBoxes + showExtraListOnScreen çakışması
    // (asılı kalan/çift/yanlış kapsam/kapatınca dönmeme) artık YOK.
    private var renderScopeSel: SaveScope = SaveScope.MainFlow
    private var renderRuleIds: List<String>? = null   // null = kapsamın TÜMÜ (canlı); non-null = sanal seçim (sadece bu id'ler)
    private var renderExtra: Triple<ActiveRegion, Boolean, List<ExtraAction>>? = null // set ise On Success/Fail modu; normal kapsam yok sayılır
    private var renderLabel: String = "🏠 Ana Akış"

    private fun rulesForScope(scope: SaveScope): List<RuleDefinition> = when (scope) {
        is SaveScope.MainFlow -> RuleStorage.load(this)
        is SaveScope.Group -> ActionGroupStorage.load(this).find { it.id == scope.groupId }?.rules ?: emptyList()
        is SaveScope.Function -> FunctionStorage.load(this).find { it.id == scope.functionId }?.rules ?: emptyList()
    }

    /** Ekrandaki TÜM çizim view'larını kaldırır (kapsam/görünürlük durumuna DOKUNMAZ). Tek merkezi temizleme. */
    private fun clearRenderViews() {
        clickMarkers.forEach { try { windowManager?.removeView(it.view) } catch (e: Exception) {} }
        clickMarkers.clear()
        workspaceBoxes.forEach {
            try { windowManager?.removeView(it.box) } catch (e: Exception) {}
            try { windowManager?.removeView(it.label) } catch (e: Exception) {}
        }
        workspaceBoxes.clear()
        workspaceLiveMarkers.forEach { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        workspaceLiveMarkers.clear()
        swipeFrameViews.forEach { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        swipeFrameViews.clear()
        swipeArrowLayer?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        swipeArrowLayer = null; swipeArrowParams = null
        clickMarkersVisible = false
    }

    /** KALICI kapsamı ekrana çizer — TEK giriş noktası. clear → (gizli değilse) bölge görünürlüğü + kural çizimi. */
    private fun renderNow() {
        clearRenderViews()
        if (allOverlaysHidden) return
        val ex = renderExtra
        if (ex != null) { drawExtraListNow(ex.first, ex.second, ex.third); return }
        // Bölge görünürlüğü: SADECE aktif kapsama ait, henüz-kaydedilmemiş bölgeler görünür kalır.
        activeRegions.forEach { r ->
            val vis = if (r.saveScope == renderScopeSel) View.VISIBLE else View.GONE
            r.container.visibility = vis; r.label.visibility = vis
        }
        val all = rulesForScope(renderScopeSel)
        val rules = renderRuleIds?.let { ids -> all.filter { it.id in ids } } ?: all
        drawRulesNow(renderScopeSel, rules)
    }

    /** Bir kural listesini TEK, tutarlı görsel dille çizer: tespit→mavi kutu, TAP/SWIPE→numaralı sürüklenebilir işaretçi. */
    private fun drawRulesNow(scope: SaveScope, rules: List<RuleDefinition>) {
        // KULLANICI RAPORU (ekran görüntüsüyle doğrulandı): "2 tane alan oluşuyor" — kök neden,
        // bölgeler artık HER ZAMAN kaydedildiği için (bkz. buildConditionAltFromRegion) bir kural
        // HEM ekranda hâlâ AKTİF/AÇIK bir ActiveRegion olarak (kullanıcı henüz düzenliyor) HEM DE
        // burada `RuleStorage`'dan okunup TEKRAR bir workspace kutusu olarak çiziliyordu — AYNI
        // kural için İKİ AYRI kutu. Artık zaten AKTİF bir bölgesi olan kurallar burada
        // ATLANIYOR — o kuralın TEK görseli, kendi ActiveRegion'ı (yukarıdaki activeRegions
        // döngüsü) üzerinden gösteriliyor.
        //
        // KULLANICI İSTEĞİ: Ana Akış'taki "seç/çiz" mantığı DİĞER şemalarda (Fonksiyonlar, Grup)
        // da AYNI şekilde çalışmalı, SADECE o ağacın alan/komutlarını göstermeli. Bu hariç tutma
        // artık AYNI ZAMANDA kapsama (`saveScope == scope`) göre de filtreleniyor — bir başka
        // ağaçta (örn. Ana Akış'ta) hâlâ açık bir bölge, YANLIŞLIKLA bu ağacın (örn. bir
        // Fonksiyon'un) aynı ID'li bir kuralını gizlemesin (id'ler zaten global-benzersiz UUID
        // olduğu için pratikte çakışmaz, ama bu ekstra netlik/doğruluk için önemli).
        val activeRegionRuleIds = activeRegions.filter { it.saveScope == scope }.mapNotNull { it.existingRuleId }.toSet()
        val visible = rules.filter { !it.id.endsWith("-fail") && it.id !in activeRegionRuleIds }
        visible.forEachIndexed { idx, rule ->
            val order = idx + 1
            val firstKind = rule.alternatives.firstOrNull()?.conditionKind
            val isScreenless = firstKind == "VARIABLE" || firstKind == "CUSTOM"
            when {
                rule.alternatives.isNotEmpty() && !isScreenless -> addWorkspaceBox(rule, scope)
                rule.actionType == "TAP" -> drawTapMarkerU(rule, scope, order)
                rule.actionType == "SWIPE" -> drawSwipeMarkersU(rule, scope, order)
                else -> { /* ekranda konumu olmayan (screenless) adım — çizilmez */ }
            }
        }
    }

    /** TEK tutarlı TAP işaretçisi: numaralı, sürükle=taşı(kapsama kaydet), dokun=düzenle, basılı-tut=menü. */
    private fun drawTapMarkerU(rule: RuleDefinition, scope: SaveScope, order: Int) {
        val m = placeLiveMarker("$order", rule.actionX, rule.actionY,
            onMove = { x, y -> rule.actionX = x; rule.actionY = y; saveRuleToScope(scope, rule) },
            onTap = { showTapPointEditor(rule) },
            onLongPress = { showTapContextMenu(rule) }
        )
        workspaceLiveMarkers.add(m.view)
    }

    /** TEK tutarlı SWIPE gösterimi: iki numaralı işaretçi + ortak taşıma çerçevesi. */
    private fun drawSwipeMarkersU(rule: RuleDefinition, scope: SaveScope, order: Int) {
        val markerSize = (34 * resources.displayMetrics.density).toInt()
        var m1: LiveMarkerHandle? = null
        var m2: LiveMarkerHandle? = null
        val frameView = addSwipeFrame(listOf(rule.actionX to rule.actionY, rule.actionX2 to rule.actionY2), markerSize) { dx, dy ->
            m1?.let { shiftLiveMarker(it, dx, dy); rule.actionX = it.params.x + it.size / 2; rule.actionY = it.params.y + it.size / 2 }
            m2?.let { shiftLiveMarker(it, dx, dy); rule.actionX2 = it.params.x + it.size / 2; rule.actionY2 = it.params.y + it.size / 2 }
            saveRuleToScope(scope, rule)
        }
        frameView?.let { workspaceLiveMarkers.add(it) }
        val newM1 = placeLiveMarker("$order.1", rule.actionX, rule.actionY,
            onMove = { x, y -> rule.actionX = x; rule.actionY = y; saveRuleToScope(scope, rule) },
            onTap = { showSwipePointEditor(rule, 0) },
            onLongPress = { showSwipeContextMenu(rule) }
        )
        val newM2 = placeLiveMarker("$order.2", rule.actionX2, rule.actionY2,
            onMove = { x, y -> rule.actionX2 = x; rule.actionY2 = y; saveRuleToScope(scope, rule) },
            onTap = { showSwipePointEditor(rule, 1) },
            onLongPress = { showSwipeContextMenu(rule) }
        )
        m1 = newM1; m2 = newM2
        workspaceLiveMarkers.add(newM1.view); workspaceLiveMarkers.add(newM2.view)
    }

    /** Seçilen kapsamı KALICI olarak çizer (panel kapansa da kalır). "draw select" ana giriş noktası. */
    private fun showWorkspaceFor(scope: SaveScope, rules: List<RuleDefinition>, label: String) {
        showWorkspaceForSilent(scope, rules, label)
        val ids = renderRuleIds ?: emptyList()
        val shown = rulesForScope(scope).count { it.id in ids && !it.id.endsWith("-fail") }
        if (shown == 0) Toast.makeText(this, "$label içinde çizilecek öğe yok", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "$label — $shown öğe gösteriliyor (dokun=düzenle, sürükle=taşı; kapatmak için 🗺️)", Toast.LENGTH_LONG).show()
    }

    /**
     * Macrorify dokümanındaki "By default everything in this Group is rendered to the screen"
     * davranışı: bir grup/fonksiyon/Ana Akış ekranı AÇILDIĞINDA içeriği otomatik (sessizce, Toast'suz)
     * çizilir — "Seç/Çiz" ikonu bunu sadece DARALTIR (seçili öğeler) veya BAŞKA bir gruba geçirir.
     * Panel (%94x%82) ekranı tam kaplamadığı için kenarlarda görünür; ikonla paneli kapatıp
     * TAM görmek zaten mevcut akış. Toast YOK — her ekran açılışında/yenilenişinde spam olmasın.
     */
    private fun showWorkspaceForSilent(scope: SaveScope, rules: List<RuleDefinition>, label: String) {
        renderScopeSel = scope
        renderRuleIds = rules.map { it.id }
        renderExtra = null
        renderLabel = label
        renderNow()
    }

    /**
     * DÜZELTME (kullanıcı isteği): eskiden turuncu (#FFA500), AYRI bir görsel dil kullanıyordu
     * (kutu + üstünde geniş turuncu etiket çubuğu) — bu, TAP/SWIPE'ın kullandığı mavi, sade
     * numaralı-daire stiliyle TUTARSIZDI. Artık `addRegionWindow`'daki İLE AYNI mavi (#2196F3)
     * + köşe-kıvrımlı (dog-ear) stil kullanıyor — TEK, tutarlı görsel dil, HER YERDE.
     */
    private fun addWorkspaceBox(rule: RuleDefinition, scope: SaveScope) {
        val alt = rule.alternatives.first()
        val density = resources.displayMetrics.density
        val accentBlue = Color.parseColor("#2196F3")
        val box = object : View(this) {
            private val borderPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = accentBlue; style = android.graphics.Paint.Style.STROKE; strokeWidth = 2.5f * density
            }
            private val foldFillPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#552196F3"); style = android.graphics.Paint.Style.FILL
            }
            private val foldEdgePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = accentBlue; style = android.graphics.Paint.Style.STROKE; strokeWidth = 1.5f * density
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val w = width.toFloat(); val h = height.toFloat()
                val inset = borderPaint.strokeWidth / 2
                canvas.drawRect(inset, inset, w - inset, h - inset, borderPaint)
                val fold = 12f * density
                if (w > fold * 2 && h > fold * 2) {
                    val path = android.graphics.Path().apply {
                        moveTo(w - inset, h - inset - fold); lineTo(w - inset, h - inset); lineTo(w - inset - fold, h - inset); close()
                    }
                    canvas.drawPath(path, foldFillPaint)
                    canvas.drawLine(w - inset, h - inset - fold, w - inset - fold, h - inset, foldEdgePaint)
                }
            }
        }
        val boxParams = WindowManager.LayoutParams(
            alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }

        // Küçük, sade etiket — TAP/SWIPE dairelerindeki İLE AYNI ölçekte, artık geniş bir çubuk değil.
        val label = TextView(this).apply {
            text = rule.name
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#CC2196F3"))
            textSize = 10f
            setPadding(6, 2, 6, 2)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = alt.x
            y = (alt.y - 24 * density).toInt().coerceAtLeast(0)
        }

        box.setOnClickListener { /* no-op, dokunuşu ACTION_DOWN'da yakalıyoruz */ }
        box.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Sadece çizim view'larını kaldır (kapsam KALICI kalır); düzenleme bölgesi
                // temiz bir zeminde açılır. Bölge kapanınca removeRegionWindow → renderNow
                // KALICI kapsamı yeniden çizer.
                clearRenderViews()
                editExistingRule(rule, scope)
            }
            true
        }

        try {
            windowManager?.addView(box, boxParams)
            windowManager?.addView(label, labelParams)
            workspaceBoxes.add(WorkspaceBox(box, label, boxParams, labelParams))
        } catch (e: Exception) {
            android.util.Log.e("BigBossWorkspace", "Kutu eklenemedi: ${rule.name}", e)
            Toast.makeText(this, "⚠️ '${rule.name}' gösterilemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Sadece EKRANDAKİ workspace view'larını kaldırır — clearWorkspace()'in "durum sıfırlamayan" hafif versiyonu (showClickMarkers()'ın sayfalamayı bozmadan diğer sistemi temizlemesi için). */
    private fun clearWorkspaceViewsOnly() { clearRenderViews() }

    /**
     * DÜZELTME (kullanıcı raporu: "draw select yapınca sadece o alanın komutları gözükmeli").
     * Kök neden: `clickMarkers` (Ana Akış'ın ESKİ numaralı-daire sistemi — bir Click/Swipe
     * oluşturunca OTOMATİK gösterilir) ve `workspaceBoxes`/`workspaceLiveMarkers` ("draw select"
     * ile gösterilen YENİ sistem) birbirinden TAMAMEN BAĞIMSIZDI — biri diğerini TEMİZLEMİYORDU.
     * Yani ÖNCE bir yerde Click oluşturup (eski sistem gösterildi), SONRA başka bir kapsamda
     * "draw select" yapınca (yeni sistem), ESKİ işaretçiler ekranda ASILI KALIYORDU. Artık
     * `clearWorkspace()` HER İKİ sistemi de temizliyor — hangi "draw select" çağrılırsa çağrılsın
     * ekranda SADECE o an istenen kapsamın öğeleri kalıyor.
     */
    private fun clearWorkspace() {
        // TEK temizleme: tüm çizim view'larını kaldır (clickMarkers/kutular/işaretçiler/çerçeveler).
        clearRenderViews()
        workspaceHidden = false
        // Kapsam-filtrelemesi bazı activeRegions'ı GİZLEMİŞ olabilir — hepsini tekrar görünür yap.
        activeRegions.forEach { region ->
            region.container.visibility = View.VISIBLE
            region.label.visibility = View.VISIBLE
        }
    }

    // ==================== 👆 Dokunma/Kaydırma Noktası İşaretçisi (Macrorify'daki gibi sürüklenebilir parmak simgesi) ====================

    /** Şu an ekranda duran (henüz onaylanmamış) nokta işaretçisi ve onay butonu. */
    private var pointMarkerContainer: View? = null
    private var pointMarkerParams: WindowManager.LayoutParams? = null
    private var pointMarkerConfirmBtn: View? = null
    private var pointMarkerConfirmParams: WindowManager.LayoutParams? = null

    /**
     * Ekranda sürüklenebilir bir 👆 işaretçi gösterir (isteğe bağlı "1"/"2" etiketiyle).
     * Kullanıcı işaretçiyi istediği yere sürükler, ayrı duran "✓ Onayla" butonuna basınca
     * o anki TAM konum (markerSize/2 merkez alınarak) geri döner.
     *
     * `addClickMarker`'daki İLE BİREBİR AYNI görsel VE etkileşim (sürükle=canlı taşı,
     * kısa dokun=hızlı düzenle, basılı tut=bağlam menüsü) — ama RuleStorage'a değil, verilen
     * `onMove`/`onTap`/`onLongPress` callback'lerine bağlı, bu yüzden HEM Ana Akış/Fonksiyon
     * kurallarında HEM On Success/On Fail (ExtraAction) HEM bölge editörünün Action noktalarında
     * KULLANILABİLİR — "Onayla" YOK, işaretçi HER ZAMAN canlı.
     */
    private data class LiveMarkerHandle(val view: View, val params: WindowManager.LayoutParams, val size: Int)

    private fun placeLiveMarker(
        label: String, initialX: Int?, initialY: Int?,
        onTap: (() -> Unit)? = null,
        onLongPress: (() -> Unit)? = null,
        onMove: (Int, Int) -> Unit
    ): LiveMarkerHandle {
        val density = resources.displayMetrics.density
        val frame = ScreenCaptureService.latestFrame
        val size = (34 * density).toInt()
        val accentBlue = Color.parseColor("#3B9EE8")
        val startX = (initialX ?: ((frame?.width ?: 1080) / 2)) - size / 2
        val startY = (initialY ?: ((frame?.height ?: 1920) / 2)) - size / 2

        val circle = TextView(this).apply {
            text = label
            setTextColor(accentBlue)
            textSize = if (label.length > 2) 10f else 13f
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F0FFFFFF"))
                setStroke((2.5f * density).toInt(), accentBlue)
                cornerRadius = size / 2f
            }
        }
        val params = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = startX; y = startY }

        windowManager?.addView(circle, params)
        onMove(startX + size / 2, startY + size / 2) // başlangıç konumu HEMEN bildirilir — kaydetmek için "Onayla"ya gerek yok

        var downRawX = 0f; var downRawY = 0f; var startPX = 0; var startPY = 0; var moved = false; var longPressFired = false
        val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val longPressRunnable = Runnable { if (!moved) { longPressFired = true; onLongPress?.invoke() } }
        circle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; startPX = params.x; startPY = params.y
                    moved = false; longPressFired = false
                    if (onLongPress != null) longPressHandler.postDelayed(longPressRunnable, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
                    if (abs(dx) > slop || abs(dy) > slop) { moved = true; longPressHandler.removeCallbacks(longPressRunnable) }
                    params.x = startPX + dx
                    params.y = startPY + dy
                    try { windowManager?.updateViewLayout(circle, params) } catch (e: Exception) {}
                    onMove(params.x + size / 2, params.y + size / 2)
                }
                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressFired) onTap?.invoke()
                }
                MotionEvent.ACTION_CANCEL -> longPressHandler.removeCallbacks(longPressRunnable)
            }
            true
        }
        return LiveMarkerHandle(circle, params, size)
    }

    private fun removeLiveMarker(marker: View?) {
        marker?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
    }
    private fun removeLiveMarker(marker: LiveMarkerHandle?) = removeLiveMarker(marker?.view)

    /**
     * MACROrify'daki gibi: bir Swipe'ın (2+ nokta) TÜM daire işaretçilerini çevreleyen ince,
     * yarı-saydam bir TAŞIMA ÇERÇEVESİ. Dairelerin KAPLAMADIĞI (BOŞ) kısmına dokunup sürüklemek
     * TÜM noktaları AYNI ANDA (göreli konumlarını koruyarak) taşır. Daireler KENDİ üzerlerinde
     * HER ZAMAN önceliklidir — bunun için ÇERÇEVE, DAİRELERDEN ÖNCE (bu fonksiyon ÇAĞRILDIKTAN
     * SONRA `placeLiveMarker` ile) eklenmeli (Android'de SONRA eklenen pencere touch önceliğini
     * alır). Bu yüzden bu fonksiyon `LiveMarkerHandle` DEĞİL, HAM koordinat listesi alır — henüz
     * daireler YOKKEN çerçeveyi kurup, sürüklendiğinde SADECE bir (dx,dy) DELTASI bildirir;
     * çağıran taraf kendi (SONRADAN oluşturduğu) dairelerini bu deltayla kendisi taşır.
     *
     * TEK MERKEZİ FONKSİYON — Ana Akış (`showClickMarkers`), On Success/On Fail
     * (`armActionPoint`'in EXTRA_SWIPE_* dalları) ve Bölge Editörü'nün Action sekmesi
     * (SWIPE_START/SWIPE_END) HEPSİ bunu çağırır; swipe'ın taşıma çerçevesiyle ilgili GELECEKTE
     * yapılacak TEK bir değişiklik otomatik olarak HER YERE yayılır.
     */
    private fun addSwipeFrame(initialPoints: List<Pair<Int, Int>>, markerSize: Int, onMovedAll: (dx: Int, dy: Int) -> Unit): View? {
        if (initialPoints.size < 2) return null
        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()
        val minX = initialPoints.minOf { it.first } - pad
        val maxX = initialPoints.maxOf { it.first } + pad
        val minY = initialPoints.minOf { it.second } - pad
        val maxY = initialPoints.maxOf { it.second } + pad
        val w = (maxX - minX).coerceAtLeast(markerSize + pad * 2)
        val h = (maxY - minY).coerceAtLeast(markerSize + pad * 2)

        val frameView = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#113B9EE8"))
                setStroke((2.5f * density).toInt().coerceAtLeast(2), Color.parseColor("#3B9EE8"))
                cornerRadius = 12f * density
            }
        }
        val frameParams = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = minX; y = minY }

        try { windowManager?.addView(frameView, frameParams) } catch (e: Exception) { return null }

        var downRawX = 0f; var downRawY = 0f; var startFX = 0; var startFY = 0
        frameView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downRawX = event.rawX; downRawY = event.rawY; startFX = frameParams.x; startFY = frameParams.y }
                MotionEvent.ACTION_MOVE -> {
                    val newFX = startFX + (event.rawX - downRawX).toInt()
                    val newFY = startFY + (event.rawY - downRawY).toInt()
                    val dx = newFX - frameParams.x; val dy = newFY - frameParams.y
                    if (dx != 0 || dy != 0) {
                        frameParams.x = newFX; frameParams.y = newFY
                        try { windowManager?.updateViewLayout(frameView, frameParams) } catch (e: Exception) {}
                        onMovedAll(dx, dy)
                    }
                }
            }
            true
        }
        return frameView
    }

    /** `addSwipeFrame`'in delta callback'i içinde tek bir daireyi (dx,dy) kadar taşımak için ortak yardımcı. */
    private fun shiftLiveMarker(m: LiveMarkerHandle, dx: Int, dy: Int) {
        m.params.x += dx; m.params.y += dy
        try { windowManager?.updateViewLayout(m.view, m.params) } catch (e: Exception) {}
    }

    private fun removePointMarker() {
        pointMarkerContainer?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerConfirmBtn?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        pointMarkerContainer = null; pointMarkerParams = null
        pointMarkerConfirmBtn = null; pointMarkerConfirmParams = null
    }

    // ==================== Ekrana dokunarak nokta/renk seçme (tam ekran yakalayıcı — sadece renk örneklemede kullanılıyor) ====================

    private fun armColorPick(region: ActiveRegion) {
        pendingPick = PendingPick.ColorPick(region)
        showTouchCatcher { bx, by -> handlePointCaught(bx, by) }
        Toast.makeText(this, "Renk almak istediğin NOKTAYA dokun", Toast.LENGTH_LONG).show()
    }

    /**
     * YENİDEN YAZILDI (kullanıcı isteği): "1. Noktayı Onayla / 2. Noktayı Onayla" YOK artık.
     * TAP için TEK, SWIPE için İKİ işaretçi AYNI ANDA belirir (sırayla değil) — ikisi de
     * BAĞIMSIZ sürüklenebilir, her hareket region.actionX/Y (ve SWIPE için actionX2/Y2)
     * alanlarına CANLI yazılır. Region editörü zaten "Otomatik kaydediliyor" olduğu için bu
     * konumlar otomatik kalıcı hale gelir.
     */
    /**
     * On Success/On Fail'deki bir TAP tipi ExtraAction için hızlı ayar dialogu —
     * `showTapPointEditor`'ın (Ana Akış kuralları için) ExtraAction karşılığı. AYNI alanlar:
     * Koordinat/Hold/Repeat/Delay.
     */
    private fun showExtraTapEditor(extra: ExtraAction) {
        val ctx = this
        val density = resources.displayMetrics.density
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun label(t: String) = TextView(ctx).apply { text = t; setTextColor(TEXT_SECONDARY); textSize = 12f; setPadding(0, (10 * density).toInt(), 0, 2) }

        root.addView(TextView(ctx).apply { text = "👆 On Success/On Fail — Dokunma"; setTextColor(TEXT_PRIMARY); textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(label("Koordinat (x, y)"))
        val coordInput = EditText(ctx).apply { setText("${extra.x}, ${extra.y}") }
        root.addView(coordInput)
        root.addView(label("Hold (ms)"))
        val holdInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.holdMs.toString()) }
        root.addView(holdInput)
        root.addView(label("Repeat"))
        val repeatInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.repeat.toString()) }
        root.addView(repeatInput)
        root.addView(label("Delay — bittikten sonra ek bekleme (ms)"))
        val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
        root.addView(delayInput)

        overlayDialog().setTitle("Dokunma Noktası").setView(android.widget.ScrollView(ctx).apply { addView(root) })
            .setPositiveButton("Kaydet") { _, _ ->
                val parts = coordInput.text.toString().split(",").map { it.trim() }
                if (parts.size == 2) { parts[0].toIntOrNull()?.let { extra.x = it }; parts[1].toIntOrNull()?.let { extra.y = it } }
                extra.holdMs = holdInput.text.toString().toLongOrNull() ?: extra.holdMs
                extra.repeat = repeatInput.text.toString().toIntOrNull() ?: extra.repeat
                extra.postDelayMs = delayInput.text.toString().toLongOrNull() ?: extra.postDelayMs
            }
            .setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** SWIPE tipi ExtraAction için hızlı ayar — `showSwipePointEditor`'ın ExtraAction karşılığı. */
    private fun showExtraSwipeEditor(extra: ExtraAction) {
        val ctx = this
        val density = resources.displayMetrics.density
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun label(t: String) = TextView(ctx).apply { text = t; setTextColor(TEXT_SECONDARY); textSize = 12f; setPadding(0, (10 * density).toInt(), 0, 2) }

        root.addView(TextView(ctx).apply { text = "👉 On Success/On Fail — Kaydırma"; setTextColor(TEXT_PRIMARY); textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(label("1. Nokta (x, y)"))
        val coord1Input = EditText(ctx).apply { setText("${extra.x}, ${extra.y}") }
        root.addView(coord1Input)
        root.addView(label("2. Nokta (x, y)"))
        val coord2Input = EditText(ctx).apply { setText("${extra.x2}, ${extra.y2}") }
        root.addView(coord2Input)
        root.addView(label("Hold (başlangıç, ms)"))
        val holdStartInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldStartMs.toString()) }
        root.addView(holdStartInput)
        root.addView(label("Hold (bitiş, ms)"))
        val holdEndInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldEndMs.toString()) }
        root.addView(holdEndInput)
        root.addView(label("Delay — bittikten sonra ek bekleme (ms)"))
        val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
        root.addView(delayInput)
        // Hız preseti: seçilirse KAYDET sırasında iki nokta arası mesafeye göre süre (durationMs) hesaplanır.
        var selectedSpeed = 0
        root.addView(label("Hız preseti (mesafeye göre süreyi ayarlar; dokunma = mevcut süreyi koru):"))
        val extraSpeedRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        swipeSpeedPresets.forEach { (nm, v) ->
            extraSpeedRow.addView(Button(ctx).apply { text = nm; textSize = 9f; setOnClickListener { selectedSpeed = v; Toast.makeText(ctx, "Hız: $nm", Toast.LENGTH_SHORT).show() } })
        }
        root.addView(android.widget.HorizontalScrollView(ctx).apply { addView(extraSpeedRow) })

        overlayDialog().setTitle("Kaydırma Noktaları").setView(android.widget.ScrollView(ctx).apply { addView(root) })
            .setPositiveButton("Kaydet") { _, _ ->
                coord1Input.text.toString().split(",").map { it.trim() }.let { p -> if (p.size == 2) { p[0].toIntOrNull()?.let { extra.x = it }; p[1].toIntOrNull()?.let { extra.y = it } } }
                coord2Input.text.toString().split(",").map { it.trim() }.let { p -> if (p.size == 2) { p[0].toIntOrNull()?.let { extra.x2 = it }; p[1].toIntOrNull()?.let { extra.y2 = it } } }
                extra.swipeHoldStartMs = holdStartInput.text.toString().toLongOrNull() ?: extra.swipeHoldStartMs
                extra.swipeHoldEndMs = holdEndInput.text.toString().toLongOrNull() ?: extra.swipeHoldEndMs
                extra.postDelayMs = delayInput.text.toString().toLongOrNull() ?: extra.postDelayMs
                if (selectedSpeed > 0) {
                    val dist = Math.hypot((extra.x2 - extra.x).toDouble(), (extra.y2 - extra.y).toDouble())
                    extra.swipeDurationMs = ((dist / selectedSpeed) * 12.0).toLong().coerceIn(1L, 8000L)
                }
            }
            .setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * On Success/On Fail'deki bir TAP/SWIPE ExtraAction için basılı-tut bağlam menüsü —
     * `showTapContextMenu`/`showSwipeContextMenu`'nün ExtraAction karşılığı. Silme, listeden
     * VE ekrandaki işaretçi(ler)den kaldırır.
     */
    private fun showExtraActionContextMenu(region: ActiveRegion, isFail: Boolean, extra: ExtraAction, markers: List<LiveMarkerHandle>, frameView: View? = null) {
        val list = if (isFail) region.onFailActions else region.extraActions
        overlayDialog().setTitle(if (extra.type == "SWIPE") "Kaydırma İşlemleri" else "Dokunma İşlemleri")
            .setItems(arrayOf("✏️ Hızlı Düzenle", "🗑 Sil")) { _, which ->
                when (which) {
                    0 -> if (extra.type == "SWIPE") showExtraSwipeEditor(extra) else showExtraTapEditor(extra)
                    1 -> {
                        list.remove(extra)
                        markers.forEach { removeLiveMarker(it) }
                        removeLiveMarker(frameView)
                        region.onRectChangedListeners.forEach { it() }
                        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun armActionPoint(region: ActiveRegion, target: String) {
        // Sürüklemenin HER ANINDA canlı kaydetmeyi tetikler (region.onRectChangedListeners zaten
        // openRegionConfigDialog'un autoSave()'ini bu listeye eklemişti — burada AYNI mekanizmayı
        // ExtraAction (On Success/On Fail) noktaları için de kullanıyoruz).
        fun liveSave() { region.onRectChangedListeners.forEach { it() } }

        when (target) {
            "TAP" -> {
                // Önce OLASI eski aksiyon-noktası işaretçilerini temizle (yeniden "arm" edilirse
                // BİRİKMESİN — aynı "S1/👆1 çifti" hatasının bu bölgenin KENDİ noktası için de
                // yaşanmaması için).
                region.actionPointMarkers.forEach { try { windowManager?.removeView(it) } catch (e: Exception) {} }
                region.actionPointMarkers.clear()
                val initial = if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else null
                val m = placeLiveMarker("👆", initial?.first, initial?.second) { bx, by -> applyActionPoint(region, "TAP", bx, by) }
                region.actionPointMarkers.add(m.view)
            }
            "SWIPE_START", "SWIPE_END" -> {
                region.actionPointMarkers.forEach { try { windowManager?.removeView(it) } catch (e: Exception) {} }
                region.actionPointMarkers.clear()
                // Çerçeve ÖNCE (dairelerin ALTINDA kalsın diye), daireler SONRA — Android'de SONRA
                // eklenen pencere touch önceliğini alır, bu yüzden daireler HER ZAMAN tıklanabilir kalır.
                val initial1 = if (region.actionX != 0 || region.actionY != 0) region.actionX to region.actionY else (540 to 900)
                val initial2 = if (region.actionX2 != 0 || region.actionY2 != 0) region.actionX2 to region.actionY2 else (initial1.first + 200 to initial1.second)
                val markerSize = (34 * resources.displayMetrics.density).toInt()
                var m1: LiveMarkerHandle? = null
                var m2: LiveMarkerHandle? = null
                val frameView = addSwipeFrame(listOf(initial1, initial2), markerSize) { dx, dy ->
                    m1?.let { shiftLiveMarker(it, dx, dy); applyActionPoint(region, "SWIPE_START", it.params.x + it.size / 2, it.params.y + it.size / 2) }
                    m2?.let { shiftLiveMarker(it, dx, dy); applyActionPoint(region, "SWIPE_END", it.params.x + it.size / 2, it.params.y + it.size / 2) }
                }
                frameView?.let { region.actionPointMarkers.add(it) }
                m1 = placeLiveMarker("1", initial1.first, initial1.second) { bx, by -> applyActionPoint(region, "SWIPE_START", bx, by) }
                m2 = placeLiveMarker("2", initial2.first, initial2.second) { bx, by -> applyActionPoint(region, "SWIPE_END", bx, by) }
                region.actionPointMarkers.add(m1.view)
                region.actionPointMarkers.add(m2.view)
            }
            "EXTRA_TAP_SUCCESS", "EXTRA_TAP_FAIL" -> {
                val isFail = target.endsWith("FAIL")
                val list = if (isFail) region.onFailActions else region.extraActions
                val idx = pendingExtraActionIndex
                val initial = list.getOrNull(idx)?.let { it.x to it.y }
                val numLabel = "${if (isFail) "F" else "S"}${idx + 1}"
                lateinit var marker: LiveMarkerHandle
                marker = placeLiveMarker(numLabel, initial?.first, initial?.second,
                    onMove = { bx, by -> list.getOrNull(idx)?.let { it.x = bx; it.y = by }; liveSave() },
                    onTap = { list.getOrNull(idx)?.let { showExtraTapEditor(it) } },
                    onLongPress = { list.getOrNull(idx)?.let { showExtraActionContextMenu(region, isFail, it, listOf(marker)) } }
                )
                // KULLANICI RAPORU: bu işaretçi HİÇBİR temizleme mekanizması tarafından
                // TAKİP EDİLMİYORDU — daha sonra "draw select" (showExtraListOnScreen) YENİ bir
                // işaretçi oluşturunca İKİSİ BİRDEN ekranda kalıp KAFA KARIŞTIRICI bir çift
                // görünüme yol açıyordu. Artık workspaceLiveMarkers'a eklenip clearWorkspace()
                // (ki showExtraListOnScreen'in İLK satırı budur) ile düzgün temizleniyor.
                workspaceLiveMarkers.add(marker.view)
            }
            "EXTRA_SWIPE_START_SUCCESS", "EXTRA_SWIPE_START_FAIL" -> {
                val isFail = target.endsWith("FAIL")
                val list = if (isFail) region.onFailActions else region.extraActions
                val idx = pendingExtraActionIndex
                val p1 = list.getOrNull(idx)?.let { it.x to it.y } ?: (540 to 900)
                val p2 = list.getOrNull(idx)?.let { it.x2 to it.y2 } ?: (p1.first + 200 to p1.second)
                val prefix = if (isFail) "F" else "S"
                val markerSize = (34 * resources.displayMetrics.density).toInt()
                val markers = mutableListOf<LiveMarkerHandle>()
                var frameViewRef: View? = null // addSwipeFrame'den SONRA atanır — closure REFERANS yakaladığı için basılı-tutulduğunda güncel değeri görür
                // Çerçeve ÖNCE (ham koordinatlarla) — daireler SONRA eklenip ÜSTTE kalacak, HER ZAMAN tıklanabilir.
                frameViewRef = addSwipeFrame(listOf(p1, p2), markerSize) { dx, dy ->
                    markers.getOrNull(0)?.let { shiftLiveMarker(it, dx, dy); list.getOrNull(idx)?.apply { x = it.params.x + it.size / 2; y = it.params.y + it.size / 2 } }
                    markers.getOrNull(1)?.let { shiftLiveMarker(it, dx, dy); list.getOrNull(idx)?.apply { x2 = it.params.x + it.size / 2; y2 = it.params.y + it.size / 2 } }
                    liveSave()
                }
                markers.add(placeLiveMarker("$prefix${idx + 1}.1", p1.first, p1.second,
                    onMove = { bx, by -> list.getOrNull(idx)?.let { it.x = bx; it.y = by }; liveSave() },
                    onTap = { list.getOrNull(idx)?.let { showExtraSwipeEditor(it) } },
                    onLongPress = { list.getOrNull(idx)?.let { showExtraActionContextMenu(region, isFail, it, markers, frameViewRef) } }
                ))
                markers.add(placeLiveMarker("$prefix${idx + 1}.2", p2.first, p2.second,
                    onMove = { bx, by -> list.getOrNull(idx)?.let { it.x2 = bx; it.y2 = by }; liveSave() },
                    onTap = { list.getOrNull(idx)?.let { showExtraSwipeEditor(it) } },
                    onLongPress = { list.getOrNull(idx)?.let { showExtraActionContextMenu(region, isFail, it, markers, frameViewRef) } }
                ))
                // AYNI düzeltme: bu iki işaretçi + çerçeve de artık takip ediliyor.
                workspaceLiveMarkers.add(markers[0].view)
                workspaceLiveMarkers.add(markers[1].view)
                frameViewRef?.let { swipeFrameViews.add(it) }
            }
        }
    }

    /**
     * SADECE bölgenin KENDİ aksiyon noktası (TAP/SWIPE_START/SWIPE_END) için — EXTRA_* (On
     * Success/On Fail) durumları artık armActionPoint() içinde DOĞRUDAN ele alınıyor. Dialog
     * YENİDEN AÇILMIYOR artık (sürüklemenin HER ANINDA çağrıldığı için bu eskiden flicker/kötü
     * UX yaratırdı) — sadece alanları günceller ve CANLI kaydeder.
     */
    private fun applyActionPoint(region: ActiveRegion, target: String, bx: Int, by: Int) {
        when (target) {
            "TAP" -> { region.actionType = "TAP"; region.actionX = bx; region.actionY = by }
            "SWIPE_START" -> { region.actionType = "SWIPE"; region.actionX = bx; region.actionY = by }
            "SWIPE_END" -> { region.actionType = "SWIPE"; region.actionX2 = bx; region.actionY2 = by }
        }
        region.onRectChangedListeners.forEach { it() } // canlı kaydet — "Onayla"ya gerek yok
    }

    private fun showTouchCatcher(onTap: (Int, Int) -> Unit) {
        val catcher = View(this)
        val catcherParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val bx = event.rawX.toInt(); val by = event.rawY.toInt()
                try { windowManager?.removeView(catcher) } catch (e: Exception) {}
                colorPickCatcher = null
                onTap(bx, by)
            }
            true
        }
        colorPickCatcher = catcher
        windowManager?.addView(catcher, catcherParams)
    }

    private fun handlePointCaught(bx: Int, by: Int) {
        val pick = pendingPick ?: return
        pendingPick = null
        val frame = ScreenCaptureService.latestFrame
        when (pick) {
            is PendingPick.ColorPick -> {
                val region = pick.region as ActiveRegion
                val color = frame?.let {
                    if (bx in 0 until it.width && by in 0 until it.height) it.getPixel(bx, by) else Color.BLACK
                } ?: Color.BLACK
                showColorConfirm(region, color, bx, by)
            }
        }
    }

    private fun showColorConfirm(region: ActiveRegion, color: Int, bx: Int, by: Int) {
        val hex = String.format("#%06X", 0xFFFFFF and color)
        val swatch = View(this).apply { setBackgroundColor(color) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 0)
            addView(swatch, LinearLayout.LayoutParams(120, 120))
            addView(TextView(this@OverlayService).apply { text = hex; setPadding(0, 12, 0, 0) })
        }
        overlayDialog()
            .setTitle("Bu renk mi?")
            .setView(container)
            .setPositiveButton("Evet, kullan") { _, _ ->
                region.conditionKind = "COLOR"
                region.conditionColor = color
                openRegionConfigDialog(region)
            }
            .setNegativeButton("Tekrar dene") { _, _ -> openRegionConfigDialog(region) }
            .create().showOverlay()
    }

    // ==================== SEKMELİ AYAR PENCERESİ ====================

    private fun openRegionConfigDialog(region: ActiveRegion) {
        var currentTab = "GENERAL" // GENERAL | ACTION | ON_SUCCESS | ON_FAIL | LOOP — Macrorify'daki 5 sekmeyle BİREBİR
        val density = resources.displayMetrics.density
        // NOT: Bu ekran bir ara (geçmiş bir turda) MacroDroid tarzı 3 sekmeye ("Ne Aranacak/Ne
        // Yapılacak/Gelişmiş") sadeleştirilmişti. Kullanıcı Macrorify'ın kendi ekran görüntülerini
        // atıp BİREBİR 5 sekmeli orijinal yapıyı istediğini netçe belirtti — bu yüzden GERİ ALINDI.
        // Hiçbir özellik kaybolmadı, sadece gruplama Macrorify'ın GENEL/AKSİYON/BAŞARILI OLUNCA/
        // BULUNAMAZSA/DÖNGÜ 5 sekmesine göre YENİDEN düzenlendi.
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val backArrow = TextView(this).apply {
            text = "←"; textSize = 18f; setTextColor(C_PURPLE); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
        }
        tabRow.addView(backArrow)
        fun tabButton(label: String) = TextView(this).apply {
            text = label; textSize = 11f; isAllCaps = true; gravity = Gravity.CENTER
            setPadding(4, (14 * density).toInt(), 4, (10 * density).toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val tabGeneral = tabButton("General")
        val tabAction = tabButton("Action")
        val tabOnSuccess = tabButton("On Success")
        val tabOnFail = tabButton("On Fail")
        val tabLoop = tabButton("Loop")
        val tabList = listOf(tabGeneral to "GENERAL", tabAction to "ACTION", tabOnSuccess to "ON_SUCCESS", tabOnFail to "ON_FAIL", tabLoop to "LOOP")
        tabList.forEach { (b, _) -> tabRow.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        val tabUnderline = View(this).apply { setBackgroundColor(ACCENT) }
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tabRow); addView(tabUnderline, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (2 * density).toInt())) }

        val autoSaveLabel = TextView(this).apply {
            text = "💾 Otomatik kaydediliyor — Kaydet'e basmana gerek yok"; textSize = 11f; setTextColor(Color.parseColor("#4CAF50"))
            setPadding((16 * density).toInt(), (8 * density).toInt(), (16 * density).toInt(), 0)
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * density).toInt(), (16 * density).toInt(), (20 * density).toInt(), 0) }
        // ÖNEMLİ: overlayDialog() artık HER ZAMAN açık tema kullanıyor (kök-noktadan düzeltildi) —
        // burada da UYUMLU olması için sabit BEYAZ arka plan + koyu yazı (isDarkMode'a bağlı
        // SURFACE_COLOR/TEXT_SECONDARY DEĞİL, kullanıcının "her zaman açık, her zaman siyah yazı"
        // isteğiyle tutarlı sabit değerler).
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE)
            addView(tabBar); addView(autoSaveLabel); addView(content)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(root); setBackgroundColor(Color.WHITE) }

        val dialog = overlayDialog()
            .setView(scroll)
            .setNeutralButton("🗑 Sil", null)
            .setNegativeButton("Kapat (kaydeder)", null)
            .create()

        fun autoSave() {
            if (region !in activeRegions) return
            val gateGroupId = region.isGateForGroupId
            if (gateGroupId != null) saveRegionAsGate(region, gateGroupId, silent = true)
            else saveRegionAsRule(region, silent = true)
        }

        fun sectionHeader(text: String) = TextView(this).apply {
            this.text = text; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(ACCENT); setPadding(0, (20 * density).toInt(), 0, (8 * density).toInt())
        }
        fun divider() = View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt()).apply { topMargin = (12 * density).toInt() }
        }

        fun highlight() {
            tabList.forEach { (b, k) ->
                if (k == currentTab) { b.setTextColor(ACCENT) } else { b.setTextColor(Color.parseColor("#616161")) }
            }
            // Alttaki mor çizgiyi aktif sekmenin altına kaydır (5 eşit dilimden hangisi).
            val idx = tabList.indexOfFirst { it.second == currentTab }.coerceAtLeast(0)
            tabRow.post {
                val tabWidth = tabGeneral.width.takeIf { it > 0 } ?: (tabRow.width / 5)
                val backArrowWidth = backArrow.width
                (tabUnderline.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
                    lp.width = tabWidth
                    lp.marginStart = backArrowWidth + tabWidth * idx
                    tabUnderline.layoutParams = lp
                }
            }
        }
        fun render() {
            region.onRectChangedListeners.clear()
            region.onRectChangedListeners.add { autoSave() }
            content.removeAllViews()
            when (currentTab) {
                "GENERAL" -> buildGeneralTab(region, content, dialog)
                "ACTION" -> buildActionTab(region, content, dialog)
                "ON_SUCCESS" -> buildExtraTab(region, content, dialog, false)
                "ON_FAIL" -> buildExtraTab(region, content, dialog, true)
                "LOOP" -> buildLoopTab(region, content)
            }
            highlight()
        }
        fun switchTab(tab: String) { autoSave(); currentTab = tab; render() }
        tabGeneral.setOnClickListener { switchTab("GENERAL") }
        tabAction.setOnClickListener { switchTab("ACTION") }
        tabOnSuccess.setOnClickListener { switchTab("ON_SUCCESS") }
        tabOnFail.setOnClickListener { switchTab("ON_FAIL") }
        tabLoop.setOnClickListener { switchTab("LOOP") }
        backArrow.setOnClickListener { autoSave(); dialog.dismiss() }

        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.setOnShowListener {
            render()
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                val scope = region.saveScope
                val gateGroupId2 = region.isGateForGroupId
                if (gateGroupId2 != null) {
                    val group = ActionGroupStorage.load(this).find { it.id == gateGroupId2 }
                    if (group != null) { group.gate = null; ActionGroupStorage.upsert(this, group) }
                } else when (scope) {
                    is SaveScope.MainFlow -> region.existingRuleId?.let { RuleStorage.deleteRule(this, it) }
                    is SaveScope.Group -> region.existingRuleId?.let { ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, it) }
                    is SaveScope.Function -> region.existingRuleId?.let { FunctionStorage.deleteRuleFromFunction(this, scope.functionId, it) }
                }
                removeRegionWindow(region)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
            }
        }
        dialog.setOnDismissListener {
            // KULLANICI İSTEĞİ: ayrı bir "✓ Bitir" butonu YOK artık — o buton alanı EKRANDAN
            // KALDIRIYORDU (removeRegionWindow), kullanıcı bunu istemiyor ("zaten ana menüde
            // hide/show var, onu kullanmalıyız"). Artık "Kapat" ya da geri tuşu/dışarı dokunma
            // İLE kapatıldığında: veriler otomatik kaydedilir, ALAN EKRANDA KALIR — kaldırmak
            // istersen 👁 Tüm Panelleri Gizle/Göster'i (sidebar) kullan.
            // (On Success/On Fail'in "draw select"i bu bölgenin kutusunu GEÇİCİ gizlemiş
            // olabilir — dialog kapanınca HER ZAMAN tekrar görünür yap.)
            region.container.visibility = View.VISIBLE
            region.label.visibility = View.VISIBLE
            val parentRegion = region.isMultiDetectionExtraFor
            if (parentRegion != null) {
                // Multi Detection'ın alt-koşulu: kapanırken otomatik olarak üst bölgenin
                // extraConditions'ına eklenir (eskiden SADECE "Bitir"e basınca oluyordu).
                val alt = buildConditionAltFromRegion(region)
                if (alt != null) {
                    parentRegion.extraConditions.add(alt)
                    Toast.makeText(this, "Koşul eklendi (${parentRegion.extraConditions.size + 1} koşul toplam)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Koşul tamamlanmadı (renk/resim/yazı seçilmedi) — eklenmedi", Toast.LENGTH_LONG).show()
                }
            } else {
                val gateGroupId = region.isGateForGroupId
                val saved = if (gateGroupId != null) saveRegionAsGate(region, gateGroupId, silent = true) else saveRegionAsRule(region, silent = true)
                // HATA DÜZELTMESİ (kullanıcı raporu: "On Success'e yeni tarama alanı eklerken her
                // dialog kapanışında listede fazladan kopyalar oluşuyor"): bu dialog'un YAŞAM
                // SÜRESİ boyunca (ör. "Seç/Çiz" veya başka bir aksiyon dialog'u kapatıp region'ı
                // TEKRAR açtırıyor) onDismissListener HER SEFERİNDE tetiklenir — ama
                // onSavedCallback "bu tarama YENİ oluşturuldu, çağırana bir CALL_FUNCTION öğesi
                // ekle" anlamına geliyor ve SADECE BİR KEZ çalışmalı. Aksi halde her kapan/aç
                // döngüsünde ("Seç/Çiz" tam olarak bunu tetikliyordu) listeye AYNI fonksiyonu
                // gösteren birden fazla kopya ekleniyordu. Callback'i ateşledikten sonra temizle.
                if (saved) {
                    region.onSavedCallback?.invoke()
                    region.onSavedCallback = null
                }
            }
        }
        dialog.show()
    }

    /** Bir alanı Action Group'un KAPI koşulu olarak kaydeder — sadece GENEL sekmesindeki koşul + cooldown kullanılır. */
    private fun saveRegionAsGate(region: ActiveRegion, groupId: String, silent: Boolean = false): Boolean {
        val group = ActionGroupStorage.load(this).find { it.id == groupId } ?: return false
        val r = regionRect(region)
        val gateAlt = when (region.conditionKind) {
            "IMAGE" -> {
                if (region.conditionTemplatePath.isNullOrBlank()) { if (!silent) Toast.makeText(this, "Resim seçilmedi", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath, minScore = region.minScore)
            }
            "TEXT" -> {
                if (region.conditionText.isBlank()) { if (!silent) Toast.makeText(this, "Metin boş", Toast.LENGTH_LONG).show(); return false }
                ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore,
                    textCaseSensitive = region.conditionTextCaseSensitive, textWhitelist = region.conditionTextWhitelist, textBlacklist = region.conditionTextBlacklist)
            }
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore)
        }
        group.gate = gateAlt
        group.gateCooldownMs = region.cooldownMs
        ActionGroupStorage.upsert(this, group)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kapı koşulu kaydedildi: ${group.name}", Toast.LENGTH_SHORT).show()
        return true
    }

    /** Bir ActiveRegion'ın GÜNCEL koşul alanlarından (renk/resim/yazı/değişken/custom) bir ConditionAlt üretir. Eksikse null döner. */
    /**
     * KULLANICI İSTEĞİ: "HAYIR kayıt edilsin, sadece TEST etmek istediğimde uyarı versin" —
     * eskiden koşul eksikse (resim/metin/değişken/kod seçilmemişse) bu fonksiyon `null` dönüp
     * `saveRegionAsRule`'un kaydetmeyi TAMAMEN REDDETMESİNE yol açıyordu — bölge hiçbir zaman
     * Ana Akış listesine DÜŞMÜYORDU. Artık HER ZAMAN bir ConditionAlt döndürüyor (eksik alanlar
     * BOŞ değerlerle) — kural HER DURUMDA kaydedilip listede görünüyor. "Eksik mi" kontrolü
     * ARTIK SADECE test/play başlatılırken `isConditionAltIncomplete` ile ayrıca yapılıyor.
     */
    private fun buildConditionAltFromRegion(region: ActiveRegion): ConditionAlt {
        val r = regionRect(region)
        val relId = region.relativeAnchorRuleId
        return when (region.conditionKind) {
            "IMAGE" -> ConditionAlt("IMAGE", r[0], r[1], r[2], r[3], templatePath = region.conditionTemplatePath ?: "", minScore = region.minScore,
                relativeAnchorRuleId = relId, relativeOffsetX = region.relativeOffsetX, relativeOffsetY = region.relativeOffsetY,
                relativeResizeW = region.relativeResizeW, relativeResizeH = region.relativeResizeH)
            "TEXT" -> ConditionAlt("TEXT", r[0], r[1], r[2], r[3], expectedText = region.conditionText, minScore = region.minScore,
                textCaseSensitive = region.conditionTextCaseSensitive, textWhitelist = region.conditionTextWhitelist, textBlacklist = region.conditionTextBlacklist,
                relativeAnchorRuleId = relId, relativeOffsetX = region.relativeOffsetX, relativeOffsetY = region.relativeOffsetY,
                relativeResizeW = region.relativeResizeW, relativeResizeH = region.relativeResizeH)
            "VARIABLE" -> ConditionAlt("VARIABLE", variableName = region.conditionVariableName, variableOp = region.conditionVariableOp, compareValue = region.conditionCompareValue)
            "CUSTOM" -> ConditionAlt("CUSTOM", customCode = region.conditionCustomCode)
            else -> ConditionAlt("COLOR", r[0], r[1], r[2], r[3], color = region.conditionColor, minScore = region.minScore,
                relativeAnchorRuleId = relId, relativeOffsetX = region.relativeOffsetX, relativeOffsetY = region.relativeOffsetY,
                relativeResizeW = region.relativeResizeW, relativeResizeH = region.relativeResizeH)
        }
    }

    /** Bir ConditionAlt'ın (henüz) TEST edilmeye/çalıştırılmaya HAZIR olmadığını (eksik resim/metin/değişken/kod) tespit eder. */
    private fun isConditionAltIncomplete(alt: ConditionAlt): Boolean = when (alt.conditionKind) {
        "IMAGE" -> alt.templatePath.isNullOrBlank()
        "TEXT" -> alt.expectedText.isNullOrBlank()
        "VARIABLE" -> alt.variableName.isBlank()
        "CUSTOM" -> alt.customCode.isBlank()
        else -> false // COLOR her zaman geçerli bir değere sahip (varsayılan bile olsa)
    }

    /** Bir kuralın (RuleDefinition) TÜM alternatiflerinden HERHANGİ biri eksikse true döner. */
    private fun isRuleIncomplete(rule: RuleDefinition): Boolean =
        rule.alternatives.any { alt -> isConditionAltIncomplete(alt) }

    /** Macrorify'daki "Multi Detection": ana koşula EK bir koşul çizdirir (kendi bölgesinde). */
    private fun startMultiDetectionCondition(parentRegion: ActiveRegion) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.isMultiDetectionExtraFor = parentRegion
        region.label.text = "🔀 Ek Koşul ${parentRegion.extraConditions.size + 2}"
        Toast.makeText(this, "Koşulu ayarla (GENEL sekmesi yeter), sonra kapat — otomatik eklenir", Toast.LENGTH_LONG).show()
    }

    private fun buildGeneralTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val density = resources.displayMetrics.density
        content.addView(TextView(ctx).apply { text = "DESCRIPTION"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 0) })
        val nameInput = EditText(ctx).apply {
            hint = "Image Detection"; setText(region.name)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        nameInput.addTextChangedListener(simpleWatcher { region.name = it })
        content.addView(nameInput)
        content.addView(TextView(ctx).apply { text = "What does this action do?"; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, 4, 0, 0) })

        val templateHeader = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 4) }
        templateHeader.addView(TextView(ctx).apply { text = "Template"; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
        templateHeader.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener {
                showHintDialog("Template", hintText(
                    "Image: " to "Ekrandan kırpılmış küçük bir görsel — bölge içinde taranır.",
                    "Text: " to "OCR ile okunacak bir kelime/metin.",
                    "Color: " to "Bölge içinde aranacak hedef renk (Delta-E ile karşılaştırılır).",
                    "Değişken/Custom: " to "Macrorify'daki ayrı 'Conditional' özelliğimiz — ekranı taramaz, bir değişken/JavaScript ifadesi kontrol eder."
                ))
            }
        })
        content.addView(templateHeader)
        val radioGroup = android.widget.RadioGroup(ctx)
        // Macrorify'daki GERÇEK sıra: Image, Text, Color. Değişken/Custom bizim "Conditional" genişletmemiz — sona eklendi.
        val rbImage = android.widget.RadioButton(ctx).apply { text = "Image"; id = 2 }
        val rbText = android.widget.RadioButton(ctx).apply { text = "Text"; id = 3 }
        val rbColor = android.widget.RadioButton(ctx).apply { text = "Color"; id = 1 }
        val rbVariable = android.widget.RadioButton(ctx).apply { text = "🔢 Değişken (Conditional)"; id = 4 }
        val rbCustom = android.widget.RadioButton(ctx).apply { text = "⚡ Custom (Conditional)"; id = 5 }
        listOf(rbImage, rbText, rbColor, rbVariable, rbCustom).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.conditionKind) { "IMAGE" -> 2; "TEXT" -> 3; "VARIABLE" -> 4; "CUSTOM" -> 5; else -> 1 })
        content.addView(radioGroup)

        val sub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        content.addView(sub)

        fun renderSub() {
            sub.removeAllViews()
            when (region.conditionKind) {
                "IMAGE" -> {
                    val iv = android.widget.ImageView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(200, 200)
                        scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                    val path = region.conditionTemplatePath
                    if (!path.isNullOrBlank()) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(path)
                        if (bmp != null) iv.setImageBitmap(bmp)
                        sub.addView(TextView(ctx).apply { text = "Seçili resim:"; setTextColor(TEXT_SECONDARY) })
                        sub.addView(iv)
                    } else {
                        sub.addView(TextView(ctx).apply { text = "Henüz resim seçilmedi — aşağıdaki ikonlardan birini kullan."; setTextColor(TEXT_SECONDARY) })
                    }
                    // KULLANICI İSTEĞİ: "tarama alanında sadece kütüphaneden seç seçeneği olsun" —
                    // ekrandan-kırp ve Advanced kaldırıldı; resim çekme artık SADECE Resources
                    // ekranından (kontrol panelli, küçük-piksel destekli) yapılıyor.
                    val templateIconRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
                    templateIconRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_library, C_GREEN, "Kütüphaneden Seç") {
                        pickFromLibrary(region) { renderSub() }
                    })
                    sub.addView(templateIconRow)
                }
                "TEXT" -> {
                    val input = EditText(ctx).apply { hint = "Aranacak kelime/metin"; setText(region.conditionText) }
                    input.addTextChangedListener(simpleWatcher { region.conditionText = it })
                    sub.addView(input)

                    sub.addView(styledField(
                        "WHITELIST", "Sadece BU karakterlere izin ver, gerisini at (örn. sadece sayı bekliyorsan: 0123456789). Boş = kapalı",
                        region.conditionTextWhitelist, keyboardNumeric = false
                    ) { region.conditionTextWhitelist = it })
                    sub.addView(styledField(
                        "BLACKLIST", "BU karakterleri okunan metinden çıkar (örn. 'O' harfi hep '0' okunuyorsa listeye ekle). Boş = kapalı",
                        region.conditionTextBlacklist, keyboardNumeric = false
                    ) { region.conditionTextBlacklist = it })
                    val caseSensitiveCheck = android.widget.CheckBox(ctx).apply {
                        text = "Büyük/Küçük Harf Duyarlı (Case Sensitive)"
                        isChecked = region.conditionTextCaseSensitive
                        setPadding(0, 12, 0, 0)
                    }
                    caseSensitiveCheck.setOnCheckedChangeListener { _, checked -> region.conditionTextCaseSensitive = checked }
                    sub.addView(caseSensitiveCheck)
                }
                "VARIABLE" -> {
                    sub.addView(TextView(ctx).apply {
                        text = "🔢 Değişken Koşulu — bir sayacın değeri bir sayıyla karşılaştırılır. Doğruysa \"Ne Yapılacak\" (On True), yanlışsa \"Bulunamazsa\" (On False) çalışır.\n\nNOT: Bu koşul EKRANI TARAMAZ — bölge/renk/skor gerekmez. Değişkeni script'lerle (setVar) ya da aksiyonlardaki \"Değişken Ayarla\" ile değiştirirsin."
                        textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 8)
                    })
                    sub.addView(styledField(
                        "DEĞİŞKEN ADI", "Karşılaştırılacak sayacın adı (örn. tur, can, altin)",
                        region.conditionVariableName, keyboardNumeric = false
                    ) { region.conditionVariableName = it })

                    sub.addView(TextView(ctx).apply { text = "OPERATÖR"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 12, 0, 4) })
                    val ops = listOf(">=", "<=", "==", "!=", ">", "<")
                    val opLabels = listOf("≥ büyük/eşit", "≤ küçük/eşit", "= eşit", "≠ eşit değil", "> büyük", "< küçük")
                    val opRow1 = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.HORIZONTAL }
                    ops.forEachIndexed { i, op ->
                        val rb = android.widget.RadioButton(ctx).apply { text = opLabels[i]; id = i + 1; textSize = 12f }
                        if (region.conditionVariableOp == op) rb.isChecked = true
                        opRow1.addView(rb)
                    }
                    opRow1.setOnCheckedChangeListener { _, checkedId -> region.conditionVariableOp = ops[checkedId - 1] }
                    val opScroll = android.widget.HorizontalScrollView(ctx).apply { addView(opRow1); isHorizontalScrollBarEnabled = false }
                    sub.addView(opScroll)

                    sub.addView(styledField(
                        "KARŞILAŞTIRILACAK DEĞER", "Değişken bu sayıyla karşılaştırılır",
                        region.conditionCompareValue.toString()
                    ) { region.conditionCompareValue = it.toIntOrNull() ?: 0 })
                }
                "CUSTOM" -> {
                    sub.addView(TextView(ctx).apply {
                        text = "⚡ Custom Koşul — true/false dönen bir JavaScript ifadesi. Doğruysa \"Ne Yapılacak\" (On True), yanlışsa \"Bulunamazsa\" (On False) çalışır.\n\nÖrnekler:\n  getVar(\"can\") < 30\n  getVar(\"tur\") % 2 == 0\n  findColor(100,200,4,4,\"#FF0000\",0.9)\n\nNOT: Script köprü fonksiyonlarının tamamını kullanabilirsin (Kod menüsündeki ile aynı)."
                        textSize = 12f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 8)
                    })
                    val codeInput = EditText(ctx).apply {
                        setText(region.conditionCustomCode)
                        hint = "örn. getVar(\"can\") < 30"
                        typeface = android.graphics.Typeface.MONOSPACE
                        textSize = 13f
                        isSingleLine = false
                        minLines = 2
                        maxLines = 6
                        setBackgroundColor(SURFACE_ALT_COLOR)
                        setPadding(16, 12, 16, 12)
                    }
                    codeInput.addTextChangedListener(simpleWatcher { region.conditionCustomCode = it })
                    sub.addView(codeInput)
                }
                else -> {
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val swatch = View(ctx).apply { setBackgroundColor(region.conditionColor) }
                    row.addView(swatch, LinearLayout.LayoutParams(50, 50))
                    row.addView(TextView(ctx).apply { text = String.format(" #%06X", 0xFFFFFF and region.conditionColor) })
                    sub.addView(row)
                    val btnPick = Button(ctx).apply { text = "📍 Ekrandan Noktayı Seç" }
                    btnPick.setOnClickListener { dialog.dismiss(); armColorPick(region) }
                    sub.addView(btnPick)
                    val hexInput = EditText(ctx).apply {
                        hint = "veya HEX gir: #RRGGBB"
                        setText(String.format("#%06X", 0xFFFFFF and region.conditionColor))
                    }
                    hexInput.addTextChangedListener(simpleWatcher { text ->
                        val parsed = try { Color.parseColor(text.trim()) } catch (e: Exception) { null }
                        if (parsed != null) { region.conditionColor = parsed; swatch.setBackgroundColor(parsed) }
                    })
                    sub.addView(hexInput)
                }
            }
        }
        renderSub()
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.conditionKind = when (checkedId) { 2 -> "IMAGE"; 3 -> "TEXT"; 4 -> "VARIABLE"; 5 -> "CUSTOM"; else -> "COLOR" }
            renderSub()
            applyFindRegionVisibility()
        }

        // NOT: "Wait Next" (cooldownMs) ve "Delay" (matchDelayMs) artık Macrorify'daki gibi
        // AKSİYON sekmesinin "Click Option" bölümünde — burada değil (bkz. buildActionTab).
        // "Timeout" ve "Scan rate" da artık yukarıdaki "Find Option" bölümünde.
        content.addView(styledField(
            "RASTGELE ŞANS (%)", "Eşleşme bulunsa bile sadece bu yüzdelik ihtimalle tetiklenir. 100 = her zaman (kapalı)",
            region.randomChancePercent.toString()
        ) { region.randomChancePercent = it.toIntOrNull()?.coerceIn(0, 100) ?: 100 })
        content.addView(styledField(
            "OTOMATİK DURDURMA (art arda kaç kez bulunamayınca)", "Bu alan art arda bu kadar kez bulunamazsa kendini devre dışı bırakır. 0 = sınırsız, hiç durmaz",
            region.maxConsecutiveFailures.toString()
        ) { region.maxConsecutiveFailures = it.toIntOrNull()?.coerceAtLeast(0) ?: 0 })

        // ---- 🔀 Multi Detection: bu koşula EK koşullar ekleyip mantıkla (VE/VEYA/vb) birleştirme ----
        if (region.isMultiDetectionExtraFor == null) {
            content.addView(TextView(ctx).apply {
                text = "🔀 Multi Detection (İsteğe Bağlı — Ek Koşullar)"
                textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ACCENT); setPadding(0, 20, 0, 8)
            })
            if (region.extraConditions.isNotEmpty()) {
                region.extraConditions.forEachIndexed { idx, alt ->
                    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val kindIcon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
                    row.addView(TextView(ctx).apply {
                        text = "$kindIcon Koşul ${idx + 2} — (${alt.x},${alt.y},${alt.width},${alt.height})"
                        setTextColor(TEXT_PRIMARY); textSize = 12f
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    val btnRemove = Button(ctx).apply { text = "🗑"; textSize = 11f }
                    btnRemove.setOnClickListener { region.extraConditions.removeAt(idx); dialog.dismiss(); openRegionConfigDialog(region) }
                    row.addView(btnRemove)
                    content.addView(row)
                }
            }
            val btnAddCondition = Button(ctx).apply { text = "➕ Ek Koşul Ekle (başka bölgede)" }
            btnAddCondition.setOnClickListener { dialog.dismiss(); startMultiDetectionCondition(region) }
            content.addView(btnAddCondition)

            if (region.extraConditions.isNotEmpty()) {
                content.addView(TextView(ctx).apply {
                    text = "Mantık — bu koşul VE ek koşullar nasıl birleşsin:"
                    textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 12, 0, 4)
                })
                val logicOptions = listOf(
                    "ONE_SUCCESS" to "VEYA — biri doğruysa yeter",
                    "ALL_SUCCESS" to "VE — hepsi doğru olmalı",
                    "ALL_FAIL" to "Hepsi Yanlış — hiçbiri bulunmamalı",
                    "ONE_FAIL" to "Biri Yanlış — en az biri bulunmamalı",
                    "ALWAYS_SUCCESS" to "Her Zaman Doğru (bu grup dış sonucu etkilemesin)",
                    "ALWAYS_FAIL" to "Her Zaman Yanlış (bu grup dış sonucu etkilemesin)"
                )
                val logicRadio = android.widget.RadioGroup(ctx)
                logicOptions.forEachIndexed { i, (key, label) ->
                    val rb = android.widget.RadioButton(ctx).apply { text = label; id = i + 1; setTextColor(TEXT_PRIMARY) }
                    if (region.conditionsLogic == key) logicRadio.check(i + 1)
                    logicRadio.addView(rb)
                }
                logicRadio.setOnCheckedChangeListener { _, checkedId -> region.conditionsLogic = logicOptions[checkedId - 1].first }
                content.addView(logicRadio)
            }
        }

        // ---- Find Region: TEK bir "x, y, width, height" alanı (Macrorify'daki BİREBİR format) ----
        // VARIABLE/CUSTOM koşulları ekranı taramadığı için bu bölüm onlarda GİZLENİR (bölge anlamsız).
        val findRegionSection = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(findRegionSection)
        val regionHeader = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 4) }
        regionHeader.addView(TextView(ctx).apply { text = "Region"; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
        regionHeader.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener { showHintDialog("Region", hintText("Coordinate: " to "Bölge, x/y/genişlik/yükseklik piksel koordinatlarıyla tanımlanır.")) }
        })
        findRegionSection.addView(regionHeader)
        findRegionSection.addView(TextView(ctx).apply { text = "⦿ Coordinate"; textSize = 13f; setTextColor(ACCENT); setPadding(0, 0, 0, 8) })
        findRegionSection.addView(TextView(ctx).apply { text = "Find Region"; textSize = 11f; setTextColor(TEXT_SECONDARY) })
        val r = regionRect(region)
        val etRegion = EditText(ctx).apply {
            setText("${r[0]}, ${r[1]}, ${r[2]}, ${r[3]}")
            textSize = 15f; setTextColor(TEXT_PRIMARY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        findRegionSection.addView(etRegion)
        findRegionSection.addView(TextView(ctx).apply {
            text = "x, y, width, height of finding region"; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, 4, 0, 0)
        })

        var suppressFindRegionSync = false
        fun applyFindRegionToScreen() {
            if (suppressFindRegionSync) return
            val parts = etRegion.text.toString().split(",").map { it.trim().toIntOrNull() }
            if (parts.size != 4 || parts.any { it == null }) return
            val (x, y, w, h) = parts.map { it!! }
            moveAndResizeRegion(region, x, y, w.coerceAtLeast(4), h.coerceAtLeast(4))
        }
        etRegion.addTextChangedListener(simpleWatcher { applyFindRegionToScreen() })
        region.onRectChangedListeners.add {
            suppressFindRegionSync = true
            val r2 = regionRect(region)
            etRegion.setText("${r2[0]}, ${r2[1]}, ${r2[2]}, ${r2[3]}")
            suppressFindRegionSync = false
        }

        // 📐 Region Scaling + 🔗 Relative Coordinates — Find Region'ın hemen altında (Macrorify'daki "Scale" satırı).
        val scalingAndRelativeSection = buildScalingAndRelativeSection(region, ctx)
        content.addView(scalingAndRelativeSection)

        // ---- Find Option: Algorithm / Timeout / Min Score / Scan rate (Macrorify'daki BİREBİR) ----
        val findOptionSection = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(findOptionSection)
        val findOptionHeader = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 4) }
        findOptionHeader.addView(TextView(ctx).apply { text = "Find Option"; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
        findOptionHeader.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener {
                showHintDialog("Find Option", hintText(
                    "Algorithm: " to "BigBoss'ta tek algoritma var: Normalize Edilmiş Çapraz Korelasyon (NCC) — OpenCV'nin matchTemplate/TM_CCOEFF_NORMED'iyle aynı matematiksel temel, çoklu ölçekte arar.",
                    "Timeout: " to "Bulma işlemi için zaman aşımı. -1 = sonsuza kadar dene.",
                    "Min Score: " to "Minimum eşleşme yüzdesi.",
                    "Scan rate: " to "Saniyede kaç bulma işlemi yapılsın."
                ))
            }
        })
        findOptionSection.addView(findOptionHeader)
        findOptionSection.addView(TextView(ctx).apply {
            text = "Algorithm  Correlation Coefficient (Default)"; textSize = 13f; setTextColor(TEXT_PRIMARY); setPadding(0, 0, 0, 12)
        })
        addHoldOrDelayField(ctx, findOptionSection, "TIMEOUT — Timeout for find operation. -1 for forever (miliseconds)",
            region.scanTimeoutMs, region.scanTimeoutVarName,
            { region.scanTimeoutMs = it.coerceAtLeast(-1) }, { region.scanTimeoutVarName = it }, allowForever = true)
        addMinScoreControls(ctx, findOptionSection, region)
        addHoldOrDelayField(ctx, findOptionSection, "SCAN RATE — Number of find operation per second (x10, örn. 30 = 3.0/sn)",
            (region.scanRateHz * 10).toLong(), region.scanRateVarName,
            { region.scanRateHz = it / 10f }, { region.scanRateVarName = it })

        // VARIABLE/CUSTOM seçiliyse: Find Region'ı gizle VE ekrandaki bölge kutusunu da gizle
        // (bu koşullar ekranı taramaz, bölgeyle işleri yoktur). Diğer tiplerde geri göster.
        applyFindRegionVisibility = {
            val screenless = region.conditionKind == "VARIABLE" || region.conditionKind == "CUSTOM"
            findRegionSection.visibility = if (screenless) View.GONE else View.VISIBLE
            region.container.visibility = if (screenless) View.GONE else View.VISIBLE
            region.label.visibility = if (screenless) View.GONE else View.VISIBLE
            scalingAndRelativeSection.visibility = if (screenless) View.GONE else View.VISIBLE
            findOptionSection.visibility = if (screenless) View.GONE else View.VISIBLE
        }
        applyFindRegionVisibility()

        val disableCheck2 = android.widget.CheckBox(ctx).apply {
            text = "Disable"
            isChecked = !region.enabled
            setTextColor(TEXT_PRIMARY)
            setPadding(0, 20, 0, 0)
        }
        disableCheck2.setOnCheckedChangeListener { _, checked -> region.enabled = !checked }
        content.addView(disableCheck2)
    }

    /**
     * Macrorify'daki "Region Scaling" (Fixed/Dynamic/Sticky) + "Relative Coordinates"
     * (Locatable Detection) ayarlarını GENEL sekmesine ekler. Sadece bölgesi olan koşul
     * tipleri (COLOR/IMAGE/TEXT) için anlamlıdır — VARIABLE/CUSTOM'da çağrılmaz.
     */
    private fun buildScalingAndRelativeSection(region: ActiveRegion, ctx: android.content.Context): LinearLayout {
        val section = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        // ---- 📐 Region Scaling: farklı ekran çözünürlüğünde çalıştırıldığında bölge nasıl ölçeklensin ----
        section.addView(TextView(ctx).apply {
            text = "📐 Region Scaling (Farklı Cihaz Uyumu)"
            textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(ACCENT); setPadding(0, 20, 0, 4)
        })
        section.addView(TextView(ctx).apply {
            text = "Bu kural BAŞKA bir ekran çözünürlüğünde çalıştırılırsa (farklı telefon, yeniden kurulum), bölge/nokta nasıl ölçeklensin?"
            textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 6)
        })
        val scaleRadio = android.widget.RadioGroup(ctx)
        val rbFixed = android.widget.RadioButton(ctx).apply { text = "📐 Sabit (Fixed) — ortadan, oranı bozmadan"; id = 1 }
        val rbDynamic = android.widget.RadioButton(ctx).apply { text = "📊 Dinamik (Dynamic) — kenara yüzde, esneyebilir"; id = 2 }
        val rbSticky = android.widget.RadioButton(ctx).apply { text = "📌 Kenara Sabit (Sticky) — seçtiğin kenardan boşluk korunur"; id = 3 }
        listOf(rbFixed, rbDynamic, rbSticky).forEach { scaleRadio.addView(it) }
        scaleRadio.check(when (region.regionScaleMode) { "DYNAMIC" -> 2; "STICKY" -> 3; else -> 1 })
        section.addView(scaleRadio)

        val stickyRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 0) }
        val cbLeft = android.widget.CheckBox(ctx).apply { text = "Sol"; isChecked = region.stickyLeft }
        val cbTop = android.widget.CheckBox(ctx).apply { text = "Üst"; isChecked = region.stickyTop }
        val cbRight = android.widget.CheckBox(ctx).apply { text = "Sağ"; isChecked = region.stickyRight }
        val cbBottom = android.widget.CheckBox(ctx).apply { text = "Alt"; isChecked = region.stickyBottom }
        listOf(cbLeft, cbTop, cbRight, cbBottom).forEach { stickyRow.addView(it) }
        cbLeft.setOnCheckedChangeListener { _, v -> region.stickyLeft = v }
        cbTop.setOnCheckedChangeListener { _, v -> region.stickyTop = v }
        cbRight.setOnCheckedChangeListener { _, v -> region.stickyRight = v }
        cbBottom.setOnCheckedChangeListener { _, v -> region.stickyBottom = v }
        stickyRow.visibility = if (region.regionScaleMode == "STICKY") View.VISIBLE else View.GONE
        section.addView(stickyRow)
        scaleRadio.setOnCheckedChangeListener { _, checkedId ->
            region.regionScaleMode = when (checkedId) { 2 -> "DYNAMIC"; 3 -> "STICKY"; else -> "FIXED" }
            stickyRow.visibility = if (region.regionScaleMode == "STICKY") View.VISIBLE else View.GONE
        }

        // ---- 🔗 Relative Coordinates: bu bölgeyi başka bir kuralın bulduğu konuma göre taşı ----
        section.addView(TextView(ctx).apply {
            text = "🔗 Relatif Konum (Locatable Detection)"
            textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(ACCENT); setPadding(0, 20, 0, 4)
        })
        section.addView(TextView(ctx).apply {
            text = "Kaydırılan bir listede (fiyat, satın-al butonu gibi) sabit koordinat işe yaramaz — bu alanı başka bir kuralın SON bulduğu konuma göre konumlandır."
            textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 0, 0, 6)
        })
        val relativeCheck = android.widget.CheckBox(ctx).apply {
            text = "Bu alanı bir referans kuralın konumuna göre taşı"
            isChecked = !region.relativeAnchorRuleId.isNullOrBlank()
        }
        section.addView(relativeCheck)
        val relativeSub = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 0) }
        section.addView(relativeSub)

        fun renderRelativeSub() {
            relativeSub.removeAllViews()
            if (!relativeCheck.isChecked) return
            val btnPick = Button(ctx).apply {
                text = if (region.relativeAnchorRuleName.isNotBlank()) "🔗 Referans: ${region.relativeAnchorRuleName}" else "🔗 Referans Kural Seç"
            }
            btnPick.setOnClickListener {
                pickAnchorRule(region.existingRuleId) { id, name ->
                    region.relativeAnchorRuleId = id; region.relativeAnchorRuleName = name
                    renderRelativeSub()
                }
            }
            relativeSub.addView(btnPick)
            relativeSub.addView(styledField("OFFSET X (px)", "Referans noktasından sağa/sola kaç piksel kaydır (negatif = sola)",
                region.relativeOffsetX.toString()) { region.relativeOffsetX = it.toIntOrNull() ?: 0 })
            relativeSub.addView(styledField("OFFSET Y (px)", "Referans noktasından aşağı/yukarı kaç piksel kaydır (negatif = yukarı)",
                region.relativeOffsetY.toString()) { region.relativeOffsetY = it.toIntOrNull() ?: 0 })
            relativeSub.addView(styledField("YENİDEN BOYUTLANDIR — GENİŞLİK (opsiyonel)", "Boş bırakırsan alanın kendi genişliği korunur",
                region.relativeResizeW?.toString() ?: "") { region.relativeResizeW = it.toIntOrNull() })
            relativeSub.addView(styledField("YENİDEN BOYUTLANDIR — YÜKSEKLİK (opsiyonel)", "Boş bırakırsan alanın kendi yüksekliği korunur",
                region.relativeResizeH?.toString() ?: "") { region.relativeResizeH = it.toIntOrNull() })
        }
        renderRelativeSub()
        relativeCheck.setOnCheckedChangeListener { _, checked ->
            if (!checked) { region.relativeAnchorRuleId = null; region.relativeAnchorRuleName = "" }
            renderRelativeSub()
        }
        return section
    }

    /** buildGeneralTab içinde koşul tipi değişince Find Region + ekran kutusunu göster/gizle (VARIABLE/CUSTOM için gizli). */
    private var applyFindRegionVisibility: () -> Unit = {}

    private fun addMinScoreControls(ctx: android.content.Context, sub: LinearLayout, region: ActiveRegion) {
        val density = resources.displayMetrics.density
        val label = TextView(ctx).apply {
            text = "MIN SKOR (%)"; textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, (14 * density).toInt(), 0, 0)
        }
        var suppress = false
        val numberInput = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(region.minScore.toString())
            textSize = 15f; setTextColor(TEXT_PRIMARY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
        }
        val seek = SeekBar(ctx).apply {
            max = 100; progress = region.minScore
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    region.minScore = v
                    if (fromUser) { suppress = true; numberInput.setText(v.toString()); suppress = false }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        numberInput.addTextChangedListener(simpleWatcher { text ->
            if (suppress) return@simpleWatcher
            val v = text.toIntOrNull()?.coerceIn(0, 100) ?: return@simpleWatcher
            region.minScore = v; seek.progress = v
        })
        sub.addView(label); sub.addView(numberInput); sub.addView(seek)
    }

    private fun pickFromLibrary(region: ActiveRegion, onDone: () -> Unit) {
        val localItems = LibraryStorage.load(this)
        val globalItems = com.bigboss.app.storage.GlobalLibraryStorage.load(this)
        val items = localItems + globalItems
        if (items.isEmpty()) { Toast.makeText(this, "Kütüphane boş", Toast.LENGTH_SHORT).show(); return }
        val labels = localItems.map { "${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" } +
            globalItems.map { "🌐${if (it.kind == "IMAGE") "🖼️" else "🎨"} ${it.name}" }
        overlayDialog()
            .setTitle("Seç")
            .setItems(labels.toTypedArray()) { _, idx ->
                val item = items[idx]
                if (item.kind == "IMAGE") { region.conditionKind = "IMAGE"; region.conditionTemplatePath = item.templatePath }
                else { region.conditionKind = "COLOR"; region.conditionColor = item.color }
                onDone()
            }
            .create().showOverlay()
    }

    /**
     * ACTION sekmesi — Macrorify referansına (WA0045/WA0044) BİREBİR uyarlandı: artık TEK bir
     * "Action" açılır menüsü var, 4 mod:
     *   • Click best match      → min skor üstü EN İYİ eşleşmeye tıkla
     *   • Click multiple matches → min skor üstü TÜM eşleşmelere tıkla
     *   • Wait till appear       → şablon GÖRÜNENE kadar bekle (tıklamaz)
     *   • Wait till vanish       → şablon KAYBOLANA kadar bekle (tıklamaz)
     * Eski birincil aksiyonlar (Kaydırma/Fonksiyon/Sistem/sabit-nokta) buradan KALDIRILDI —
     * hepsi "On Success" sekmesinden eklenebiliyor (orada zaten tam destek var). Wait modları
     * motorda mevcut `negate` (Wait till vanish = negate) + tıklamasız `actionType="NONE"`
     * (mapper'da Action.NoOp) mekanizmasıyla çalışır — onSuccess yine çalışır.
     */
    private fun buildActionTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog) {
        val ctx = this
        val density = resources.displayMetrics.density

        val actionHeader = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 4) }
        actionHeader.addView(TextView(ctx).apply { text = "Action"; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY) })
        actionHeader.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener {
                showHintDialog("Action", hintText(
                    "Click best match: " to "Min skorun üstünde EN YÜKSEK eşleşme puanına sahip şablona tıklar.",
                    "Click multiple matches: " to "Min skorun üstünde eşleşen TÜM şablonlara tıklar.",
                    "Wait till appear: " to "Min skorun üstünde bir şablon bölgede GÖRÜNENE kadar bekler (tıklamaz).",
                    "Wait till vanish: " to "Min skorun üstünde eşleşen tüm şablonlar bölgeden KAYBOLANA kadar bekler (tıklamaz).",
                    "Not: " to "Kaydırma / Fonksiyon Çağır / Sistem gibi aksiyonları artık 'On Success' sekmesinden eklersin."
                ))
            }
        })
        content.addView(actionHeader)

        val modeKeys = listOf("CLICK_BEST", "CLICK_MULTIPLE", "WAIT_APPEAR", "WAIT_VANISH")
        val modeLabels = listOf("Click best match", "Click multiple matches", "Wait till appear", "Wait till vanish")
        fun currentMode(): String = when {
            region.actionType == "NONE" && region.negate -> "WAIT_VANISH"
            region.actionType == "NONE" -> "WAIT_APPEAR"
            region.tapAtMatchLocation && region.tapAllMatches -> "CLICK_MULTIPLE"
            else -> "CLICK_BEST"
        }
        fun applyMode(mode: String) {
            when (mode) {
                "CLICK_BEST" -> { region.actionType = "TAP"; region.tapAtMatchLocation = true; region.tapAllMatches = false; region.negate = false }
                "CLICK_MULTIPLE" -> { region.actionType = "TAP"; region.tapAtMatchLocation = true; region.tapAllMatches = true; region.negate = false }
                "WAIT_APPEAR" -> { region.actionType = "NONE"; region.tapAtMatchLocation = false; region.tapAllMatches = false; region.negate = false }
                "WAIT_VANISH" -> { region.actionType = "NONE"; region.tapAtMatchLocation = false; region.tapAllMatches = false; region.negate = true }
            }
        }
        // Eski model (Kaydırma/Fonksiyon/Sistem/sabit-nokta) → "Click best match"e normalize et,
        // böylece açılır menü GERÇEKTE kayıtlı olanla tutarlı olur.
        // NOT: Kapı (gate) bölgelerinde `negate` TERS anlam taşır (saveRegionAsGate → !region.negate),
        // bu yüzden otomatik normalizasyon SADECE normal tespit bölgelerinde yapılır — gate'lerin
        // negate'ine dokunmayız (kullanıcı menüden bir mod SEÇERSE elbette uygulanır).
        if (region.isGateForGroupId == null) applyMode(currentMode())

        // Spinner overlay pencerede kendi penceresini açtığı için sorunlu olabiliyor —
        // tıklanabilir bir satır + overlayDialog listesi kullanıyoruz (uygulamanın geri kalanıyla tutarlı).
        val dropdown = TextView(ctx).apply {
            textSize = 15f; setTextColor(TEXT_PRIMARY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke((1 * density).toInt(), DIVIDER_COLOR); cornerRadius = 6 * density
            }
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
        }
        fun refreshDropdownText() { dropdown.text = modeLabels[modeKeys.indexOf(currentMode())] + "    ▾" }
        refreshDropdownText()
        content.addView(dropdown)

        val clickOption = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(clickOption)

        fun renderClickOption() {
            clickOption.removeAllViews()
            val isClick = region.actionType == "TAP"
            clickOption.addView(TextView(ctx).apply {
                text = "Click Option"; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(TEXT_PRIMARY); setPadding(0, 20, 0, 4)
            })
            // Hold / Repeat / Randomize sadece GERÇEKTEN dokunan modlarda anlamlı.
            if (isClick) {
                addHoldOrDelayField(ctx, clickOption, "HOLD — How long to hold at this point (miliseconds)",
                    region.actionHoldMs, region.actionHoldVarName,
                    { region.actionHoldMs = it }, { region.actionHoldVarName = it })
                addHoldOrDelayField(ctx, clickOption, "REPEAT — Repeat this action",
                    region.actionRepeatCount.toLong(), region.actionRepeatVarName,
                    { region.actionRepeatCount = it.toInt().coerceAtLeast(1) }, { region.actionRepeatVarName = it })
            }
            addHoldOrDelayField(ctx, clickOption, "DELAY — Delay the execution of this action (miliseconds)",
                region.matchDelayMs, region.matchDelayVarName,
                { region.matchDelayMs = it.coerceAtLeast(0) }, { region.matchDelayVarName = it })
            addHoldOrDelayField(ctx, clickOption, "WAIT NEXT — How long to wait for next action (miliseconds)",
                region.cooldownMs, region.cooldownVarName,
                { region.cooldownMs = it.coerceAtLeast(0) }, { region.cooldownVarName = it })
            if (isClick) {
                addHoldOrDelayField(ctx, clickOption, "RANDOMIZE — Randomize every point by this amount (pixels)",
                    region.randomOffsetPx.toLong(), region.randomOffsetVarName,
                    { region.randomOffsetPx = it.toInt().coerceAtLeast(0) }, { region.randomOffsetVarName = it })
            }
            // BigBoss'a özel EK alan: işlem bittikten SONRA (Wait Next'ten ayrı) ekstra bekleme.
            addHoldOrDelayField(ctx, clickOption, "⏱️ EK BEKLEME (post-delay) — bu işlem bittikten hemen sonra kaç ms daha beklesin:",
                region.actionPostDelayMs, region.actionPostDelayVarName,
                { region.actionPostDelayMs = it }, { region.actionPostDelayVarName = it })
            if (!isClick) {
                clickOption.addView(TextView(ctx).apply {
                    text = "ℹ️ Bu modda ekrana dokunulmaz (sadece beklenir); Hold/Repeat/Randomize bu yüzden gizli. Bekleme sonrası yapılacaklar için 'On Success' sekmesini kullan."
                    textSize = 11f; setTextColor(TEXT_SECONDARY); setPadding(0, 8, 0, 0)
                })
            }
        }
        renderClickOption()

        dropdown.setOnClickListener {
            overlayDialog().setTitle("Action").setItems(modeLabels.toTypedArray()) { _, idx ->
                applyMode(modeKeys[idx])
                refreshDropdownText()
                renderClickOption()
            }.setNegativeButton("Kapat", null).create().showOverlay()
        }
    }

    private fun pickOrCreateFunction(region: ActiveRegion, onDone: () -> Unit) {
        val functions = FunctionStorage.load(this)
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur")
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        overlayDialog().setItems(options.toTypedArray()) { _, index ->
            if (index == 0) {
                val fn = FunctionDefinition(UUID.randomUUID().toString(), "f_${System.currentTimeMillis()}")
                FunctionStorage.upsert(this, fn)
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            } else if (index <= functions.size) {
                val fn = functions[index - 1]
                region.callFunctionId = fn.id; region.callFunctionName = fn.name
                onDone()
            } else {
                val group = groups[index - 1 - functions.size]
                region.callFunctionId = group.id; region.callFunctionName = "📦 ${group.name}"
                onDone()
            }
        }.create().showOverlay()
    }

    /**
     * Macrorify'daki "Relative Coordinates" (Locatable Detection): Ana Akış'taki kurallardan
     * birini "anchor" (referans nokta) olarak seçtirir — kendi kuralımız hariç. Seçilen kuralın
     * SON bulunduğu konum, RuleEngine tarafından MatchLocationRegistry'ye otomatik kaydedilir.
     */
    private fun pickAnchorRule(excludeRuleId: String?, onPicked: (id: String, name: String) -> Unit) {
        val candidates = RuleStorage.load(this).filter { it.id != excludeRuleId }
        if (candidates.isEmpty()) {
            Toast.makeText(this, "Ana Akış'ta başka kural yok — önce bir 'arama' kuralı oluştur", Toast.LENGTH_LONG).show()
            return
        }
        val labels = candidates.map { "${it.name} (${it.alternatives.firstOrNull()?.conditionKind ?: "?"})" }.toTypedArray()
        overlayDialog()
            .setTitle("Referans Kural Seç")
            .setItems(labels) { _, idx -> val rule = candidates[idx]; onPicked(rule.id, rule.name) }
            .create().showOverlay()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki bir dokunma/kaydırma adımının HOLD süresini düzenler. */
    private fun showHoldEditDialog(extra: ExtraAction, onDone: () -> Unit) {
        val ctx = this
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        if (extra.type == "TAP") {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD — noktada kaç ms basılı tutulsun:" })
            val input = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.holdMs.toString()) }
            container.addView(input)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süresi").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.holdMs = input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        } else {
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (başlangıç) — hareket etmeden önce kaç ms beklesin:" })
            val startInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldStartMs.toString()) }
            container.addView(startInput)
            container.addView(TextView(ctx).apply { text = "⏱️ HOLD (bitiş) — vardıktan sonra kaç ms daha beklesin:"; setPadding(0, 16, 0, 0) })
            val endInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.swipeHoldEndMs.toString()) }
            container.addView(endInput)
            container.addView(TextView(ctx).apply { text = "⏱️ DELAY — tamamlandıktan sonra sıradakine geçmeden önce kaç ms beklesin:"; setPadding(0, 16, 0, 0) })
            val delayInput = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(extra.postDelayMs.toString()) }
            container.addView(delayInput)
            overlayDialog().setTitle("Basılı Tutma / Bekleme Süreleri").setView(container)
                .setPositiveButton("Kaydet") { _, _ ->
                    extra.swipeHoldStartMs = startInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.swipeHoldEndMs = endInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    extra.postDelayMs = delayInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                    onDone()
                }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        }
    }

    /** BAŞARILI OLUNCA / BULUNAMAZSA listeleri için tek kullanımlık kopyala/kes panosu. */
    /**
     * "🔍 Tarama Alanı Ekle" (BAŞARILI/BULUNAMAZSA listesinde): ekrana koşullu bir
     * alan çizdirir, otomatik bir Fonksiyona kaydeder, sonra o Fonksiyonu çağıran
     * bir "🔧 Fonksiyon Çağır" adımını listeye ekler — böylece sıra içinde
     * GERÇEK bir koşullu tespit (iç içe tarama) yapılabilir.
     */
    private fun startExtraTabScan(callerRegion: ActiveRegion, list: MutableList<ExtraAction>, label: String) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val fnName = "🔍 ${callerRegion.name.ifBlank { "Tarama" }} → $label"
        val fn = FunctionDefinition(UUID.randomUUID().toString(), fnName)
        FunctionStorage.upsert(this, fn)
        val scanRegion = addRegionWindow()
        scanRegion.saveScope = SaveScope.Function(fn.id)
        scanRegion.label.text = "🔍 $label → yeni tarama"
        scanRegion.onSavedCallback = {
            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
            com.bigboss.app.storage.EngineAssembler.refresh(this)
            Toast.makeText(this, "Tarama eklendi: ${fn.name}", Toast.LENGTH_SHORT).show()
            openRegionConfigDialog(callerRegion)
        }
        Toast.makeText(this, "Bu alan \"$label\" listesine bir TARAMA (koşullu tespit) olarak eklenecek", Toast.LENGTH_LONG).show()
    }

    /** BAŞARILI/BULUNAMAZSA listesindeki dokunma/kaydırma noktalarını VE tarama alanlarını ekranda gösterir (Çalışma Alanı ile aynı mekanizma). */
    private fun showExtraListOnScreen(region: ActiveRegion, isFail: Boolean, list: List<ExtraAction>, label: String) {
        // On Success/On Fail modu da TEK çizim motorundan geçer (renderExtra set → renderNow).
        renderExtra = Triple(region, isFail, list)
        renderLabel = label
        renderNow()
        val count = list.count { it.type == "TAP" || it.type == "SWIPE" || it.type == "CALL_FUNCTION" }
        if (count == 0) Toast.makeText(this, "$label listesinde gösterilecek nokta/alan yok", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "$label listesi ekranda gösteriliyor ($count öğe) — sürükle/dokun/basılı-tut çalışır, kapatmak için tekrar 🗺️", Toast.LENGTH_LONG).show()
    }

    /** On Success/On Fail listesini çizer — SADECE renderNow() içinden çağrılır (view listesi + temizleme ortak). */
    private fun drawExtraListNow(region: ActiveRegion, isFail: Boolean, list: List<ExtraAction>) {
        // Bu liste düzenlenen bölgenin KENDİ tarama kutusunun bir parçası DEĞİL — TÜM aktif
        // bölgeleri gizle, SADECE bu listenin öğeleri görünsün.
        activeRegions.forEach { r ->
            r.container.visibility = View.GONE
            r.label.visibility = View.GONE
        }
        fun liveSave() { region.onRectChangedListeners.forEach { it() } }
        list.forEachIndexed { i, extra ->
            when (extra.type) {
                "TAP" -> {
                    lateinit var m: LiveMarkerHandle
                    m = placeLiveMarker("👆${i + 1}", extra.x, extra.y,
                        onMove = { x, y -> extra.x = x; extra.y = y; liveSave() },
                        onTap = { showExtraTapEditor(extra) },
                        onLongPress = { showExtraActionContextMenu(region, isFail, extra, listOf(m)) }
                    )
                    workspaceLiveMarkers.add(m.view)
                }
                "SWIPE" -> {
                    val markerSize = (34 * resources.displayMetrics.density).toInt()
                    val markers = mutableListOf<LiveMarkerHandle>()
                    var frameViewRef: View? = null
                    frameViewRef = addSwipeFrame(listOf(extra.x to extra.y, extra.x2 to extra.y2), markerSize) { dx, dy ->
                        markers.getOrNull(0)?.let { shiftLiveMarker(it, dx, dy); extra.x = it.params.x + it.size / 2; extra.y = it.params.y + it.size / 2 }
                        markers.getOrNull(1)?.let { shiftLiveMarker(it, dx, dy); extra.x2 = it.params.x + it.size / 2; extra.y2 = it.params.y + it.size / 2 }
                        liveSave()
                    }
                    frameViewRef?.let { workspaceLiveMarkers.add(it) }
                    markers.add(placeLiveMarker("${i + 1}.1", extra.x, extra.y,
                        onMove = { x, y -> extra.x = x; extra.y = y; liveSave() },
                        onTap = { showExtraSwipeEditor(extra) },
                        onLongPress = { showExtraActionContextMenu(region, isFail, extra, markers, frameViewRef) }
                    ))
                    markers.add(placeLiveMarker("${i + 1}.2", extra.x2, extra.y2,
                        onMove = { x, y -> extra.x2 = x; extra.y2 = y; liveSave() },
                        onTap = { showExtraSwipeEditor(extra) },
                        onLongPress = { showExtraActionContextMenu(region, isFail, extra, markers, frameViewRef) }
                    ))
                    workspaceLiveMarkers.add(markers[0].view); workspaceLiveMarkers.add(markers[1].view)
                }
                "CALL_FUNCTION" -> {
                    val fnRules = FunctionStorage.load(this).find { it.id == extra.functionId }?.rules
                        ?: ActionGroupStorage.load(this).find { it.id == extra.functionId }?.rules
                    fnRules?.filter { !it.id.endsWith("-fail") && it.alternatives.isNotEmpty() }?.forEach { r ->
                        addWorkspaceBox(r, SaveScope.Function(extra.functionId ?: ""))
                    }
                }
            }
        }
    }

    /**
     * KULLANICI İSTEĞİ: "tüm butonları global düşünmeliyiz" — eskiden On Success/On Fail'in
     * KENDİ, AYRI bir panosu (extraActionClipboard) vardı; Ana Akış/Fonksiyon'da kopyalanan bir
     * kural BURADA hiç görünmüyordu (ve tam tersi) — İKİ FARKLI pano birbirini TANIMIYORDU. Artık
     * On Success/On Fail de TEK, GERÇEKTEN global panoyu (`RuleClipboard`) kullanıyor — bu iki
     * fonksiyon `ExtraAction` (sadece bu dosyaya özel, private) ile `RuleDefinition` (global pano
     * TİPİ) arasında köprü kuruyor.
     */
    private fun extraActionToRuleDefinition(extra: ExtraAction): RuleDefinition {
        val def = RuleDefinition(id = java.util.UUID.randomUUID().toString(), name = "📋 ${extra.type}", actionType = extra.type)
        def.actionX = extra.x; def.actionY = extra.y; def.actionX2 = extra.x2; def.actionY2 = extra.y2
        def.actionHoldMs = extra.holdMs; def.actionRepeatCount = extra.repeat; def.actionPostDelayMs = extra.postDelayMs
        def.swipeHoldStartMs = extra.swipeHoldStartMs; def.swipeHoldEndMs = extra.swipeHoldEndMs
        def.swipeDurationMs = extra.swipeDurationMs
        def.callFunctionId = extra.functionId; def.callFunctionRepeat = extra.repeat
        def.playRecordId = extra.recordId
        if (extra.type == "WAIT") def.actionPostDelayMs = extra.waitMs
        return def
    }

    private fun ruleDefinitionToExtraAction(def: RuleDefinition): ExtraAction? {
        if (def.alternatives.isNotEmpty()) return null // GERÇEK bir koşulu (Image/Text/Color Detection) olan kurallar ExtraAction'a dönüşemez
        val extra = ExtraAction(type = def.actionType)
        extra.x = def.actionX; extra.y = def.actionY; extra.x2 = def.actionX2; extra.y2 = def.actionY2
        extra.holdMs = def.actionHoldMs; extra.repeat = def.actionRepeatCount; extra.postDelayMs = def.actionPostDelayMs
        extra.swipeHoldStartMs = def.swipeHoldStartMs; extra.swipeHoldEndMs = def.swipeHoldEndMs
        extra.swipeDurationMs = def.swipeDurationMs
        extra.functionId = def.callFunctionId; extra.functionName = FunctionStorage.load(this).find { it.id == def.callFunctionId }?.name ?: ""
        extra.recordId = def.playRecordId
        if (def.actionType == "WAIT") extra.waitMs = def.actionPostDelayMs
        return extra
    }

    /** "Variables" sayfasındaki Kopyala/Kes/Yapıştır için — tek kullanımlık bellek panosu. */
    private var variableClipboard: com.bigboss.app.storage.GlobalVariableDefinition? = null

    // ==================== Sürüklenebilir Numaralı Click İşaretçileri (Macrorify tarzı) ====================
    // Ana akıştaki her TAP/SWIPE kuralı, ekranda sıra-numaralı bir daire olarak görünür.
    // Sürükleyip bırakınca koordinatı güncellenir ve kalıcı olarak kaydedilir.
    // Kullanıcı gizle ikonuna basana kadar ekranda kalır.

    private data class ClickMarker(
        val view: View,
        val params: WindowManager.LayoutParams,
        val ruleId: String,
        val pointIndex: Int,        // TAP için 0; SWIPE için noktanın sırası (0-based)
        val isTap: Boolean,
        var cx: Int = 0,            // anlık merkez X (ok çizimi için)
        var cy: Int = 0             // anlık merkez Y
    )
    private val clickMarkers = mutableListOf<ClickMarker>()
    /** `addSwipeFrame` ile oluşturulan TÜM taşıma çerçevesi görünümleri — showClickMarkers()
     *  her çağrıldığında (sayfa değişimi, düzenleme sonrası yeniden çizim vb.) HAYALET pencere
     *  BİRİKMESİN diye clearClickMarkersViewsOnly()'de bunlarla birlikte temizlenir. */
    private val swipeFrameViews = mutableListOf<View>()
    private var clickMarkersVisible = false
    private var clickMarkerPage = 0                 // geçerli sayfa (0-based)
    private val MARKERS_PER_PAGE = 10               // Macrorify: 10 komuttan sonra yeni sayfa

    /** SWIPE kurallarının çok-noktalı yollarını (polyline + ok) çizen tam-ekran şeffaf katman. */
    private var swipeArrowLayer: SwipeArrowView? = null
    private var swipeArrowParams: WindowManager.LayoutParams? = null

    /** Bir kaydırmanın tüm noktalarını sırayla birleştiren yol. Noktalar sürüklendikçe güncellenir. */
    private inner class SwipeArrowView(context: android.content.Context) : View(context) {
        // ruleId -> düz polyline [x0,y0,x1,y1,x2,y2,...]
        val paths = mutableMapOf<String, IntArray>()
        private val linePaint = android.graphics.Paint().apply {
            color = Color.parseColor("#3B9EE8"); strokeWidth = 6f
            style = android.graphics.Paint.Style.STROKE; isAntiAlias = true
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        private val headPaint = android.graphics.Paint().apply {
            color = Color.parseColor("#3B9EE8"); style = android.graphics.Paint.Style.FILL; isAntiAlias = true
        }
        private val pointPaint = android.graphics.Paint().apply {
            color = Color.parseColor("#FFFFFF"); style = android.graphics.Paint.Style.FILL; isAntiAlias = true
        }
        private val pointStrokePaint = android.graphics.Paint().apply {
            color = Color.parseColor("#3B9EE8"); strokeWidth = 4f
            style = android.graphics.Paint.Style.STROKE; isAntiAlias = true
        }
        override fun onDraw(canvas: android.graphics.Canvas) {
            paths.values.forEach { poly ->
                if (poly.size < 4) return@forEach
                // Segment çizgileri
                var i = 0
                while (i + 3 < poly.size) {
                    val sx = poly[i].toFloat(); val sy = poly[i + 1].toFloat()
                    val ex = poly[i + 2].toFloat(); val ey = poly[i + 3].toFloat()
                    canvas.drawLine(sx, sy, ex, ey, linePaint)
                    i += 2
                }
                // Son segmentin ucuna tek ok başı
                val lastSx = poly[poly.size - 4].toFloat(); val lastSy = poly[poly.size - 3].toFloat()
                val lastEx = poly[poly.size - 2].toFloat(); val lastEy = poly[poly.size - 1].toFloat()
                val angle = kotlin.math.atan2((lastEy - lastSy).toDouble(), (lastEx - lastSx).toDouble())
                val headLen = 28f; val headAng = Math.toRadians(26.0)
                val p = android.graphics.Path()
                p.moveTo(lastEx, lastEy)
                p.lineTo((lastEx - headLen * kotlin.math.cos(angle - headAng)).toFloat(), (lastEy - headLen * kotlin.math.sin(angle - headAng)).toFloat())
                p.lineTo((lastEx - headLen * kotlin.math.cos(angle + headAng)).toFloat(), (lastEy - headLen * kotlin.math.sin(angle + headAng)).toFloat())
                p.close()
                canvas.drawPath(p, headPaint)
                // Her noktaya küçük daire (nokta konumlarını vurgula)
                i = 0
                while (i + 1 < poly.size) {
                    val cx = poly[i].toFloat(); val cy = poly[i + 1].toFloat()
                    canvas.drawCircle(cx, cy, 7f, pointPaint)
                    canvas.drawCircle(cx, cy, 7f, pointStrokePaint)
                    i += 2
                }
            }
        }
    }

    /**
     * Bir SWIPE kuralının noktalarını TEK biçimde döndürür: çoklu-nokta yolu (swipePathPoints)
     * varsa onu, yoksa eski 2-nokta temsilini (actionX/Y + actionX2/Y2) sentezler.
     */
    private fun swipePointsOf(rule: RuleDefinition): MutableList<com.bigboss.app.storage.SwipePointData> {
        if (rule.swipePathPoints.size >= 2) return rule.swipePathPoints
        return mutableListOf(
            com.bigboss.app.storage.SwipePointData(rule.actionX, rule.actionY, rule.swipeHoldStartMs),
            com.bigboss.app.storage.SwipePointData(rule.actionX2, rule.actionY2, rule.swipeHoldEndMs)
        )
    }

    /** Noktaları kurala yazar; geriye dönük uyum için ilk/son noktayı eski alanlara da yansıtır. */
    private fun writeSwipePoints(rule: RuleDefinition, pts: List<com.bigboss.app.storage.SwipePointData>) {
        rule.swipePathPoints = pts.toMutableList()
        if (pts.isNotEmpty()) { rule.actionX = pts.first().x; rule.actionY = pts.first().y; rule.swipeHoldStartMs = pts.first().holdMs }
        if (pts.size >= 2) { rule.actionX2 = pts.last().x; rule.actionY2 = pts.last().y; rule.swipeHoldEndMs = pts.last().holdMs }
    }

    /** Ana akıştaki tüm TAP/SWIPE kurallarını numaralı sürüklenebilir dairelerle gösterir (sayfalı). */
    private fun showClickMarkers() {
        // Ana Akış = varsayılan KALICI kapsam. Artık TEK çizim motorundan geçer (renderNow).
        // Bir Click/Swipe eklenince/düzenlenince buradan yeniden çizilir; sayfalama kaldırıldı,
        // tüm öğeler tek, tutarlı görsel dille (TAP/SWIPE=numaralı işaretçi, tespit=mavi kutu) çizilir.
        renderScopeSel = SaveScope.MainFlow
        renderRuleIds = null
        renderExtra = null
        renderLabel = "🏠 Ana Akış"
        renderNow()
        clickMarkersVisible = true
    }

    /** ‹ önceki sayfa. */
    private fun clickMarkersPrevPage() {
        if (!clickMarkersVisible) { showClickMarkers(); return }
        if (clickMarkerPage > 0) { clickMarkerPage--; showClickMarkers() }
        else Toast.makeText(this, "İlk sayfadasın", Toast.LENGTH_SHORT).show()
    }

    /** › sonraki sayfa. */
    private fun clickMarkersNextPage() {
        if (!clickMarkersVisible) { showClickMarkers(); return }
        val rules = RuleStorage.load(this).filter { it.actionType == "TAP" || it.actionType == "SWIPE" }
        val totalPages = (rules.size + MARKERS_PER_PAGE - 1) / MARKERS_PER_PAGE
        if (clickMarkerPage < totalPages - 1) { clickMarkerPage++; showClickMarkers() }
        else Toast.makeText(this, "Son sayfadasın", Toast.LENGTH_SHORT).show()
    }

    /** Tam-ekran şeffaf yol katmanını (dokunulamaz) bir kez oluşturur. */
    private fun ensureSwipeArrowLayer() {
        if (swipeArrowLayer != null) return
        val layer = SwipeArrowView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        try {
            windowManager?.addView(layer, lp)
            swipeArrowLayer = layer; swipeArrowParams = lp
        } catch (e: Exception) {
            android.util.Log.e("BigBossClickMarker", "Yol katmanı eklenemedi", e)
        }
    }

    /** Tek bir numaralı, sürüklenebilir daire ekler. Tap=düzenle, basılı tut=menü, sürükle=taşı. */
    private fun addClickMarker(px: Int, py: Int, order: Int, pointIndex: Int, ruleId: String, isTap: Boolean) {
        val density = resources.displayMetrics.density
        val size = (34 * density).toInt()
        val accentBlue = Color.parseColor("#3B9EE8")

        val fingerIdx = pointIndex / 100
        val ptIdx = pointIndex % 100
        // Macrorify belgesindeki nokta etiketleme: 1-1, 1-2, 2-1, 2-2 ...
        val label = if (isTap) "$order" else if (fingerIdx == 0) "$order-${ptIdx + 1}" else "$order-${fingerIdx + 1}-${ptIdx + 1}"
        val circle = TextView(this).apply {
            text = label
            setTextColor(accentBlue)
            textSize = if (label.length > 2) 10f else 13f
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F0FFFFFF"))
                setStroke((2.5f * density).toInt(), accentBlue)
                cornerRadius = size / 2f
            }
        }
        val params = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px - size / 2; y = py - size / 2 }

        val marker = ClickMarker(circle, params, ruleId, pointIndex, isTap, px, py)

        var downRawX = 0f; var downRawY = 0f; var startX = 0; var startY = 0; var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            if (!moved) {
                longPressed = true
                // Basılı tut → bağlam menüsü (TAP ve SWIPE için AYNI zenginlikte).
                RuleStorage.load(this).find { it.id == ruleId }?.let { rule ->
                    if (rule.actionType == "SWIPE") showSwipeContextMenu(rule)
                    else showTapContextMenu(rule)
                }
            }
        }
        circle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY; startX = params.x; startY = params.y
                    moved = false; longPressed = false
                    circle.postDelayed(longPressRunnable, 500)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt(); val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        moved = true; circle.removeCallbacks(longPressRunnable)
                    }
                    if (!longPressed) {
                        params.x = startX + dx; params.y = startY + dy
                        try { windowManager?.updateViewLayout(circle, params) } catch (e: Exception) {}
                        marker.cx = params.x + size / 2; marker.cy = params.y + size / 2
                        updateSwipeArrowFor(ruleId, pointIndex, marker.cx, marker.cy)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    circle.removeCallbacks(longPressRunnable)
                    if (longPressed) { /* menü zaten açıldı */ }
                    else if (moved) {
                        val newX = params.x + size / 2; val newY = params.y + size / 2
                        saveMarkerPosition(ruleId, pointIndex, newX, newY)
                    } else {
                        // Kısa dokunuş → SWIPE nokta editörü / TAP hafif editörü (İKİSİ DE işaretçileri SİLMİYOR).
                        RuleStorage.load(this).find { it.id == ruleId }?.let { rule ->
                            if (rule.actionType == "SWIPE") showSwipePointEditor(rule, pointIndex)
                            else showTapPointEditor(rule)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { circle.removeCallbacks(longPressRunnable); true }
                else -> false
            }
        }
        try {
            windowManager?.addView(circle, params)
            clickMarkers.add(marker)
        } catch (e: Exception) {
            android.util.Log.e("BigBossClickMarker", "İşaretçi eklenemedi", e)
        }
    }

    /** Bir nokta sürüklenirken o kuralın yolundaki ilgili noktayı günceller ve yeniden çizer. */
    private fun updateSwipeArrowFor(ruleId: String, pointIndex: Int, cx: Int, cy: Int) {
        val poly = swipeArrowLayer?.paths?.get(ruleId) ?: return
        val i = pointIndex * 2
        if (i + 1 < poly.size) { poly[i] = cx; poly[i + 1] = cy; swipeArrowLayer?.invalidate() }
    }

    /** Sürüklenen işaretçinin yeni koordinatını ilgili kurala/noktaya yazar (kalıcı). */
    private fun saveMarkerPosition(ruleId: String, pointIndex: Int, newX: Int, newY: Int) {
        val rule = RuleStorage.load(this).find { it.id == ruleId } ?: return
        if (rule.actionType == "TAP") {
            rule.actionX = newX; rule.actionY = newY
        } else {
            val fingerIdx = pointIndex / 100
            val ptIdx = pointIndex % 100
            if (fingerIdx == 0) {
                val pts = swipePointsOf(rule)
                if (ptIdx in pts.indices) { pts[ptIdx].x = newX; pts[ptIdx].y = newY }
                writeSwipePoints(rule, pts)
            } else {
                // GERÇEK çoklu parmak: (fingerIdx-1)., (fingerIdx). EK parmağın noktasını güncelle.
                val extraIdx = fingerIdx - 1
                if (extraIdx in rule.swipeExtraFingerPaths.indices) {
                    val fingerPts = rule.swipeExtraFingerPaths[extraIdx]
                    if (ptIdx in fingerPts.indices) { fingerPts[ptIdx].x = newX; fingerPts[ptIdx].y = newY }
                }
            }
        }
        RuleStorage.upsert(this, rule)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
    }

    /** Tüm click işaretçilerini ve swipe ok katmanını ekrandan kaldırır. */
    private fun clearClickMarkers() {
        clearRenderViews()
        clickMarkerPage = 0
    }

    /** Sadece ekrandaki marker view'larını kaldırır (sayfa değişiminde; görünürlük bayrağını korur). */
    private fun clearClickMarkersViewsOnly() { clearRenderViews() }

    // ==================== REC — Kayıt Modu (Record) ====================
    // Macrorify: REC ile ekranda yapılan gerçek dokunuş/kaydırmalar zaman damgalarıyla
    // yakalanır ve bir "kayıt" olur; sonra Play Record ile birebir oynatılır.
    // Bu sürüm TEK PARMAK (dokunuş + kaydırma). Çok-parmak sonraki sürümde.

    private var recording = false
    private var recordPaused = false
    private var recordCatcher: View? = null           // tam-ekran dokunuş yakalayıcı
    private var recordControlPanel: View? = null       // ▶️ / ⏹️ kontrol paneli
    private var recordFrameView: View? = null          // yeşil çerçeve (kayıt aktif göstergesi)
    private val recordEvents = mutableListOf<com.bigboss.app.storage.RecordEvent>()
    private var recordStartTime = 0L
    private var recordAccumulatedMs = 0L               // pause'lar arası biriken süre

    /** REC butonu: kayıt modunu başlatır (kontrol panelini gösterir). */
    private fun startRecordMode() {
        if (recording) { Toast.makeText(this, "Zaten kayıt modundasın", Toast.LENGTH_SHORT).show(); return }
        recordEvents.clear()
        recordAccumulatedMs = 0L
        recordPaused = true // panel açık ama henüz kayıt başlamadı (Start bekleniyor)
        recording = true
        // Paneli göstermek için ana sidebar'ı gizle (karışmasın)
        sidebarCollapsed = true; rebuildPanel()
        showRecordControlPanel()
        Toast.makeText(this, "Kayıt Modu — ▶️ ile başla, dokunuşların yakalanacak", Toast.LENGTH_LONG).show()
    }

    /** ▶️ / ⏹️ kontrol panelini gösterir. */
    private fun showRecordControlPanel() {
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F7F7F9"))
            setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
        }
        val btnSize = (44 * density).toInt()
        val startBtn = android.widget.ImageView(this).apply {
            setImageResource(com.bigboss.app.R.drawable.ic_play)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
            setOnClickListener { toggleRecordCapture() }
        }
        val stopBtn = android.widget.ImageView(this).apply {
            setImageResource(com.bigboss.app.R.drawable.ic_stop)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
            setOnClickListener { finishRecordMode() }
        }
        panel.addView(startBtn); panel.addView(stopBtn)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 200 }
        try { windowManager?.addView(panel, lp); recordControlPanel = panel } catch (e: Exception) {}
    }

    /** ▶️: kayıt yakalamayı başlat/duraklat (pause). */
    private fun toggleRecordCapture() {
        if (recordPaused) {
            // Başlat / devam et
            recordPaused = false
            recordStartTime = System.currentTimeMillis()
            showRecordFrame()
            startRecordCatcher()
            Toast.makeText(this, "▶️ Kayıt başladı — çerçeve görününce dokun", Toast.LENGTH_SHORT).show()
        } else {
            // Duraklat: o ana kadar geçen süreyi biriktir
            recordPaused = true
            recordAccumulatedMs += System.currentTimeMillis() - recordStartTime
            stopRecordCatcher()
            hideRecordFrame()
            Toast.makeText(this, "⏸️ Duraklatıldı — ▶️ ile devam", Toast.LENGTH_SHORT).show()
        }
    }

    /** Kaydın aktif olduğunu gösteren yeşil çerçeve (dokunulamaz). */
    private fun showRecordFrame() {
        if (recordFrameView != null) return
        val density = resources.displayMetrics.density
        val frame = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke((3 * density).toInt(), Color.parseColor("#00D9A5"))
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        try { windowManager?.addView(frame, lp); recordFrameView = frame } catch (e: Exception) {}
    }
    private fun hideRecordFrame() {
        recordFrameView?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        recordFrameView = null
    }

    /**
     * Tam-ekran dokunuş yakalayıcı. DOWN→UP arası hareketi ölçer:
     * kısa mesafe = TAP, uzun mesafe = SWIPE. Zaman damgasıyla kaydeder.
     * NOT: Yakalayıcı dokunuşları TÜKETİR (alttaki uygulamaya geçmez) — Macrorify de
     * kayıt sırasında böyle yapar; bu yüzden "sadece çerçeve görünürken dokun" uyarısı var.
     */
    private fun startRecordCatcher() {
        if (recordCatcher != null) return
        val catcher = View(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        var downX = 0f; var downY = 0f; var downTime = 0L
        catcher.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val upX = event.rawX; val upY = event.rawY
                    val dur = (System.currentTimeMillis() - downTime).coerceAtLeast(1)
                    val dist = kotlin.math.hypot((upX - downX).toDouble(), (upY - downY).toDouble())
                    val offset = recordAccumulatedMs + (downTime - recordStartTime)
                    if (dist < 20) {
                        recordEvents.add(com.bigboss.app.storage.RecordEvent("TAP", downX.toInt(), downY.toInt(), durationMs = dur, startOffsetMs = offset))
                    } else {
                        recordEvents.add(com.bigboss.app.storage.RecordEvent("SWIPE", downX.toInt(), downY.toInt(), upX.toInt(), upY.toInt(), dur, offset))
                    }
                    true
                }
                else -> true
            }
        }
        try { windowManager?.addView(catcher, lp); recordCatcher = catcher } catch (e: Exception) {}
    }
    private fun stopRecordCatcher() {
        recordCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        recordCatcher = null
    }

    /** Resources ekranından (🎬 Kayıt ikonu) LOCAL mı GLOBAL mı hedeflendiğini taşır — startRecordMode() öncesi ayarlanır. */
    private var pendingRecordScope: String = "LOCAL"

    /** ⏹️: kaydı bitir, isimlendir ve sakla. */
    private fun finishRecordMode() {
        stopRecordCatcher(); hideRecordFrame()
        recordControlPanel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        recordControlPanel = null
        recording = false; recordPaused = false
        sidebarCollapsed = false; rebuildPanel()

        if (recordEvents.isEmpty()) {
            Toast.makeText(this, "Boş kayıt — hiçbir dokunuş yakalanmadı", Toast.LENGTH_SHORT).show()
            pendingRecordScope = "LOCAL"
            return
        }
        val eventsCopy = recordEvents.toMutableList()
        val scope = pendingRecordScope
        pendingRecordScope = "LOCAL"
        val existingCount = if (scope == "GLOBAL") com.bigboss.app.storage.GlobalRecordStorage.load(this).size else com.bigboss.app.storage.RecordStorage.load(this).size
        val nameInput = EditText(this).apply { hint = "Kayıt adı"; setText("Kayıt ${existingCount + 1}") }
        overlayDialog().setTitle("Kayıt Tamamlandı (${eventsCopy.size} olay)").setView(nameInput)
            .setPositiveButton("Kaydet") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "İsimsiz Kayıt" }
                val record = com.bigboss.app.storage.RecordDefinition(UUID.randomUUID().toString(), name, eventsCopy)
                if (scope == "GLOBAL") com.bigboss.app.storage.GlobalRecordStorage.upsert(this, record)
                else com.bigboss.app.storage.RecordStorage.upsert(this, record)
                Toast.makeText(this, "Kaydedildi: $name — 🎬 Kayıtlar'dan oynatabilirsin", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("At", null).create().showOverlay()
    }

    /** Kaydı motorla oynatır (olayları Action'a çevirip sırayla çalıştırır). */
    private fun playRecord(record: com.bigboss.app.storage.RecordDefinition) {
        val executor = BigBossAccessibilityService.instance
        if (executor == null) { Toast.makeText(this, "Erişilebilirlik servisi kapalı", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this, "▶️ Oynatılıyor: ${record.name}", Toast.LENGTH_SHORT).show()
        Thread {
            com.bigboss.app.storage.RecordStorage.toActions(record).forEach { action ->
                try { executor.execute(action) } catch (e: Exception) {}
            }
        }.start()
    }

    /** 🎬 Kayıtlar menüsü: oynat / sil. */
    private fun showRecordsMenu() {
        val records = com.bigboss.app.storage.RecordStorage.load(this)
        val options = mutableListOf("🔴 Yeni Kayıt (REC)")
        options.addAll(records.map { "🎬 ${it.name} (${it.events.size} olay)" })
        overlayDialog().setTitle("Kayıtlar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) { startRecordMode(); return@setItems }
            val record = records[index - 1]
            val actions = arrayOf("▶️ Oynat", "🗑 Sil")
            overlayDialog().setTitle(record.name).setItems(actions) { _, which ->
                when (which) {
                    0 -> playRecord(record)
                    1 -> { com.bigboss.app.storage.RecordStorage.delete(this, record.id); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() }
                }
            }.setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** Kayıt modu kaynaklarını temizler (kapanış/mod değişiminde). */
    private fun clearRecordMode() {
        stopRecordCatcher(); hideRecordFrame()
        recordControlPanel?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        recordControlPanel = null
        recording = false; recordPaused = false
    }

    // ---- Görsel 5: Nokta parametreleri (Coordinate / Scale / Hold / Speed) ----
    /** Macrorify swipe hız presetleri — piksel/12ms (büyük = hızlı). */
    private val swipeSpeedPresets = listOf("Çok Yavaş" to 6, "Yavaş" to 12, "Normal" to 20, "Hızlı" to 45, "Çok Hızlı" to 90, "Flick" to 220)

    private fun showSwipePointEditor(rule: RuleDefinition, pointIndex: Int) {
        val ctx = this
        val density = resources.displayMetrics.density
        val fingerIdx = pointIndex / 100
        val ptIdx = pointIndex % 100
        val isExtraFinger = fingerIdx > 0
        val pts = if (isExtraFinger) {
            val extraIdx = fingerIdx - 1
            if (extraIdx !in rule.swipeExtraFingerPaths.indices) return
            rule.swipeExtraFingerPaths[extraIdx]
        } else swipePointsOf(rule)
        if (ptIdx !in pts.indices) return
        val pt = pts[ptIdx]

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun label(t: String) = TextView(ctx).apply { text = t; setTextColor(TEXT_SECONDARY); textSize = 12f; setPadding(0, (10 * resources.displayMetrics.density).toInt(), 0, 2) }

        root.addView(TextView(ctx).apply { text = "(${pt.x}, ${pt.y})"; setTextColor(TEXT_PRIMARY); textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD) })

        // Koordinat (x, y) — birleşik değişken sistemi sayesinde "değişkenAdı" da yazılabilir
        root.addView(label("Koordinat (x, y) — sayı ya da değişken"))
        val coordInput = EditText(ctx).apply { setText("${pt.x}, ${pt.y}") }
        root.addView(coordInput)

        // Scale: Fixed / Sticky
        root.addView(label("Ölçekleme (Scale)"))
        val scaleGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.HORIZONTAL }
        val rbFixed = android.widget.RadioButton(ctx).apply { text = "Fixed"; id = 1; setTextColor(TEXT_PRIMARY) }
        val rbSticky = android.widget.RadioButton(ctx).apply { text = "Sticky"; id = 2; setTextColor(TEXT_PRIMARY) }
        scaleGroup.addView(rbFixed); scaleGroup.addView(rbSticky)
        if (pt.scale == "STICKY") rbSticky.isChecked = true else rbFixed.isChecked = true
        root.addView(scaleGroup)

        // Hold
        root.addView(label("Hold — bu noktada bekleme (ms) — 💡 ile değişken"))
        val holdInput = EditText(ctx).apply { setText(pt.holdVarName ?: pt.holdMs.toString()) }
        root.addView(wrapWithBulb(holdInput))

        // Speed
        root.addView(label("Speed — sonraki noktaya hız (piksel/12ms) — 💡 ile değişken"))
        val speedInput = EditText(ctx).apply { setText(pt.speedVarName ?: pt.speed.toString()) }
        root.addView(wrapWithBulb(speedInput))
        root.addView(label("Hız preseti (dokun → yukarıdaki Speed'i doldurur):"))
        val speedPresetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (4 * density).toInt(), 0, 0) }
        swipeSpeedPresets.forEach { (nm, v) ->
            val selected = (pt.speedVarName == null && pt.speed == v)
            val chip = TextView(ctx).apply {
                text = nm
                textSize = 11f
                setTextColor(if (selected) Color.WHITE else Color.parseColor("#3B9EE8"))
                setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 24f * density
                    setColor(if (selected) Color.parseColor("#3B9EE8") else Color.parseColor("#EAF4FD"))
                }
                setOnClickListener { speedInput.setText(v.toString()) }
            }
            speedPresetRow.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins((4 * density).toInt(), 0, (4 * density).toInt(), 0)
            })
        }
        root.addView(android.widget.HorizontalScrollView(ctx).apply { addView(speedPresetRow) })

        overlayDialog()
            .setTitle(if (isExtraFinger) "🤚 Parmak ${fingerIdx + 1} — Nokta ${ptIdx + 1}" else "Nokta ${ptIdx + 1}")
            .setView(android.widget.ScrollView(ctx).apply { addView(root) })
            .setPositiveButton("Kaydet") { _, _ ->
                // Koordinat
                val parts = coordInput.text.toString().split(",").map { it.trim() }
                if (parts.size == 2) {
                    parts[0].toIntOrNull()?.let { pt.x = it }
                    parts[1].toIntOrNull()?.let { pt.y = it }
                }
                pt.scale = if (scaleGroup.checkedRadioButtonId == 2) "STICKY" else "FIXED"
                // Hold: {isim} ise varName'e, sayıysa değere
                val holdText = holdInput.text.toString().trim()
                if (holdText.startsWith("{")) { pt.holdVarName = holdText; }
                else { pt.holdVarName = null; pt.holdMs = holdText.toLongOrNull() ?: pt.holdMs }
                val speedText = speedInput.text.toString().trim()
                if (speedText.startsWith("{")) { pt.speedVarName = speedText; }
                else { pt.speedVarName = null; pt.speed = speedText.toIntOrNull() ?: pt.speed }
                if (!isExtraFinger) writeSwipePoints(rule, pts) // ana yol için gerekli — extra parmakta pt zaten doğrudan referans
                RuleStorage.upsert(ctx, rule)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                showClickMarkers() // yeniden çiz
                // KULLANICI RAPORU: "swipe için HERHANGİ bir değeri değiştirirsem çalışmıyor" —
                // exception yok, dispatchGesture reddi/iptali de yok. Bu TANI, kaydedilen verinin
                // DEPODAN GERİ OKUNAN hâlini (motorun GERÇEKTEN göreceği hâli) doğrudan gösteriyor —
                // "veri mi bozuluyor yoksa çalıştırma mı başarısız oluyor" sorusuna KESİN cevap.
                val reloaded = RuleStorage.load(ctx).find { it.id == rule.id }
                if (reloaded == null) {
                    Toast.makeText(ctx, "🔍 TANI: Kural KAYDEDİLEMEDİ — depoda YOK (id: ${rule.id.take(8)})", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "🔍 TANI — Depodan okunan: enabled=${reloaded.enabled} actionType=${reloaded.actionType} " +
                        "(${reloaded.actionX},${reloaded.actionY})→(${reloaded.actionX2},${reloaded.actionY2}) " +
                        "holdStart=${reloaded.swipeHoldStartMs} holdEnd=${reloaded.swipeHoldEndMs} pathPts=${reloaded.swipePathPoints.size}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    /**
     * TAP işaretçisine KISA dokununca açılan HAFİF düzenleyici (showSwipePointEditor'ün TAP
     * karşılığı) — tam 5 sekmeli bölge editörünü AÇMIYOR, bu yüzden işaretçileri SİLMİYOR/
     * ekrandan KAYBOLMUYOR. Sadece koordinat/hold/repeat/delay gibi hızlı ayarlar için.
     * Tam düzenleme (bölge/koşul değiştirme) hâlâ basılı-tutma menüsünden erişilebilir.
     */
    private fun showTapPointEditor(rule: RuleDefinition) {
        val ctx = this
        val density = resources.displayMetrics.density
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun label(t: String) = TextView(ctx).apply { text = t; setTextColor(TEXT_SECONDARY); textSize = 12f; setPadding(0, (10 * density).toInt(), 0, 2) }

        root.addView(TextView(ctx).apply { text = "👆 ${rule.name}"; setTextColor(TEXT_PRIMARY); textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD) })

        root.addView(label("Koordinat (x, y)"))
        val coordInput = EditText(ctx).apply { setText("${rule.actionX}, ${rule.actionY}") }
        root.addView(coordInput)

        root.addView(label("Hold — noktada basılı tutma (ms) — 💡 ile değişken"))
        val holdInput = EditText(ctx).apply { setText(rule.actionHoldVarName ?: rule.actionHoldMs.toString()) }
        root.addView(wrapWithBulb(holdInput))

        root.addView(label("Repeat — kaç kere tıklansın — 💡 ile değişken"))
        val repeatInput = EditText(ctx).apply { setText(rule.actionRepeatVarName ?: rule.actionRepeatCount.toString()) }
        root.addView(wrapWithBulb(repeatInput))

        root.addView(label("Delay — işlem bittikten sonra ek bekleme (ms) — 💡 ile değişken"))
        val delayInput = EditText(ctx).apply { setText(rule.actionPostDelayVarName ?: rule.actionPostDelayMs.toString()) }
        root.addView(wrapWithBulb(delayInput))

        overlayDialog()
            .setTitle("Dokunma Noktası")
            .setView(android.widget.ScrollView(ctx).apply { addView(root) })
            .setPositiveButton("Kaydet") { _, _ ->
                val parts = coordInput.text.toString().split(",").map { it.trim() }
                if (parts.size == 2) {
                    parts[0].toIntOrNull()?.let { rule.actionX = it }
                    parts[1].toIntOrNull()?.let { rule.actionY = it }
                }
                val holdText = holdInput.text.toString().trim()
                if (holdText.startsWith("{")) rule.actionHoldVarName = holdText
                else { rule.actionHoldVarName = null; rule.actionHoldMs = holdText.toLongOrNull() ?: rule.actionHoldMs }
                val repeatText = repeatInput.text.toString().trim()
                if (repeatText.startsWith("{")) rule.actionRepeatVarName = repeatText
                else { rule.actionRepeatVarName = null; rule.actionRepeatCount = repeatText.toIntOrNull() ?: rule.actionRepeatCount }
                val delayText = delayInput.text.toString().trim()
                if (delayText.startsWith("{")) rule.actionPostDelayVarName = delayText
                else { rule.actionPostDelayVarName = null; rule.actionPostDelayMs = delayText.toLongOrNull() ?: rule.actionPostDelayMs }
                RuleStorage.upsert(ctx, rule)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                showClickMarkers() // işaretçileri yeniden çiz — SİLİNMİYOR
            }
            .setNegativeButton("Kapat", null)
            .create().showOverlay()
    }

    /** Basılı-tut bağlam menüsü — TAP karşılığı (showSwipeContextMenu ile AYNI yapı). */
    private fun showTapContextMenu(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Hızlı Düzenle (koordinat/hold/repeat/delay)",
            "🔧 Tam Düzenle (bölge/koşul dahil)",
            "🙈 Gizle",
            "🗑 Sil"
        )
        overlayDialog()
            .setTitle("Dokunma İşlemleri")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showTapPointEditor(rule)
                    1 -> { clearClickMarkers(); editExistingRule(rule, SaveScope.MainFlow) }
                    2 -> clearClickMarkers()
                    3 -> {
                        RuleStorage.deleteRule(this, rule.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        showClickMarkers()
                        Toast.makeText(this, "Dokunma silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    // ---- Görsel 3: Basılı-tut bağlam menüsü ----
    private fun showSwipeContextMenu(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Swipe'ı Düzenle",     // Edit Swipe (Repeat/Delay/Wait Next/Randomize)
            "➕ Nokta Ekle",          // Add Point
            "➖ Nokta Çıkar",         // Remove Point
            "🤚 Parmak Ekle (çoklu-dokunuş — pinch/zoom)",   // Add Finger
            "🤚 Parmak Çıkar",        // Remove Finger
            "🙈 Gizle",               // Hide
            "🗑 Sil"                  // Delete
        )
        overlayDialog()
            .setTitle("Kaydırma İşlemleri (${rule.swipeExtraFingerPaths.size + 1} parmak)")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { clearClickMarkers(); editExistingRule(rule, SaveScope.MainFlow) }
                    1 -> addSwipePoint(rule)
                    2 -> removeSwipePoint(rule)
                    3 -> addSwipeFinger(rule)
                    4 -> removeSwipeFinger(rule)
                    5 -> clearClickMarkers()
                    6 -> {
                        RuleStorage.deleteRule(this, rule.id)
                        com.bigboss.app.storage.EngineAssembler.refresh(this)
                        showClickMarkers()
                        Toast.makeText(this, "Kaydırma silindi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /**
     * "🤚 Parmak Ekle" (Macrorify'daki GERÇEK çoklu-parmak — pinch/zoom/çoklu-dokunuş için).
     * Yeni parmağın 2 noktasını (başlangıç/bitiş) seçtirir, `swipeExtraFingerPaths`'e ekler.
     * En fazla 10 parmak (Android AccessibilityService'in desteklediği sınır).
     */
    private fun addSwipeFinger(rule: RuleDefinition) {
        val fingerCount = rule.swipeExtraFingerPaths.size + 1
        if (fingerCount >= 10) {
            Toast.makeText(this, "En fazla 10 parmak desteklenir", Toast.LENGTH_SHORT).show()
            return
        }
        val fingerNum = fingerCount + 1
        // "Onayla" YOK: yeni parmak HEMEN, ekranın ortasına yakın varsayılan bir konumla eklenir,
        // sonra showClickMarkers() ile (zaten sürükle+canlı-kaydet destekleyen sistem) gösterilir.
        val frame = ScreenCaptureService.latestFrame
        val cx = (frame?.width ?: 1080) / 2; val cy = (frame?.height ?: 1920) / 2
        val offset = fingerNum * 60
        rule.swipeExtraFingerPaths.add(mutableListOf(
            com.bigboss.app.storage.SwipePointData(cx - 100 + offset, cy + offset, 0, 20),
            com.bigboss.app.storage.SwipePointData(cx + 100 + offset, cy + offset, 0, 20)
        ))
        RuleStorage.upsert(this, rule)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        showClickMarkers()
        Toast.makeText(this, "🤚 $fingerNum. parmak eklendi — iki işaretçiyi de istediğin yere sürükle", Toast.LENGTH_LONG).show()
    }

    /** "🤚 Parmak Çıkar" — SON eklenen ek parmağı kaldırır (en az 1 parmak/ana yol her zaman kalır). */
    private fun removeSwipeFinger(rule: RuleDefinition) {
        if (rule.swipeExtraFingerPaths.isEmpty()) {
            Toast.makeText(this, "Zaten tek parmaklı", Toast.LENGTH_SHORT).show()
            return
        }
        rule.swipeExtraFingerPaths.removeAt(rule.swipeExtraFingerPaths.size - 1)
        RuleStorage.upsert(this, rule)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        showClickMarkers()
        Toast.makeText(this, "Son parmak çıkarıldı (${rule.swipeExtraFingerPaths.size + 1} parmak kaldı)", Toast.LENGTH_SHORT).show()
    }

    /** Add Point: yolun sonuna, son iki noktanın ortasından bir nokta ekler. */
    private fun addSwipePoint(rule: RuleDefinition) {
        val pts = swipePointsOf(rule)
        val last = pts.last(); val prev = if (pts.size >= 2) pts[pts.size - 2] else last
        val midX = (last.x + prev.x) / 2 + 40
        val midY = (last.y + prev.y) / 2 + 40
        pts.add(com.bigboss.app.storage.SwipePointData(midX, midY, 0, last.speed, last.scale))
        writeSwipePoints(rule, pts)
        RuleStorage.upsert(this, rule)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        showClickMarkers()
        Toast.makeText(this, "Nokta eklendi (${pts.size} nokta) — sürükleyerek yerleştir", Toast.LENGTH_SHORT).show()
    }

    /** Remove Point: son noktayı çıkarır (min 2 nokta korunur). */
    private fun removeSwipePoint(rule: RuleDefinition) {
        val pts = swipePointsOf(rule)
        if (pts.size <= 2) {
            Toast.makeText(this, "Kaydırma en az 2 nokta içermeli", Toast.LENGTH_SHORT).show()
            return
        }
        pts.removeAt(pts.size - 1)
        writeSwipePoints(rule, pts)
        RuleStorage.upsert(this, rule)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        showClickMarkers()
        Toast.makeText(this, "Nokta çıkarıldı (${pts.size} nokta)", Toast.LENGTH_SHORT).show()
    }

    private fun buildExtraTab(region: ActiveRegion, content: LinearLayout, dialog: AlertDialog, isFail: Boolean) {
        val ctx = this
        val list = if (isFail) region.onFailActions else region.extraActions
        val suffix = if (isFail) "FAIL" else "SUCCESS"
        val listLabel = if (isFail) "Bulunamazsa" else "Başarılı"
        content.addView(TextView(ctx).apply {
            text = if (isFail) "Bu alan BULUNAMAZSA sırayla yapılacaklar:" else "Birincil aksiyondan SONRA sırayla yapılacaklar:"
            textSize = 12f
        })

        val selectedIndices = mutableSetOf<Int>()
        val inflater = android.view.LayoutInflater.from(ctx)
        val listView = android.widget.ListView(ctx)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val extra = list[position]
                val (icon, desc) = when (extra.type) {
                    "CALL_FUNCTION" -> "🔧" to "f{} ${extra.functionName} x${extra.repeat}"
                    "SWIPE" -> "👉" to "(${extra.x},${extra.y})→(${extra.x2},${extra.y2})"
                    "WAIT" -> "⏱️" to "Bekle ${extra.waitMs}ms"
                    "SET_VARIABLE" -> "(x)" to "${extra.variableName} += ${extra.variableDelta}"
                    "RUN_SCRIPT" -> "🖥️" to extra.scriptName
                    "PLAY_RECORD" -> "🎬" to extra.recordName
                    "SYSTEM_BACK" -> "🔙" to "Geri Tuşu"
                    "SYSTEM_HOME" -> "🏠" to "Ana Ekran"
                    "SYSTEM_RECENTS" -> "🗂️" to "Son Uygulamalar"
                    "SYSTEM_NOTIFICATIONS" -> "🔔" to "Bildirim Paneli"
                    "SYSTEM_QUICK_SETTINGS" -> "⚡" to "Hızlı Ayarlar"
                    "READ_TEXT" -> "📖" to "${extra.variableName} = oku(${extra.x},${extra.y},${extra.x2},${extra.y2})"
                    else -> "👆" to "(${extra.x},${extra.y})"
                }
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "${position + 1}. $desc"
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = if (extra.holdMs != 50L || extra.postDelayMs > 0) "⏱️" else ""
                view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                return view
            }
        }
        listView.adapter = adapter
        styleListDividers(listView)
        listView.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.28).toInt()
        )
        // Kısa dokunuş: dokunma/kaydırma ise HOLD/DELAY düzenlemesini doğrudan açar.
        listView.setOnItemClickListener { _, _, position, _ ->
            val extra = list[position]
            if (extra.type == "TAP" || extra.type == "SWIPE") showHoldEditDialog(extra) { adapter.notifyDataSetChanged() }
            else Toast.makeText(ctx, "Bu adım türü için ek ayar yok — silmek/taşımak için basılı tut", Toast.LENGTH_SHORT).show()
        }
        // Basılı tutma: çoklu seçime ekler/çıkarır (toplu işlemler için).
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
            adapter.notifyDataSetChanged()
            true
        }
        content.addView(listView)
        content.addView(TextView(ctx).apply {
            text = "Dokun = ayarları aç · Basılı tut = çoklu seç (toplu işlem için)"
            textSize = 10f; setTextColor(Color.GRAY); setPadding(16, 4, 16, 8)
        })

        fun openAddMenu() {
            showIconMenuDialog("Ne eklemek istersin?", listOf(
                IconMenuRow(Ic.ic_pause, C_BLUE, "Wait") {
                    val input = EditText(ctx).apply { hint = "Bekleme (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("500") }
                    overlayDialog().setTitle("Bekleme Süresi").setView(input)
                        .setPositiveButton("Ekle") { _, _ ->
                            list.add(ExtraAction("WAIT", waitMs = input.text.toString().toLongOrNull() ?: 500))
                            adapter.notifyDataSetChanged()
                        }.create().showOverlay()
                },
                IconMenuRow(Ic.ic_tap, C_GREEN, "Click") {
                    list.add(ExtraAction("TAP"))
                    pendingExtraActionIndex = list.size - 1
                    dialog.dismiss()
                    armActionPoint(region, "EXTRA_TAP_$suffix")
                },
                IconMenuRow(Ic.ic_swipe, C_GREEN, "Swipe") {
                    list.add(ExtraAction("SWIPE"))
                    pendingExtraActionIndex = list.size - 1
                    dialog.dismiss()
                    armActionPoint(region, "EXTRA_SWIPE_START_$suffix")
                },
                IconMenuRow(Ic.ic_scan, C_ORANGE, "Image/Text/Color Detection") {
                    dialog.dismiss()
                    startExtraTabScan(region, list, if (isFail) "bulunamazsa" else "başarılı")
                },
                IconMenuRow(Ic.ic_live_capture, C_ORANGE, "Image Detection Live Capture") {
                    // Basitleştirme: mevcut tarama-alanı akışına yönlendirir (gerçek "canlı" yakalama değil).
                    dialog.dismiss()
                    startExtraTabScan(region, list, if (isFail) "bulunamazsa" else "başarılı")
                },
                IconMenuRow(Ic.ic_multi_detection, C_GREEN, "Multi Detection") {
                    dialog.dismiss()
                    startExtraTabScan(region, list, if (isFail) "bulunamazsa" else "başarılı")
                    Toast.makeText(ctx, "İlk koşulu ayarla, GENEL sekmesindeki \"🔀 Multi Detection\" bölümünden ek koşullar ekleyebilirsin", Toast.LENGTH_LONG).show()
                },
                IconMenuRow(Ic.ic_text_reader, C_ORANGE, "Text Reader") {
                    dialog.dismiss()
                    startTextReadRegion(list)
                },
                IconMenuRow(Ic.ic_record, C_RED, "Play Record") {
                    val records = com.bigboss.app.storage.RecordStorage.load(ctx)
                    val opts = mutableListOf("🔴 Yeni Kayıt Yap (REC)")
                    opts.addAll(records.map { "🎬 ${it.name} (${it.events.size} olay)" })
                    overlayDialog().setTitle("Play Record").setItems(opts.toTypedArray()) { _, idx2 ->
                        if (idx2 == 0) { dialog.dismiss(); startRecordMode(); return@setItems }
                        val rec = records[idx2 - 1]
                        list.add(ExtraAction("PLAY_RECORD", recordId = rec.id, recordName = rec.name))
                        adapter.notifyDataSetChanged()
                    }.setNegativeButton("Kapat", null).create().showOverlay()
                },
                IconMenuRow(Ic.ic_action_group, C_PURPLE, "Action Group (Loop)") { createActionGroup() },
                IconMenuRow(Ic.ic_flavor_group, C_BLUE, "Flavor Group") { quickAddFlavorGroup() },
                IconMenuRow(Ic.ic_function, C_GREEN, "Call Function") {
                    val functions = FunctionStorage.load(ctx)
                    val groups = ActionGroupStorage.load(ctx)
                    val opts = mutableListOf("➕ Yeni Fonksiyon Oluştur")
                    opts.addAll(functions.map { "f{} ${it.name}" })
                    opts.addAll(groups.map { "📦 ${it.name}" })
                    overlayDialog().setItems(opts.toTypedArray()) { _, idx2 ->
                        if (idx2 == 0) {
                            val fn = FunctionDefinition(UUID.randomUUID().toString(), "f_${System.currentTimeMillis()}")
                            FunctionStorage.upsert(ctx, fn)
                            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                            adapter.notifyDataSetChanged()
                        } else if (idx2 <= functions.size) {
                            val fn = functions[idx2 - 1]
                            list.add(ExtraAction("CALL_FUNCTION", functionId = fn.id, functionName = fn.name))
                            adapter.notifyDataSetChanged()
                        } else {
                            val group = groups[idx2 - 1 - functions.size]
                            list.add(ExtraAction("CALL_FUNCTION", functionId = group.id, functionName = "📦 ${group.name}"))
                            adapter.notifyDataSetChanged()
                        }
                    }.create().showOverlay()
                },
                IconMenuRow(Ic.ic_conditional, C_ORANGE, "Conditional (if-else)") {
                    // Bilinçli basitleştirme: bu liste İÇİNE gömülü DEĞİL, Ana Akış'a bağımsız bir Conditional kuralı ekler.
                    dialog.dismiss()
                    startAddConditional(SaveScope.MainFlow)
                    Toast.makeText(ctx, "Not: Conditional şu an bu listenin İÇİNE değil, Ana Akış'a bağımsız bir kural olarak ekleniyor", Toast.LENGTH_LONG).show()
                },
                IconMenuRow(Ic.ic_variable, C_PURPLE, "Set Variable") {
                    val nameInput = EditText(ctx).apply { hint = "Değişken/sayaç adı" }
                    val deltaInput = EditText(ctx).apply { hint = "Ne kadar artırılsın (örn. 1, -1)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("1") }
                    val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; addView(nameInput); addView(deltaInput) }
                    overlayDialog().setTitle("Set Variable").setView(box)
                        .setPositiveButton("Ekle") { _, _ ->
                            val vname = nameInput.text.toString().ifBlank { "sayac" }
                            val delta = deltaInput.text.toString().toIntOrNull() ?: 1
                            list.add(ExtraAction("SET_VARIABLE", variableName = vname, variableDelta = delta))
                            adapter.notifyDataSetChanged()
                        }.create().showOverlay()
                },
                IconMenuRow(Ic.ic_code, C_GREEN, "Code") {
                    val scripts = com.bigboss.app.storage.ScriptStorage.load(ctx)
                    val opts = mutableListOf("➕ Yeni Kod Oluştur")
                    opts.addAll(scripts.map { "</> ${it.name}" })
                    overlayDialog().setTitle("Code").setItems(opts.toTypedArray()) { _, sIdx ->
                        if (sIdx == 0) {
                            val script = com.bigboss.app.storage.ScriptDefinition(UUID.randomUUID().toString(), "Code", code = "")
                            com.bigboss.app.storage.ScriptStorage.upsert(ctx, script)
                            list.add(ExtraAction("RUN_SCRIPT", scriptId = script.id, scriptName = script.name))
                            adapter.notifyDataSetChanged()
                            dialog.dismiss()
                            pushScreen("</> ${script.name}") { buildCodeEditorContent(script.id) }
                        } else {
                            val s = scripts[sIdx - 1]
                            list.add(ExtraAction("RUN_SCRIPT", scriptId = s.id, scriptName = s.name))
                            adapter.notifyDataSetChanged()
                        }
                    }.setNegativeButton("Kapat", null).create().showOverlay()
                },
                IconMenuRow(Ic.ic_system, C_BLUE, "System") {
                    val sysOpts = arrayOf("🔙 Geri Tuşu", "🏠 Ana Ekran", "🗂️ Son Uygulamalar", "🔔 Bildirim Paneli", "⚡ Hızlı Ayarlar")
                    val sysTypes = arrayOf("SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS")
                    overlayDialog().setItems(sysOpts) { _, sIdx ->
                        list.add(ExtraAction(sysTypes[sIdx]))
                        adapter.notifyDataSetChanged()
                    }.create().showOverlay()
                }
            ))
        }

        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        // 1) "Draw selected/Change working group" karşılığı: seçili adım(lar) varsa SADECE onları,
        //    yoksa TÜM listeyi ekranda (nokta/alan olarak) gösterir.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_select_frame, C_BLUE) {
            // HATA DÜZELTMESİ ("draw select çalışmıyor"): showExtraListOnScreen bölgeleri gizleyip
            // ekrana işaretçi çiziyor AMA yapılandırma dialog'u TAM EKRAN açık kaldığı için çizilen
            // işaretçiler dialog'un ARKASINDA kalıyordu → kullanıcı hiçbir şey görmüyordu. Artık önce
            // dialog kapatılıyor (autoSave zaten "Kapat" ile tetikleniyor), sonra çizim yapılıyor.
            val sel = selectedIndices.sorted().mapNotNull { list.getOrNull(it) }
            dialog.dismiss()
            if (sel.isNotEmpty()) showExtraListOnScreen(region, isFail, sel, "🔍 Seçililer (${sel.size})")
            else showExtraListOnScreen(region, isFail, list, listLabel)
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_add, C_BLUE) { openAddMenu() })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            com.bigboss.app.storage.RuleClipboard.copy(extraActionToRuleDefinition(list[idx]))
            Toast.makeText(ctx, "Kopyalandı (Ana Akış/Fonksiyon'a da yapıştırılabilir)", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) bir adım seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            com.bigboss.app.storage.RuleClipboard.copy(extraActionToRuleDefinition(list[idx]))
            list.removeAt(idx)
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val pastedRule = com.bigboss.app.storage.RuleClipboard.pasteAsNew()
            if (pastedRule == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            val clip = ruleDefinitionToExtraAction(pastedRule)
            if (clip == null) { Toast.makeText(ctx, "Panodaki öğe bir Tespit (Image/Text/Color) kuralı — On Success/On Fail'e yapıştırılamaz", Toast.LENGTH_LONG).show(); return@makeToolIcon }
            list.add(clip)
            adapter.notifyDataSetChanged()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            if (selectedIndices.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            selectedIndices.sortedDescending().forEach { list.removeAt(it) }
            selectedIndices.clear()
            adapter.notifyDataSetChanged()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            val idx = selectedIndices.minOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            if (idx > 0) {
                val tmp = list[idx - 1]; list[idx - 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx - 1)
                adapter.notifyDataSetChanged()
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            val idx = selectedIndices.maxOrNull()
            if (idx == null) { Toast.makeText(ctx, "Önce (basılı tutarak) adım seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            if (idx < list.size - 1) {
                val tmp = list[idx + 1]; list[idx + 1] = list[idx]; list[idx] = tmp
                selectedIndices.clear(); selectedIndices.add(idx + 1)
                adapter.notifyDataSetChanged()
            }
        })
        content.addView(toolbarRow)
    }

    private fun buildLoopTab(region: ActiveRegion, content: LinearLayout) {
        val ctx = this
        val headerRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        headerRow.addView(TextView(ctx).apply {
            text = "Bu alan nasıl çalışsın?"
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        headerRow.addView(TextView(ctx).apply {
            text = "  ⓘ"; textSize = 12f; setTextColor(ACCENT)
            setOnClickListener {
                showHintDialog("Loop", hintText(
                    "None: " to "Döngü yok, alan bir kere çalışıp durur.",
                    "Loop When Success: " to "Eşleşme bulunup başarılı olduğu SÜRECE tekrar dener (Başarılı Olunca adımları her seferinde çalışır); İLK BULUNAMADIĞINDA durur.",
                    "Loop When Fail: " to "Eşleşme bulunamadığı SÜRECE tekrar dener; İLK BULUNDUĞUNDA (Başarılı Olunca çalışır) durur.",
                    "Loop Always: " to "Sonuçtan bağımsız her zaman devam eder — kendi durdurma mantığını Başarılı/Bulunamazsa adımlarında kurman gerekir.",
                    "Not: " to "Macrorify'ın kendi tanımıyla birebir aynı — bu senin daha önce anlattığın Action Group tanımının TERSİDİR, isimler orada karışmıştı, burada Macrorify'ın gerçek dokümantasyonuna göre düzeltildi."
                ))
            }
        })
        content.addView(headerRow)
        val radioGroup = android.widget.RadioGroup(ctx)
        // Macrorify'daki GERÇEK sıra: None, Loop when success, Loop when fail, Loop always.
        val rbNone = android.widget.RadioButton(ctx).apply {
            text = "None — tarama yapar ve durur (bir kere dener, biter)"; id = 1
        }
        val rbLoopWhenSuccess = android.widget.RadioButton(ctx).apply {
            text = "Loop when success — başarılı olduğu sürece tekrarlar, ilk bulunamayışta durur"; id = 4
        }
        val rbLoopWhenFail = android.widget.RadioButton(ctx).apply {
            text = "Loop when fail — bulunamadığı sürece tekrarlar, ilk bulunduğunda durur"; id = 3
        }
        val rbAlways = android.widget.RadioButton(ctx).apply {
            text = "Loop always — sonsuz döngü, hep açık kalır"; id = 2
        }
        // ÖNEMLİ DÜZELTME: Macrorify'ın resmi dokümantasyonuna göre etiketler düzeltildi.
        // "Loop when success" = başarılı olduğu SÜRECE tekrarlar (bizim motor-içi "WHILE_FAIL" anahtarımız).
        // "Loop when fail" = başarısız olduğu SÜRECE tekrarlar (bizim motor-içi "WHILE_SUCCESS" anahtarımız).
        // Motor davranışı ve kayıtlı veri AYNI KALDI — sadece hangi ismin hangi davranışa ait olduğu düzeltildi.
        listOf(rbNone, rbLoopWhenSuccess, rbLoopWhenFail, rbAlways).forEach { radioGroup.addView(it) }
        radioGroup.check(when (region.loopMode) {
            "NONE" -> 1; "WHILE_SUCCESS" -> 3; "WHILE_FAIL" -> 4; else -> 2
        })
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            region.loopMode = when (checkedId) {
                1 -> "NONE"; 3 -> "WHILE_SUCCESS"; 4 -> "WHILE_FAIL"; else -> "ALWAYS"
            }
        }
        content.addView(radioGroup)
    }

    /** Macrorify'daki "Text Reader": bir bölge çizdirip, okunan metni bir DEĞİŞKENE yazan adım ekler. */
    private fun startTextReadRegion(targetList: MutableList<ExtraAction>) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.isTextReadCapture = true
        region.textReadTargetList = targetList
        region.label.text = "📖 Metin Oku"
        Toast.makeText(this, "Okunacak alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    private fun openTextReadSaveDialog(region: ActiveRegion) {
        val targetList = region.textReadTargetList ?: return
        val r = regionRect(region)
        val ctx = this
        val varNameInput = EditText(ctx).apply { hint = "Değişken adı (örn. altin)" }
        val defaultInput = EditText(ctx).apply { hint = "Okunamazsa varsayılan değer"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("0") }
        val whitelistInput = EditText(ctx).apply { hint = "Whitelist (opsiyonel, örn. 0123456789)" }
        val blacklistInput = EditText(ctx).apply { hint = "Blacklist (opsiyonel)" }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0)
            addView(TextView(ctx).apply { text = "📖 Bu bölgedeki metni oku, İÇİNDEKİ İLK SAYIYI bir değişkene yaz (örn. \"Altın: 1500\" -> 1500)"; textSize = 12f })
            addView(varNameInput); addView(defaultInput); addView(whitelistInput); addView(blacklistInput)
        }
        overlayDialog().setTitle("Metni Değişkene Oku").setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val vname = varNameInput.text.toString().ifBlank { "okunan_deger" }
                targetList.add(ExtraAction(
                    type = "READ_TEXT", x = r[0], y = r[1], x2 = r[2], y2 = r[3],
                    variableName = vname,
                    readDefaultValue = defaultInput.text.toString().toIntOrNull() ?: 0,
                    readWhitelist = whitelistInput.text.toString(),
                    readBlacklist = blacklistInput.text.toString()
                ))
                removeRegionWindow(region)
                Toast.makeText(ctx, "Eklendi: 📖 $vname", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    private fun extraActionToStep(extra: ExtraAction): com.bigboss.app.storage.ActionStep =
        com.bigboss.app.storage.ActionStep(
            type = extra.type, x = extra.x, y = extra.y, x2 = extra.x2, y2 = extra.y2,
            waitMs = extra.waitMs, repeat = extra.repeat, functionId = extra.functionId,
            recordId = extra.recordId,
            variableName = extra.variableName, variableDelta = extra.variableDelta,
            scriptId = extra.scriptId,
            scriptCode = extra.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.code },
            holdMs = extra.holdMs, swipeHoldStartMs = extra.swipeHoldStartMs, swipeHoldEndMs = extra.swipeHoldEndMs, postDelayMs = extra.postDelayMs,
            // KÖK NEDEN DÜZELTMESİ: swipeDurationMs eskiden buraya hiç taşınmıyordu (ActionStep'te
            // alan yoktu) — showExtraSwipeEditor'daki hız preseti sessizce kayboluyordu.
            swipeDurationMs = extra.swipeDurationMs,
            readDefaultValue = extra.readDefaultValue, readWhitelist = extra.readWhitelist, readBlacklist = extra.readBlacklist
        )

    /** region.stickyLeft/Top/Right/Bottom bayraklarını RegionScaler'ın bit-bayrağı formatına çevirir. */
    private fun stickyEdgesBitmask(region: ActiveRegion): Int {
        var mask = 0
        if (region.stickyLeft) mask = mask or com.bigboss.app.engine.RegionScaler.EDGE_LEFT
        if (region.stickyTop) mask = mask or com.bigboss.app.engine.RegionScaler.EDGE_TOP
        if (region.stickyRight) mask = mask or com.bigboss.app.engine.RegionScaler.EDGE_RIGHT
        if (region.stickyBottom) mask = mask or com.bigboss.app.engine.RegionScaler.EDGE_BOTTOM
        return mask
    }

    private fun saveRegionAsRule(region: ActiveRegion, silent: Boolean = false): Boolean {
        if (region.actionType == "CALL_FUNCTION" && region.callFunctionId.isNullOrBlank()) {
            if (!silent) Toast.makeText(this, "Önce bir fonksiyon seç (Aksiyon sekmesi)", Toast.LENGTH_LONG).show()
            return false
        }
        // KULLANICI İSTEĞİ: "HAYIR kayıt edilsin, sadece TEST etmek istediğimde uyarı versin" —
        // artık koşul eksik (resim/metin/vb. seçilmemiş) olsa BİLE kural KAYDEDİLİYOR; "eksik mi"
        // uyarısı ARTIK SADECE test/play başlatılırken (bkz. isConditionAltIncomplete kullanan
        // yerler) gösteriliyor, kaydetme sırasında DEĞİL.
        val mainAlt = buildConditionAltFromRegion(region)
        val name = region.name.ifBlank { "İsimsiz kural" }
        // ÖNEMLİ: id'yi BİR KERE üretip region'a KALICI olarak yazıyoruz — yoksa her otomatik
        // kaydetmede YENİ bir rastgele id üretilip aynı kuraldan kopyalar oluşurdu.
        val ruleId = region.existingRuleId ?: UUID.randomUUID().toString().also { region.existingRuleId = it }

        // Birincil kural: GENEL/AKSİYON/BAŞARILI/TEKRAR sekmelerindeki her şeyi taşır.
        val def = RuleDefinition(
            id = ruleId, name = name, enabled = region.enabled,
            alternatives = (mutableListOf(mainAlt) + region.extraConditions).toMutableList(),
            alternativesLogic = region.conditionsLogic,
            timeoutMs = region.cooldownMs,
            matchDelayMs = region.matchDelayMs,
            cooldownVarName = region.cooldownVarName, matchDelayVarName = region.matchDelayVarName,
            scanTimeoutMs = region.scanTimeoutMs,
            scanRateHz = region.scanRateHz,
            scanTimeoutVarName = region.scanTimeoutVarName, scanRateVarName = region.scanRateVarName,
            maxConsecutiveFailures = region.maxConsecutiveFailures,
            negateCondition = region.negate,
            loopMode = region.loopMode,
            requireVariableName = region.requireVariableName, requireVariableOp = region.requireVariableOp, requireVariableValue = region.requireVariableValue,
            actionType = region.actionType,
            actionX = region.actionX, actionY = region.actionY, actionX2 = region.actionX2, actionY2 = region.actionY2,
            swipePathPoints = if (region.swipeExtraPoints.isEmpty()) mutableListOf() else mutableListOf(
                com.bigboss.app.storage.SwipePointData(region.actionX, region.actionY, region.swipeHoldStartMs),
                com.bigboss.app.storage.SwipePointData(region.actionX2, region.actionY2, 0)
            ).apply { addAll(region.swipeExtraPoints) }.also { it[it.size - 1].holdMs = region.swipeHoldEndMs },
            tapAtMatchLocation = region.tapAtMatchLocation,
            tapAllMatches = region.tapAllMatches,
            actionRepeatCount = region.actionRepeatCount,
            actionHoldMs = region.actionHoldMs,
            actionPostDelayMs = region.actionPostDelayMs,
            randomOffsetPx = region.randomOffsetPx,
            randomChancePercent = region.randomChancePercent,
            swipeHoldStartMs = region.swipeHoldStartMs,
            swipeHoldEndMs = region.swipeHoldEndMs,
            actionHoldVarName = region.actionHoldVarName,
            actionPostDelayVarName = region.actionPostDelayVarName,
            swipeHoldStartVarName = region.swipeHoldStartVarName,
            swipeHoldEndVarName = region.swipeHoldEndVarName,
            actionRepeatVarName = region.actionRepeatVarName,
            randomOffsetVarName = region.randomOffsetVarName,
            swipeDurationVarName = region.swipeDurationVarName,
            actionXVarName = region.actionXVarName,
            actionYVarName = region.actionYVarName,
            actionX2VarName = region.actionX2VarName,
            actionY2VarName = region.actionY2VarName,
            callFunctionId = region.callFunctionId, callFunctionRepeat = region.callFunctionRepeat,
            incrementVariableName = region.incrementVariableName, incrementVariableDelta = region.incrementVariableDelta,
            extraSteps = region.extraActions.map { extraActionToStep(it) }.toMutableList(),
            // KÖK NEDEN DÜZELTMESİ (kullanıcı raporu + Macrorify'ın resmi akış şeması): "On Fail"
            // artık AYRI, TERS koşullu bir "gölge kural" DEĞİL — AYNI kuralın bir PARÇASI. Motor
            // (RuleEngine) artık Timeout dolup dolmadığına göre BU listeyi doğrudan tetikliyor.
            onFailSteps = region.onFailActions.map { extraActionToStep(it) }.toMutableList(),
            baseScreenW = region.baseScreenW, baseScreenH = region.baseScreenH,
            regionScaleMode = region.regionScaleMode,
            regionStickyEdges = stickyEdgesBitmask(region),
            actionRelativeAnchorRuleId = region.actionRelativeAnchorRuleId,
            actionRelativeOffsetX = region.actionRelativeOffsetX, actionRelativeOffsetY = region.actionRelativeOffsetY
        )

        val scope = region.saveScope
        when (scope) {
            is SaveScope.MainFlow -> RuleStorage.upsert(this, def)
            is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, def)
            is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, def)
        }

        // GERİYE DÖNÜK TEMİZLİK: eski mimaride bir "-fail" gölge kural OLUŞTURULUYORDU. Artık
        // On Fail bu kuralın KENDİSİNDE (onFailSteps) — eğer eski bir gölge kural hâlâ depoda
        // duruyorsa (bu bölge daha önce eski sürümle kaydedilmişse) burada silinir, mükerrer/
        // yanlış davranan bir kural ARTIK kalmasın.
        region.existingRuleId?.let { id ->
            when (scope) {
                is SaveScope.MainFlow -> RuleStorage.deleteRule(this, "$id-fail")
                is SaveScope.Group -> ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, "$id-fail")
                is SaveScope.Function -> FunctionStorage.deleteRuleFromFunction(this, scope.functionId, "$id-fail")
            }
        }

        com.bigboss.app.storage.EngineAssembler.refresh(this)
        if (!silent) Toast.makeText(this, "Kaydedildi: $name", Toast.LENGTH_SHORT).show()
        return true
    }

    /**
     * KRİTİK DÜZELTME (kullanıcı raporu: "çerçevenin içinde farklı bir yer kaydediliyor"):
     * MediaProjection (AUTO_MIRROR VirtualDisplay) TÜM fiziksel ekranı yakalar — bu, BİZİM
     * KENDİ overlay pencerelerimizi (bölge çerçevesi mavi kutu, "Kırp" etiketi, köşe kıvrımı)
     * DA İÇERİR. Kırpma anında bu kendi arayüzümüz hâlâ EKRANDA görünür olduğu için kaydedilen
     * görüntü hedef uygulamanın SAF içeriği değil, KISMEN KENDİ ÇERÇEVEMİZİ içeriyordu.
     * Çözüm: kırpmadan ÖNCE kendi çerçevemizi/etiketimizi GİZLE, gizlemeden SONRA yakalanmış
     * TEMİZ bir kare gelene kadar bekle (frameTimestamp ile), O kareyle kırp, SONRA arayüzü
     * geri göster. Timeout (800ms) sonunda elimizdeki en son kareyle devam eder (asla kilitlenmez).
     */
    private fun captureCleanRegionCrop(region: ActiveRegion, onResult: (Bitmap?) -> Unit) {
        val startTs = ScreenCaptureService.frameTimestamp
        region.container.visibility = View.GONE
        region.label.visibility = View.GONE
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val deadline = System.currentTimeMillis() + 800
        // KÖK NEDEN DÜZELTMESİ (kullanıcı raporu: kırpılan görüntü ÇERÇEVENİN içeriğiyle
        // birebir eşleşmiyordu): tek bir "zaman damgası değişti" kontrolü YETERSİZDİ — o İLK
        // yeni kare, gizleme isteğimiz ekrana ÇİZİLMEDEN ÖNCE MediaProjection kuyruğunda zaten
        // BEKLEYEN bir kare olabiliyordu (hâlâ bizim çerçevemizi/etiketimizi İÇEREN "kirli" bir
        // kare). Artık gizlemeden SONRA yakalanan kareyi bir kez atlıyoruz ve ONDAN SONRAKİ
        // (kesinlikle temiz) kareyi kullanıyoruz — yine de 800ms zaman aşımı içinde, asla kilitlenmez.
        var seenFirstNewFrame = false
        fun finish() {
            region.container.visibility = View.VISIBLE
            region.label.visibility = View.VISIBLE
            val frame = ScreenCaptureService.latestFrame
            val r = regionRect(region)
            onResult(frame?.let { safeCrop(it, r[0], r[1], r[2], r[3]) })
        }
        fun poll() {
            val timedOut = System.currentTimeMillis() > deadline
            if (timedOut) { finish(); return }
            if (ScreenCaptureService.frameTimestamp > startTs) {
                if (seenFirstNewFrame) { finish(); return }
                seenFirstNewFrame = true
            }
            handler.postDelayed(::poll, 25)
        }
        handler.postDelayed(::poll, 25)
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val safeX = x.coerceIn(0, bitmap.width - 1)
        val safeY = y.coerceIn(0, bitmap.height - 1)
        val safeW = w.coerceAtMost(bitmap.width - safeX)
        val safeH = h.coerceAtMost(bitmap.height - safeY)
        if (safeW < 1 || safeH < 1) return null
        return Bitmap.createBitmap(bitmap, safeX, safeY, safeW, safeH)
    }

    /**
     * MacrorifyCropTool'dan gelen ham Rect ile temiz kare kırpar. Çerçeve/panel zaten
     * kapandığı için burada kendi arayüzümüzü gizlemeye gerek yok; sadece gizlemeden
     * SONRA yakalanan ilk kareyi atlayıp sonrakini kullanarak "kirli kare" riskini önler.
     */
    private fun captureCleanRectCrop(rect: android.graphics.Rect, onResult: (Bitmap?) -> Unit) {
        val startTs = ScreenCaptureService.frameTimestamp
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val deadline = System.currentTimeMillis() + 800
        var seenFirstNewFrame = false
        fun finish() {
            val frame = ScreenCaptureService.latestFrame
            onResult(frame?.let { safeCrop(it, rect.left, rect.top, rect.width(), rect.height()) })
        }
        fun poll() {
            if (System.currentTimeMillis() > deadline) { finish(); return }
            if (ScreenCaptureService.frameTimestamp > startTs) {
                if (seenFirstNewFrame) { finish(); return }
                seenFirstNewFrame = true
            }
            handler.postDelayed(::poll, 25)
        }
        handler.postDelayed(::poll, 25)
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ==================== Ana Akış ====================

    /**
     * Macrorify'daki araç çubuğu (toolbar) tarzı: aydınlık zeminde, renkli vektör ikonlu,
     * tek satırda eşit ağırlıklı küçük kare butonlar. `rebuildPanel()`'daki `iconBtn` ile
     * AYNI görsel dil ama PAYLAŞILABİLİR (class seviyesinde) — Ana Akış gibi tam sayfa
     * ekranların araç çubuklarında da kullanılabilir.
     */
    /**
     * Basılı tutunca (long-press) Android'in KENDİ tooltip mekanizması (API 26+, minSdk=26
     * olduğu için güvenli) ile ismini gösterecek ikonlar için VARSAYILAN Türkçe isimler.
     * Aynı ikon BAĞLAMA göre farklı anlama gelebiliyor (örn. ic_select_frame Ana Akış'ta
     * "Seç/Çiz", Setting Builder'da "Sekme Özeti") — bu yüzden çağrı yerlerinde `name`
     * parametresiyle İSTENİRSE ezilebilir; burası sadece EN YAYGIN anlamı karşılıyor.
     */
    private fun defaultIconName(drawableRes: Int): String = when (drawableRes) {
        com.bigboss.app.R.drawable.ic_add -> "Ekle"
        com.bigboss.app.R.drawable.ic_arrow_down -> "Aşağı Taşı"
        com.bigboss.app.R.drawable.ic_arrow_up -> "Yukarı Taşı"
        com.bigboss.app.R.drawable.ic_bulb -> "Değer Bağla (Değişken/Setting Builder)"
        com.bigboss.app.R.drawable.ic_capture -> "Ekran Görüntüsü Al"
        com.bigboss.app.R.drawable.ic_chevron_left -> "Daralt"
        com.bigboss.app.R.drawable.ic_chevron_right -> "Genişlet"
        com.bigboss.app.R.drawable.ic_save -> "Kaydet ve Motoru Yenile"
        com.bigboss.app.R.drawable.ic_close -> "Kapat"
        com.bigboss.app.R.drawable.ic_code -> "Kod Ekle"
        com.bigboss.app.R.drawable.ic_color_add -> "Renk Ekle"
        com.bigboss.app.R.drawable.ic_conditional -> "Koşullu (if-else) Ekle"
        com.bigboss.app.R.drawable.ic_copy -> "Kopyala"
        com.bigboss.app.R.drawable.ic_cut -> "Kes"
        com.bigboss.app.R.drawable.ic_delete -> "Sil"
        com.bigboss.app.R.drawable.ic_edit -> "Düzenle / İsimle Seç"
        com.bigboss.app.R.drawable.ic_eye -> "Tüm Panelleri Gizle"
        com.bigboss.app.R.drawable.ic_eye_off -> "Tüm Panelleri Göster"
        com.bigboss.app.R.drawable.ic_flavor_group -> "Flavor Group Ekle"
        com.bigboss.app.R.drawable.ic_format -> "Biçimlendir"
        com.bigboss.app.R.drawable.ic_function -> "Fonksiyon Ekle/Çağır"
        com.bigboss.app.R.drawable.ic_home -> "Ana Akış"
        com.bigboss.app.R.drawable.ic_indent -> "Girinti Ekle"
        com.bigboss.app.R.drawable.ic_library -> "Kütüphaneden Seç"
        com.bigboss.app.R.drawable.ic_live_capture -> "Canlı Yakalama"
        com.bigboss.app.R.drawable.ic_move -> "Local/Global Taşı"
        com.bigboss.app.R.drawable.ic_multi_detection -> "Çoklu Algılama Ekle"
        com.bigboss.app.R.drawable.ic_paste -> "Yapıştır"
        com.bigboss.app.R.drawable.ic_pause -> "Duraklat / Bekleme Ekle"
        com.bigboss.app.R.drawable.ic_play -> "Çalıştır / Başlat"
        com.bigboss.app.R.drawable.ic_record -> "Kayıt"
        com.bigboss.app.R.drawable.ic_scan -> "Tarama Alanı Ekle"
        com.bigboss.app.R.drawable.ic_select_frame -> "Seç / Çiz"
        com.bigboss.app.R.drawable.ic_settings -> "Ayarlar"
        com.bigboss.app.R.drawable.ic_sort -> "Sırala"
        com.bigboss.app.R.drawable.ic_stop -> "Durdur"
        com.bigboss.app.R.drawable.ic_swipe -> "Kaydırma Ekle"
        com.bigboss.app.R.drawable.ic_system -> "Sistem Aksiyonu Ekle"
        com.bigboss.app.R.drawable.ic_tap -> "Dokunma Ekle"
        com.bigboss.app.R.drawable.ic_test -> "Canlı Test"
        com.bigboss.app.R.drawable.ic_text_reader -> "Metin Okuyucu Ekle"
        com.bigboss.app.R.drawable.ic_variable -> "Değişken Ekle"
        com.bigboss.app.R.drawable.ic_workspace -> "Çalışma Alanını Göster"
        com.bigboss.app.R.drawable.ic_action_group -> "Action Group (Loop) Ekle"
        else -> ""
    }

    private fun makeToolIcon(ctx: android.content.Context, drawableRes: Int, tint: Int, name: String? = null, onClick: () -> Unit): View {
        val density = resources.displayMetrics.density
        val btnSize = (40 * density).toInt()
        val iconSize = (20 * density).toInt()
        return android.widget.ImageView(ctx).apply {
            setImageResource(drawableRes)
            layoutParams = LinearLayout.LayoutParams(0, btnSize, 1f)
            val pad = (btnSize - iconSize) / 2
            setPadding(pad, pad, pad, pad)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setColorFilter(tint)
            isClickable = true
            setOnClickListener { onClick() }
            // Basılı tutunca isim balonu göster (Android'in KENDİ tooltip mekanizması, API 26+).
            val tooltip = name ?: defaultIconName(drawableRes)
            if (tooltip.isNotBlank()) tooltipText = tooltip
        }
    }

    /** Macrorify'daki "+" menüsü tarzı: her satırda renkli bir vektör ikon + isim (emoji YOK, gerçek ikon). */
    private data class IconMenuRow(val icon: Int, val tint: Int, val name: String, val onClick: () -> Unit)

    private fun showIconMenuDialog(title: String, rows: List<IconMenuRow>, closable: Boolean = true) {
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_icon_menu_row, parent, false)
                val row = rows[position]
                view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivRowIcon).apply {
                    setImageResource(row.icon); setColorFilter(row.tint)
                }
                view.findViewById<TextView>(com.bigboss.app.R.id.tvIconRowName).text = row.name
                return view
            }
        }
        val builder = overlayDialog().setTitle(title).setAdapter(adapter) { _, position -> rows[position].onClick() }
        if (closable) builder.setNegativeButton("Kapat", null)
        val dialog = builder.create()
        // ÖNEMLİ: satır metni (item_icon_menu_row.xml) SABİT koyu (#212121) renk kullanıyor —
        // ama dialog'un arka planı CİHAZIN sistem temasına (açık/koyu) bağlıydı. Koyu sistem
        // temasında koyu yazı, koyu zemin üzerinde OKUNAMIYORDU. Arka planı EXPLICIT beyaz
        // yaparak bu belirsizliği ortadan kaldırıyoruz (5 sekmeli bölge editöründe yaptığımız
        // düzeltmeyle AYNI kök nedene karşı, buradaki AYNI çözüm).
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
        dialog.showOverlay()
    }

    private data class MenuRow(val icon: String, val name: String, val extra: String, val onClick: () -> Unit)

    private fun showRowListDialog(title: String, rows: List<MenuRow>, closable: Boolean = true) {
        val inflater = android.view.LayoutInflater.from(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                val row = rows[position]
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = row.icon
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = row.name
                view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = row.extra
                return view
            }
        }
        val builder = overlayDialog().setTitle(title).setAdapter(adapter) { _, position -> rows[position].onClick() }
        if (closable) builder.setNegativeButton("Kapat", null)
        val dialog = builder.create()
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
        dialog.showOverlay()
    }

    /**
     * Bir kuralın Ana Akış listesinde (ve aynı düzeni kullanan Fonksiyonlar sayfasında) hangi
     * emoji ile gösterileceğini belirler. Koşullu (bölge tarayan) kurallarda koşul tipine göre,
     * koşulsuz (Macrorify "+" menüsünden eklenen bağımsız adım) kurallarda actionType'a göre.
     */
    private fun anaAkisRuleIcon(r: RuleDefinition): String {
        if (r.alternatives.isNotEmpty()) {
            return when (r.alternatives.first().conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
        }
        return when (r.actionType) {
            "SWIPE" -> "👉"
            "WAIT" -> "⏸️"
            "SET_VARIABLE" -> "🔢"
            "PLAY_RECORD" -> "🎬"
            "READ_TEXT" -> "📖"
            "RUN_SCRIPT" -> "</>"
            "CALL_FUNCTION" -> "f{}"
            "SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS" -> "🤖"
            else -> "👆"
        }
    }

    /** Ana Akış listesindeki tek bir öğe: ya bir kural ya bir Action Group. */
    private sealed class AnaAkisEntry {
        data class Rule(val rule: RuleDefinition) : AnaAkisEntry()
        data class Group(val group: com.bigboss.app.storage.ActionGroupDefinition) : AnaAkisEntry()
    }

    /**
     * "Ana Akış" artık küçük bir liste penceresi değil, Macrorify'daki gibi TAM BİR
     * SAYFA: üstte kaydırılabilir liste, altta seçili öğe üzerinde çalışan 8 ikonlu
     * araç çubuğu (Görüntüle, Ekle, Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı).
     */
    private fun buildAnaAkisScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer)
        root.addView(footer)

        fun currentEntries(): List<AnaAkisEntry> {
            val entries = mutableListOf<AnaAkisEntry>()
            ActionGroupStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Group(it)) }
            RuleStorage.load(ctx).forEach { entries.add(AnaAkisEntry.Rule(it)) }
            return entries
        }

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz kural/grup yok — alttaki ➕ ile başla"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    when (val entry = entries[position]) {
                        is AnaAkisEntry.Group -> {
                            val g = entry.group
                            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (g.enabled) "📦" else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = g.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "$gateInfo · ${g.rules.size} · x${g.gateRepeat}"
                        }
                        is AnaAkisEntry.Rule -> {
                            val r = entry.rule
                            val icon = anaAkisRuleIcon(r)
                            val extra = if (!r.enabled) "🔕" else if (r.loopMode == "ALWAYS") "" else r.loopMode
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (r.enabled) icon else "🔕"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = r.groupName?.let { "[$it] " }.orEmpty() + r.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = extra
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.4).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is AnaAkisEntry.Rule -> openRuleForEditing(entry.rule, SaveScope.MainFlow)
                    is AnaAkisEntry.Group -> showActionGroupOptions(entry.group)
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = bilgiyi aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<AnaAkisEntry> {
            val entries = currentEntries()
            return selectedIndices.sorted().mapNotNull { entries.getOrNull(it) }
        }

        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        // ---- Macrorify'daki TEK SATIR, 8 gerçek vektör ikonlu araç çubuğu (Görüntüle/Grup Değiştir,
        // Ekle, Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı) — eskiden 2 satır emoji-metin buton grubuydu. ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        // 1) "Draw selected/Change working group" (resmi Macrorify açıklaması: "By default everything
        //    in this Group is rendered to the screen... [icon] switches to whatever Group you're
        //    opening and only renders the content of that Group. You could also hold and select only
        //    the actions you want and use the button — it'll create a virtual Group and render only
        //    those actions out."):
        //    - Bir GRUP seçiliyse: o grubun çalışma alanına geç, içeriğini ekranda göster.
        //    - Bir/birkaç KURAL seçiliyse: SADECE onları ekranda göster (sanal/geçici grup).
        //    - Hiçbir şey seçili değilse: mevcut çalışma grubunun (Ana Akış) TÜMÜNÜ ekranda göster.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_select_frame, C_BLUE) {
            val selGroup = selectedEntries().filterIsInstance<AnaAkisEntry.Group>().singleOrNull()
            val selRules = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule }
            when {
                selGroup != null -> {
                    closeAppPanel(); showWorkspaceFor(SaveScope.Group(selGroup.group.id), selGroup.group.rules, "📦 ${selGroup.group.name}")
                }
                selRules.isNotEmpty() -> {
                    closeAppPanel(); showWorkspaceFor(SaveScope.MainFlow, selRules, "🔍 Seçililer (${selRules.size})")
                }
                else -> {
                    closeAppPanel(); showWorkspaceFor(SaveScope.MainFlow, RuleStorage.load(ctx), "🏠 Ana Akış")
                }
            }
        })
        // 2) "+": Macrorify'daki TAM 15 öğelik liste (gerçek ikonlarla) — Wait, Click, Swipe,
        //    Image/Text/Color Detection, Image Detection Live Capture, Multi Detection, Text Reader,
        //    Play Record, Action Group (Loop), Flavor Group, Call Function, Conditional (if-else),
        //    Set Variable, Code, System.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_add, C_BLUE) {
            showIconMenuDialog("Ne eklemek istersin?", buildAddMenuItems(SaveScope.MainFlow) { buildContent() })
        })
        // 3-8) Kopyala/Kes/Yapıştır/Sil/Yukarı/Aşağı — TÜM şemalarda paylaşılan TEK algoritma.
        // Sil'de Ana Akış'a ÖZGÜ bir ek var: seçili GRUPLAR da (kural değil, üst-düzey varlık) siliniyor.
        buildStandardToolbar(
            ctx, toolbarRow, SaveScope.MainFlow,
            getSelectedRules = { selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule } },
            onRefresh = { refreshThisScreen() },
            onDeleteExtra = {
                val groups = selectedEntries().filterIsInstance<AnaAkisEntry.Group>()
                groups.forEach { ActionGroupStorage.delete(ctx, it.group.id) }
                if (groups.isNotEmpty()) com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                groups.size
            }
        )
        footer.addView(toolbarRow)
        footer.addView(TextView(ctx).apply {
            text = "Tümünü seç/kaldır"
            textSize = 11f; setTextColor(ACCENT); setPadding(0, 6, 0, 0)
            setOnClickListener {
                val total = currentEntries().size
                if (selectedIndices.size == total) selectedIndices.clear()
                else { selectedIndices.clear(); selectedIndices.addAll(0 until total) }
                buildContent()
            }
        })


        // ---- ▶️ Unit Test (Macrorify'daki gibi): seçili öğeleri, ya da hiç seçim yoksa TÜMÜNÜ, gerçekten çalıştırır ----
        val testBtn = Button(ctx).apply {
            text = "▶️ Test Et — seçiliyse sadece SEÇİLİLER, seçim yoksa HEPSİ çalışır"
            textSize = 13f
            setOnClickListener {
                val selRules = selectedEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule }
                if (selRules.isNotEmpty()) {
                    testSelectedRules(selRules)
                } else {
                    val all = currentEntries().filterIsInstance<AnaAkisEntry.Rule>().map { it.rule }
                    if (all.isEmpty()) { Toast.makeText(ctx, "Çalıştırılacak kural yok", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    overlayDialog().setTitle("Hiçbir şey seçili değil")
                        .setMessage("Seçim yapmadın — TÜM Ana Akış'ı (${all.size} kural) GERÇEKTEN çalıştıracağım. Emin misin?")
                        .setPositiveButton("Evet, hepsini çalıştır") { _, _ -> testSelectedRules(all) }
                        .setNegativeButton("Vazgeç", null)
                        .create().showOverlay()
                }
            }
        }
        footer.addView(testBtn)

        buildContent()
        // Macrorify'daki "by default everything in this Group is rendered" — Ana Akış açılınca
        // TÜMÜ otomatik (sessizce) ekranda gösterilir; "Seç/Çiz" ikonu bunu daraltır/değiştirir.
        showWorkspaceForSilent(SaveScope.MainFlow, RuleStorage.load(ctx), "🏠 Ana Akış")
        return root
    }

    /** RuleDefinition'ı doğru depoya (Ana Akış/Grup/Fonksiyon) yazar — saveRegionAsRule'daki dispatch ile AYNI mantık, "+" menüsü hızlı-ekle akışları için paylaşılabilir hale getirildi. */
    /**
     * KULLANICI İSTEĞİ: "Fonksiyonlar" ve "Variables" listeleri de ortak hafızadan çekmeli.
     * Her iki ekran da "</> Kod" girdilerini (ScriptDefinition/ScriptStorage/ScriptClipboard)
     * BİREBİR AYNI şekilde ekliyor/kopyalıyor/kesip/yapıştırıyor/siliyordu — bu ORTAK kısım
     * artık TEK yerde. Birincil tip (Fonksiyon/Değişken) hâlâ ekrana özel kalıyor (farklı
     * depolama/pano mekanizmaları), ama "eğer seçili şey bir Script'se" dalı artık HER YERDE
     * AYNI davranıyor — biri değişince öbürü unutulmaz.
     */
    private fun addScriptEntry() {
        val script = com.bigboss.app.storage.ScriptDefinition(UUID.randomUUID().toString(), "Code", code = "")
        com.bigboss.app.storage.ScriptStorage.upsert(this, script)
        pushScreen("</> ${script.name}") { buildCodeEditorContent(script.id) }
    }

    private fun copyScriptEntry(script: com.bigboss.app.storage.ScriptDefinition) {
        com.bigboss.app.storage.ScriptClipboard.copy(script)
        Toast.makeText(this, "Kopyalandı: ${script.name}", Toast.LENGTH_SHORT).show()
    }

    private fun cutScriptEntry(script: com.bigboss.app.storage.ScriptDefinition) {
        com.bigboss.app.storage.ScriptClipboard.copy(script)
        com.bigboss.app.storage.ScriptStorage.delete(this, script.id)
    }

    /** Panoda bir Script varsa yeni kopya olarak yapıştırır ve true döner; yoksa false (çağıran, kendi birincil tipini dener). */
    private fun tryPasteScriptEntry(): Boolean {
        val pasted = com.bigboss.app.storage.ScriptClipboard.pasteAsNew() ?: return false
        com.bigboss.app.storage.ScriptStorage.upsert(this, pasted)
        return true
    }

    private fun deleteScriptEntry(script: com.bigboss.app.storage.ScriptDefinition) {
        com.bigboss.app.storage.ScriptStorage.delete(this, script.id)
    }

    private fun saveRuleToScope(scope: SaveScope, def: RuleDefinition) {
        when (scope) {
            is SaveScope.MainFlow -> RuleStorage.upsert(this, def)
            is SaveScope.Group -> ActionGroupStorage.upsertRuleInGroup(this, scope.groupId, def)
            is SaveScope.Function -> FunctionStorage.upsertRuleInFunction(this, scope.functionId, def)
        }
        com.bigboss.app.storage.EngineAssembler.refresh(this)
    }

    /**
     * KULLANICI İSTEĞİ: "ortak araç çubuğu mantığıyla ilerlemelisin" — alt araç çubuğunun
     * (Kes/Sil/Yukarı/Aşağı) TÜM şemalarda kullandığı, kapsama göre DOĞRU depoya (RuleStorage/
     * FunctionStorage/ActionGroupStorage) yönlenen TEK silme fonksiyonu. `-fail` eşleniğini de
     * (Ana Akış'ın Conditional kuralları için) otomatik temizler.
     */
    private fun deleteRuleFromScope(scope: SaveScope, ruleId: String) {
        when (scope) {
            is SaveScope.MainFlow -> { RuleStorage.deleteRule(this, ruleId); RuleStorage.deleteRule(this, "$ruleId-fail") }
            is SaveScope.Group -> ActionGroupStorage.deleteRuleFromGroup(this, scope.groupId, ruleId)
            is SaveScope.Function -> FunctionStorage.deleteRuleFromFunction(this, scope.functionId, ruleId)
        }
        com.bigboss.app.storage.EngineAssembler.refresh(this)
    }

    /** Kapsama göre DOĞRU depoda bir kuralı bir sıra yukarı/aşağı taşıyan TEK, paylaşılan fonksiyon. */
    private fun moveRuleInScope(scope: SaveScope, ruleId: String, up: Boolean) {
        when (scope) {
            is SaveScope.MainFlow -> if (up) RuleStorage.moveUp(this, ruleId) else RuleStorage.moveDown(this, ruleId)
            is SaveScope.Group -> if (up) ActionGroupStorage.moveRuleUp(this, scope.groupId, ruleId) else ActionGroupStorage.moveRuleDown(this, scope.groupId, ruleId)
            is SaveScope.Function -> if (up) FunctionStorage.moveRuleUp(this, scope.functionId, ruleId) else FunctionStorage.moveRuleDown(this, scope.functionId, ruleId)
        }
        com.bigboss.app.storage.EngineAssembler.refresh(this)
    }

    /**
     * KULLANICI İSTEĞİ: "ortak araç çubuğu mantığıyla ilerlemelisin, her şemada ayrı ayrı
     * algoritma üretmek yerine tek bir algoritma üret, tüm şemalar bu ortak hafızadan çeksin."
     * "+" menüsündeki 15 öğe eskiden Ana Akış'ta VE Fonksiyon Detayı'nda İKİ AYRI, EL İLE
     * kopyalanmış liste olarak yazılıydı — biri değişince öbürü unutulabiliyordu. Artık TEK
     * fonksiyon: `scope`'a göre parametreleşiyor, HER İKİ ekran da BURAYA yönleniyor. Bir
     * öğenin davranışı değişince (örn. yeni bir quickAdd* eklenince/değişince) TEK bir yerde
     * güncellenir, TÜM şemalara otomatik yansır.
     */
    private fun buildAddMenuItems(scope: SaveScope, onRefresh: () -> Unit): List<IconMenuRow> = listOf(
        IconMenuRow(Ic.ic_pause, C_BLUE, "Wait") { quickAddWait(scope); onRefresh() },
        IconMenuRow(Ic.ic_tap, C_GREEN, "Click") { addSimpleStep(scope, "TAP"); onRefresh() },
        IconMenuRow(Ic.ic_swipe, C_GREEN, "Swipe") { addSimpleStep(scope, "SWIPE"); onRefresh() },
        IconMenuRow(Ic.ic_scan, C_ORANGE, "Image/Text/Color Detection") { closeAppPanel(); startAddRegion(scope) },
        IconMenuRow(Ic.ic_live_capture, C_ORANGE, "Image Detection Live Capture") { quickAddLiveCapture(scope); onRefresh() },
        IconMenuRow(Ic.ic_multi_detection, C_GREEN, "Multi Detection") { quickAddMultiDetection(scope); onRefresh() },
        IconMenuRow(Ic.ic_text_reader, C_ORANGE, "Text Reader") { quickAddTextReader(scope); onRefresh() },
        IconMenuRow(Ic.ic_record, C_RED, "Play Record") { quickAddPlayRecord(scope); onRefresh() },
        // Action Group/Flavor Group HER ZAMAN üst-düzey (top-level) kavramlardır — bir
        // Fonksiyon/Grup İÇİNDEN eklense bile Ana Akış seviyesinde oluşturulur (mevcut, kasıtlı
        // davranış — bu birleştirmeyle DEĞİŞTİRİLMEDİ, sadece TEK yerden sunuluyor).
        IconMenuRow(Ic.ic_action_group, C_PURPLE, "Action Group (Loop)") { createActionGroup(); onRefresh() },
        IconMenuRow(Ic.ic_flavor_group, C_BLUE, "Flavor Group") { quickAddFlavorGroup(); onRefresh() },
        IconMenuRow(Ic.ic_function, C_GREEN, "Call Function") { quickAddCallFunction(scope); onRefresh() },
        IconMenuRow(Ic.ic_conditional, C_ORANGE, "Conditional (if-else)") { closeAppPanel(); startAddConditional(scope) },
        IconMenuRow(Ic.ic_variable, C_PURPLE, "Set Variable") { quickAddSetVariable(scope); onRefresh() },
        IconMenuRow(Ic.ic_code, C_GREEN, "Code") { quickAddCode(scope); onRefresh() },
        IconMenuRow(Ic.ic_system, C_BLUE, "System") { quickAddSystemAction(scope); onRefresh() }
    )

    /**
     * KULLANICI İSTEĞİ: "ortak araç çubuğu mantığıyla ilerlemelisin [...] yapılan bir değişiklik
     * TÜM şemalardaki komutlarda yapılmalı." Kopyala/Kes/Yapıştır/Sil/Yukarı/Aşağı butonları
     * eskiden Ana Akış'ta VE Fonksiyon Detayı'nda AYRI AYRI (yapısal olarak neredeyse BİREBİR
     * aynı, ama EL İLE iki kere yazılmış) kodlardı — ikisi de zaten paylaşılan
     * `deleteRuleFromScope`/`saveRuleToScope`/`moveRuleInScope`'u ÇAĞIRIYORDU, ama BUTONLARIN
     * KENDİSİ (toolbarRow.addView(...)) tekrar tekrar yazılıyordu. Artık TEK fonksiyon.
     *
     * [getSelectedRules]: o ekranın SEÇİLİ kurallarını döndürür (Ana Akış'ta Grup+Kural karışık
     * bir liste olduğu için `filterIsInstance<Rule>()`, Fonksiyon'da doğrudan liste).
     * [onDeleteExtra]: SADECE Ana Akış'ın kullandığı bir kanca — seçili GRUPLARI da siler ve
     * silinen grup SAYISINI döner (Fonksiyon'da grup kavramı olmadığı için null bırakılır).
     */
    private fun buildStandardToolbar(
        ctx: android.content.Context,
        toolbarRow: LinearLayout,
        scope: SaveScope,
        getSelectedRules: () -> List<RuleDefinition>,
        onRefresh: () -> Unit,
        onDeleteExtra: (() -> Int)? = null
    ) {
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            val sel = getSelectedRules().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel)
                Toast.makeText(ctx, "Kopyalandı: ${sel.name}", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            val sel = getSelectedRules().firstOrNull()
            if (sel != null) {
                com.bigboss.app.storage.RuleClipboard.copy(sel)
                deleteRuleFromScope(scope, sel.id)
                onRefresh()
            } else Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew()
            if (pasted == null) { Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            saveRuleToScope(scope, pasted)
            onRefresh()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            val sel = getSelectedRules()
            val extraDeleted = onDeleteExtra?.invoke() ?: 0
            if (sel.isEmpty() && extraDeleted == 0) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { deleteRuleFromScope(scope, it.id) }
            Toast.makeText(ctx, "${sel.size + extraDeleted} öğe silindi", Toast.LENGTH_SHORT).show()
            onRefresh()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            val sel = getSelectedRules()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { moveRuleInScope(scope, it.id, up = true) }
            onRefresh()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            val sel = getSelectedRules()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.asReversed().forEach { moveRuleInScope(scope, it.id, up = false) }
            onRefresh()
        })
    }

    // ==================== Ana Akış "+" menüsü — Macrorify'daki 15 öğeye TAM karşılık gelen,
    // BAĞIMSIZ (koşulsuz) üst-düzey hızlı-ekleme akışları ====================

    /** "Wait": Ana Akış'a (ya da verilen scope'a) doğrudan, koşulsuz bir bekleme adımı ekler. */
    private fun quickAddWait(scope: SaveScope = SaveScope.MainFlow) {
        val ctx = this
        val input = EditText(ctx).apply { hint = "Bekleme süresi (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("1000") }
        overlayDialog().setTitle("⏸️ Wait — koşulsuz bekleme").setView(input)
            .setPositiveButton("Ekle") { _, _ ->
                val ms = input.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 1000
                saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = "⏸️ Bekle ${ms}ms", actionType = "WAIT", actionPostDelayMs = ms))
                Toast.makeText(ctx, "Eklendi: ⏸️ Bekle ${ms}ms", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** "Image Detection Live Capture": normal tarama-alanı akışının IMAGE moduna doğrudan başlar (tek dokunuşla şablon seçimine geçiş). */
    private fun quickAddLiveCapture(scope: SaveScope = SaveScope.MainFlow) {
        closeAppPanel()
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.saveScope = scope
        region.conditionKind = "IMAGE"
        region.label.text = "🖼️ Live Capture"
        Toast.makeText(this, "Alanı sürükle/boyutlandır, sonra dokunup şablonu seç/kırp", Toast.LENGTH_LONG).show()
    }

    /** "Multi Detection": bir tarama alanı çizer — Multi Detection zaten GENEL sekmesindeki "➕ Ek Koşul Ekle" ile bu alanın İÇİNDE kurulur. */
    private fun quickAddMultiDetection(scope: SaveScope = SaveScope.MainFlow) {
        closeAppPanel()
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.saveScope = scope
        Toast.makeText(this, "İlk koşulu ayarla, kaydetmeden önce \"🔀 Multi Detection\" bölümünden ek koşullar ekleyebilirsin", Toast.LENGTH_LONG).show()
    }

    /** "Text Reader" (BAĞIMSIZ, verilen scope'a doğrudan): bir bölge çizdirip, okunan metni bir değişkene yazan KOŞULSUZ bir kural ekler. */
    private fun quickAddTextReader(scope: SaveScope = SaveScope.MainFlow) {
        closeAppPanel()
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        val region = addRegionWindow()
        region.saveScope = scope
        region.isTopLevelTextRead = true
        region.label.text = "📖 Text Reader"
        Toast.makeText(this, "Okunacak alanı sürükle/boyutlandır, sonra dokunup ayarla", Toast.LENGTH_LONG).show()
    }

    /** quickAddTextReader() ile çizilen bölgeyi, region.saveScope'a bir READ_TEXT kuralı olarak kaydeder. */
    private fun openTopLevelTextReadSaveDialog(region: ActiveRegion) {
        val r = regionRect(region)
        val ctx = this
        val varNameInput = EditText(ctx).apply { hint = "Değişken adı (örn. altin)" }
        val defaultInput = EditText(ctx).apply { hint = "Okunamazsa varsayılan değer"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("0") }
        val whitelistInput = EditText(ctx).apply { hint = "Whitelist (opsiyonel, örn. 0123456789)" }
        val blacklistInput = EditText(ctx).apply { hint = "Blacklist (opsiyonel)" }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0)
            addView(TextView(ctx).apply { text = "📖 Text Reader — bu bölgedeki metni oku, İÇİNDEKİ İLK SAYIYI bir değişkene yaz. Koşulsuz bir adım olarak eklenir."; textSize = 12f })
            addView(varNameInput); addView(defaultInput); addView(whitelistInput); addView(blacklistInput)
        }
        overlayDialog().setTitle("Text Reader").setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val vname = varNameInput.text.toString().ifBlank { "okunan_deger" }
                saveRuleToScope(region.saveScope, RuleDefinition(
                    id = UUID.randomUUID().toString(), name = "📖 Text Reader ($vname)",
                    actionType = "READ_TEXT",
                    actionX = r[0], actionY = r[1], actionX2 = r[2], actionY2 = r[3],
                    readTextVariableName = vname,
                    readTextDefaultValue = defaultInput.text.toString().toIntOrNull() ?: 0,
                    readTextWhitelist = whitelistInput.text.toString(),
                    readTextBlacklist = blacklistInput.text.toString(),
                    baseScreenW = region.baseScreenW, baseScreenH = region.baseScreenH,
                    regionScaleMode = region.regionScaleMode, regionStickyEdges = stickyEdgesBitmask(region)
                ))
                removeRegionWindow(region)
                Toast.makeText(ctx, "Eklendi: 📖 $vname", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç") { _, _ -> removeRegionWindow(region) }
            .create().showOverlay()
    }

    /** "Play Record": mevcut bir kaydı (ya da yeni bir kayıt) seçip verilen scope'a koşulsuz bir "oynat" adımı ekler. */
    private fun quickAddPlayRecord(scope: SaveScope = SaveScope.MainFlow) {
        val ctx = this
        val records = com.bigboss.app.storage.RecordStorage.load(ctx)
        val options = mutableListOf("🔴 Yeni Kayıt Yap (REC)")
        options.addAll(records.map { "🎬 ${it.name} (${it.events.size} olay)" })
        overlayDialog().setTitle("Play Record").setItems(options.toTypedArray()) { _, idx ->
            if (idx == 0) { closeAppPanel(); startRecordMode(); return@setItems }
            val record = records[idx - 1]
            saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = "🎬 ${record.name}", actionType = "PLAY_RECORD", playRecordId = record.id))
            Toast.makeText(ctx, "Eklendi: 🎬 ${record.name}", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * "Flavor Group": Macrorify'da build-variant'a göre (debug/release, free/pro vb.) hangi
     * aksiyonların dahil edileceğini belirleyen bir grup — dağıtım/derleme zamanı bir kavram.
     * BigBoss TEK bir APK olarak kişisel kullanım için üretildiğinden (birden fazla build
     * variant seçme ekranı yok), bunu BASİTLEŞTİRİLMİŞ bir Action Group olarak uyguluyoruz:
     * içine aksiyon koyabileceğin bir grup, ama "hangi variant'ta dahil edilsin" seçimi YOK —
     * her zaman dahil edilir. Dürüstçe belirtelim: bu, Macrorify'ın TAM özelliği değil.
     */
    private fun quickAddFlavorGroup() {
        val ctx = this
        val input = EditText(ctx).apply { hint = "Flavor Group adı (örn. debug, free)" }
        overlayDialog().setTitle("🏷️ Flavor Group")
            .setMessage("Macrorify'da bu, build-variant'a göre koşullu dahil edilen bir gruptur (birden fazla APK varyantı derlerken kullanılır). BigBoss TEK bir kişisel APK olduğundan, burada BASİTLEŞTİRİLMİŞ bir grup olarak oluşturulur — her zaman dahil edilir.")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "flavor" }
                val group = com.bigboss.app.storage.ActionGroupDefinition(UUID.randomUUID().toString(), "🏷️ $name")
                ActionGroupStorage.upsert(ctx, group)
                com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                Toast.makeText(ctx, "Oluşturuldu: 🏷️ $name", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /** "Call Function": Ana Akış'a doğrudan, koşulsuz bir "fonksiyon çağır" adımı ekler (fonksiyon TANIMLAMAZ, var olanı ya da yeni oluşturulanı çağırır). */
    private fun quickAddCallFunction(scope: SaveScope = SaveScope.MainFlow) {
        val ctx = this
        val functions = FunctionStorage.load(ctx)
        val groups = ActionGroupStorage.load(ctx)
        val options = mutableListOf("➕ Yeni Fonksiyon Oluştur ve Çağır")
        options.addAll(functions.map { "f{} ${it.name}" })
        options.addAll(groups.map { "📦 ${it.name}" })
        overlayDialog().setTitle("Call Function").setItems(options.toTypedArray()) { _, idx ->
            if (idx == 0) {
                val fn = FunctionDefinition(UUID.randomUUID().toString(), "f_${System.currentTimeMillis()}")
                FunctionStorage.upsert(ctx, fn)
                saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = "f{} ${fn.name}", actionType = "CALL_FUNCTION", callFunctionId = fn.id))
                Toast.makeText(ctx, "Eklendi: f{} ${fn.name}", Toast.LENGTH_SHORT).show()
            } else if (idx <= functions.size) {
                val fn = functions[idx - 1]
                saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = "f{} ${fn.name}", actionType = "CALL_FUNCTION", callFunctionId = fn.id))
                Toast.makeText(ctx, "Eklendi: f{} ${fn.name}", Toast.LENGTH_SHORT).show()
            } else {
                val group = groups[idx - 1 - functions.size]
                saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = "📦 ${group.name}", actionType = "CALL_FUNCTION", callFunctionId = group.id))
                Toast.makeText(ctx, "Eklendi: 📦 ${group.name}", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "Set Variable": verilen scope'a doğrudan, koşulsuz bir değişken ayarlama adımı ekler. */
    private fun quickAddSetVariable(scope: SaveScope = SaveScope.MainFlow) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Değişken adı" }
        val valueInput = EditText(ctx).apply { hint = "Değer/Delta"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText("1") }
        val modeRadio = android.widget.RadioGroup(ctx)
        val rbSet = android.widget.RadioButton(ctx).apply { text = "SET (değeri doğrudan bu yap)"; id = 1; isChecked = true }
        val rbInc = android.widget.RadioButton(ctx).apply { text = "INCREMENT (mevcut değere ekle)"; id = 2 }
        modeRadio.addView(rbSet); modeRadio.addView(rbInc)
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0)
            addView(nameInput); addView(valueInput); addView(modeRadio)
        }
        overlayDialog().setTitle("{x} Set Variable").setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val name = nameInput.text.toString().ifBlank { "degisken" }
                val delta = valueInput.text.toString().toIntOrNull() ?: 1
                val mode = if (modeRadio.checkedRadioButtonId == 2) "INCREMENT" else "SET"
                saveRuleToScope(scope, RuleDefinition(
                    id = UUID.randomUUID().toString(), name = "{x} $name ${if (mode == "SET") "=" else "+="} $delta",
                    actionType = "SET_VARIABLE", incrementVariableName = name, incrementVariableDelta = delta, incrementVariableMode = mode
                ))
                Toast.makeText(ctx, "Eklendi: {x} $name", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    /**
     * "Code": kütüphaneye kaydetmeden, verilen scope'a DOĞRUDAN gömülü bir kod adımı ekler.
     *
     * KULLANICI İSTEĞİ (14 Temmuz): "tüm pencerelerde işlem ağacına kod eklemek istersek [...]
     * bir düzen ile kod ekleyelim" — artık TAP/SWIPE'ın `addSimpleStepToMainFlow/Function` ile
     * ANINDA oluşturulup canlı düzenlenmesiyle AYNI desen: kural boş kodla HEMEN oluşturulur,
     * ardından TEK merkezi `buildCodeEditorScreen` (Script Kütüphanesi'yle BİREBİR aynı ekran)
     * açılır — eski küçük AlertDialog+düz-metin-kutusu KALDIRILDI.
     */
    private fun quickAddCode(scope: SaveScope = SaveScope.MainFlow) {
        val def = RuleDefinition(
            id = UUID.randomUUID().toString(), name = "</> Kod Adımı",
            actionType = "RUN_SCRIPT", runScriptCode = "", runScriptLanguage = "EMSCRIPT"
        )
        saveRuleToScope(scope, def)
        pushScreen("</> Kod Adımı") {
            buildCodeEditorScreen(
                this, "Code",
                getCode = { def.runScriptCode ?: "" },
                setCode = { text -> def.runScriptCode = text; saveRuleToScope(scope, def) }
            )
        }
    }

    /** "System": verilen scope'a doğrudan, koşulsuz bir sistem aksiyonu (Geri/Ana Ekran/vb) adımı ekler. */
    private fun quickAddSystemAction(scope: SaveScope = SaveScope.MainFlow) {
        val ctx = this
        val opts = listOf(
            "SYSTEM_BACK" to "🔙 Geri Tuşu", "SYSTEM_HOME" to "🏠 Ana Ekran",
            "SYSTEM_RECENTS" to "🗂️ Son Uygulamalar", "SYSTEM_NOTIFICATIONS" to "🔔 Bildirim Paneli",
            "SYSTEM_QUICK_SETTINGS" to "⚡ Hızlı Ayarlar"
        )
        overlayDialog().setTitle("System").setItems(opts.map { it.second }.toTypedArray()) { _, idx ->
            val (type, label) = opts[idx]
            saveRuleToScope(scope, RuleDefinition(id = UUID.randomUUID().toString(), name = label, actionType = type))
            Toast.makeText(ctx, "Eklendi: $label", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun pasteRule() {
        val pasted = com.bigboss.app.storage.RuleClipboard.pasteAsNew() ?: return
        RuleStorage.upsert(this, pasted)
        com.bigboss.app.storage.EngineAssembler.refresh(this)
        Toast.makeText(this, "Yapıştırıldı: ${pasted.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showGroupFilterMenu(groups: List<String>) {
        overlayDialog().setTitle("Grup Seç").setItems(groups.toTypedArray()) { _, gIndex ->
            val group = groups[gIndex]
            val filtered = RuleStorage.load(this).filter { it.groupName == group }
            val labels = filtered.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
            overlayDialog().setTitle("[$group] (${filtered.size})").setItems(labels) { _, idx -> showRuleOptions(filtered[idx]) }
                .setNegativeButton("Kapat", null).create().showOverlay()
        }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showRuleOptions(rule: RuleDefinition) {
        val options = arrayOf(
            "✏️ Düzenle", if (rule.enabled) "🔕 Devre Dışı Bırak" else "🔔 Etkinleştir", "🧪 Test Et",
            "📋 Kopyala", "✂️ Kes", "⬆️ Yukarı Taşı", "⬇️ Aşağı Taşı", "🗑 Sil"
        )
        overlayDialog().setTitle(rule.name).setItems(options) { _, index ->
            when (index) {
                0 -> {
                    if (rule.alternatives.isEmpty()) {
                        RuleStorage.deleteRule(this, rule.id)
                        addSimpleStep(SaveScope.MainFlow, rule.actionType)
                    } else {
                        editExistingRule(rule)
                    }
                }
                1 -> { rule.enabled = !rule.enabled; RuleStorage.upsert(this, rule); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                2 -> testRule(rule)
                3 -> { com.bigboss.app.storage.RuleClipboard.copy(rule); Toast.makeText(this, "Kopyalandı: ${rule.name}", Toast.LENGTH_SHORT).show() }
                4 -> {
                    com.bigboss.app.storage.RuleClipboard.copy(rule)
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Kesildi: ${rule.name}", Toast.LENGTH_SHORT).show()
                }
                5 -> { RuleStorage.moveUp(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                6 -> { RuleStorage.moveDown(this, rule.id); com.bigboss.app.storage.EngineAssembler.refresh(this) }
                7 -> {
                    RuleStorage.deleteRule(this, rule.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Var olan bir kuralı düzenlemek için, o kuralın alanını ekranda GERÇEK overlay kutusu olarak geri getirir. */
    private fun stepToExtraAction(step: com.bigboss.app.storage.ActionStep): ExtraAction {
        val fnName = step.functionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        }
        return ExtraAction(
            type = step.type, x = step.x, y = step.y, x2 = step.x2, y2 = step.y2,
            waitMs = step.waitMs, functionId = step.functionId, functionName = fnName ?: "",
            recordId = step.recordId, recordName = step.recordId?.let { id -> com.bigboss.app.storage.RecordStorage.load(this).find { it.id == id }?.name } ?: "",
            repeat = step.repeat, variableName = step.variableName, variableDelta = step.variableDelta,
            scriptId = step.scriptId, scriptName = step.scriptId?.let { id -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.id == id }?.name } ?: "",
            holdMs = step.holdMs, swipeHoldStartMs = step.swipeHoldStartMs, swipeHoldEndMs = step.swipeHoldEndMs, postDelayMs = step.postDelayMs,
            swipeDurationMs = step.swipeDurationMs,
            readDefaultValue = step.readDefaultValue, readWhitelist = step.readWhitelist, readBlacklist = step.readBlacklist
        )
    }

    /**
     * KULLANICI İSTEĞİ: "bir işleme tıklayınca ARA bir menü DEĞİL, veri girdiğimiz panel
     * DOĞRUDAN açılsın — bu menü eskiden kalma, zaten sayfaların alt kısmındaki araç çubuğunda
     * (Kopyala/Kes/Sil/Yukarı/Aşağı) var." Listede bir kurala DOKUNULDUĞUNDA çağrılacak TEK,
     * MERKEZİ giriş noktası:
     * - GERÇEK bir koşulu (Image/Text/Color Detection) olan kurallar için DOĞRUDAN tam
     *   bölge düzenleyiciyi açar (`editExistingRule`) — ARA kutu-tıklama adımı YOK.
     * - Koşulsuz TAP/SWIPE (vb.) kurallar için `showWorkspaceFor`'un ZATEN kanıtlanmış canlı
     *   işaretçi (sürükle + kısa-dokun-hızlı-düzenle + basılı-tut-menü) mantığını TEK öğelik
     *   bir liste vererek yeniden kullanır — kural EKRANDA DOĞRUDAN düzenlenebilir hâlde belirir.
     */
    /**
     * KULLANICI RAPORU: bir Fonksiyon içine "Kod Adımı" (RUN_SCRIPT) ekleyip üzerine dokununca
     * panel TAMAMEN kapanıp "1 öğe gösteriliyor" diye bir mesaj çıkıyordu — DÜZENLEME EKRANI
     * AÇILMIYORDU. Kök neden: bu dispatcher, "koşulsuz kural" = "TAP/SWIPE" varsayıyordu ve
     * HER koşulsuz kuralı `showWorkspaceFor` (ekranda göster) akışına yönlendiriyordu — ama
     * RUN_SCRIPT/WAIT/SET_VARIABLE/CALL_FUNCTION/SYSTEM eylemleri/PLAY_RECORD gibi türlerin ekranda
     * gösterilecek bir X/Y'si YOK, bu yüzden "göster" hiçbir şey yapmıyordu (sadece paneli
     * kapatıp anlamsız bir toast gösteriyordu). Artık TÜRE göre doğru düzenleyici açılıyor.
     */
    private fun openRuleForEditing(rule: RuleDefinition, scope: SaveScope) {
        if (rule.alternatives.isNotEmpty()) {
            closeAppPanel()
            editExistingRule(rule, scope)
            return
        }
        when (rule.actionType) {
            "TAP", "SWIPE" -> { closeAppPanel(); showWorkspaceFor(scope, mutableListOf(rule), rule.name) }
            "RUN_SCRIPT" -> openEditCodeStepDialog(rule, scope)
            "WAIT" -> openEditWaitDialog(rule, scope)
            "SET_VARIABLE" -> openEditSetVariableDialog(rule, scope)
            "CALL_FUNCTION" -> openEditCallFunctionDialog(rule, scope)
            "SYSTEM_BACK", "SYSTEM_HOME", "SYSTEM_RECENTS", "SYSTEM_NOTIFICATIONS", "SYSTEM_QUICK_SETTINGS" -> openEditSystemActionDialog(rule, scope)
            else -> showRuleOptions(rule) // PLAY_RECORD ve nadir diğer türler için — en azından Sil/Yukarı/Aşağı çalışır
        }
    }

    /**
     * "Kod Adımı" (RUN_SCRIPT) türü koşulsuz bir kuralı düzenler — `quickAddCode` ile AYNI
     * merkezi `buildCodeEditorScreen` ekranını açar (eski küçük AlertDialog KALDIRILDI).
     */
    private fun openEditCodeStepDialog(rule: RuleDefinition, scope: SaveScope) {
        rule.runScriptLanguage = "EMSCRIPT"
        pushScreen("</> Kod Adımı") {
            buildCodeEditorScreen(
                this, "Code",
                getCode = { rule.runScriptCode ?: "" },
                setCode = { text -> rule.runScriptCode = text; saveRuleToScope(scope, rule) }
            )
        }
    }

    /** "Wait" türü koşulsuz bir kuralı düzenler. */
    private fun openEditWaitDialog(rule: RuleDefinition, scope: SaveScope) {
        val ctx = this
        val input = EditText(ctx).apply { hint = "Bekleme (ms)"; inputType = InputType.TYPE_CLASS_NUMBER; setText(rule.actionPostDelayMs.toString()) }
        overlayDialog().setTitle("Bekleme Süresini Düzenle").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                rule.actionPostDelayMs = input.text.toString().toLongOrNull() ?: rule.actionPostDelayMs
                saveRuleToScope(scope, rule)
                renderCurrentScreen()
            }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "Set Variable" türü koşulsuz bir kuralı düzenler. */
    private fun openEditSetVariableDialog(rule: RuleDefinition, scope: SaveScope) {
        val ctx = this
        val nameInput = EditText(ctx).apply { hint = "Değişken adı"; setText(rule.incrementVariableName ?: "") }
        val deltaInput = EditText(ctx).apply { hint = "Değer/Artış"; setText(rule.incrementVariableDelta.toString()) }
        val modeGroup = android.widget.RadioGroup(ctx).apply { orientation = android.widget.RadioGroup.HORIZONTAL }
        val rbSet = android.widget.RadioButton(ctx).apply { text = "SET (ata)"; id = 1; isChecked = rule.incrementVariableMode != "INCREMENT" }
        val rbInc = android.widget.RadioButton(ctx).apply { text = "INCREMENT (artır)"; id = 2; isChecked = rule.incrementVariableMode == "INCREMENT" }
        modeGroup.addView(rbSet); modeGroup.addView(rbInc)
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); addView(nameInput); addView(deltaInput); addView(modeGroup) }
        overlayDialog().setTitle("Set Variable'ı Düzenle").setView(box)
            .setPositiveButton("Kaydet") { _, _ ->
                rule.incrementVariableName = nameInput.text.toString().ifBlank { rule.incrementVariableName }
                rule.incrementVariableDelta = deltaInput.text.toString().toIntOrNull() ?: rule.incrementVariableDelta
                rule.incrementVariableMode = if (modeGroup.checkedRadioButtonId == 2) "INCREMENT" else "SET"
                saveRuleToScope(scope, rule)
                renderCurrentScreen()
            }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** "Call Function" türü koşulsuz bir kuralı düzenler. */
    private fun openEditCallFunctionDialog(rule: RuleDefinition, scope: SaveScope) {
        val ctx = this
        val functions = FunctionStorage.load(ctx)
        if (functions.isEmpty()) { Toast.makeText(ctx, "Henüz fonksiyon yok", Toast.LENGTH_SHORT).show(); return }
        val names = functions.map { it.name }.toTypedArray()
        val currentIdx = functions.indexOfFirst { it.id == rule.callFunctionId }.coerceAtLeast(0)
        overlayDialog().setTitle("Hangi fonksiyon çağrılsın?").setSingleChoiceItems(names, currentIdx) { d, idx ->
            rule.callFunctionId = functions[idx].id
            rule.name = "f{} ${functions[idx].name}"
            saveRuleToScope(scope, rule)
            renderCurrentScreen()
            d.dismiss()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /** Sistem eylemi (BACK/HOME/RECENTS/vb.) türü koşulsuz bir kuralı düzenler. */
    private fun openEditSystemActionDialog(rule: RuleDefinition, scope: SaveScope) {
        val ctx = this
        val options = arrayOf("SYSTEM_BACK" to "⬅️ Geri", "SYSTEM_HOME" to "🏠 Ana Ekran", "SYSTEM_RECENTS" to "📋 Son Uygulamalar", "SYSTEM_NOTIFICATIONS" to "🔔 Bildirimler", "SYSTEM_QUICK_SETTINGS" to "⚙️ Hızlı Ayarlar")
        val labels = options.map { it.second }.toTypedArray()
        val currentIdx = options.indexOfFirst { it.first == rule.actionType }.coerceAtLeast(0)
        overlayDialog().setTitle("Sistem Eylemini Düzenle").setSingleChoiceItems(labels, currentIdx) { d, idx ->
            rule.actionType = options[idx].first
            rule.name = options[idx].second
            saveRuleToScope(scope, rule)
            renderCurrentScreen()
            d.dismiss()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * KULLANICI RAPORU: "Ana Akış'ta bir kurala her tıkladığımda YENİ bir tarama alanı
     * kutusu oluşuyor, ayrıca hangi kutunun nereye kaydedildiğini anlayamıyorum" — kök neden
     * ÇİFT: (1) bu fonksiyon HER çağrıldığında koşulsuz `addRegionWindow` ile YENİ bir kutu
     * çiziyordu; aynı kural için ekranda ZATEN açık bir düzenleme kutusu olsa bile onu hiç
     * KONTROL ETMİYORDU — art arda tıklamalar (ya da listeye geri dönüp tekrar tıklama) aynı
     * kural için ÜST ÜSTE kutular biriktiriyordu. (2) kutu çizildikten sonra kullanıcı o
     * kutuya AYRICA dokunup ayar menüsünü AÇMASI gerekiyordu — oysa listeden bir kurala
     * tıklamak doğrudan o kuralın AYAR MENÜSÜNE girmeliydi. Artık: aynı kural için ekranda
     * zaten bir kutu varsa YENİSİ oluşturulmuyor, mevcudu doğrudan ayar menüsüne açılıyor;
     * yeni oluşturuluyorsa da kutu çizilir çizilmez ayar menüsü OTOMATİK açılıyor.
     */
    private fun editExistingRule(rule: RuleDefinition, scope: SaveScope = SaveScope.MainFlow) {
        val alt = rule.alternatives.firstOrNull() ?: return
        activeRegions.find { it.existingRuleId == rule.id }?.let { existing ->
            openRegionConfigDialog(existing)
            return
        }
        val region = addRegionWindow(alt.x, alt.y, alt.width, alt.height)
        // addRegionWindow GÜNCEL ekrandan otomatik baseScreenW/H yakalar — bu YANLIŞ, çünkü
        // DÜZENLERKEN kuralın ORİJİNAL (kaydedildiği) çözünürlüğünü korumalıyız.
        region.baseScreenW = rule.baseScreenW
        region.baseScreenH = rule.baseScreenH
        region.regionScaleMode = rule.regionScaleMode
        region.stickyLeft = rule.regionStickyEdges and com.bigboss.app.engine.RegionScaler.EDGE_LEFT != 0
        region.stickyTop = rule.regionStickyEdges and com.bigboss.app.engine.RegionScaler.EDGE_TOP != 0
        region.stickyRight = rule.regionStickyEdges and com.bigboss.app.engine.RegionScaler.EDGE_RIGHT != 0
        region.stickyBottom = rule.regionStickyEdges and com.bigboss.app.engine.RegionScaler.EDGE_BOTTOM != 0
        region.saveScope = scope
        region.existingRuleId = rule.id
        region.name = rule.name
        region.conditionKind = alt.conditionKind
        region.conditionColor = alt.color
        region.conditionTemplatePath = alt.templatePath
        region.conditionText = alt.expectedText ?: ""
        region.conditionTextCaseSensitive = alt.textCaseSensitive
        region.conditionTextWhitelist = alt.textWhitelist
        region.conditionTextBlacklist = alt.textBlacklist
        region.conditionVariableName = alt.variableName
        region.conditionVariableOp = alt.variableOp
        region.conditionCompareValue = alt.compareValue
        region.conditionCustomCode = alt.customCode
        region.minScore = alt.minScore
        // Macrorify "Relative Coordinates" (koşul tarafı): anchor id'den ismi bulup geri yükle.
        region.relativeAnchorRuleId = alt.relativeAnchorRuleId
        region.relativeAnchorRuleName = alt.relativeAnchorRuleId?.let { id -> RuleStorage.load(this).find { it.id == id }?.name } ?: ""
        region.relativeOffsetX = alt.relativeOffsetX
        region.relativeOffsetY = alt.relativeOffsetY
        region.relativeResizeW = alt.relativeResizeW
        region.relativeResizeH = alt.relativeResizeH
        region.extraConditions.clear()
        region.extraConditions.addAll(rule.alternatives.drop(1).map { it.copy() })
        region.conditionsLogic = rule.alternativesLogic
        region.actionType = rule.actionType
        region.actionX = rule.actionX; region.actionY = rule.actionY
        region.actionX2 = rule.actionX2; region.actionY2 = rule.actionY2
        region.swipeExtraPoints.clear()
        if (rule.swipePathPoints.size > 2) {
            region.swipeExtraPoints.addAll(rule.swipePathPoints.drop(2).map { it.copy() })
        }
        region.tapAtMatchLocation = rule.tapAtMatchLocation
        region.tapAllMatches = rule.tapAllMatches
        region.actionRepeatCount = rule.actionRepeatCount
        region.actionHoldMs = rule.actionHoldMs
        region.actionPostDelayMs = rule.actionPostDelayMs
        region.randomOffsetPx = rule.randomOffsetPx
        region.randomChancePercent = rule.randomChancePercent
        region.swipeHoldStartMs = rule.swipeHoldStartMs
        region.swipeHoldEndMs = rule.swipeHoldEndMs
        region.actionHoldVarName = rule.actionHoldVarName
        region.actionPostDelayVarName = rule.actionPostDelayVarName
        region.swipeHoldStartVarName = rule.swipeHoldStartVarName
        region.swipeHoldEndVarName = rule.swipeHoldEndVarName
        region.actionRepeatVarName = rule.actionRepeatVarName
        region.randomOffsetVarName = rule.randomOffsetVarName
        region.swipeDurationVarName = rule.swipeDurationVarName
        region.actionXVarName = rule.actionXVarName
        region.actionYVarName = rule.actionYVarName
        region.actionX2VarName = rule.actionX2VarName
        region.actionY2VarName = rule.actionY2VarName
        region.callFunctionId = rule.callFunctionId
        region.callFunctionName = rule.callFunctionId?.let { id ->
            FunctionStorage.load(this).find { it.id == id }?.name
                ?: ActionGroupStorage.load(this).find { it.id == id }?.name?.let { "📦 $it" }
        } ?: ""
        region.callFunctionRepeat = rule.callFunctionRepeat
        // Macrorify "Relative Coordinates" (aksiyon tarafı): anchor id'den ismi bulup geri yükle.
        region.actionRelativeAnchorRuleId = rule.actionRelativeAnchorRuleId
        region.actionRelativeAnchorRuleName = rule.actionRelativeAnchorRuleId?.let { id -> RuleStorage.load(this).find { it.id == id }?.name } ?: ""
        region.actionRelativeOffsetX = rule.actionRelativeOffsetX
        region.actionRelativeOffsetY = rule.actionRelativeOffsetY
        region.cooldownMs = rule.timeoutMs
        region.matchDelayMs = rule.matchDelayMs
        region.cooldownVarName = rule.cooldownVarName
        region.matchDelayVarName = rule.matchDelayVarName
        region.scanTimeoutMs = rule.scanTimeoutMs
        region.scanRateHz = rule.scanRateHz
        region.scanTimeoutVarName = rule.scanTimeoutVarName
        region.scanRateVarName = rule.scanRateVarName
        region.maxConsecutiveFailures = rule.maxConsecutiveFailures
        region.enabled = rule.enabled
        region.negate = rule.negateCondition
        region.loopMode = rule.loopMode
        region.requireVariableName = rule.requireVariableName
        region.requireVariableOp = rule.requireVariableOp
        region.requireVariableValue = rule.requireVariableValue
        region.incrementVariableName = rule.incrementVariableName
        region.incrementVariableDelta = rule.incrementVariableDelta
        region.extraActions.clear()
        rule.extraSteps.forEach { region.extraActions.add(stepToExtraAction(it)) }

        // KÖK NEDEN DÜZELTMESİ: "On Fail" artık AYNI kuralın `onFailSteps` alanında — AYRI bir
        // "-fail" gölge kural aramaya GEREK YOK. Geriye dönük uyumluluk için: eğer BU kural
        // henüz eski mimariden GÖÇ ETMEMİŞSE (onFailSteps boş AMA eski bir "-fail" gölge kural
        // hâlâ depoda duruyorsa), onu BİR KEZLİĞİNE oradan da okuyoruz — bir sonraki kaydetmede
        // (saveRegionAsRule) o eski gölge kural zaten silinip yeni modele geçilmiş olacak.
        region.onFailActions.clear()
        if (rule.onFailSteps.isNotEmpty()) {
            rule.onFailSteps.forEach { region.onFailActions.add(stepToExtraAction(it)) }
        } else {
            val legacyFailRule = when (scope) {
                is SaveScope.MainFlow -> RuleStorage.load(this).find { it.id == "${rule.id}-fail" }
                is SaveScope.Group -> ActionGroupStorage.load(this).find { it.id == scope.groupId }?.rules?.find { it.id == "${rule.id}-fail" }
                is SaveScope.Function -> FunctionStorage.load(this).find { it.id == scope.functionId }?.rules?.find { it.id == "${rule.id}-fail" }
            }
            legacyFailRule?.extraSteps?.forEach { region.onFailActions.add(stepToExtraAction(it)) }
        }

        val icon = when (alt.conditionKind) { "IMAGE" -> "🖼️"; "TEXT" -> "📝"; "VARIABLE" -> "🔢"; "CUSTOM" -> "⚡"; else -> "🎨" }
        region.label.text = "$icon ${region.name}"
        // Kutu ekrana yerleşir yerleşmez doğrudan ayar menüsünü aç — listeden bir kurala
        // tıklamak artık TEK adımda o kuralın kendi ayarlarına götürüyor.
        openRegionConfigDialog(region)
    }

    /**
     * "🧪 Test Et": Macrorify'daki "Canlı İzleme" ELLE aç/kapa sistemi kaldırıldı — kullanıcı
     * bunun yerine SADECE test ettiği alan için OTOMATİK geri bildirim istedi. Bu fonksiyon
     * SALT-OKUNUR bir kontrol yapar (gerçek dokunuş/kaydırma YAPMAZ — motoru ÇALIŞTIRMAZ),
     * bu yüzden ekranla senin etkileşimini hiç ENGELLEMEZ. Sonucu ekranda (bloke etmeyen bir
     * toast + alanın üstünde birkaç saniyeliğine yeşil/kırmızı bir çerçeve) gösterir.
     */
    private fun testRule(rule: RuleDefinition) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val firstAlt = rule.alternatives.firstOrNull()
        val screenless = firstAlt == null || firstAlt.conditionKind in listOf("VARIABLE", "CUSTOM")
        val condition = RuleDefinitionMapper.toCondition(rule, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        val score = condition.matchScore(frame)
        val rawMatched = score >= condition.minScore
        val matched = if (rule.negateCondition) !rawMatched else rawMatched
        val color = if (matched) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
        val scoreText = "Skor: %${(score * 100).toInt()} (gereken: %${(condition.minScore * 100).toInt()})"

        clearTestFeedback() // önceki testin kutusu varsa önce temizle

        if (screenless || firstAlt == null) {
            // Bölgesi olmayan (Değişken/Custom) koşullar için ekranda gösterilecek bir yer yok — sadece toast.
            Toast.makeText(this, "${if (matched) "✅ Eşleşti" else "❌ Eşleşmedi"} — $scoreText", Toast.LENGTH_LONG).show()
            return
        }
        val alt = firstAlt // bu noktadan sonra Kotlin'in akıllı tip daraltması güvenilir çalışsın diye YENİ, null OLMAYAN bir isme atandı.

        closeAppPanel() // kutunun görünmesi için paneli kapat (alan panelin ARKASINDA olabilir)
        val box = View(this).apply { background = borderDrawable(color, 5f) }
        val boxParams = WindowManager.LayoutParams(
            alt.width.coerceAtLeast(4), alt.height.coerceAtLeast(4),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = alt.y }
        val label = TextView(this).apply {
            text = "${if (matched) "✅" else "❌"} ${rule.name} — $scoreText"
            setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#DD000000"))
            textSize = 12f; setPadding(16, 6, 16, 6)
        }
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = alt.x; y = (alt.y - 50).coerceAtLeast(0) }
        try {
            windowManager?.addView(box, boxParams)
            windowManager?.addView(label, labelParams)
            testFeedbackBox = box; testFeedbackLabel = label; testFeedbackLabelParams = labelParams
        } catch (e: Exception) {}

        val clearRunnable = Runnable { clearTestFeedback() }
        testFeedbackClearRunnable = clearRunnable
        testFeedbackHandler.postDelayed(clearRunnable, 3000L)
    }

    // ==================== Action Group ====================

    private fun showActionGroupsMenu() {
        val groups = ActionGroupStorage.load(this)
        val options = mutableListOf("➕ Yeni Action Group")
        options.addAll(groups.map { g ->
            val gateInfo = if (g.gate != null) "kapı ✓" else "kapı YOK"
            "📦 ${if (g.enabled) "" else "🔕 "}${g.name} ($gateInfo, ${g.rules.size} tarama)"
        })
        overlayDialog().setTitle("📦 Action Group'lar").setItems(options.toTypedArray()) { _, index ->
            if (index == 0) createActionGroup() else showActionGroupOptions(groups[index - 1])
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    private fun createActionGroup() {
        val input = EditText(this).apply { hint = "Grup adı (örn. \"Savaş Ekranı\")" }
        overlayDialog().setTitle("Yeni Action Group").setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().ifBlank { "grup" }
                ActionGroupStorage.upsert(this, com.bigboss.app.storage.ActionGroupDefinition(UUID.randomUUID().toString(), name))
                Toast.makeText(this, "Oluşturuldu — şimdi \"🎯 Kapı Koşulunu Ayarla\" ile devam et", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showActionGroupOptions(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val options = arrayOf(
            "🎯 Kapı Koşulunu Ayarla/Değiştir",
            "➕ Bu Gruba Tarama Ekle",
            "📋 Gruptaki Taramaları Listele",
            "🖼 Ekranda Göster (bu grubun İÇİNDEKİ TÜM tarama alanları + komutlar)",
            "⚙️ Grup Ayarları (döngü sayısı, kapı sıklığı)",
            if (group.enabled) "🔕 Grubu Devre Dışı Bırak" else "🔔 Grubu Etkinleştir",
            "🗑 Grubu Sil"
        )
        overlayDialog().setTitle("📦 ${group.name}").setItems(options) { _, index ->
            when (index) {
                0 -> startGateRegion(group)
                1 -> startGroupScan(group)
                2 -> showGroupRulesList(group)
                3 -> { closeAppPanel(); showWorkspaceFor(SaveScope.Group(group.id), group.rules, "📦 ${group.name}") }
                4 -> showGroupSettingsDialog(group)
                5 -> {
                    group.enabled = !group.enabled
                    ActionGroupStorage.upsert(this, group)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
                6 -> {
                    ActionGroupStorage.delete(this, group.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /** Gruba özel ayarlar: kapı bulununca kaç kere taransın (döngü sayısı) + kapı ne sıklıkla kontrol edilsin. */
    private fun showGroupSettingsDialog(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        container.addView(TextView(this).apply {
            text = "Döngü sayısı — kapı koşulu bulununca gruptaki taramalar kaç kere art arda çalışsın (Infinite Loop AÇIKSA bu yok sayılır):"
            textSize = 12f
        })
        val repeatInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateRepeat.toString())
        }
        container.addView(repeatInput)
        container.addView(TextView(this).apply {
            text = "Kapı kontrol sıklığı (ms) — kapı koşulu en fazla ne kadar sık kontrol edilsin:"
            textSize = 12f; setPadding(0, 16, 0, 0)
        })
        val cooldownInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateCooldownMs.toString())
        }
        container.addView(cooldownInput)

        container.addView(TextView(this).apply {
            text = "🔁 Infinite Loop"; setTypeface(null, android.graphics.Typeface.BOLD); textSize = 13f; setPadding(0, 20, 0, 4)
        })
        val infiniteCheck = android.widget.CheckBox(this).apply {
            text = "Döngü Sayısı yerine, kapı koşulu doğru olduğu SÜRECE sürekli tekrarla"
            isChecked = group.gateInfiniteLoop
        }
        container.addView(infiniteCheck)
        container.addView(TextView(this).apply {
            text = "Time Limit (ms) — Infinite Loop bu süreyi aşınca otomatik durur. 0 = motorun kendi güvenlik sınırı (5 dakika) uygulanır, GERÇEKTEN sınırsız çalışmaz (uygulamanın donmasını önlemek için)."
            textSize = 11f; setPadding(0, 12, 0, 0)
        })
        val timeLimitInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(group.gateTimeLimitMs.toString())
        }
        container.addView(timeLimitInput)

        overlayDialog().setTitle("⚙️ ${group.name} Ayarları").setView(container)
            .setPositiveButton("Kaydet") { _, _ ->
                group.gateRepeat = repeatInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                group.gateCooldownMs = cooldownInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 300
                group.gateInfiniteLoop = infiniteCheck.isChecked
                group.gateTimeLimitMs = timeLimitInput.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
                ActionGroupStorage.upsert(this, group)
                com.bigboss.app.storage.EngineAssembler.refresh(this)
                Toast.makeText(this, "Ayarlar kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    /**
     * Grubun KAPI koşulunu ayarlamak için ekrana bir alan çizer. `editExistingRule`'daki AYNI
     * düzeltme buraya da uygulandı: aynı grup için ekranda ZATEN açık bir kapı kutusu varsa
     * yenisi oluşturulmuyor (doğrudan mevcut kutunun ayar menüsü açılıyor); yeni oluşturuluyorsa
     * da kutu çizilir çizilmez ayar menüsü OTOMATİK açılıyor — elle ikinci bir dokunuşa gerek yok.
     */
    private fun startGateRegion(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        activeRegions.find { it.isGateForGroupId == group.id }?.let { existing ->
            openRegionConfigDialog(existing)
            return
        }
        val gate = group.gate
        val region = if (gate != null) addRegionWindow(gate.x, gate.y, gate.width, gate.height) else addRegionWindow()
        region.isGateForGroupId = group.id
        if (gate != null) {
            region.conditionKind = gate.conditionKind
            region.conditionColor = gate.color
            region.conditionTemplatePath = gate.templatePath
            region.conditionText = gate.expectedText ?: ""
            region.conditionTextCaseSensitive = gate.textCaseSensitive
            region.conditionTextWhitelist = gate.textWhitelist
            region.conditionTextBlacklist = gate.textBlacklist
            region.minScore = gate.minScore
            region.cooldownMs = group.gateCooldownMs
        }
        region.label.text = "🎯 ${group.name}"
        openRegionConfigDialog(region)
    }

    /** Gruba yeni bir tarama (kural) eklemek için ekrana bir alan çizer. */
    private fun startGroupScan(group: com.bigboss.app.storage.ActionGroupDefinition) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return
        }
        val region = addRegionWindow()
        region.saveScope = SaveScope.Group(group.id)
        region.label.text = "📦 ${group.name} → yeni"
        Toast.makeText(this, "Bu alan \"${group.name}\" grubuna kaydedilecek", Toast.LENGTH_LONG).show()
    }

    private fun showGroupRulesList(group: com.bigboss.app.storage.ActionGroupDefinition) {
        val rules = group.rules.filter { !it.id.endsWith("-fail") }
        if (rules.isEmpty()) {
            Toast.makeText(this, "Bu grupta henüz tarama yok", Toast.LENGTH_SHORT).show(); return
        }
        val labels = rules.mapIndexed { i, r -> "${i + 1}. ${if (r.enabled) "" else "🔕 "}${r.name}" }.toTypedArray()
        overlayDialog().setTitle("📦 ${group.name} (${rules.size})").setItems(labels) { _, idx ->
            val rule = rules[idx]
            overlayDialog().setTitle(rule.name).setItems(arrayOf("✏️ Düzenle", "🗑 Sil")) { _, action ->
                if (action == 0) {
                    editExistingRule(rule, SaveScope.Group(group.id))
                } else {
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, rule.id)
                    ActionGroupStorage.deleteRuleFromGroup(this, group.id, "${rule.id}-fail")
                    com.bigboss.app.storage.EngineAssembler.refresh(this)
                }
            }.create().showOverlay()
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Fonksiyonlar ====================

    /**
     * "f{} Fonksiyonlar" — Ana Akış için yaptığımız AYNI sayfa+araç çubuğu düzeni:
     * dokun = bilgiyi aç, basılı tut = çoklu seç, altta 8 ikonlu toplu işlem çubuğu.
     */
    /**
     * Bir Fonksiyonun İÇİNE dokununca açılan TAM SAYFA ekran — Macrorify'daki
     * "f_..." fonksiyon detay sayfasıyla BİREBİR: Ana Akış'la AYNI 8 ikonlu araç
     * çubuğu (Seç/Çiz/Grup Değiştir yerine burada sadece Çiz — fonksiyon içinde
     * "grup değiştirme" kavramı yok — + Kopyala Kes Yapıştır Sil Yukarı Aşağı),
     * "+" ile AYNI 15 öğelik Macrorify menüsü, ama hepsi bu fonksiyonun KENDİ
     * kural listesine (SaveScope.Function) kaydediliyor.
     */
    private fun buildFunctionDetailScreen(fnId: String): View {
        val ctx = this
        val scope = SaveScope.Function(fnId)
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }

        fun currentFn(): FunctionDefinition? = FunctionStorage.load(ctx).find { it.id == fnId }

        // ✏️ İsim — dokununca yeniden adlandırma (Macrorify'daki "pen icon ile değiştir" — kod editörüyle AYNI desen).
        root.addView(TextView(ctx).apply {
            text = "✏️ ${currentFn()?.name ?: ""}"
            textSize = 13f; setTextColor(ACCENT); setPadding(0, 0, 0, 8)
            setOnClickListener {
                val fn = currentFn() ?: return@setOnClickListener
                val input = EditText(ctx).apply { setText(fn.name) }
                overlayDialog().setTitle("Yeniden Adlandır").setView(input)
                    .setPositiveButton("Kaydet") { _, _ ->
                        fn.name = input.text.toString().ifBlank { fn.name }
                        FunctionStorage.upsert(ctx, fn)
                        if (navStack.isNotEmpty()) navStack[navStack.size - 1] = NavEntry("f{} ${fn.name}", navStack.last().build)
                        renderCurrentScreen()
                    }.setNegativeButton("Vazgeç", null).create().showOverlay()
            }
        })

        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun currentRules(): List<RuleDefinition> = currentFn()?.rules?.filter { !it.id.endsWith("-fail") } ?: emptyList()

        fun buildContent() {
            listContainer.removeAllViews()
            val rules = currentRules()
            if (rules.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz adım yok — alttaki + ile başla"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = rules.size
                override fun getItem(position: Int): Any = rules[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    val r = rules[position]
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = if (r.enabled) anaAkisRuleIcon(r) else "🔕"
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = r.name
                    view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = if (!r.enabled) "🔕" else if (r.loopMode == "ALWAYS") "" else r.loopMode
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.45).toInt())
            listView.setOnItemClickListener { _, _, position, _ -> openRuleForEditing(rules[position], scope) }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged(); true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = düzenle · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedRules(): List<RuleDefinition> = selectedIndices.sorted().mapNotNull { currentRules().getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        // 1) "Draw selected": bir/birkaç adım seçiliyse SADECE onları ekranda göster; değilse
        //    fonksiyonun TÜM adımlarını göster (Macrorify'daki "render the content of that Group"
        //    ile aynı mantık — fonksiyonun kendisi de bir Group, bu yüzden "grup değiştirme" yok,
        //    çünkü zaten bu fonksiyonun İÇİNDEYİZ).
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_select_frame, C_BLUE) {
            val sel = selectedRules()
            closeAppPanel()
            if (sel.isNotEmpty()) showWorkspaceFor(scope, sel, "🔍 Seçililer (${sel.size})")
            else showWorkspaceFor(scope, currentRules(), "f{} ${currentFn()?.name ?: ""}")
        })
        // 2) +: Ana Akış'takiyle AYNI 15 öğelik Macrorify menüsü, bu fonksiyona kaydedilir.
        // KULLANICI RAPORU: "+" ile bir adım (örn. Code) eklenince listede HEMEN görünmüyordu,
        // fonksiyonu kapatıp AÇMAK gerekiyordu — HİÇBİR quickAdd* çağrısı ARDINDAN listeyi
        // yeniden çizmiyordu. Artık HEMEN bir kural oluşturan TÜM öğeler `buildContent()`'i de
        // çağırıyor (Image/Text/Color Detection ve Conditional gibi ERTELENMİŞ/panel-kapatan
        // akışlar hariç — onlar zaten panel kapandığı için buna ihtiyaç duymuyor).
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_add, C_BLUE) {
            showIconMenuDialog("Ne eklemek istersin?", buildAddMenuItems(scope) { buildContent() })
        })
        // 3-8) Kopyala/Kes/Yapıştır/Sil/Yukarı/Aşağı — TÜM şemalarda paylaşılan TEK algoritma (bkz. Ana Akış).
        buildStandardToolbar(
            ctx, toolbarRow, scope,
            getSelectedRules = { selectedRules() },
            onRefresh = { refreshThisScreen() }
        )
        footer.addView(toolbarRow)
        footer.addView(TextView(ctx).apply {
            text = "🗑 Fonksiyonu Tamamen Sil"
            textSize = 11f; setTextColor(C_RED); setPadding(0, 10, 0, 0)
            setOnClickListener {
                overlayDialog().setTitle("Fonksiyonu Sil").setMessage("\"${currentFn()?.name}\" tamamen silinsin mi?")
                    .setPositiveButton("Sil") { _, _ ->
                        FunctionStorage.delete(ctx, fnId)
                        com.bigboss.app.storage.EngineAssembler.refresh(ctx)
                        closeAppPanel()
                    }.setNegativeButton("Vazgeç", null).create().showOverlay()
            }
        })

        buildContent()
        // Macrorify'daki "by default everything in this Group is rendered" — fonksiyon zaten
        // kendi Group'u olduğu için açılınca TÜM adımları otomatik (sessizce) ekranda gösterilir.
        showWorkspaceForSilent(scope, currentRules(), "f{} ${currentFn()?.name ?: ""}")
        return root
    }

    /** "Functions" listesindeki tek bir öğe: ya bir Fonksiyon (f{}, görsel adım dizisi) ya bir Script (</>, kod). */
    private sealed class FunctionsEntry {
        data class Fn(val fn: FunctionDefinition) : FunctionsEntry()
        data class Scr(val script: com.bigboss.app.storage.ScriptDefinition) : FunctionsEntry()
    }

    private fun buildFonksiyonlarScreen(): View {
        val ctx = this
        val selectedIndices = mutableSetOf<Int>()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        root.addView(listContainer); root.addView(footer)

        fun currentEntries(): List<FunctionsEntry> {
            val entries = mutableListOf<FunctionsEntry>()
            FunctionStorage.load(ctx).forEach { entries.add(FunctionsEntry.Fn(it)) }
            com.bigboss.app.storage.ScriptStorage.load(ctx).forEach { entries.add(FunctionsEntry.Scr(it)) }
            return entries
        }

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply { text = "Henüz fonksiyon/kod yok — alttaki f{} ya da </> ile oluştur"; setPadding(0, 24, 0, 24) })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_ana_akis_row, parent, false)
                    when (val entry = entries[position]) {
                        is FunctionsEntry.Fn -> {
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "f{}"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = entry.fn.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "${entry.fn.rules.size} adım"
                        }
                        is FunctionsEntry.Scr -> {
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowIcon).text = "</>"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = entry.script.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = entry.script.language
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.45).toInt()
            )
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is FunctionsEntry.Fn -> pushScreen("f{} ${entry.fn.name}") { buildFunctionDetailScreen(entry.fn.id) }
                    is FunctionsEntry.Scr -> pushScreen("</> ${entry.script.name}") { buildCodeEditorContent(entry.script.id) }
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<FunctionsEntry> = selectedIndices.sorted().mapNotNull { currentEntries().getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        // ---- Macrorify'daki TEK SATIR, 8 gerçek vektör ikonlu araç çubuğu: f{} (Fonksiyon Ekle),
        // </> (Kod Ekle), Kopyala, Kes, Yapıştır, Sil, Yukarı, Aşağı. ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        // Macrorify: "By default, when declare new function, the system automatically generate
        // the name using the format f_ + current time in miliseconds. You can change it using
        // the pen icon." — İSİM SORULMUYOR, anında oluşturulup doğrudan İÇİNE giriliyor.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_function, C_GREEN) {
            val fn = FunctionDefinition(UUID.randomUUID().toString(), "f_${System.currentTimeMillis()}")
            FunctionStorage.upsert(ctx, fn)
            pushScreen("f{} ${fn.name}") { buildFunctionDetailScreen(fn.id) }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_code, C_BLUE) { addScriptEntry() })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            when (val sel = selectedEntries().firstOrNull()) {
                is FunctionsEntry.Fn -> { com.bigboss.app.storage.FunctionClipboard.copy(sel.fn); Toast.makeText(ctx, "Kopyalandı: ${sel.fn.name}", Toast.LENGTH_SHORT).show() }
                is FunctionsEntry.Scr -> copyScriptEntry(sel.script)
                null -> Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            when (val sel = selectedEntries().firstOrNull()) {
                is FunctionsEntry.Fn -> {
                    com.bigboss.app.storage.FunctionClipboard.copy(sel.fn); FunctionStorage.delete(ctx, sel.fn.id)
                    com.bigboss.app.storage.EngineAssembler.refresh(ctx); refreshThisScreen()
                }
                is FunctionsEntry.Scr -> { cutScriptEntry(sel.script); refreshThisScreen() }
                null -> Toast.makeText(ctx, "Önce (basılı tutarak) bir öğe seç", Toast.LENGTH_SHORT).show()
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val pastedFn = com.bigboss.app.storage.FunctionClipboard.pasteAsNew()
            if (pastedFn != null) { FunctionStorage.upsert(ctx, pastedFn); refreshThisScreen(); return@makeToolIcon }
            if (tryPasteScriptEntry()) { refreshThisScreen(); return@makeToolIcon }
            Toast.makeText(ctx, "Panoda bir şey yok", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { entry ->
                when (entry) {
                    is FunctionsEntry.Fn -> FunctionStorage.delete(ctx, entry.fn.id)
                    is FunctionsEntry.Scr -> deleteScriptEntry(entry.script)
                }
            }
            com.bigboss.app.storage.EngineAssembler.refresh(ctx)
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { entry ->
                when (entry) {
                    is FunctionsEntry.Fn -> FunctionStorage.moveUp(ctx, entry.fn.id)
                    is FunctionsEntry.Scr -> com.bigboss.app.storage.ScriptStorage.moveUp(ctx, entry.script.id)
                }
            }
            refreshThisScreen()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.asReversed().forEach { entry ->
                when (entry) {
                    is FunctionsEntry.Fn -> FunctionStorage.moveDown(ctx, entry.fn.id)
                    is FunctionsEntry.Scr -> com.bigboss.app.storage.ScriptStorage.moveDown(ctx, entry.script.id)
                }
            }
            refreshThisScreen()
        })
        footer.addView(toolbarRow)

        buildContent()
        return root
    }

    /** Fonksiyona tam bir tarama alanı YERİNE, sadece koşulsuz bir dokunma/kaydırma adımı ekler. */
    private fun promptTapHold(onDone: (Long) -> Unit) {
        val input = EditText(this).apply { hint = "HOLD (ms) — basılı tutma süresi"; inputType = InputType.TYPE_CLASS_NUMBER; setText("50") }
        overlayDialog().setTitle("⏱️ Basılı Tutma Süresi").setView(input)
            .setPositiveButton("Tamam") { _, _ -> onDone(input.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 50) }
            .setNegativeButton("Atla (varsayılan 50ms)") { _, _ -> onDone(50) }
            .create().showOverlay()
    }

    /** Ana Akış'a doğrudan, koşulsuz bir dokunma/kaydırma adımı ekler (tarama alanı gerekmeden). */
    /**
     * YENİDEN YAZILDI (kullanıcı isteği): "Onayla" YOK, "Hold süresi gir" gibi ÖN-sorular YOK.
     * Kural, DEFAULT (ekran ortası, makul hold/repeat) değerlerle ANINDA oluşturulup kaydedilir
     * ve numaralı, sürüklenebilir bir daire (Image 2'deki gibi) olarak GÖSTERİLİR — kullanıcı
     * konumu sürükleyerek, ince ayarları (Hold/Repeat/Delay) kısa dokunuşla (showTapPointEditor/
     * showSwipePointEditor, işaretçileri SİLMEDEN) düzenler. Bu, hem daha PRATİK hem de kayıtlı
     * kuralların ZATEN kullandığı işaretçi sistemiyle TUTARLI.
     */
    /** Aynı "+ Click/Swipe" eylemi ÇOK KISA sürede (dialog/dokunuş sisteminin bilinen bir
     *  "çift tetikleme" sınıfı hatası yüzünden) İKİ KEZ tetiklenirse İKİNCİ (yinelenen) kuralın
     *  oluşmasını engeller — kullanıcı raporu: "1 click oluşturunca 2 tane oluşuyor". */
    private var lastAddStepAt = 0L
    private fun addStepDebounced(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAddStepAt < 700L) return false
        lastAddStepAt = now
        return true
    }

    /**
     * KULLANICI İSTEĞİ: "ayrı ayrı algoritma üretmek yerine tek bir algoritma üret, tüm
     * şemalar bu ortak hafızadan çeksin." Eskiden `addSimpleStepToMainFlow` (RuleStorage +
     * `showClickMarkers()` ile TÜM ekranı yeniden çiziyordu) VE `addSimpleStepToFunction`
     * (FunctionStorage + `placeLiveMarker`/`addSwipeFrame`'i EL İLE, ~50 satır TEKRARLI kodla
     * yeniden yazıyordu) AYNI işi İKİ FARKLI şekilde yapan iki AYRI fonksiyondu — biri
     * değişince öbürü GÜNCELLENMEYİ UNUTULABİLİYORDU. Artık TEK fonksiyon: kaydetme için zaten
     * paylaşılan `saveRuleToScope`, çizim için zaten paylaşılan `drawTapMarkerU`/
     * `drawSwipeMarkersU`'yu kullanıyor — Ana Akış/Fonksiyon/Grup FARK ETMEKSİZİN AYNI kod yolu.
     */
    private fun addSimpleStep(scope: SaveScope, type: String) {
        if (!addStepDebounced()) return
        val frame = ScreenCaptureService.latestFrame
        val cx = (frame?.width ?: 1080) / 2; val cy = (frame?.height ?: 1920) / 2
        if (type == "TAP") {
            val def = RuleDefinition(
                id = UUID.randomUUID().toString(), name = "👆 Dokunma",
                alternatives = mutableListOf(), timeoutMs = 100, loopMode = "ALWAYS",
                actionType = "TAP", actionX = cx, actionY = cy
            )
            saveRuleToScope(scope, def)
            drawTapMarkerU(def, scope, 1)
            Toast.makeText(this, "Eklendi: 👆 Dokunma — işaretçiyi sürükle, dokununca hızlı ayarları aç", Toast.LENGTH_LONG).show()
        } else {
            val def = RuleDefinition(
                id = UUID.randomUUID().toString(), name = "👉 Kaydırma",
                alternatives = mutableListOf(), timeoutMs = 100, loopMode = "ALWAYS",
                actionType = "SWIPE", actionX = cx - 150, actionY = cy, actionX2 = cx + 150, actionY2 = cy
            )
            saveRuleToScope(scope, def)
            drawSwipeMarkersU(def, scope, 1)
            Toast.makeText(this, "Eklendi: 👉 Kaydırma — iki işaretçiyi de istediğin yere sürükle", Toast.LENGTH_LONG).show()
        }
    }

    // ==================== Kod (Script) ====================

    /**
     * Macrorify'daki tam ekran "Code" editörüyle BİREBİR: satır numaralı kod alanı, sağ üstte
     * ▶️ Çalıştır 💡 Snippet 📋 Kopyala ✂️ Kes 📥 Yapıştır 🗑 Temizle ☰ Düzenle ⇥| Girinti araç
     * çubuğu. Her tuş vuruşunda otomatik kaydedilir (Macrorify'da da görünür bir "Kaydet"
     * butonu yok — canlı kaydediliyor).
     */
    /**
     * TEK, MERKEZİ "Code" editör düzeni (ekran görüntüsündeki hedef tasarım: "← Code ✏️" başlığı +
     * ▶️ 💡 📋 ✂️ 📥 🗑 ≡ ⇥ araç çubuğu + satır numaralı EMScript alanı).
     *
     * KULLANICI İSTEĞİ (14 Temmuz): "tüm pencerelerde işlem ağacına kod eklemek istersek [...]
     * bir düzen ile kod ekleyelim" — Script Kütüphanesi, Ana Akış/Fonksiyon/Grup'a hızlı kod
     * ekleme VE var olan bir kod adımını düzenleme dahil HER YERDE bu AYNI fonksiyon kullanılır.
     * Hangi veri kaynağına (ScriptDefinition, RuleDefinition...) okunup yazılacağı get/set
     * lambdalarıyla dışarıdan enjekte edilir — editörün kendisi hiçbir zaman çatallanmaz.
     *
     * @param title      Üst başlıkta gösterilecek metin (rename yoksa sabit "Code").
     * @param getCode    Mevcut kodu okur.
     * @param setCode    Her tuş vuruşunda (canlı, "Kaydet" butonu YOK) çağrılır.
     * @param onRename   null ise ✎ ikonu gizlenir (örn. hızlı kod adımlarında isim yok);
     *                   verilirse ✎'ye dokununca çağrılır (yeni ismi döndürmesi beklenmez,
     *                   çağıran kendi diyaloğunu açıp `renderCurrentScreen()`'i kendisi tetikler).
     */
    private fun buildCodeEditorScreen(
        ctx: android.content.Context,
        title: String,
        getCode: () -> String,
        setCode: (String) -> Unit,
        onRename: (() -> Unit)? = null
    ): View {
        val density = resources.displayMetrics.density
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        // Ekran görüntüsündeki hedef tasarım: "← Code ✏️" — geri oku, ortalanmış başlık,
        // sağda (varsa) yeniden-adlandırma kalemi. (Panelin GENEL "← GERİ"/"KAPAT" çubuğu zaten
        // ayrıca var — bu, o çubuğun ALTINDA ekrana özel ikinci bir başlık satırı.)
        val headerRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (12 * density).toInt())
        }
        headerRow.addView(TextView(ctx).apply {
            text = "←"; textSize = 20f; setTextColor(ACCENT); setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, (16 * density).toInt(), 0)
            setOnClickListener { popScreen() }
        })
        headerRow.addView(TextView(ctx).apply {
            text = title; textSize = 16f; setTextColor(TEXT_PRIMARY); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (onRename != null) {
            headerRow.addView(TextView(ctx).apply {
                text = "✎"; textSize = 18f; setTextColor(ACCENT)
                setPadding((16 * density).toInt(), 0, 0, 0)
                setOnClickListener { onRename() }
            })
        }
        root.addView(headerRow)

        // ---- Satır numaralı kod alanı (önce tanımlanıyor, araç çubuğu bunu referans alacak) ----
        val lineNumbers = TextView(ctx).apply {
            typeface = android.graphics.Typeface.MONOSPACE; textSize = 13f
            setTextColor(Color.parseColor("#AAAAAA")); gravity = Gravity.END or Gravity.TOP
            setPadding(0, (2 * density).toInt(), (8 * density).toInt(), 0)
        }
        val codeInput = EditText(ctx).apply {
            setText(getCode())
            hint = "Enter your code here"
            typeface = android.graphics.Typeface.MONOSPACE; textSize = 13f
            isSingleLine = false; gravity = Gravity.TOP or Gravity.START
            background = null
            setPadding(0, (2 * density).toInt(), 0, 0)
        }
        fun updateLineNumbers() {
            val n = (codeInput.text?.toString()?.count { it == '\n' } ?: 0) + 1
            lineNumbers.text = (1..n).joinToString("\n") { String.format("%02d", it) }
        }
        updateLineNumbers()
        codeInput.addTextChangedListener(simpleWatcher { text ->
            updateLineNumbers()
            setCode(text)
        })

        fun insertAtCursor(snippet: String) {
            val start = codeInput.selectionStart.coerceAtLeast(0)
            val end = codeInput.selectionEnd.coerceAtLeast(0)
            codeInput.text?.replace(minOf(start, end), maxOf(start, end), snippet)
        }
        fun selectedOrAllText(): String {
            val s = codeInput.selectionStart; val e = codeInput.selectionEnd
            val text = codeInput.text?.toString() ?: ""
            return if (s in 0 until text.length && e in 0..text.length && s != e) text.substring(minOf(s, e), maxOf(s, e)) else text
        }

        // ---- Üst araç çubuğu: ▶️ Çalıştır, 💡 Snippet, Kopyala, Kes, Yapıştır, Temizle, Düzenle, Girinti ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, 0, 0, 8) }
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_play, C_GREEN) {
            // KULLANICI İSTEĞİ (14 Temmuz): JS/Rhino seçeneği kaldırıldığı için ▶️ Çalıştır da
            // artık HER ZAMAN EMScript yorumlayıcısını (EmScriptRunner + AndroidEmHost) kullanır
            // — script.language zaten üstte EMSCRIPT'e zorlanıyor. Eski "JS" olarak kaydedilmiş
            // bir scripti burada AÇIP test edersen o da artık EMScript olarak çalıştırılır (dil
            // alanı üstte sessizce EMSCRIPT'e çevrildi).
            val host = com.bigboss.app.engine.ScriptRuntime.emHost
            if (host == null) {
                Toast.makeText(ctx, "Motor hazır değil — önce ✏️ Edit Mode ya da ▶️ Play Mode'u başlatman gerekiyor (o an OverlayService'i kuran taraf ScriptRuntime.emHost'u da kuruyor)", Toast.LENGTH_LONG).show()
            } else if (com.bigboss.app.service.ScreenCaptureService.latestFrame == null) {
                Toast.makeText(ctx, "Henüz ekran görüntüsü yok — birkaç saniye bekleyip tekrar dene (Region taraması için gerekli)", Toast.LENGTH_LONG).show()
            } else {
                val rawError = com.bigboss.app.emscript.EmScriptRunner.run(codeInput.text.toString(), host)
                if (rawError == null) {
                    Toast.makeText(ctx, "✅ Çalıştırıldı — hata yok", Toast.LENGTH_SHORT).show()
                } else {
                    // EMScript hataları "Satır N: mesaj" formatındadır (bkz. EmScriptError) —
                    // imleci ilgili satıra atlıyoruz.
                    val lineMatch = Regex("""^Satır (\d+):""").find(rawError)
                    val lineNum = lineMatch?.groupValues?.get(1)?.toIntOrNull()
                    val displayMessage = "❌ $rawError"

                    if (lineNum != null) {
                        val lines = codeInput.text.toString().split("\n")
                        if (lineNum - 1 in lines.indices) {
                            val offset = lines.take(lineNum - 1).sumOf { it.length + 1 }
                            codeInput.setSelection(offset.coerceIn(0, codeInput.text?.length ?: 0))
                            codeInput.requestFocus()
                        }
                    }
                    overlayDialog().setTitle("Çalıştırma Hatası").setMessage(displayMessage)
                        .setPositiveButton("Tamam", null).create().showOverlay()
                }
            }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_bulb, Color.parseColor("#F5C518")) {
            showCodeSnippetMenu { snippet -> insertAtCursor(snippet) }
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_copy, C_GREEN) {
            val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("code", selectedOrAllText()))
            Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_cut, C_BLUE) {
            val s = codeInput.selectionStart; val e = codeInput.selectionEnd
            val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("code", selectedOrAllText()))
            if (s in 0 until (codeInput.text?.length ?: 0) && e in 0..(codeInput.text?.length ?: 0) && s != e) {
                codeInput.text?.replace(minOf(s, e), maxOf(s, e), "")
            } else {
                codeInput.setText("")
            }
            Toast.makeText(ctx, "Kesildi", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_paste, C_ORANGE) {
            val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString() ?: ""
            if (clip.isNotEmpty()) insertAtCursor(clip) else Toast.makeText(ctx, "Panoda metin yok", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            overlayDialog().setTitle("Kodu Temizle").setMessage("Tüm kod silinsin mi?")
                .setPositiveButton("Temizle") { _, _ -> codeInput.setText("") }
                .setNegativeButton("Vazgeç", null).create().showOverlay()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_format, C_GREEN) {
            // Basit "format": satır sonu boşluklarını temizler, fazla boş satırları teke indirir.
            val cleaned = codeInput.text.toString().lines().joinToString("\n") { it.trimEnd() }.replace(Regex("\n{3,}"), "\n\n")
            codeInput.setText(cleaned)
            codeInput.setSelection(codeInput.text?.length ?: 0)
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_indent, C_GREEN) {
            insertAtCursor("    ")
        })

        root.addView(toolbarRow)

        val editorRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        editorRow.addView(lineNumbers)
        editorRow.addView(codeInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(editorRow)

        return root
    }

    /** Script Kütüphanesi'ndeki bir kaydı `buildCodeEditorScreen` ile açar (isim değiştirme dahil). */
    private fun buildCodeEditorContent(scriptId: String): View {
        val ctx = this
        val script = com.bigboss.app.storage.ScriptStorage.load(ctx).find { it.id == scriptId }
            ?: return TextView(ctx).apply { text = "Script bulunamadı (silinmiş olabilir)"; setPadding(24, 24, 24, 24) }

        // KULLANICI İSTEĞİ (14 Temmuz): dil seçim RadioGroup'u (JavaScript/EMScript) tamamen
        // kaldırıldı — sistem artık HER ZAMAN EMScript kullanıyor. Eski bir script hâlâ "JS"
        // olarak kayıtlıysa, burada sessizce EMSCRIPT'e geçiriliyor.
        if (script.language != "EMSCRIPT") {
            script.language = "EMSCRIPT"
            com.bigboss.app.storage.ScriptStorage.upsert(ctx, script)
        }

        return buildCodeEditorScreen(
            ctx, "Code",
            getCode = { script.code },
            setCode = { text -> script.code = text; com.bigboss.app.storage.ScriptStorage.upsert(ctx, script) },
            onRename = {
                val input = EditText(ctx).apply { setText(script.name) }
                overlayDialog().setTitle("Yeniden Adlandır").setView(input)
                    .setPositiveButton("Kaydet") { _, _ ->
                        script.name = input.text.toString().ifBlank { script.name }
                        com.bigboss.app.storage.ScriptStorage.upsert(ctx, script)
                        if (navStack.isNotEmpty()) navStack[navStack.size - 1] = NavEntry("</> ${script.name}", navStack.last().build)
                        renderCurrentScreen()
                    }.setNegativeButton("Vazgeç", null).create().showOverlay()
            }
        )
    }

    /**
     * 💡 Snippet menüsü (Macrorify'daki "Variables / Setting Builder / Current Time / Middle
     * Screen / Random Number / if-else-do-while-for" listesiyle birebir). Seçilen snippet
     * doğrudan imlecin bulunduğu yere eklenir.
     */
    private fun showCodeSnippetMenu(onPick: (String) -> Unit) {
        val ctx = this
        val items = listOf(
            "Variables" to null,
            "Setting Builder" to "settingGet(\"key\")",
            "Current Time (milliseconds)" to "Date.now()",
            "Middle Screen (Point)" to "Point(screenWidth() / 2, screenHeight() / 2)",
            "Random Number" to "randomInt(0, 100)",
            "</> if () { }" to "if (condition) {\n    \n}",
            "</> else { }" to "else {\n    \n}",
            "</> do { } while ()" to "do {\n    \n} while (condition)",
            "</> while () { }" to "while (condition) {\n    \n}",
            "</> for (;;) { }" to "for (var i = 0; i < 10; i++) {\n    \n}"
        )
        overlayDialog().setTitle("💡 Ekle").setItems(items.map { it.first }.toTypedArray()) { _, idx ->
            val (label, snippet) = items[idx]
            if (snippet != null) { onPick(snippet); return@setItems }
            // "Variables": kayıtlı değişkenlerden seçtir, yoksa adını yazdır.
            val names = (com.bigboss.app.storage.GlobalVariableStorage.load(ctx).map { it.name } + com.bigboss.app.engine.VariableStore.getAll().keys).distinct()
            if (names.isEmpty()) {
                val input = EditText(ctx).apply { hint = "Değişken adı" }
                overlayDialog().setTitle("Değişken Adı").setView(input)
                    .setPositiveButton("Ekle") { _, _ -> onPick("getVar(\"${input.text}\")") }
                    .setNegativeButton("Vazgeç", null).create().showOverlay()
            } else {
                overlayDialog().setTitle("Değişken Seç").setItems(names.toTypedArray()) { _, i -> onPick("getVar(\"${names[i]}\")") }
                    .setNegativeButton("Kapat", null).create().showOverlay()
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    // ==================== Kütüphane ====================

    /** 🎨+ ikonu: Macrorify'daki gibi "Pick from screen" / "Manual" seçtirir. */
    private fun showColorAddMenu(scope: String, existing: LibraryItem? = null, onSaved: (() -> Unit)? = null) {
        overlayDialog().setItems(arrayOf("Pick from screen", "Manual")) { _, idx ->
            when (idx) {
                0 -> { closeAppPanel(); startColorPickRegion(scope, existing, onSaved) }
                1 -> openManualColorEditor(scope, existing, onSaved)
            }
        }.setNegativeButton("Kapat", null).create().showOverlay()
    }

    /**
     * KULLANICI İSTEĞİ (güncellendi): "alan kullanmak yerine tıkladığımız nokta için daha büyük
     * bir alanda piksellik hassasiyetle renk seçmek" — artık bir BÖLGE çizmiyoruz. Kullanıcı
     * rengini istediği NOKTAYA bir kez dokunuyor; ardından o noktanın ETRAFINDAKİ daha geniş bir
     * alanı (radius kadar) sınır alan büyüteç+piksel-adım editörü açılıyor. Böylece kaba dokunuş
     * yeterli — ince ayarı büyüteçte piksel piksel yapıyor, ama daha büyük bir komşulukta gezebiliyor.
     */
    private fun startColorPickRegion(scope: String, existing: LibraryItem?, onSaved: (() -> Unit)?) {
        if (ScreenCaptureService.latestFrame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Rengini almak istediğin NOKTAYA dokun — sonra büyüteçle piksel piksel ince ayar yaparsın", Toast.LENGTH_LONG).show()
        showTouchCatcher { bx, by ->
            val frame = ScreenCaptureService.latestFrame
            if (frame == null) {
                Toast.makeText(this, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show()
                return@showTouchCatcher
            }
            // Tıklanan noktanın ETRAFINDA piksel piksel gezilebilecek DAHA BÜYÜK alan (radius).
            // KULLANICI İSTEĞİ: "önüme sunulan ekranın 2 katı büyüklükte bir alana hitap etmeli" — 2x.
            val radius = (120 * resources.displayMetrics.density).toInt()
            val minX = (bx - radius).coerceAtLeast(0)
            val minY = (by - radius).coerceAtLeast(0)
            val maxX = (bx + radius).coerceAtMost(frame.width - 1)
            val maxY = (by + radius).coerceAtMost(frame.height - 1)
            openPickFromScreenColorEditor(scope, bx, by, existing, onSaved, intArrayOf(minX, minY, maxX, maxY))
        }
    }

    /** Seçilen renk-alanının MERKEZİNDEN başlayarak büyüteç+piksel-adım editörünü açar. */
    private fun openColorPickFromRegion(region: ActiveRegion) {
        val r = regionRect(region)
        val cx = r[0] + r[2] / 2
        val cy = r[1] + r[3] / 2
        val bounds = intArrayOf(r[0], r[1], r[0] + r[2] - 1, r[1] + r[3] - 1)
        val scope = region.colorPickScope
        val existing = region.colorPickExisting
        val onSaved = region.colorPickOnSaved
        removeRegionWindow(region)
        openPickFromScreenColorEditor(scope, cx, cy, existing, onSaved, bounds)
    }

    private fun saveColorItem(scope: String, existing: LibraryItem?, color: Int, description: String) {
        val name = description.ifBlank { String.format("#%06X", 0xFFFFFF and color) }
        val item = existing?.copy(color = color, description = description, name = name)
            ?: LibraryItem(UUID.randomUUID().toString(), name, "COLOR", color, description = description)
        if (scope == "GLOBAL") com.bigboss.app.storage.GlobalLibraryStorage.upsert(this, item)
        else LibraryStorage.upsert(this, item)
    }

    /** Macrorify'daki "Manual" renk editörü — A/R/G/B slider'ları + hex alanı + Description. */
    private fun openManualColorEditor(scope: String, existing: LibraryItem?, onSaved: (() -> Unit)?) {
        val ctx = this
        val density = resources.displayMetrics.density
        val initial = existing?.color ?: Color.BLACK
        var a = (initial shr 24) and 0xFF; var r = (initial shr 16) and 0xFF
        var g = (initial shr 8) and 0xFF; var b = initial and 0xFF
        fun current() = (a shl 24) or (r shl 16) or (g shl 8) or b

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((32 * density).toInt(), (16 * density).toInt(), (32 * density).toInt(), 0) }

        val btnPickFromScreen = Button(ctx).apply { text = "📷 PICK FROM SCREEN" }
        root.addView(btnPickFromScreen)

        val preview = View(ctx).apply {
            setBackgroundColor(current())
            layoutParams = LinearLayout.LayoutParams((60 * density).toInt(), (60 * density).toInt()).apply { topMargin = (8 * density).toInt() }
        }
        val previewRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previewRow.addView(preview)
        root.addView(previewRow)

        val hexInput = EditText(ctx).apply { setText(String.format("#%08X", current())) }

        fun refreshPreview() { preview.setBackgroundColor(current()); hexInput.setText(String.format("#%08X", current())) }

        lateinit var sliderA: SeekBar; lateinit var sliderR: SeekBar; lateinit var sliderG: SeekBar; lateinit var sliderB: SeekBar
        lateinit var tvA: TextView; lateinit var tvR: TextView; lateinit var tvG: TextView; lateinit var tvB: TextView

        fun sliderRow(label: String, initialVal: Int, onChange: (Int) -> Unit): Pair<LinearLayout, Pair<SeekBar, TextView>> {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, (6 * density).toInt(), 0, 0) }
            val valueTv = TextView(ctx).apply { text = initialVal.toString(); layoutParams = LinearLayout.LayoutParams((40 * density).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT) }
            val seek = SeekBar(ctx).apply { max = 255; progress = initialVal; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) { onChange(v); valueTv.text = v.toString(); refreshPreview() }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            row.addView(valueTv); row.addView(seek)
            return row to (seek to valueTv)
        }
        sliderRow("A", a) { a = it }.let { (row, pair) -> root.addView(row); sliderA = pair.first; tvA = pair.second }
        sliderRow("R", r) { r = it }.let { (row, pair) -> root.addView(row); sliderR = pair.first; tvR = pair.second }
        sliderRow("G", g) { g = it }.let { (row, pair) -> root.addView(row); sliderG = pair.first; tvG = pair.second }
        sliderRow("B", b) { b = it }.let { (row, pair) -> root.addView(row); sliderB = pair.first; tvB = pair.second }

        root.addView(TextView(ctx).apply { text = "#FFRRGGBB"; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (12 * density).toInt(), 0, 0) })
        root.addView(hexInput)
        hexInput.addTextChangedListener(simpleWatcher { text ->
            val parsed = try { Color.parseColor(text) } catch (e: Exception) { null } ?: return@simpleWatcher
            a = (parsed shr 24) and 0xFF; r = (parsed shr 16) and 0xFF; g = (parsed shr 8) and 0xFF; b = parsed and 0xFF
            preview.setBackgroundColor(parsed)
            sliderA.progress = a; sliderR.progress = r; sliderG.progress = g; sliderB.progress = b
            tvA.text = a.toString(); tvR.text = r.toString(); tvG.text = g.toString(); tvB.text = b.toString()
        })

        root.addView(TextView(ctx).apply { text = "Description"; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (12 * density).toInt(), 0, 0) })
        val descInput = EditText(ctx).apply { setText(existing?.description ?: existing?.name ?: "") }
        root.addView(descInput)

        overlayDialog().setTitle(if (existing != null) "Rengi Düzenle" else "Yeni Renk (Manual)").setView(root)
            .setPositiveButton("SAVE") { _, _ ->
                saveColorItem(scope, existing, current(), descInput.text.toString())
                onSaved?.invoke()
            }
            .setNegativeButton("CANCEL", null).create().also { dlg ->
                btnPickFromScreen.setOnClickListener {
                    dlg.dismiss()
                    closeAppPanel()
                    startColorPickRegion(scope, existing, onSaved)
                }
            }.showOverlay()
    }

    /**
     * Macrorify'daki "Pick from screen" renk editörü — dokunulan noktanın etrafını büyüteçle
     * gösterir, X/Y ile 1 piksel hassasiyetinde ince ayar yapılabilir (her değişiklikte renk
     * YENİDEN örneklenir).
     */
    private fun openPickFromScreenColorEditor(
        scope: String, initialX: Int, initialY: Int, existing: LibraryItem?, onSaved: (() -> Unit)?,
        bounds: IntArray? = null // [minX, minY, maxX, maxY] — KULLANICI İSTEĞİ: piksel-piksel seçim, kullanıcının SEÇTİĞİ alanla SINIRLI olsun
    ) {
        val ctx = this
        val density = resources.displayMetrics.density
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) { Toast.makeText(ctx, "Ekran görüntüsü yok", Toast.LENGTH_SHORT).show(); return }
        val minX = bounds?.get(0) ?: 0
        val minY = bounds?.get(1) ?: 0
        val maxX = bounds?.get(2) ?: (frame.width - 1)
        val maxY = bounds?.get(3) ?: (frame.height - 1)
        var px = initialX.coerceIn(minX, maxX)
        var py = initialY.coerceIn(minY, maxY)

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), 0) }

        val magnifierSize = (200 * density).toInt()
        // KULLANICI İSTEĞİ: dokunulan yerin çevresi çok küçük gösteriliyordu, "nereyi seçtiğim
        // anlaşılmıyor" — büyütecin GERÇEK ekrandan kırptığı alan 2 katına çıkarıldı (24→48).
        val cropSize = 48 // büyütecin GERÇEK ekrandan kırptığı piksel boyutu (kare)
        val magnifier = android.widget.ImageView(ctx).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(magnifierSize, magnifierSize)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            background = android.graphics.drawable.GradientDrawable().apply { setStroke((2 * density).toInt(), C_PURPLE); setColor(Color.TRANSPARENT) }
        }
        // KULLANICI İSTEĞİ: "tam nereyi seçtiğimiz belirsiz" — büyütecin TAM ORTASINA (kırpma
        // HER ZAMAN o an seçili pikseli merkez alır) ince bir artı/çerçeve işareti çiziyoruz,
        // ki hangi pikselin örneklendiği KESİN olarak görünsün.
        val crosshair = object : View(ctx) {
            private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.RED; style = android.graphics.Paint.Style.STROKE; strokeWidth = 1.5f * density
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val cellPx = width.toFloat() / cropSize // 1 gerçek pikselin büyüteçteki karşılığı
                val cx = width / 2f; val cy = height / 2f
                // Seçili pikselin TAM hücresini kare olarak çerçeveler (nokta değil, GÖRÜLEBİLİR bir kare).
                canvas.drawRect(cx - cellPx / 2, cy - cellPx / 2, cx + cellPx / 2, cy + cellPx / 2, paint)
                // Artı işareti — hücrenin merkezini de ayrıca vurgular.
                canvas.drawLine(cx - cellPx, cy, cx + cellPx, cy, paint)
                canvas.drawLine(cx, cy - cellPx, cx, cy + cellPx, paint)
            }
        }.apply { layoutParams = android.widget.FrameLayout.LayoutParams(magnifierSize, magnifierSize) }
        val magnifierFrame = android.widget.FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(magnifierSize, magnifierSize)
            addView(magnifier); addView(crosshair)
        }
        val magnifierRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        magnifierRow.addView(magnifierFrame)
        root.addView(magnifierRow)

        val preview = View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams((50 * density).toInt(), (50 * density).toInt()).apply { topMargin = (10 * density).toInt() }
        }
        val previewRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previewRow.addView(preview)
        root.addView(previewRow)

        lateinit var xLabel: TextView; lateinit var yLabel: TextView
        // HATA DÜZELTMESİ: her refresh()'te yeni bir büyütülmüş bitmap üretiliyor ama eskisi hiç
        // recycle edilmiyordu — büyüteç üzerinde parmak gezdirdikçe (ACTION_MOVE) yüzlerce bitmap
        // birikip belleği şişiriyordu. Artık yenisini koyduktan sonra eskisi + ara kırpma bırakılıyor.
        var lastZoomed: Bitmap? = null

        fun refresh() {
            val cx = px.coerceIn(cropSize / 2, (frame.width - cropSize / 2 - 1).coerceAtLeast(cropSize / 2))
            val cy = py.coerceIn(cropSize / 2, (frame.height - cropSize / 2 - 1).coerceAtLeast(cropSize / 2))
            val crop = safeCrop(frame, cx - cropSize / 2, cy - cropSize / 2, cropSize, cropSize)
            if (crop != null) {
                val zoomed = Bitmap.createScaledBitmap(crop, magnifierSize, magnifierSize, false)
                magnifier.setImageBitmap(zoomed)
                lastZoomed?.let { if (!it.isRecycled) it.recycle() }
                lastZoomed = zoomed
                if (crop != zoomed && !crop.isRecycled) crop.recycle()
            }
            val color = frame.getPixel(px, py)
            preview.setBackgroundColor(color)
            xLabel.text = "X:  $px"
            yLabel.text = "Y:  $py"
        }

        // KULLANICI İSTEĞİ: "+/-" butonlarına ek olarak, büyütecin ÜZERİNE doğrudan dokunarak da
        // piksel seçebilmeli — dokunulan yerel (yerel_x, yerel_y) konumu, büyütecin GERÇEKTEN
        // gösterdiği kırpma alanındaki karşılık gelen piksele çevirip px/py'yi günceller.
        magnifier.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                val cx = px.coerceIn(cropSize / 2, (frame.width - cropSize / 2 - 1).coerceAtLeast(cropSize / 2))
                val cy = py.coerceIn(cropSize / 2, (frame.height - cropSize / 2 - 1).coerceAtLeast(cropSize / 2))
                val cellPx = magnifierSize.toFloat() / cropSize
                val offsetX = (event.x / cellPx).toInt().coerceIn(0, cropSize - 1)
                val offsetY = (event.y / cellPx).toInt().coerceIn(0, cropSize - 1)
                px = (cx - cropSize / 2 + offsetX).coerceIn(minX, maxX)
                py = (cy - cropSize / 2 + offsetY).coerceIn(minY, maxY)
                refresh()
            }
            true
        }

        fun stepperRow(label: String, onMinus: () -> Unit, onPlus: () -> Unit): Pair<LinearLayout, TextView> {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, (10 * density).toInt(), 0, 0) }
            val tv = TextView(ctx).apply { text = label; textSize = 14f; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            val btnMinus = Button(ctx).apply { text = "–"; setOnClickListener { onMinus(); refresh() } }
            val btnPlus = Button(ctx).apply { text = "+"; setOnClickListener { onPlus(); refresh() } }
            row.addView(tv); row.addView(btnMinus); row.addView(btnPlus)
            return row to tv
        }
        stepperRow("X:  $px", { px = (px - 1).coerceAtLeast(minX) }, { px = (px + 1).coerceAtMost(maxX) }).let { (row, tv) -> root.addView(row); xLabel = tv }
        stepperRow("Y:  $py", { py = (py - 1).coerceAtLeast(minY) }, { py = (py + 1).coerceAtMost(maxY) }).let { (row, tv) -> root.addView(row); yLabel = tv }

        root.addView(TextView(ctx).apply { text = "Description"; textSize = 10f; setTextColor(TEXT_SECONDARY); setPadding(0, (14 * density).toInt(), 0, 0) })
        val descInput = EditText(ctx).apply { setText(existing?.description ?: existing?.name ?: "") }
        root.addView(descInput)

        refresh()

        overlayDialog().setTitle("Pick from Screen").setView(root)
            .setPositiveButton("SAVE") { _, _ ->
                saveColorItem(scope, existing, frame.getPixel(px, py), descInput.text.toString())
                onSaved?.invoke()
            }
            .setNegativeButton("CANCEL", null).create().showOverlay()
    }

    /** "Resources" listesindeki tek bir öğe: bir Kütüphane öğesi (resim/renk) ya da bir Kayıt. */
    private sealed class ResourcesEntry {
        data class Lib(val item: LibraryItem) : ResourcesEntry()
        data class Rec(val record: com.bigboss.app.storage.RecordDefinition) : ResourcesEntry()
    }

    /**
     * Macrorify'daki "Resources" ekranıyla BİREBİR: LOCAL (aktif macro'ya özel) / GLOBAL (TÜM
     * macrolar arasında paylaşılan) iki sekme, 🔍 arama, ve resim/renk/kayıt karışık TEK liste.
     * Alt araç çubuğu: 📷 Ekran Görüntüsü, 🎬 Kayıt, 🎨 Renk (Manual/Pick from screen), ⇄ Local/
     * Global Taşı, ⇅ Sırala, 🗑 Sil, ↑ Yukarı, ↓ Aşağı.
     */
    private fun buildResourcesScreen(): View {
        val ctx = this
        var currentScope = "LOCAL" // LOCAL | GLOBAL
        var searchQuery = ""
        var searchVisible = false
        val selectedIndices = mutableSetOf<Int>()

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }

        fun loadLibraryItems(): List<LibraryItem> =
            if (currentScope == "LOCAL") LibraryStorage.load(ctx) else com.bigboss.app.storage.GlobalLibraryStorage.load(ctx)
        fun loadRecords(): List<com.bigboss.app.storage.RecordDefinition> =
            if (currentScope == "LOCAL") com.bigboss.app.storage.RecordStorage.load(ctx) else com.bigboss.app.storage.GlobalRecordStorage.load(ctx)
        fun deleteLibraryItem(id: String) {
            if (currentScope == "LOCAL") LibraryStorage.delete(ctx, id) else com.bigboss.app.storage.GlobalLibraryStorage.delete(ctx, id)
        }
        fun deleteRecord(id: String) {
            if (currentScope == "LOCAL") com.bigboss.app.storage.RecordStorage.delete(ctx, id) else com.bigboss.app.storage.GlobalRecordStorage.delete(ctx, id)
        }

        fun currentEntries(): List<ResourcesEntry> {
            val entries = mutableListOf<ResourcesEntry>()
            loadLibraryItems()
                .filter { searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) }
                .forEach { entries.add(ResourcesEntry.Lib(it)) }
            loadRecords()
                .filter { searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) }
                .forEach { entries.add(ResourcesEntry.Rec(it)) }
            return entries
        }

        // ---- Sekme çubuğu: LOCAL | GLOBAL + 🔍 (Macrorify'daki BİREBİR üst çubuk) ----
        val density = resources.displayMetrics.density
        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val tabLocal = TextView(ctx).apply { text = "LOCAL"; textSize = 12f; isAllCaps = true; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt()) }
        val tabGlobal = TextView(ctx).apply { text = "GLOBAL"; textSize = 12f; isAllCaps = true; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt()) }
        tabRow.addView(tabLocal, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tabRow.addView(tabGlobal, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val searchInput = EditText(ctx).apply {
            hint = "Ara..."; visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        root.addView(tabRow)
        root.addView(searchInput)
        root.addView(listContainer)
        root.addView(footer)

        fun buildContent() {
            listContainer.removeAllViews()
            val entries = currentEntries()
            if (entries.isEmpty()) {
                listContainer.addView(TextView(ctx).apply {
                    text = if (currentScope == "LOCAL") "Bu macroda henüz kaynak yok — alttaki ikonlarla ekle"
                    else "Global kaynak yok — bir öğeyi ⇄ ile buraya taşıyabilirsin"
                    setPadding(0, 24, 0, 24)
                })
                return
            }
            val inflater = android.view.LayoutInflater.from(ctx)
            val listView = android.widget.ListView(ctx)
            val adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = entries.size
                override fun getItem(position: Int): Any = entries[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val view = convertView ?: inflater.inflate(com.bigboss.app.R.layout.item_resource_row, parent, false)
                    val thumb = view.findViewById<android.widget.ImageView>(com.bigboss.app.R.id.ivResourceThumb)
                    when (val entry = entries[position]) {
                        is ResourcesEntry.Lib -> {
                            // KULLANICI İSTEĞİ: "resmin kütüphanede gözükmesi lazım, neye benzediğini
                            // görmem lazım" — artık emoji YERİNE GERÇEK küçük resim/renk önizlemesi.
                            if (entry.item.kind == "IMAGE") {
                                val path = entry.item.templatePath
                                val bmp = if (!path.isNullOrBlank()) android.graphics.BitmapFactory.decodeFile(path) else null
                                if (bmp != null) { thumb.setImageBitmap(bmp); thumb.setBackgroundColor(Color.TRANSPARENT) }
                                else { thumb.setImageDrawable(null); thumb.setBackgroundColor(Color.parseColor("#E0E0E0")) }
                            } else {
                                thumb.setImageDrawable(null)
                                thumb.setBackgroundColor(entry.item.color)
                            }
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = entry.item.name
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = entry.item.kind
                        }
                        is ResourcesEntry.Rec -> {
                            thumb.setImageDrawable(null)
                            thumb.setBackgroundColor(Color.parseColor("#E0E0E0"))
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowName).text = "🎬 ${entry.record.name}"
                            view.findViewById<TextView>(com.bigboss.app.R.id.tvRowExtra).text = "${entry.record.events.size} olay"
                        }
                    }
                    view.setBackgroundColor(if (position in selectedIndices) Color.parseColor("#557C4DFF") else Color.TRANSPARENT)
                    return view
                }
            }
            listView.adapter = adapter
            styleListDividers(listView)
            listView.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.4).toInt())
            listView.setOnItemClickListener { _, _, position, _ ->
                when (val entry = entries[position]) {
                    is ResourcesEntry.Lib -> if (entry.item.kind == "COLOR") showColorAddMenu(currentScope, entry.item) { buildContent() } else showLibraryItemOptions(entry.item, currentScope)
                    is ResourcesEntry.Rec -> {
                        val actions = arrayOf("▶️ Oynat", "🗑 Sil")
                        overlayDialog().setTitle(entry.record.name).setItems(actions) { _, which ->
                            when (which) { 0 -> playRecord(entry.record); 1 -> { deleteRecord(entry.record.id); buildContent() } }
                        }.setNegativeButton("Kapat", null).create().showOverlay()
                    }
                }
            }
            listView.setOnItemLongClickListener { _, _, position, _ ->
                if (position in selectedIndices) selectedIndices.remove(position) else selectedIndices.add(position)
                adapter.notifyDataSetChanged()
                true
            }
            listContainer.addView(listView)
            listContainer.addView(TextView(ctx).apply {
                text = "Dokun = aç · Basılı tut = çoklu seç (toplu işlem için)"
                textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 8, 0, 0)
            })
        }

        fun selectedEntries(): List<ResourcesEntry> = selectedIndices.sorted().mapNotNull { currentEntries().getOrNull(it) }
        fun refreshThisScreen() { selectedIndices.clear(); buildContent() }

        fun highlightTabs() {
            tabLocal.setTextColor(if (currentScope == "LOCAL") ACCENT else Color.DKGRAY)
            tabGlobal.setTextColor(if (currentScope == "GLOBAL") ACCENT else Color.DKGRAY)
        }
        tabLocal.setOnClickListener { currentScope = "LOCAL"; highlightTabs(); refreshThisScreen() }
        tabGlobal.setOnClickListener { currentScope = "GLOBAL"; highlightTabs(); refreshThisScreen() }
        highlightTabs()

        // ---- Macrorify'daki TEK SATIR 8 ikonlu araç çubuğu ----
        val toolbarRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        // 1) 📷 Ekran Görüntüsü — bölge çizip görsel kaydeder (aktif sekmeye göre LOCAL/GLOBAL).
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_capture, C_BLUE) {
            closeAppPanel(); startLibraryCaptureRegion(currentScope)
        })
        // 2) 🎬 Kayıt — REC modunu başlatır, bittiğinde aktif sekmeye kaydeder.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_record, C_RED) {
            pendingRecordScope = currentScope
            closeAppPanel(); startRecordMode()
        })
        // 3) 🎨 Renk — Pick from screen / Manual.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_color_add, C_GREEN) {
            showColorAddMenu(currentScope) { refreshThisScreen() }
        })
        // 4) ⇄ Local ↔ Global taşı.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_move, C_PURPLE) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            val targetScope = if (currentScope == "LOCAL") "GLOBAL" else "LOCAL"
            sel.forEach { entry ->
                when (entry) {
                    is ResourcesEntry.Lib -> {
                        deleteLibraryItem(entry.item.id)
                        val moved = entry.item.copy(id = UUID.randomUUID().toString())
                        if (targetScope == "GLOBAL") com.bigboss.app.storage.GlobalLibraryStorage.upsert(ctx, moved) else LibraryStorage.upsert(ctx, moved)
                    }
                    is ResourcesEntry.Rec -> {
                        deleteRecord(entry.record.id)
                        val moved = entry.record.copy(id = UUID.randomUUID().toString())
                        if (targetScope == "GLOBAL") com.bigboss.app.storage.GlobalRecordStorage.upsert(ctx, moved) else com.bigboss.app.storage.RecordStorage.upsert(ctx, moved)
                    }
                }
            }
            Toast.makeText(ctx, "${sel.size} öğe ${if (targetScope == "GLOBAL") "Global'e" else "Local'e"} taşındı", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        // 5) ⇅ Sırala (alfabetik).
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_sort, C_BLUE) {
            val libs = loadLibraryItems().sortedBy { it.name.lowercase() }
            if (currentScope == "LOCAL") { libs.forEach { LibraryStorage.upsert(ctx, it) } } else { libs.forEach { com.bigboss.app.storage.GlobalLibraryStorage.upsert(ctx, it) } }
            Toast.makeText(ctx, "Alfabetik sıralandı", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        // 6) Sil
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_delete, C_RED) {
            val sel = selectedEntries()
            if (sel.isEmpty()) { Toast.makeText(ctx, "Önce (basılı tutarak) öğe seç", Toast.LENGTH_SHORT).show(); return@makeToolIcon }
            sel.forEach { entry ->
                when (entry) {
                    is ResourcesEntry.Lib -> deleteLibraryItem(entry.item.id)
                    is ResourcesEntry.Rec -> deleteRecord(entry.record.id)
                }
            }
            Toast.makeText(ctx, "${sel.size} öğe silindi", Toast.LENGTH_SHORT).show()
            refreshThisScreen()
        })
        // 7) Yukarı / 8) Aşağı — sıralama LibraryStorage'da desteklenmiyor.
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_up, C_GREEN) {
            Toast.makeText(ctx, "Kaynaklarda elle sıralama şu an desteklenmiyor — ⇅ ile alfabetik sıralayabilirsin", Toast.LENGTH_SHORT).show()
        })
        toolbarRow.addView(makeToolIcon(ctx, com.bigboss.app.R.drawable.ic_arrow_down, C_ORANGE) {
            Toast.makeText(ctx, "Kaynaklarda elle sıralama şu an desteklenmiyor — ⇅ ile alfabetik sıralayabilirsin", Toast.LENGTH_SHORT).show()
        })
        footer.addView(toolbarRow)
        footer.addView(TextView(ctx).apply {
            text = "🔍 Ara"
            textSize = 11f; setTextColor(ACCENT); setPadding(0, 8, 0, 0)
            setOnClickListener {
                searchVisible = !searchVisible
                searchInput.visibility = if (searchVisible) View.VISIBLE else View.GONE
                if (!searchVisible) { searchQuery = ""; searchInput.setText(""); refreshThisScreen() }
            }
        })
        searchInput.addTextChangedListener(simpleWatcher { searchQuery = it; buildContent() })

        buildContent()
        return root
    }

    /** "📷 Ekrandan Kırp" — Macrorify'daki gibi solda kontrol paneli, sağda turkuaz çerçeve. */
    private fun startLibraryCaptureRegion(scope: String = "LOCAL") {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        closeAppPanel()
        val density = resources.displayMetrics.density
        val startSize = (min(frame.width, frame.height) * 0.4f).toInt().coerceAtLeast((100 * density).toInt())
        val startX = (frame.width - startSize) / 2
        val startY = (frame.height - startSize) / 2
        MacrorifyCropTool(
            context = this,
            windowManager = windowManager ?: return,
            maxW = frame.width,
            maxH = frame.height,
            initialRect = android.graphics.Rect(startX, startY, startX + startSize, startY + startSize),
            onDone = { rect ->
                captureCleanRectCrop(rect) { cropped ->
                    if (cropped == null) {
                        Toast.makeText(this, "Ekran görüntüsü yok ya da alan çok küçük", Toast.LENGTH_SHORT).show()
                        return@captureCleanRectCrop
                    }
                    showLibraryCaptureSaveDialog(cropped, scope)
                }
            },
            onCancel = { Toast.makeText(this, "İptal edildi", Toast.LENGTH_SHORT).show() }
        ).show()
    }

    private fun showLibraryCaptureSaveDialog(cropped: Bitmap, scope: String) {
        val ctx = this
        val density = resources.displayMetrics.density

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * density).toInt(), (8 * density).toInt(), (16 * density).toInt(), 0) }
        root.addView(TextView(ctx).apply { text = "Kaydedilecek görüntü:"; textSize = 12f; setTextColor(TEXT_SECONDARY) })
        val previewFrame = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, (8 * density).toInt(), 0, (8 * density).toInt()) }
        val previewSize = (140 * density).toInt()
        val previewImg = android.widget.ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(previewSize, previewSize)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.parseColor("#EEEEEE"))
            setImageBitmap(cropped)
        }
        previewFrame.addView(previewImg)
        root.addView(previewFrame)
        val input = EditText(ctx).apply { hint = "Kütüphanedeki adı (örn. Saldırı Butonu)" }
        root.addView(input)

        overlayDialog().setTitle("Bu resmi kaydet")
            .setView(android.widget.ScrollView(ctx).apply { addView(root) })
            .setPositiveButton("Kaydet") { _, _ ->
                val name = input.text.toString().ifBlank { "İsimsiz görsel" }
                val path = TemplateStorage.save(ctx, cropped)
                val item = LibraryItem(java.util.UUID.randomUUID().toString(), name, "IMAGE", 0, path)
                if (scope == "GLOBAL") com.bigboss.app.storage.GlobalLibraryStorage.add(ctx, item)
                else LibraryStorage.add(ctx, item)
                Toast.makeText(ctx, "Kütüphaneye kaydedildi: $name", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    private fun showLibraryItemOptions(item: LibraryItem, scope: String = "LOCAL") {
        val options = if (item.kind == "IMAGE") arrayOf("🔄 Değiştir (yeni ekran görüntüsüyle güncelle)", "✂️ Piksel Kırp", "↻ 90° Döndür", "✏️ Yeniden Adlandır", "🗑 Sil")
        else arrayOf("✏️ Yeniden Adlandır", "🗑 Sil")
        overlayDialog().setTitle(item.name).setItems(options) { _, index ->
            when (options[index]) {
                "🔄 Değiştir (yeni ekran görüntüsüyle güncelle)" -> startReplaceImageRegion(item)
                "✂️ Piksel Kırp" -> openLibraryPixelCropDialog(item)
                "↻ 90° Döndür" -> rotateLibraryImage(item)
                "✏️ Yeniden Adlandır" -> renameLibraryItem(item, scope)
                "🗑 Sil" -> {
                    if (scope == "GLOBAL") com.bigboss.app.storage.GlobalLibraryStorage.delete(this, item.id)
                    else LibraryStorage.delete(this, item.id)
                    Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                }
            }
        }.create().showOverlay()
    }

    /**
     * KULLANICI İSTEĞİ: Macrorify'daki "Resources" kırpma aracı — solda kontrol paneli,
     * sağda turkuaz çerçeve; çerçeve sürüklenebilir, sağ-alt üçgenle boyutlandırılabilir,
     * X/Y/W/H alanları çerçeveyle canlı senkronize.
     */
    private fun openLibraryPixelCropDialog(item: LibraryItem) {
        val ctx = this
        val path = item.templatePath
        if (path.isNullOrBlank()) { Toast.makeText(ctx, "Görsel bulunamadı", Toast.LENGTH_SHORT).show(); return }
        val original = android.graphics.BitmapFactory.decodeFile(path)
        if (original == null) { Toast.makeText(ctx, "Görsel okunamadı", Toast.LENGTH_SHORT).show(); return }

        MacrorifyCropTool(
            context = ctx,
            windowManager = windowManager ?: return,
            maxW = original.width,
            maxH = original.height,
            initialRect = android.graphics.Rect(0, 0, original.width, original.height),
            backgroundBitmap = original,
            onDone = { rect ->
                val safeX = rect.left.coerceIn(0, original.width - 1)
                val safeY = rect.top.coerceIn(0, original.height - 1)
                val safeW = rect.width().coerceIn(1, original.width - safeX)
                val safeH = rect.height().coerceIn(1, original.height - safeY)
                try {
                    val cropped = Bitmap.createBitmap(original, safeX, safeY, safeW, safeH)
                    java.io.FileOutputStream(path).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    com.bigboss.app.engine.ImageMatcher.clearCache()
                    Toast.makeText(ctx, "Kırpıldı ve kaydedildi (${safeW}x${safeH}px)", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
                }
            },
            onCancel = { Toast.makeText(ctx, "İptal edildi", Toast.LENGTH_SHORT).show() }
        ).show()
    }

    /**
     * Macrorify'daki "Replace Image": AYNI dosya yolunun İÇERİĞİNİ değiştirir (yeni dosya
     * oluşturmaz). Bu sayede bu görseli kullanan TÜM kurallar otomatik güncellenir —
     * sil-ve-yeniden-ekle yaparsan bunu her kuralda elle güncellemen gerekirdi.
     *
     * KULLANICI İSTEĞİ: "Değiştir" butonu eskiden ESKİ/basit bölge-çizme sistemini
     * (addRegionWindow) kullanıyordu — "📷 Ekran Görüntüsü Al" (startLibraryCaptureRegion)
     * ile AYNI, gelişmiş `MacrorifyCropTool` (X/Y/W/H paneli + turkuaz çerçeve) sistemini
     * KULLANMIYORDU. Artık BİREBİR AYNI algoritma/araç kullanılıyor.
     */
    private fun startReplaceImageRegion(item: LibraryItem) {
        val frame = ScreenCaptureService.latestFrame
        if (frame == null) {
            Toast.makeText(this, "Henüz ekran görüntüsü yok, birkaç saniye bekle", Toast.LENGTH_SHORT).show()
            return
        }
        closeAppPanel()
        val density = resources.displayMetrics.density
        val startSize = (min(frame.width, frame.height) * 0.4f).toInt().coerceAtLeast((100 * density).toInt())
        val startX = (frame.width - startSize) / 2
        val startY = (frame.height - startSize) / 2
        MacrorifyCropTool(
            context = this,
            windowManager = windowManager ?: return,
            maxW = frame.width,
            maxH = frame.height,
            initialRect = android.graphics.Rect(startX, startY, startX + startSize, startY + startSize),
            onDone = { rect ->
                captureCleanRectCrop(rect) { cropped ->
                    if (cropped == null) {
                        Toast.makeText(this, "Ekran görüntüsü yok ya da alan çok küçük", Toast.LENGTH_SHORT).show()
                        return@captureCleanRectCrop
                    }
                    openReplaceImageConfirmDialog(item, cropped)
                }
            },
            onCancel = { Toast.makeText(this, "İptal edildi", Toast.LENGTH_SHORT).show() }
        ).show()
    }

    /**
     * HATA DÜZELTMESİ (kullanıcı raporu: "image detection için bir görüntüyü kullandıktan sonra
     * görüntü bozuluyor"): burası eskiden `ScreenCaptureService.latestFrame`'i DOĞRUDAN kırpıyordu —
     * region'ın kendi mavi çerçeve/tutamaç overlay'i EKRANDA GÖRÜNÜR haldeyken (MediaProjection
     * AUTO_MIRROR kendi overlay'lerimizi de yakalar, bkz. bigboss-mediaprojection-chrome-contamination
     * notu). Sonuç: kaydedilen şablonun İÇİNE mavi çerçeve/tutamaç pikselleri gömülüyordu — görsel
     * her "Değiştir" sonrası bozuk/kullanılamaz hale geliyordu. `startLibraryCaptureRegion`'ın
     * (📷 Ekran Görüntüsü Al) kullandığı AYNI `MacrorifyCropTool` + `captureCleanRectCrop`
     * (temiz-kare bekleyen algoritma) artık BURADA da kullanılıyor — kırpma zaten TEMİZ geliyor.
     */
    private fun openReplaceImageConfirmDialog(item: LibraryItem, cropped: Bitmap) {
        val path = item.templatePath
        if (path.isNullOrBlank()) return
        overlayDialog().setTitle("'${item.name}' Değiştirilsin mi?")
            .setMessage("Bu görseli yeni yakaladığınla değiştireceğim. Bunu kullanan TÜM kurallar otomatik güncellenecek. Bu işlem GERİ ALINAMAZ.")
            .setPositiveButton("Değiştir") { _, _ ->
                try {
                    java.io.FileOutputStream(path).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    com.bigboss.app.engine.ImageMatcher.clearCache()
                    Toast.makeText(this, "Değiştirildi — bu görseli kullanan her yer güncellendi", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Vazgeç", null)
            .create().showOverlay()
    }

    private fun rotateLibraryImage(item: LibraryItem) {
        val path = item.templatePath ?: return
        try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(path) ?: return
            val matrix = android.graphics.Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            java.io.FileOutputStream(path).use { rotated.compress(Bitmap.CompressFormat.PNG, 100, it) }
            com.bigboss.app.engine.ImageMatcher.clearCache() // aynı yol üzerine yazıldı, eski önbellek geçersiz
            Toast.makeText(this, "Döndürüldü", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun renameLibraryItem(item: LibraryItem, scope: String = "LOCAL") {
        val input = EditText(this).apply { setText(item.name) }
        overlayDialog().setTitle("Yeniden adlandır").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val newName = input.text.toString().ifBlank { item.name }
                if (scope == "GLOBAL") {
                    val all = com.bigboss.app.storage.GlobalLibraryStorage.load(this)
                    val idx = all.indexOfFirst { it.id == item.id }
                    if (idx >= 0) { all[idx] = all[idx].copy(name = newName); com.bigboss.app.storage.GlobalLibraryStorage.save(this, all) }
                } else {
                    val all = LibraryStorage.load(this)
                    val idx = all.indexOfFirst { it.id == item.id }
                    if (idx >= 0) { all[idx] = all[idx].copy(name = newName); LibraryStorage.save(this, all) }
                }
            }.setNegativeButton("Vazgeç", null).create().showOverlay()
    }

    override fun onDestroy() {
        // Bu servise bağlı programatik ayar diyaloğu köprüsünü temizle (sızıntı/asılı latch önlemi).
        (com.bigboss.app.engine.ScriptRuntime.emHost as? AndroidEmHost)?.settingDialogRequester = null
        clearAllRegionWindows()
        clearWorkspace()
        clearClickMarkers()
        clearRecordMode()
        clearTestFeedback()
        removePointMarker()
        colorPickCatcher?.let { try { windowManager?.removeView(it) } catch (e: Exception) {} }
        rootView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }
}
