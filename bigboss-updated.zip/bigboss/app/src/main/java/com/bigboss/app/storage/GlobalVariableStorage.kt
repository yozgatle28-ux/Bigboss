package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * "global_variables.json" içinde BİRLEŞİK değişkenleri saklar. Artık tek değişken
 * sistemi: her yere {isim} ile gömülebilen, tipli (Number/String/Reference) değişkenler.
 * Eski dosyalar otomatik göç ettirilir (migrated()).
 */
object GlobalVariableStorage {

    private const val FILE_NAME = "global_variables.json"
    private val gson = Gson()

    @Synchronized
    fun load(context: Context): MutableList<GlobalVariableDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<GlobalVariableDefinition>>() {}.type
            val list: MutableList<GlobalVariableDefinition> = gson.fromJson(json, type) ?: mutableListOf()
            list.forEach { it.migrated() } // eski value -> textValue
            list
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    @Synchronized
    fun save(context: Context, vars: List<GlobalVariableDefinition>) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(vars))
    }

    @Synchronized
    fun upsert(context: Context, variable: GlobalVariableDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == variable.id }
        if (idx >= 0) all[idx] = variable else all.add(variable)
        save(context, all)
    }

    @Synchronized
    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    /**
     * KULLANICI İSTEĞİ ("eksik bişey kalmasın") DENETİMİNDE BULUNAN GERÇEK EKSİKLİK:
     * `FunctionStorage`'ın `moveUp`/`moveDown`'ı VARDI ama burada YOKTU — Variables ekranı
     * bu yüzden "sıralama şu an desteklenmiyor" diyip devre dışı bir buton gösteriyordu,
     * Fonksiyonlar ekranı ise ÇALIŞIYORDU. Artık BİREBİR AYNI (FunctionStorage'daki ile
     * simetrik) `moveUp`/`moveDown` burada da var — iki ekran artık AYNI yeteneğe sahip.
     */
    @Synchronized
    fun moveUp(context: Context, id: String) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == id }
        if (idx > 0) { val tmp = all[idx - 1]; all[idx - 1] = all[idx]; all[idx] = tmp; save(context, all) }
    }

    @Synchronized
    fun moveDown(context: Context, id: String) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == id }
        if (idx in 0 until all.size - 1) { val tmp = all[idx + 1]; all[idx + 1] = all[idx]; all[idx] = tmp; save(context, all) }
    }

    /** İsme göre değişkeni bulur (devre dışı olanları da döner — çağıran karar verir). */
    @Synchronized
    fun findByName(context: Context, name: String?): GlobalVariableDefinition? {
        if (name.isNullOrBlank()) return null
        return load(context).find { it.name == name }
    }

    /**
     * GERİYE DÖNÜK: bir alan bir değişkene bağlıysa SAYISAL değerini okur.
     * NUMBER için doğrudan; STRING/REFERENCE için sayıya çevrilebiliyorsa o, değilse null.
     * (Reference ifadeleri burada değerlendirilmez — motor tarafı VariableStore üzerinden çözer.)
     */
    @Synchronized
    fun valueOf(context: Context, name: String?): Long? {
        val v = findByName(context, name) ?: return null
        if (v.disabled) return null
        return v.raw().toLongOrNull()
    }
}
