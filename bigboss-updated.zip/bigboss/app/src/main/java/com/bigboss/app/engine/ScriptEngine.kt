package com.bigboss.app.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.bigboss.app.model.Region
import org.mozilla.javascript.Context as RhinoContext
import org.mozilla.javascript.NativeObject
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject

/**
 * BigBoss'un "EMScript'ten ilham alan kod sistemi" — v2, GENİŞLETİLMİŞ KÜTÜPHANE.
 *
 * Macrorify'ın EMScript'i kendi yazdıkları, "barebone" (iskelet) bir dil —
 * biz bunun yerine saf-Java olan Rhino JavaScript motorunu gömüyoruz, bu
 * yüzden dilin KENDİSİ (değişken, if/else, for/while/do-while, fonksiyon,
 * class, array, obje, try/catch, closure...) zaten EMScript'ten daha güçlü,
 * GERÇEK JavaScript. Bu güncellemede eksik olan KÜTÜPHANE (bridge API)
 * tarafını EMScript'in Region/Point/Match/CParam ekosistemine yakın bir
 * zenginliğe getirdim.
 *
 * ---- Basit fonksiyonlar ----
 *   tap(x, y, opts?)     opts: {repeat, hold, delay, random}
 *   swipe(x1,y1,x2,y2, opts?)   opts: {duration, holdStart, holdEnd, delay, random}
 *   swipePath([{x,y,hold}, ...], durationMs?)   -- çok noktalı kaydırma
 *   wait(ms)
 *   back() / home() / recents() / notifications() / quickSettings()
 *   getVar(name) / setVar(name, value)                  -- sayı değişken (birleşik, kalıcı)
 *   getVarStr(name) / setVarStr(name, text)             -- metin (String) değişken
 *   getGlobalVar(name) / setGlobalVar(name, value)       -- getVar/setVar ile AYNI (geriye dönük)
 *   Setting.get(key) / Setting.show()                    -- özel ayar (Setting Builder) oku/göster
 *   colorAt(x, y) -> "#RRGGBB"
 *   randomInt(min, max)
 *   callFunction(functionName, repeat?)   -- tanımlı bir Fonksiyonu/Action Group'u çağırır
 *   runScript(scriptName)                 -- başka kayıtlı bir Script'i çalıştırır
 *   log(msg)
 *
 * ---- Region nesnesi (EMScript'teki Region class'ının karşılığı) ----
 *   var r = Region(x, y, w, h)
 *   r.findColor(hex, minScore?)          -> true/false
 *   r.findImage(libraryName, minScore?)  -> true/false  (KÜTÜPHANEDEKİ İSİMLE arar)
 *   r.findText(text, minScore?)          -> true/false
 *   r.findImageMatch(libraryName, minScore?) -> {found, x, y, score} ya da null
 *   r.tap(opts?)                          -- bölgenin ortasına dokunur
 *   r.center()                            -> {x, y}
 *
 * ---- Örnek ----
 *   var enemy = Region(100, 200, 300, 300)
 *   if (enemy.findImage("düşman")) {
 *       var m = enemy.findImageMatch("düşman")
 *       tap(m.x, m.y, {hold: 80})
 *       setVar("vurus", getVar("vurus") + 1)
 *   }
 */
class ScriptEngine(
    private val executor: ActionExecutor,
    private val frameProvider: () -> Bitmap?,
    private val functionByName: (String) -> List<Rule>,
    private val runRuleList: (List<Rule>, Bitmap) -> Unit,
    /** true iken (Edit Mode) script'in tap/swipe/sistem çağrıları GERÇEK dokunuşa çevrilmez — güvenlik. */
    private val pausedProvider: () -> Boolean = { false },
    /** Kütüphanedeki bir görselin İSMİNDEN dosya yolunu bulur (findImage("isim") için). */
    private val libraryLookup: (String) -> String? = { null },
    /** Kayıtlı bir Script'i İSMİNDEN bulup kodunu döner (runScript("isim") için). */
    private val scriptLookup: (String) -> String? = { null }
) {

    /** Setting.show() çağrılınca UI thread'de özel ayar diyaloğunu açan köprü (OverlayService kurar). */
    var settingShowRequester: (() -> Boolean)? = null

    /** Bir script'i bir kere çalıştırır. Hata olursa mesajı döner, olmazsa null. */
    fun run(code: String): String? {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1 // Android'de bytecode üretimi yerine yorumlanır (daha güvenli)
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            cx.evaluateString(scope, code, "bigboss-script", 1, null)
            null
        } catch (e: Exception) {
            Log.e("BigBossScript", "Script hatası", e)
            e.message ?: e.toString()
        } finally {
            RhinoContext.exit()
        }
    }

    /** Bir script'i KOŞUL olarak çalıştırır: son ifadenin/return'ün boolean'a çevrilmiş hâlini döner. */
    fun evaluateAsCondition(code: String): Boolean {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            val result = cx.evaluateString(scope, code, "bigboss-condition-script", 1, null)
            RhinoContext.toBoolean(result)
        } catch (e: Exception) {
            Log.e("BigBossScript", "Koşul script hatası", e)
            false
        } finally {
            RhinoContext.exit()
        }
    }

    /**
     * Bir ifadeyi (REFERENCE tipli değişkenler için) değerlendirip sonucu METİN olarak döner.
     * Örn. "getVar(\"a\") + 5" -> "15". Hata olursa null.
     */
    fun evaluateExpression(code: String): String? {
        val cx = RhinoContext.enter()
        return try {
            cx.optimizationLevel = -1
            val scope: Scriptable = cx.initStandardObjects()
            bindBridgeFunctions(cx, scope)
            val result = cx.evaluateString(scope, code, "bigboss-reference", 1, null)
            when (result) {
                null, RhinoContext.getUndefinedValue() -> null
                is Double -> if (result == Math.floor(result) && !result.isInfinite()) result.toLong().toString() else result.toString()
                else -> RhinoContext.toString(result)
            }
        } catch (e: Exception) {
            Log.e("BigBossScript", "Reference ifade hatası", e)
            null
        } finally {
            RhinoContext.exit()
        }
    }

    private fun bindBridgeFunctions(cx: RhinoContext, scope: Scriptable) {
        fun define(name: String, fn: (Array<Any?>) -> Any?) {
            val f = object : org.mozilla.javascript.BaseFunction() {
                override fun call(cx: RhinoContext?, scope: Scriptable?, thisObj: Scriptable?, args: Array<Any?>): Any {
                    return fn(args) ?: RhinoContext.getUndefinedValue()
                }
            }
            ScriptableObject.putProperty(scope, name, f)
        }

        fun num(v: Any?, default: Int = 0): Int = (v as? Number)?.toInt() ?: default
        fun long(v: Any?, default: Long = 0L): Long = (v as? Number)?.toLong() ?: default

        /** JS obje argümanından (örn. {repeat: 2, hold: 80}) bir alanı okur. */
        fun opt(args: Array<Any?>, index: Int, key: String): Any? {
            val obj = args.getOrNull(index) as? NativeObject ?: return null
            return if (obj.containsKey(key)) obj.get(key) else null
        }

        fun newObj(cx: RhinoContext, scope: Scriptable, fields: Map<String, Any?>): Scriptable {
            val o = cx.newObject(scope)
            fields.forEach { (k, v) -> ScriptableObject.putProperty(o, k, v) }
            return o
        }

        // ---- Dokunma / Kaydırma ----

        define("tap") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — tap() engellendi)"); return@define null }
            val x = num(args.getOrNull(0)); val y = num(args.getOrNull(1))
            val repeat = num(opt(args, 2, "repeat"), 1)
            val hold = long(opt(args, 2, "hold"), 50L)
            val delay = long(opt(args, 2, "delay"), 0L)
            val random = num(opt(args, 2, "random"), 0)
            executor.execute(Action.Tap(x, y, repeat.coerceAtLeast(1), hold.coerceAtLeast(1), delay, random))
            null
        }
        // NOT: "swipe" fonksiyonu aşağıda (CParam/SParam/SwipePoint/click ile birlikte) TANIMLANIYOR —
        // hem eski basit imzayı (x1,y1,x2,y2,opts) hem Macrorify'ın RESMİ imzasını (SwipePoint[], SParam) destekler.
        define("swipePath") { args ->
            // EMScript'teki SwipePoint dizisiyle çoklu-nokta kaydırma: [{x,y,hold}, {x,y,hold}, ...]
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — swipePath() engellendi)"); return@define null }
            val points = args.getOrNull(0) as? org.mozilla.javascript.NativeArray ?: return@define null
            val durationEach = long(args.getOrNull(1), 300L)
            // Noktaları TEK bir MultiPointSwipe olarak topluyoruz: motorun continueStroke
            // zincirlemesi sayesinde parmak yerden HİÇ kalkmadan tüm noktalardan geçer
            // (eskiden her segment ayrı Action.Swipe idi; her segment arası parmak kalkıp
            // yeniden basıyordu — bu, sürükleme jestlerini bozuyordu).
            val defs = mutableListOf<Action.SwipePointDef>()
            for (i in 0 until points.length.toInt()) {
                val p = points.get(i, points) as? NativeObject ?: continue
                val px = num(p.get("x")); val py = num(p.get("y"))
                val hold = long(p.get("hold"), 0L)
                defs.add(Action.SwipePointDef(px, py, hold))
            }
            if (defs.size >= 2) {
                executor.execute(Action.MultiPointSwipe(defs, segmentDurationMs = durationEach))
            } else if (defs.size == 1) {
                // Tek nokta verildiyse basit bir dokunuşa düşür (motor da böyle davranıyor).
                executor.execute(Action.Tap(defs[0].x, defs[0].y, 1, defs[0].holdMs.coerceAtLeast(50)))
            }
            null
        }
        define("wait") { args ->
            val ms = long(args.getOrNull(0))
            if (ms > 0) Thread.sleep(ms)
            null
        }

        /**
         * KULLANICI İSTEĞİ: Macrorify'dan BİREBİR kopyalanmış EMScript kodu ("click(Point(...),
         * CParam.hold(20))" gibi) BİZİM sistemimizde de ÇALIŞSIN. Eskiden SADECE kendi
         * basitleştirilmiş API'miz (tap/swipe düz sayılarla) vardı — Macrorify'ın RESMİ
         * click()/swipe()/Point/SwipePoint/CParam/SParam API'si (bkz. kok-emm.com/docs/reference)
         * hiç YOKTU. Artık İKİSİ DE var — eski scriptler ÇALIŞMAYA devam ediyor, Macrorify'dan
         * kopyala-yapıştır kod da DOĞRUDAN çalışıyor.
         *
         * CParam/SParam iç değerleri "_repeat"/"_hold" gibi gizli anahtarlarda tutuluyor —
         * JS tarafında "repeat" HEM bir METOT (zincirlenebilir, `this` döner) HEM okunabilir
         * bir ÖZELLİK olamayacağı için (ikisi de aynı adı kullanır, biri diğerini ezerdi),
         * dışa sadece METOT olarak açılıyor; biz kendi iç okumamızı "_repeat" üzerinden yapıyoruz.
         */
        fun makeParamObj(keys: List<String>, initial: Map<String, Int>): Scriptable {
            val obj = cx.newObject(scope)
            keys.forEach { k -> ScriptableObject.putProperty(obj, "_$k", initial[k] ?: 0) }
            keys.forEach { key ->
                val f = object : org.mozilla.javascript.BaseFunction() {
                    override fun call(c: RhinoContext?, s: Scriptable?, thisObj: Scriptable?, a: Array<Any?>): Any {
                        val target = (thisObj as? Scriptable) ?: obj
                        ScriptableObject.putProperty(target, "_$key", num(a.getOrNull(0)))
                        return target
                    }
                }
                ScriptableObject.putProperty(obj, key, f)
            }
            return obj
        }
        fun readParam(obj: Any?, key: String, default: Int): Int {
            val s = obj as? Scriptable ?: return default
            val v = ScriptableObject.getProperty(s, "_$key")
            return if (v is Number) v.toInt() else default
        }
        val cParamKeys = listOf("repeat", "hold", "delay", "waitNext", "random")
        val sParamKeys = listOf("repeat", "delay", "waitNext", "random")

        // CParam(repeat=1, hold=0, delay=0, waitNext=100, random=0) — kurucu + statik fabrikalar.
        run {
            val ctor = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    makeParamObj(cParamKeys, mapOf("repeat" to num(a.getOrNull(0), 1), "hold" to num(a.getOrNull(1), 0), "delay" to num(a.getOrNull(2), 0), "waitNext" to num(a.getOrNull(3), 100), "random" to num(a.getOrNull(4), 0)))
            }
            cParamKeys.forEach { key ->
                val staticFn = object : org.mozilla.javascript.BaseFunction() {
                    override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                        makeParamObj(cParamKeys, mapOf(key to num(a.getOrNull(0), 0)))
                }
                ScriptableObject.putProperty(ctor, key, staticFn)
            }
            ScriptableObject.putProperty(scope, "CParam", ctor)
        }
        // SParam(repeat=1, delay=0, waitNext=100, random=0) — CParam ile AYNI kalıp, "hold" hariç.
        run {
            val ctor = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    makeParamObj(sParamKeys, mapOf("repeat" to num(a.getOrNull(0), 1), "delay" to num(a.getOrNull(1), 0), "waitNext" to num(a.getOrNull(2), 100), "random" to num(a.getOrNull(3), 0)))
            }
            sParamKeys.forEach { key ->
                val staticFn = object : org.mozilla.javascript.BaseFunction() {
                    override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                        makeParamObj(sParamKeys, mapOf(key to num(a.getOrNull(0), 0)))
                }
                ScriptableObject.putProperty(ctor, key, staticFn)
            }
            ScriptableObject.putProperty(scope, "SParam", ctor)
        }
        // SwipePoint(point = Point(0,0), hold = 0, speed = 20) — Macrorify'daki BİREBİR aynı.
        define("SwipePoint") { args ->
            val p = args.getOrNull(0) as? Scriptable
            val px = num(p?.let { ScriptableObject.getProperty(it, "x") })
            val py = num(p?.let { ScriptableObject.getProperty(it, "y") })
            newObj(cx, scope, mapOf("x" to px, "y" to py, "hold" to num(args.getOrNull(1), 0), "speed" to num(args.getOrNull(2), 20)))
        }
        // click(point, repeat|CParam) — Macrorify'daki RESMİ imza.
        define("click") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — click() engellendi)"); return@define null }
            val p = args.getOrNull(0) as? Scriptable
            val px = num(p?.let { ScriptableObject.getProperty(it, "x") })
            val py = num(p?.let { ScriptableObject.getProperty(it, "y") })
            val second = args.getOrNull(1)
            val isParam = second is Scriptable && ScriptableObject.hasProperty(second, "_hold")
            val repeat = if (isParam) readParam(second, "repeat", 1) else num(second, 1)
            val hold = if (isParam) readParam(second, "hold", 0) else 0
            val delay = if (isParam) readParam(second, "delay", 0) else 0
            val waitNext = if (isParam) readParam(second, "waitNext", 100) else 100
            val random = if (isParam) readParam(second, "random", 0) else 0
            for (i in 0 until repeat.coerceAtLeast(1)) {
                if (delay > 0) Thread.sleep(delay.toLong())
                val rx = if (random > 0) px + (-random..random).random() else px
                val ry = if (random > 0) py + (-random..random).random() else py
                executor.execute(Action.Tap(rx, ry, 1, hold.toLong().coerceAtLeast(1)))
                if (i < repeat - 1 && waitNext > 0) Thread.sleep(waitNext.toLong())
            }
            null
        }
        // swipe(...) — İKİ İMZAYI DA destekler: (1) kendi eski swipe(x1,y1,x2,y2,opts), (2) Macrorify'ın
        // RESMİ swipe(swipePoints[], repeat|SParam). İlk argümanın TİPİNE göre otomatik ayırt edilir.
        define("swipe") { args ->
            if (pausedProvider()) { Log.i("BigBossScript", "(Düzenleme Modu — swipe() engellendi)"); return@define null }
            val first = args.getOrNull(0)
            if (first is org.mozilla.javascript.NativeArray) {
                // Macrorify RESMİ imza: swipe(SwipePoint[], repeat|SParam)
                val second = args.getOrNull(1)
                val isParam = second is Scriptable && ScriptableObject.hasProperty(second, "_waitNext")
                val repeat = if (isParam) readParam(second, "repeat", 1) else num(second, 1)
                val delay = if (isParam) readParam(second, "delay", 0) else 0
                val waitNext = if (isParam) readParam(second, "waitNext", 100) else 100
                val random = if (isParam) readParam(second, "random", 0) else 0
                val defs = (0 until first.length.toInt()).mapNotNull { i ->
                    val sp = first.get(i, first) as? Scriptable ?: return@mapNotNull null
                    val px = num(ScriptableObject.getProperty(sp, "x")); val py = num(ScriptableObject.getProperty(sp, "y"))
                    val h = long(ScriptableObject.getProperty(sp, "hold"), 0L)
                    val sp2 = num(ScriptableObject.getProperty(sp, "speed"), 20)
                    Action.SwipePointDef(px, py, h, sp2)
                }
                if (defs.size < 2) return@define null
                for (i in 0 until repeat.coerceAtLeast(1)) {
                    if (delay > 0) Thread.sleep(delay.toLong())
                    val jitteredDefs = if (random > 0) defs.map { it.copy(x = it.x + (-random..random).random(), y = it.y + (-random..random).random()) } else defs
                    executor.execute(Action.MultiPointSwipe(jitteredDefs))
                    if (i < repeat - 1 && waitNext > 0) Thread.sleep(waitNext.toLong())
                }
                null
            } else {
                // Eski basit imza: swipe(x1,y1,x2,y2, {duration,holdStart,holdEnd,delay,random})
                val x1 = num(args.getOrNull(0)); val y1 = num(args.getOrNull(1))
                val x2 = num(args.getOrNull(2)); val y2 = num(args.getOrNull(3))
                val duration = long(opt(args, 4, "duration"), 300L)
                val holdStart = long(opt(args, 4, "holdStart"), 0L)
                val holdEnd = long(opt(args, 4, "holdEnd"), 0L)
                val delay = long(opt(args, 4, "delay"), 0L)
                val random = num(opt(args, 4, "random"), 0)
                executor.execute(Action.Swipe(x1, y1, x2, y2, duration, holdStart, holdEnd, delay, random))
                null
            }
        }

        // ---- Sistem aksiyonları ----
        define("back") { if (!pausedProvider()) executor.execute(Action.SystemAction("BACK")); null }
        define("home") { if (!pausedProvider()) executor.execute(Action.SystemAction("HOME")); null }
        define("recents") { if (!pausedProvider()) executor.execute(Action.SystemAction("RECENTS")); null }
        define("notifications") { if (!pausedProvider()) executor.execute(Action.SystemAction("NOTIFICATIONS")); null }
        define("quickSettings") { if (!pausedProvider()) executor.execute(Action.SystemAction("QUICK_SETTINGS")); null }

        // ---- Değişkenler (BİRLEŞİK sistem — hepsi tek VariableStore'a gider) ----
        define("getVar") { args -> VariableStore.getNumber(args.getOrNull(0)?.toString() ?: "").toDouble() }
        define("setVar") { args ->
            VariableStore.set(args.getOrNull(0)?.toString() ?: return@define null, num(args.getOrNull(1)))
            null
        }
        // Metin (String) değişkenler için:
        define("getVarStr") { args -> VariableStore.getString(args.getOrNull(0)?.toString() ?: "") }
        define("setVarStr") { args ->
            VariableStore.setString(args.getOrNull(0)?.toString() ?: return@define null, args.getOrNull(1)?.toString() ?: "")
            null
        }
        // Geriye dönük: getGlobalVar/setGlobalVar artık AYNI birleşik değişkenlere erişir.
        define("getGlobalVar") { args -> VariableStore.getNumber(args.getOrNull(0)?.toString() ?: "").toDouble() }
        define("setGlobalVar") { args ->
            VariableStore.set(args.getOrNull(0)?.toString() ?: return@define null, num(args.getOrNull(1)))
            null
        }

        // ---- Setting (Macrorify "Setting Builder" script API) ----
        // Setting.get(key): kayıtlı özel ayardaki bir key'in GÜNCEL değerini (metin) döner.
        //   (Kaydet'e basılınca değişkenlere yazıldığı için doğrudan VariableStore'dan okunur.)
        // Setting.show(): kayıtlı özel ayar diyaloğunu gösterir (UI thread'de OverlayService açar).
        //   Diyalog gösterildiyse true, gösterilemezse false döner (assenkron; anlık sonuç UI'da).
        define("settingGet") { args -> VariableStore.getString(args.getOrNull(0)?.toString() ?: "") }
        define("settingShow") { settingShowRequester?.invoke() ?: false }
        // Setting nesnesi: Setting.get(key) / Setting.show()
        run {
            val settingObj = cx.newObject(scope)
            val getFn = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    VariableStore.getString(a.getOrNull(0)?.toString() ?: "")
            }
            val showFn = object : org.mozilla.javascript.BaseFunction() {
                override fun call(c: RhinoContext?, s: Scriptable?, t: Scriptable?, a: Array<Any?>): Any =
                    settingShowRequester?.invoke() ?: false
            }
            ScriptableObject.putProperty(settingObj, "get", getFn)
            ScriptableObject.putProperty(settingObj, "show", showFn)
            ScriptableObject.putProperty(scope, "Setting", settingObj)
        }

        // ---- Ekran okuma (düz fonksiyonlar — geriye dönük uyumluluk) ----
        define("colorAt") { args ->
            val frame = frameProvider() ?: return@define "#000000"
            val x = num(args.getOrNull(0)).coerceIn(0, frame.width - 1)
            val y = num(args.getOrNull(1)).coerceIn(0, frame.height - 1)
            String.format("#%06X", 0xFFFFFF and frame.getPixel(x, y))
        }
        // Kod editöründeki 💡 "Middle Screen (Point)" snippet'i için: mevcut GÖRÜNTÜLENEN çözünürlük.
        define("screenWidth") { frameProvider()?.width?.toDouble() ?: 0.0 }
        define("screenHeight") { frameProvider()?.height?.toDouble() ?: 0.0 }
        define("findColor") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val hex = args.getOrNull(4)?.toString() ?: "#000000"
            val minScore = ((args.getOrNull(5) as? Number)?.toDouble() ?: 0.9).toFloat()
            val color = try { Color.parseColor(hex) } catch (e: Exception) { 0 }
            Condition.ColorInRegion(region, color, minScore).evaluate(frame)
        }
        define("findImage") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val nameOrPath = args.getOrNull(4)?.toString() ?: return@define false
            val path = libraryLookup(nameOrPath) ?: nameOrPath // önce kütüphane isminden dene, yoksa doğrudan yol say
            val minScore = ((args.getOrNull(5) as? Number)?.toDouble() ?: 0.8).toFloat()
            Condition.ImageInRegion(region, path, minScore).evaluate(frame)
        }
        define("findText") { args ->
            val frame = frameProvider() ?: return@define false
            val region = Region(num(args.getOrNull(0)), num(args.getOrNull(1)), num(args.getOrNull(2), 1), num(args.getOrNull(3), 1))
            val text = args.getOrNull(4)?.toString() ?: ""
            Condition.TextInRegion(region, text).evaluate(frame)
        }
        define("randomInt") { args ->
            val min = num(args.getOrNull(0), 0); val max = num(args.getOrNull(1), 100)
            if (max <= min) min.toDouble() else (min..max).random().toDouble()
        }

        // ---- Fonksiyon/Script çağırma ----
        define("callFunction") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val repeat = num(args.getOrNull(1), 1)
            val frame = frameProvider() ?: return@define null
            val rules = functionByName(name)
            repeat(repeat.coerceAtLeast(1)) { runRuleList(rules, frame) }
            null
        }
        define("runScript") { args ->
            val name = args.getOrNull(0)?.toString() ?: return@define null
            val code = scriptLookup(name) ?: run { Log.e("BigBossScript", "Script bulunamadı: $name"); return@define null }
            run(code) // recursive — kendi run() metodumuzu tekrar kullanıyoruz
            null
        }
        define("log") { args ->
            Log.i("BigBossScript", args.joinToString(" ") { it?.toString() ?: "null" })
            null
        }

        // ---- Point(x, y) yardımcı yapıcı ----
        define("Point") { args ->
            newObj(cx, scope, mapOf("x" to num(args.getOrNull(0)), "y" to num(args.getOrNull(1))))
        }

        // ---- Region(x, y, w, h) — EMScript'teki Region class'ının OOP benzeri karşılığı ----
        define("Region") { args ->
            val rx = num(args.getOrNull(0)); val ry = num(args.getOrNull(1))
            val rw = num(args.getOrNull(2), 1); val rh = num(args.getOrNull(3), 1)
            val regionObj = cx.newObject(scope)
            ScriptableObject.putProperty(regionObj, "x", rx)
            ScriptableObject.putProperty(regionObj, "y", ry)
            ScriptableObject.putProperty(regionObj, "w", rw)
            ScriptableObject.putProperty(regionObj, "h", rh)

            fun regionFn(name: String, fn: (Array<Any?>) -> Any?) {
                val f = object : org.mozilla.javascript.BaseFunction() {
                    override fun call(cx: RhinoContext?, scope: Scriptable?, thisObj: Scriptable?, callArgs: Array<Any?>): Any {
                        return fn(callArgs) ?: RhinoContext.getUndefinedValue()
                    }
                }
                ScriptableObject.putProperty(regionObj, name, f)
            }
            regionFn("center") { newObj(cx, scope, mapOf("x" to rx + rw / 2, "y" to ry + rh / 2)) }
            regionFn("findColor") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val hex = a.getOrNull(0)?.toString() ?: "#000000"
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.9).toFloat()
                val color = try { Color.parseColor(hex) } catch (e: Exception) { 0 }
                Condition.ColorInRegion(Region(rx, ry, rw, rh), color, minScore).evaluate(frame)
            }
            regionFn("findImage") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val nameOrPath = a.getOrNull(0)?.toString() ?: return@regionFn false
                val path = libraryLookup(nameOrPath) ?: nameOrPath
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.8).toFloat()
                Condition.ImageInRegion(Region(rx, ry, rw, rh), path, minScore).evaluate(frame)
            }
            regionFn("findImageMatch") { a ->
                val frame = frameProvider() ?: return@regionFn null
                val nameOrPath = a.getOrNull(0)?.toString() ?: return@regionFn null
                val path = libraryLookup(nameOrPath) ?: nameOrPath
                val minScore = ((a.getOrNull(1) as? Number)?.toDouble() ?: 0.8).toFloat()
                val result = ImageMatcher.bestLocation(frame, Region(rx, ry, rw, rh), path, 4) ?: return@regionFn null
                val (score, loc) = result
                if (score < minScore) return@regionFn null
                newObj(cx, scope, mapOf("found" to true, "x" to loc.first, "y" to loc.second, "score" to score.toDouble()))
            }
            regionFn("findText") { a ->
                val frame = frameProvider() ?: return@regionFn false
                val text = a.getOrNull(0)?.toString() ?: ""
                Condition.TextInRegion(Region(rx, ry, rw, rh), text).evaluate(frame)
            }
            regionFn("tap") { a ->
                if (pausedProvider()) return@regionFn null
                val hold = long(opt(a, 0, "hold"), 50L)
                executor.execute(Action.Tap(rx + rw / 2, ry + rh / 2, 1, hold))
                null
            }
            regionFn("highlight") { /* Not: script'ten ekranda görsel vurgulama şu an desteklenmiyor — sadece dokümantasyon için yer tutucu. */ null }
            regionObj
        }
    }
}
