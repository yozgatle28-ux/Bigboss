package com.bigboss.app.emscript

/** Kullanıcı tanımlı fonksiyon / lambda / metot. closure ile tanımlandığı scope'u taşır. */
class EmFunction(
    private val declName: String,
    private val params: List<Token>,
    private val body: List<Stmt>,
    private val exprBody: Expr?,   // lambda tek-ifade gövdesi (varsa)
    private val closure: Environment,
    private val boundThis: EmInstance? = null
) : EmCallable {
    override val arity: Int get() = params.size
    override fun name() = declName

    /** Metodu bir örneğe bağlar (this'i sabitler). */
    fun bind(instance: EmInstance): EmFunction =
        EmFunction(declName, params, body, exprBody, closure, instance)

    override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
        val env = Environment(closure)
        if (boundThis != null) env.define("this", boundThis)
        for (i in params.indices) env.define(params[i].lexeme, args.getOrNull(i))
        // lambda tek ifade gövdesi
        if (exprBody != null) return interpreter.evaluatePublic(exprBody, env)
        return try {
            interpreter.executeBlock(body, env)
            null
        } catch (r: Interpreter.ReturnSignal) {
            r.value
        }
    }
}

/**
 * EMScript Interpreter — AST'yi tree-walking ile çalıştırır.
 * Host köprüsü: native fonksiyonlar (tap, swipe, find, Con.out...) dışarıdan `globals`'a
 * define edilir. Böylece dil çekirdeği Android'den bağımsızdır ve izole test edilebilir.
 */
class Interpreter {

    val globals = Environment()
    private var environment = globals

    /** return sinyali (Kotlin exception ile akış kontrolü). */
    class ReturnSignal(val value: Any?) : RuntimeException(null, null, false, false)
    /** break/continue sinyalleri. */
    class BreakSignal : RuntimeException(null, null, false, false)
    class ContinueSignal : RuntimeException(null, null, false, false)

    /** Sonsuz döngü koruması: adım sayacı. 0 = kapalı. */
    var maxSteps: Long = 0
    private var steps: Long = 0

    fun interpret(statements: List<Stmt>) {
        steps = 0
        for (s in statements) execute(s)
    }

    /** Tek bir ifadeyi değerlendirip sonucu döndürür (REFERENCE değişkenleri / tek satır için). */
    fun evalExpression(statements: List<Stmt>): Any? {
        steps = 0
        var last: Any? = null
        for (s in statements) {
            last = if (s is Stmt.Expression) evaluate(s.expr) else { execute(s); null }
        }
        return last
    }

    // ==================== Deyim çalıştırma ====================

    private fun execute(stmt: Stmt) {
        tick()
        when (stmt) {
            is Stmt.Var -> environment.define(stmt.name.lexeme, stmt.initializer?.let { evaluate(it) })
            is Stmt.Expression -> evaluate(stmt.expr)
            is Stmt.Block -> executeBlock(stmt.statements, Environment(environment))
            is Stmt.If -> {
                if (truthy(evaluate(stmt.cond))) execute(stmt.thenB)
                else stmt.elseB?.let { execute(it) }
            }
            is Stmt.While -> {
                while (truthy(evaluate(stmt.cond))) {
                    try { execute(stmt.body) }
                    catch (b: BreakSignal) { break }
                    catch (c: ContinueSignal) { /* devam */ }
                    tick()
                }
            }
            is Stmt.DoWhile -> {
                do {
                    try { execute(stmt.body) }
                    catch (b: BreakSignal) { break }
                    catch (c: ContinueSignal) { }
                    tick()
                } while (truthy(evaluate(stmt.cond)))
            }
            is Stmt.For -> {
                val prev = environment
                environment = Environment(environment)
                try {
                    stmt.init?.let { execute(it) }
                    while (stmt.cond?.let { truthy(evaluate(it)) } != false) {
                        try { execute(stmt.body) }
                        catch (b: BreakSignal) { break }
                        catch (c: ContinueSignal) { }
                        stmt.step?.let { evaluate(it) }
                        tick()
                    }
                } finally { environment = prev }
            }
            is Stmt.ForEach -> {
                val iterable = evaluate(stmt.iterable)
                val list: List<Any?> = when (iterable) {
                    is EmArray -> iterable.elements.toList()
                    is String -> iterable.map { it.toString() }
                    else -> throw EmScriptError("foreach yalnızca dizi/metin üzerinde çalışır", stmt.varName.line)
                }
                val prev = environment
                environment = Environment(environment)
                try {
                    for (item in list) {
                        environment.define(stmt.varName.lexeme, item)
                        try { execute(stmt.body) }
                        catch (b: BreakSignal) { break }
                        catch (c: ContinueSignal) { }
                        tick()
                    }
                } finally { environment = prev }
            }
            is Stmt.Function -> {
                val fn = EmFunction(stmt.name.lexeme, stmt.params, stmt.body, null, environment)
                environment.define(stmt.name.lexeme, fn)
            }
            is Stmt.Return -> throw ReturnSignal(stmt.value?.let { evaluate(it) })
            is Stmt.Break -> throw BreakSignal()
            is Stmt.Continue -> throw ContinueSignal()
            is Stmt.Class -> {
                val methods = stmt.methods.associate { m ->
                    m.name.lexeme to EmFunction(m.name.lexeme, m.params, m.body, null, environment)
                }
                val statics = stmt.staticMethods.associate { m ->
                    m.name.lexeme to EmFunction(m.name.lexeme, m.params, m.body, null, environment)
                }
                val klass = EmClass(stmt.name.lexeme, stmt.initParams, stmt.initBody, methods, statics, environment)
                environment.define(stmt.name.lexeme, klass)
            }
        }
    }

    fun executeBlock(statements: List<Stmt>, env: Environment) {
        val previous = environment
        environment = env
        try {
            for (s in statements) execute(s)
        } finally {
            environment = previous
        }
    }

    // ==================== İfade değerlendirme ====================

    fun evaluatePublic(expr: Expr, env: Environment): Any? {
        val prev = environment
        environment = env
        try { return evaluate(expr) } finally { environment = prev }
    }

    private fun evaluate(expr: Expr): Any? {
        tick()
        return when (expr) {
            is Expr.Literal -> expr.value
            is Expr.Variable -> environment.get(expr.name)
            is Expr.This -> environment.getByName("this")
                ?: throw EmScriptError("'this' yalnızca metot içinde geçerli", expr.keyword.line)
            is Expr.ArrayLiteral -> EmArray(expr.elements.map { evaluate(it) }.toMutableList())
            is Expr.Assign -> evalAssign(expr)
            is Expr.Unary -> evalUnary(expr)
            is Expr.Binary -> evalBinary(expr)
            is Expr.Logical -> evalLogical(expr)
            is Expr.Ternary -> if (truthy(evaluate(expr.cond))) evaluate(expr.thenE) else evaluate(expr.elseE)
            is Expr.Get -> evalGet(expr)
            is Expr.Index -> evalIndex(expr)
            is Expr.Call -> evalCall(expr)
            is Expr.New -> evalNew(expr)
            is Expr.Lambda -> EmFunction("<lambda>", expr.params, expr.body, expr.exprBody, environment)
        }
    }

    private fun evalAssign(expr: Expr.Assign): Any? {
        val newValue = evaluate(expr.value)
        return when (val target = expr.target) {
            is Expr.Variable -> {
                val v = applyCompound(expr.op, { environment.get(target.name) }, newValue)
                environment.assign(target.name, v)
                v
            }
            is Expr.Get -> {
                val obj = evaluate(target.obj)
                if (obj !is EmInstance) throw EmScriptError("Yalnızca nesne alanına atanabilir", target.name.line)
                val v = applyCompound(expr.op, { obj.get(target.name.lexeme) }, newValue)
                obj.set(target.name.lexeme, v)
                v
            }
            is Expr.Index -> {
                val obj = evaluate(target.obj)
                val idx = toInt(evaluate(target.index))
                if (obj !is EmArray) throw EmScriptError("Yalnızca diziye indeksle atanabilir", target.bracket.line)
                val v = applyCompound(expr.op, { obj.get(idx) }, newValue)
                obj.set(idx, v)
                v
            }
            else -> throw EmScriptError("Geçersiz atama hedefi")
        }
    }

    /** += -= *= /= için mevcut değerle birleştir; = için doğrudan yeni değer. */
    private fun applyCompound(op: Token, current: () -> Any?, rhs: Any?): Any? {
        return when (op.type) {
            TokenType.ASSIGN -> rhs
            TokenType.PLUS_ASSIGN -> plus(current(), rhs, op)
            TokenType.MINUS_ASSIGN -> arith(current(), rhs, op) { a, b -> a - b }
            TokenType.STAR_ASSIGN -> arith(current(), rhs, op) { a, b -> a * b }
            TokenType.SLASH_ASSIGN -> arith(current(), rhs, op) { a, b -> a / b }
            else -> rhs
        }
    }

    private fun evalUnary(expr: Expr.Unary): Any? {
        val right = evaluate(expr.right)
        return when (expr.op.type) {
            TokenType.MINUS -> -toNum(right, expr.op)
            TokenType.NOT -> !truthy(right)
            else -> throw EmScriptError("Bilinmeyen tekli işleç ${expr.op.lexeme}", expr.op.line)
        }
    }

    private fun evalLogical(expr: Expr.Logical): Any? {
        val left = evaluate(expr.left)
        if (expr.op.type == TokenType.OR) {
            if (truthy(left)) return left
        } else { // AND
            if (!truthy(left)) return left
        }
        return evaluate(expr.right)
    }

    private fun evalBinary(expr: Expr.Binary): Any? {
        val left = evaluate(expr.left)
        val right = evaluate(expr.right)
        return when (expr.op.type) {
            TokenType.PLUS -> plus(left, right, expr.op)
            TokenType.MINUS -> arith(left, right, expr.op) { a, b -> a - b }
            TokenType.STAR -> arith(left, right, expr.op) { a, b -> a * b }
            TokenType.SLASH -> arith(left, right, expr.op) { a, b -> a / b }
            TokenType.PERCENT -> arith(left, right, expr.op) { a, b -> a % b }
            TokenType.GT -> toNum(left, expr.op) > toNum(right, expr.op)
            TokenType.GE -> toNum(left, expr.op) >= toNum(right, expr.op)
            TokenType.LT -> toNum(left, expr.op) < toNum(right, expr.op)
            TokenType.LE -> toNum(left, expr.op) <= toNum(right, expr.op)
            TokenType.EQ -> isEqual(left, right)
            TokenType.NEQ -> !isEqual(left, right)
            else -> throw EmScriptError("Bilinmeyen işleç ${expr.op.lexeme}", expr.op.line)
        }
    }

    private fun evalGet(expr: Expr.Get): Any? {
        val obj = evaluate(expr.obj)
        val nameStr = expr.name.lexeme
        return when (obj) {
            is EmInstance -> obj.get(nameStr)
            is EmArray -> when (nameStr) {
                "size", "length" -> obj.size.toDouble()
                "push" -> nativeMethod(1) { a -> obj.push(a.getOrNull(0)); null }
                "get" -> nativeMethod(1) { a -> obj.get(toInt(a.getOrNull(0))) }
                "set" -> nativeMethod(2) { a -> obj.set(toInt(a.getOrNull(0)), a.getOrNull(1)); null }
                else -> throw EmScriptError("Dizide '$nameStr' yok", expr.name.line)
            }
            is String -> when (nameStr) {
                "size", "length" -> obj.length.toDouble()
                else -> throw EmScriptError("Metinde '$nameStr' yok", expr.name.line)
            }
            is EmClass -> obj.findStatic(nameStr)
                ?: throw EmScriptError("'${obj.emName}' sınıfında static '$nameStr' yok", expr.name.line)
            is EmHostObject -> obj.get(nameStr)
                ?: throw EmScriptError("'$nameStr' bulunamadı", expr.name.line)
            else -> throw EmScriptError("'$nameStr' erişilemez (nesne değil)", expr.name.line)
        }
    }

    private fun evalIndex(expr: Expr.Index): Any? {
        val obj = evaluate(expr.obj)
        val idx = toInt(evaluate(expr.index))
        return when (obj) {
            is EmArray -> obj.get(idx)
            is String -> if (idx in obj.indices) obj[idx].toString() else ""
            else -> throw EmScriptError("İndekslenemez (dizi/metin değil)", expr.bracket.line)
        }
    }

    private fun evalCall(expr: Expr.Call): Any? {
        val callee = evaluate(expr.callee)
        val args = expr.args.map { evaluate(it) }
        if (callee !is EmCallable) throw EmScriptError("Çağrılabilir değil: ${stringify(callee)}", expr.paren.line)
        if (callee.arity != -1 && args.size != callee.arity) {
            // Esnek: eksik argümanları null, fazlasını yok say (dinamik dil davranışı)
        }
        return callee.call(this, args)
    }

    private fun evalNew(expr: Expr.New): Any? {
        val klass = environment.getByName(expr.className.lexeme)
            ?: throw EmScriptError("Bilinmeyen sınıf '${expr.className.lexeme}'", expr.className.line)
        if (klass !is EmClass) throw EmScriptError("'${expr.className.lexeme}' bir sınıf değil", expr.className.line)
        val args = expr.args.map { evaluate(it) }
        return klass.call(this, args)
    }

    // ==================== yardımcı native metot üreticisi ====================

    private fun nativeMethod(arity: Int, fn: (List<Any?>) -> Any?): EmCallable =
        object : EmCallable {
            override val arity = arity
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = fn(args)
        }

    // ==================== operatör yardımcıları ====================

    private fun plus(a: Any?, b: Any?, op: Token): Any? {
        // Sayı + Sayı = toplama; herhangi biri string ise metin birleştirme (JS/EMScript davranışı)
        if (a is Double && b is Double) return a + b
        if (a is String || b is String) return stringify(a) + stringify(b)
        if (a is Double && b is Double) return a + b
        throw EmScriptError("'+' için uyumsuz tipler: ${typeName(a)} + ${typeName(b)}", op.line)
    }

    private inline fun arith(a: Any?, b: Any?, op: Token, f: (Double, Double) -> Double): Double {
        return f(toNum(a, op), toNum(b, op))
    }

    private fun isEqual(a: Any?, b: Any?): Boolean {
        if (a == null && b == null) return true
        if (a == null || b == null) return false
        return a == b
    }

    // ==================== dönüşümler ====================

    private fun truthy(v: Any?): Boolean = when (v) {
        null -> false
        is Boolean -> v
        is Double -> v != 0.0
        is String -> v.isNotEmpty()
        else -> true // nesne/dizi/fonksiyon -> doğru (JS truthy)
    }

    private fun toNum(v: Any?, op: Token): Double = when (v) {
        is Double -> v
        is Boolean -> if (v) 1.0 else 0.0
        is String -> v.toDoubleOrNull() ?: throw EmScriptError("Sayı bekleniyordu, metin geldi: \"$v\"", op.line)
        null -> 0.0
        else -> throw EmScriptError("Sayı bekleniyordu: ${typeName(v)}", op.line)
    }

    private fun toInt(v: Any?): Int = when (v) {
        is Double -> v.toInt()
        is Boolean -> if (v) 1 else 0
        is String -> v.toDoubleOrNull()?.toInt() ?: 0
        else -> 0
    }

    private fun typeName(v: Any?): String = when (v) {
        null -> "null"; is Double -> "number"; is Boolean -> "bool"; is String -> "string"
        is EmArray -> "array"; is EmCallable -> "function"; is EmInstance -> "object"; else -> "value"
    }

    private fun tick() {
        if (maxSteps > 0) {
            steps++
            if (steps > maxSteps) throw EmScriptError("Adım sınırı aşıldı ($maxSteps) — muhtemel sonsuz döngü")
        }
    }

    companion object {
        /** Bir EMScript değerini kullanıcıya gösterilecek metne çevirir. */
        fun stringify(v: Any?): String = when (v) {
            null -> "null"
            is Double -> if (v == Math.floor(v) && !v.isInfinite()) v.toLong().toString() else v.toString()
            is Boolean -> v.toString()
            else -> v.toString()
        }
    }
}

/**
 * Host tarafından sağlanan "nesne benzeri" köprü (örn. Con, Region, Setting).
 * get(name) ile alan/metot döndürür — native fonksiyonlar ya da alt nesneler.
 */
interface EmHostObject {
    fun get(name: String): Any?
}
