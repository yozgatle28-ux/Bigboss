package com.bigboss.app.storage

/**
 * Kural editöründe (dokunarak/sürükleyerek) oluşturulan, JSON'a kolayca
 * çevrilebilen düz (flat) kural modeli. RuleEngine'in kullandığı
 * Condition/Action nesnelerine RuleDefinitionMapper ile çevrilir.
 *
 * Kurallar RuleEngine tarafından SIRAYLA (script gibi) çalıştırılır —
 * listedeki sıra, kuralların çalışma sırasıdır.
 */
data class RuleDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,

    /** Macrorify'daki "Grouping" fikri: kuralları organize etmek için isteğe bağlı etiket. */
    var groupName: String? = null,

    // ---- Koşul (IF): bir ya da birden fazla (VEYA'lı) alternatif ----
    var alternatives: MutableList<ConditionAlt> = mutableListOf(),
    /** Macrorify'daki "Multi Detection Logic": 2+ alternatif varken bunlar nasıl birleşsin.
     *  "ONE_SUCCESS"(VEYA) | "ALL_SUCCESS"(VE) | "ALL_FAIL" | "ONE_FAIL" | "ALWAYS_SUCCESS" | "ALWAYS_FAIL" */
    var alternativesLogic: String = "ONE_SUCCESS",
    /** "Wait Next": bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmeli (spam önleme). */
    var timeoutMs: Long = 300,
    /** true ise "Wait till vanish": koşul KAYBOLUNCA (eşleşmeyince) tetiklenir. */
    var negateCondition: Boolean = false,
    /** "NONE" | "ALWAYS" | "WHILE_SUCCESS" | "WHILE_FAIL" */
    var loopMode: String = "ALWAYS",
    /** Loop üst sınırı. 0 = sınırsız. (Şu an sadece geriye dönük uyumluluk için tutuluyor.) */
    var maxLoopCount: Int = 0,
    /** Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre (ms). */
    var matchDelayMs: Long = 0,
    /** 💡 Ampul: bu alanlar doluysa, yukarıdaki sabit timeoutMs/matchDelayMs YERİNE bu isimli değişkenin GÜNCEL değeri kullanılır. */
    var cooldownVarName: String? = null,
    var matchDelayVarName: String? = null,
    /** "Tarama Süresi" (Timeout): koşul tetiklenmeden önce en az bu kadar ms SÜREKLİ doğru kalmalı. 0 = anında. */
    var scanTimeoutMs: Long = 0,
    /** Macrorify'daki "Scan Rate": saniyede en fazla kaç kere kontrol edilsin (pil tasarrufu). 0 = sınırsız. */
    var scanRateHz: Float = 0f,
    /** 💡 Ampul: bu alanlar doluysa, yukarıdaki sabit scanTimeoutMs/scanRateHz YERİNE bu isimli değişkenin GÜNCEL değeri kullanılır. */
    var scanTimeoutVarName: String? = null,
    var scanRateVarName: String? = null,
    /** "Otomatik Durdurma": bu kural art arda kaç kere BULUNAMAZSA (tetiklenmeden) kendini devre dışı bıraksın. 0 = sınırsız. */
    var maxConsecutiveFailures: Int = 0,

    // ---- İsteğe bağlı ek şart: bir değişken/sayaç karşılaştırması ----
    var requireVariableName: String? = null,
    /** ">=", "<=", "==", ">", "<" */
    var requireVariableOp: String = ">=",
    var requireVariableValue: Int = 0,

    // ---- Aksiyon (THEN) ----
    /** "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" */
    var actionType: String = "TAP",
    var actionX: Int = 0,
    var actionY: Int = 0,
    var actionX2: Int = 0,
    var actionY2: Int = 0,
    var swipeDurationMs: Long = 300,
    /** Macrorify'daki "Swipe Path": 2'den FAZLA nokta varsa burası kullanılır. Boşsa (eski kurallar),
     *  aşağıdaki actionX/Y/X2/Y2 + swipeHoldStartMs/EndMs ile eski basit 2-noktalı davranış korunur. */
    var swipePathPoints: MutableList<SwipePointData> = mutableListOf(),
    /**
     * Macrorify'daki GERÇEK çoklu-parmak (Swipe Path #2, #3, ... — pinch/zoom/çoklu-dokunuş için).
     * Her iç liste AYRI bir parmağın yolu (en az 2 nokta gerekir). Ana parmak (finger 1) HÂLÂ
     * actionX/Y/X2/Y2 + swipePathPoints ile temsil edilir — burası SADECE 2., 3., ... parmaklar
     * için. Boşsa (çoğu kural) tek parmaklı eski davranış korunur.
     */
    var swipeExtraFingerPaths: MutableList<MutableList<SwipePointData>> = mutableListOf(),
    /** Kaydırma başlangıç noktasında hareket etmeden önce kaç ms basılı beklensin (sürükle-bırak için). */
    var swipeHoldStartMs: Long = 0,
    /** Kaydırma bitiş noktasında parmağı kaldırmadan önce kaç ms daha basılı tutulsun. */
    var swipeHoldEndMs: Long = 0,
    /** true ise sabit koordinat yerine, koşulun BULDUĞU konuma tıklanır ("Eşleşen Noktaya Tıkla"). */
    var tapAtMatchLocation: Boolean = false,
    /** Macrorify'daki "Click Multiple Matches": true ise (tapAtMatchLocation de true olmalı) TEK en iyi eşleşme yerine minScore üstü TÜM eşleşmelere tıklar. */
    var tapAllMatches: Boolean = false,
    /** Dokunma kaç kere tekrarlansın. */
    var actionRepeatCount: Int = 1,
    /** "HOLD": eşleşen/sabit noktada kaç ms basılı tutulsun. */
    var actionHoldMs: Long = 50,
    /** "DELAY": işlem TAMAMLANDIKTAN SONRA, sıradaki işleme geçmeden önce kaç ms beklensin. */
    var actionPostDelayMs: Long = 0,
    /** "Randomize": her noktaya ±bu kadar piksel rastgele sapma eklenir (daha insani/tespit-karşıtı). */
    var randomOffsetPx: Int = 0,
    /** "Random Condition": eşleşme bulunsa bile, sadece bu yüzdelik ŞANSLA tetiklenir. 100 = her zaman (kapalı). */
    var randomChancePercent: Int = 100,
    /** Bu alanlar doluysa, yukarıdaki sabit değer YERİNE aşağıdaki isimli Değişkenin GÜNCEL değeri kullanılır. */
    var actionHoldVarName: String? = null,
    var actionPostDelayVarName: String? = null,
    var swipeHoldStartVarName: String? = null,
    var swipeHoldEndVarName: String? = null,
    /** Macrorify "her input alanında değişken": aşağıdaki alanlar da bir değişkene bağlanabilir. */
    var actionRepeatVarName: String? = null,
    var randomOffsetVarName: String? = null,
    var swipeDurationVarName: String? = null,
    /** Dokunma/kaydırma KOORDİNATLARI da değişkene bağlanabilir (örn. skillOneLocation). */
    var actionXVarName: String? = null,
    var actionYVarName: String? = null,
    var actionX2VarName: String? = null,
    var actionY2VarName: String? = null,
    /** actionType = "CALL_FUNCTION" için: çağrılacak fonksiyonun id'si */
    var callFunctionId: String? = null,
    var callFunctionRepeat: Int = 1,
    /** "BAŞARILI OLUNCA" sekmesinde eklenen, birincil aksiyondan SONRA SIRAYLA çalışacak adımlar. */
    var extraSteps: MutableList<ActionStep> = mutableListOf(),
    /**
     * KÖK NEDEN DÜZELTMESİ (kullanıcı raporu: "On Success ve On Fail düzgün çalışmıyor" +
     * Macrorify'ın resmi akış şeması/dokümantasyonu): "BULUNAMAZSA" (On Fail) eskiden AYRI,
     * TERS KOŞULLU bir "gölge kural" (`${id}-fail`) olarak saklanıyordu — bu, motorun HER
     * KAREDE negatif koşulu ayrı ayrı değerlendirmesine, yani Timeout'u (zaman aşımını) HİÇ
     * BEKLEMEDEN anında tetiklenmesine yol açıyordu. Macrorify'ın GERÇEK mantığı: "Template
     * NOT bulunamadıysa, TÜM işlem Timeout dolana kadar TEKRARLANIR — süre dolunca On Fail
     * çalışır." Bu artık AYRI bir kural DEĞİL, AYNI kuralın (aynı koşul/timeout/scan rate'i
     * PAYLAŞAN) bir PARÇASI — motor (RuleEngine) artık "süre doldu mu" diye TEK bir yerden
     * karar veriyor.
     */
    var onFailSteps: MutableList<ActionStep> = mutableListOf(),

    // ---- İsteğe bağlı ek etki: bir sayaç değişkenini güncelle ----
    var incrementVariableName: String? = null,
    var incrementVariableDelta: Int = 1,
    /** "INCREMENT" ya da "SET" */
    var incrementVariableMode: String = "INCREMENT",

    // ---- Macrorify "Region Scaling" (Basic → Region Scaling): Fixed / Dynamic / Sticky ----
    /** Bu kural HANGİ ekran çözünürlüğünde OLUŞTURULDU (bölge/nokta koordinatları bu çözünürlüğe göredir).
     *  0 ise eski kural (ölçekleme bilgisi yok) — hiçbir ölçekleme uygulanmaz, %100 eski davranış. */
    var baseScreenW: Int = 0,
    var baseScreenH: Int = 0,
    /** "FIXED" (varsayılan, en-boy oranını bozmadan ortadan) | "DYNAMIC" (kenara-yüzde, esneyebilir) | "STICKY" (seçili kenar(lar)dan sabit boşluk). */
    var regionScaleMode: String = "FIXED",
    /** STICKY modunda hangi kenar(lar)a sabitlensin: LEFT=1, TOP=2, RIGHT=4, BOTTOM=8 (RegionScaler sabitleri, bit bayrağı olarak toplanır). */
    var regionStickyEdges: Int = 0,

    // ---- Macrorify "Relative Coordinates" (Locatable Detection) — aksiyon (TAP) tarafı ----
    /** Doluysa, actionType="TAP" iken sabit actionX/Y YERİNE bu ID'li kuralın SON bulunduğu konum + offset kullanılır ("🔗 Relatif Nokta"). */
    var actionRelativeAnchorRuleId: String? = null,
    var actionRelativeOffsetX: Int = 0,
    var actionRelativeOffsetY: Int = 0,

    // ---- Macrorify Ana Akış "+" menüsü genişletmesi: bağımsız (koşulsuz) üst-düzey aksiyon tipleri ----
    /** actionType = "PLAY_RECORD" için: RecordStorage'daki hangi kaydın oynatılacağı. */
    var playRecordId: String? = null,
    /** actionType = "READ_TEXT" için: okunan metnin yazılacağı değişken. Bölge actionX/Y/X2/Y2'de (x,y,genişlik,yükseklik) tutulur. */
    var readTextVariableName: String? = null,
    var readTextWhitelist: String = "",
    var readTextBlacklist: String = "",
    var readTextDefaultValue: Int = 0,
    /** actionType = "RUN_SCRIPT" için: koşulsuz, doğrudan gömülü kod adımı ("Code"). */
    var runScriptCode: String? = null,
    /** "JS" | "EMSCRIPT" */
    /** "EMSCRIPT" (tek motor, JS seçeneği arayüzden kaldırıldı). Eski kayıtlarda "JS" görülebilir. */
    var runScriptLanguage: String = "EMSCRIPT"
)
