package com.bigboss.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor

/**
 * RuleEngine'in kararlarını gerçek dokunuş/kaydırma jestlerine çeviren servis.
 * Kullanıcının Ayarlar > Erişilebilirlik ekranından elle etkinleştirmesi gerekir
 * (root gerektirmeyen resmi Android yolu).
 */
class BigBossAccessibilityService : AccessibilityService(), ActionExecutor {

    companion object {
        // MainActivity ve diğer servislerin erişebilmesi için basit bir referans.
        var instance: BigBossAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ScreenCaptureService.ruleEngine?.let { /* zaten bağlıysa dokunma */ }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Şu an olayları dinlemiyoruz; yalnızca jest gönderme (gesture dispatch)
        // yeteneğini kullanıyoruz. İleride ekran içeriği okumak gerekirse
        // (canRetrieveWindowContent=true yapılarak) burası genişletilebilir.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---- ActionExecutor ----

    /**
     * Macrorify'ın dokümantasyonundaki TAM matematik: "Koordinatlar, orijinal noktayı
     * MERKEZ alan bir DAİRE içinde rastgeleleştirilir, girilen miktar YARIÇAP olur."
     * Önceki sürüm x/y'yi BAĞIMSIZ rastgeleleştiriyordu (kare dağılım) — bu yanlıştı.
     * Burada tek bir açı+yarıçap seçip İKİSİNE BİRDEN uyguluyoruz (gerçek dairesel dağılım,
     * alanda düzgün dağılsın diye sqrt ile ölçekleniyor).
     */
    private fun jitterPoint(x: Int, y: Int, range: Int): Pair<Int, Int> {
        if (range <= 0) return x to y
        val angle = Math.random() * 2 * Math.PI
        val radius = range * Math.sqrt(Math.random())
        val dx = (radius * Math.cos(angle)).toInt()
        val dy = (radius * Math.sin(angle)).toInt()
        return (x + dx) to (y + dy)
    }

    override fun execute(action: Action) {
        when (action) {
            is Action.Tap -> repeat(action.repeat.coerceAtLeast(1)) {
                val (jx, jy) = jitterPoint(action.x, action.y, action.randomOffsetPx)
                dispatchTap(jx, jy, action.holdMs)
                Thread.sleep(action.holdMs + action.postDelayMs) // jestin kendi süresi + istenen ek gecikme
            }
            is Action.TapAtMatch -> { /* RuleEngine bunu somut bir Tap'e çevirip gönderir, buraya gelmemeli */ }
            is Action.TapAllMatches -> { /* RuleEngine bunu somut Tap'lere çevirip gönderir, buraya gelmemeli */ }
            is Action.TapRelative -> {
                val anchor = com.bigboss.app.engine.MatchLocationRegistry.get(action.anchorRuleId, action.maxAnchorAgeMs)
                if (anchor != null) {
                    repeat(action.repeat.coerceAtLeast(1)) {
                        val (jx, jy) = jitterPoint(anchor.first + action.offsetX, anchor.second + action.offsetY, action.randomOffsetPx)
                        dispatchTap(jx, jy, action.holdMs)
                        Thread.sleep(action.holdMs + action.postDelayMs)
                    }
                }
                // anchor henüz hiç bulunmadıysa (ya da kaydı çok eskiyse) sessizce hiçbir şey yapmaz — güvenli varsayılan
            }
            is Action.Swipe -> {
                val (jx1, jy1) = jitterPoint(action.x1, action.y1, action.randomOffsetPx)
                val (jx2, jy2) = jitterPoint(action.x2, action.y2, action.randomOffsetPx)
                dispatchSwipe(jx1, jy1, jx2, jy2, action.durationMs, action.holdStartMs, action.holdEndMs)
                Thread.sleep(action.holdStartMs + action.durationMs + action.holdEndMs + action.postDelayMs)
            }
            is Action.MultiPointSwipe -> {
                dispatchMultiPointSwipe(action)
                val total = action.points.sumOf { it.holdMs } + action.points.size * action.segmentDurationMs
                Thread.sleep(total + action.postDelayMs)
            }
            is Action.MultiFingerSwipe -> {
                dispatchMultiFingerSwipe(action)
                val longestPathMs = action.paths.maxOfOrNull { pts -> pts.sumOf { it.holdMs } + pts.size * action.segmentDurationMs } ?: 0L
                Thread.sleep(longestPathMs + action.postDelayMs)
            }
            is Action.Wait -> Thread.sleep(action.ms) // basit sürüm; büyük projede coroutine delay tercih edilmeli
            is Action.Sequence -> action.steps.forEach { execute(it) }
            is Action.SetVariable -> when (action.mode) {
                "SET" -> com.bigboss.app.engine.VariableStore.set(action.name, action.delta)
                else -> com.bigboss.app.engine.VariableStore.increment(action.name, action.delta)
            }
            is Action.CallFunction -> { /* RuleEngine bunu kendisi yönetir, buraya gelmemeli */ }
            is Action.ReadTextToVariable -> { /* RuleEngine bunu frame ile kendisi çözer (resolveAndExecute), buraya gelmemeli */ }
            is Action.RunScript -> {
                if (action.language == "EMSCRIPT") {
                    val host = com.bigboss.app.engine.ScriptRuntime.emHost
                    if (host != null) {
                        val err = com.bigboss.app.emscript.EmScriptRunner.run(action.code, host)
                        if (err != null) android.util.Log.w("BigBossEMScript", err)
                    }
                } else {
                    com.bigboss.app.engine.ScriptRuntime.engine?.run(action.code)
                }
            }
            is Action.SystemAction -> {
                val globalAction = when (action.type) {
                    "BACK" -> GLOBAL_ACTION_BACK
                    "HOME" -> GLOBAL_ACTION_HOME
                    "RECENTS" -> GLOBAL_ACTION_RECENTS
                    "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
                    "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
                    else -> null
                }
                if (globalAction != null) performGlobalAction(globalAction)
            }
            Action.NoOp -> { /* hiçbir şey yapma */ }
        }
    }

    private fun dispatchTap(x: Int, y: Int, holdMs: Long = 50) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceAtLeast(1))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long, holdStartMs: Long = 0, holdEndMs: Long = 0) {
        // Basit durum: hiç HOLD yoksa, tek segmentlik eski davranış (daha hafif).
        if (holdStartMs <= 0 && holdEndMs <= 0) {
            val path = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            return
        }

        // HOLD var: başlangıçta sabit bekle -> hareket et -> bitişte sabit bekle (sürükle-bırak, "basılı tut" jestleri için).
        var startTime = 0L
        var lastStroke: GestureDescription.StrokeDescription? = null

        if (holdStartMs > 0) {
            val holdPath = Path().apply { moveTo(x1.toFloat(), y1.toFloat()) }
            lastStroke = GestureDescription.StrokeDescription(holdPath, startTime, holdStartMs, true)
            startTime += holdStartMs
        }

        val movePath = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val willContinue = holdEndMs > 0
        lastStroke = if (lastStroke != null) {
            lastStroke.continueStroke(movePath, startTime, durationMs.coerceAtLeast(1), willContinue)
        } else {
            GestureDescription.StrokeDescription(movePath, startTime, durationMs.coerceAtLeast(1), willContinue)
        }
        startTime += durationMs.coerceAtLeast(1)

        if (holdEndMs > 0) {
            val endHoldPath = Path().apply { moveTo(x2.toFloat(), y2.toFloat()) }
            lastStroke = lastStroke!!.continueStroke(endHoldPath, startTime, holdEndMs, false)
        }

        dispatchGesture(GestureDescription.Builder().addStroke(lastStroke!!).build(), null, null)
    }

    /**
     * Macrorify'daki "Swipe Path": TEK PARMAKLA, art arda N noktadan geçen kaydırma.
     * Her nokta kendi HOLD süresini kullanabilir (o noktada durup bekleyip sonra devam eder).
     * Aynı continueStroke zincirleme tekniği — sadece 2 nokta yerine N nokta için genelleştirildi.
     */
    private fun dispatchMultiPointSwipe(action: Action.MultiPointSwipe) {
        val stroke = buildStrokeForPath(action.points, action.randomOffsetPx, action.segmentDurationMs) ?: return
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /**
     * GERÇEK çoklu parmak: her `paths` elemanı (bir parmağın yolu) için AYRI bir
     * StrokeDescription üretip TEK bir GestureDescription'a hepsini birlikte ekliyoruz
     * (addStroke ×N) — bu, Android AccessibilityService'in eşzamanlı çoklu-dokunuşu (pinch/
     * zoom/çoklu parmak jestleri) desteklediği ASIL mekanizma.
     */
    private fun dispatchMultiFingerSwipe(action: Action.MultiFingerSwipe) {
        val builder = GestureDescription.Builder()
        var anyStroke = false
        action.paths.forEach { pathPoints ->
            val stroke = buildStrokeForPath(pathPoints, action.randomOffsetPx, action.segmentDurationMs)
            if (stroke != null) { builder.addStroke(stroke); anyStroke = true }
        }
        if (anyStroke) dispatchGesture(builder.build(), null, null)
    }

    /**
     * TEK bir parmağın (N noktalı) yolunu, HOLD'ları da dahil ederek zincirlenmiş TEK bir
     * StrokeDescription'a çevirir. dispatchMultiPointSwipe VE dispatchMultiFingerSwipe'ın
     * PAYLAŞTIĞI ortak mantık (kod tekrarını önlemek için tek yerde).
     */
    private fun buildStrokeForPath(points: List<Action.SwipePointDef>, randomOffsetPx: Int, segmentDurationMs: Long): GestureDescription.StrokeDescription? {
        if (points.isEmpty()) return null
        if (points.size == 1) {
            // Tek nokta: sadece o noktada basılı tutmuş gibi davran (dokunma).
            val p = points[0]
            val (jx, jy) = jitterPoint(p.x, p.y, randomOffsetPx)
            val path = Path().apply { moveTo(jx.toFloat(), jy.toFloat()) }
            return GestureDescription.StrokeDescription(path, 0, p.holdMs.coerceAtLeast(50))
        }
        // Her nokta kendi dairesel Randomize sapmasını alır (Macrorify: "her noktayı bu miktarla rastgeleleştir").
        val jittered = points.map { p -> jitterPoint(p.x, p.y, randomOffsetPx) to p.holdMs }

        var startTime = 0L
        var lastStroke: GestureDescription.StrokeDescription? = null

        val (firstPoint, firstHold) = jittered[0]
        if (firstHold > 0) {
            val holdPath = Path().apply { moveTo(firstPoint.first.toFloat(), firstPoint.second.toFloat()) }
            lastStroke = GestureDescription.StrokeDescription(holdPath, startTime, firstHold, true)
            startTime += firstHold
        }

        for (i in 1 until jittered.size) {
            val (prevPoint, _) = jittered[i - 1]
            val (curPoint, curHold) = jittered[i]
            val isLastPoint = i == jittered.size - 1
            val movePath = Path().apply {
                moveTo(prevPoint.first.toFloat(), prevPoint.second.toFloat())
                lineTo(curPoint.first.toFloat(), curPoint.second.toFloat())
            }
            val willContinueAfterMove = curHold > 0 || !isLastPoint
            lastStroke = if (lastStroke != null) {
                lastStroke.continueStroke(movePath, startTime, segmentDurationMs.coerceAtLeast(1), willContinueAfterMove)
            } else {
                GestureDescription.StrokeDescription(movePath, startTime, segmentDurationMs.coerceAtLeast(1), willContinueAfterMove)
            }
            startTime += segmentDurationMs.coerceAtLeast(1)

            if (curHold > 0) {
                val holdPath = Path().apply { moveTo(curPoint.first.toFloat(), curPoint.second.toFloat()) }
                lastStroke = lastStroke!!.continueStroke(holdPath, startTime, curHold, !isLastPoint)
                startTime += curHold
            }
        }
        return lastStroke
    }
}
