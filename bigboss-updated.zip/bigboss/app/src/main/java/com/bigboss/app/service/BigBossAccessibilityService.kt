package com.bigboss.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor

/**
 * RuleEngine'in kararlarını gerçek dokunuş/kaydırma jestlerine çeviren servis.
 * Kullanıcının Ayarlar > Erişilebilirlik ekranından elle etkinleştirmesi gerekir
 * (root gerektirmeyen resmi Android yolu).
 */
class BigBossAccessibilityService : AccessibilityService(), ActionExecutor {

    companion object {
        // MainActivity ve diğer servislerin erişebilmesi için basit bir referans.
        var instance: BigBossAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ScreenCaptureService.ruleEngine?.let { /* zaten bağlıysa dokunma */ }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Şu an olayları dinlemiyoruz; yalnızca jest gönderme (gesture dispatch)
        // yeteneğini kullanıyoruz. İleride ekran içeriği okumak gerekirse
        // (canRetrieveWindowContent=true yapılarak) burası genişletilebilir.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---- ActionExecutor ----

    /**
     * Macrorify'ın dokümantasyonundaki TAM matematik: "Koordinatlar, orijinal noktayı
     * MERKEZ alan bir DAİRE içinde rastgeleleştirilir, girilen miktar YARIÇAP olur."
     * Önceki sürüm x/y'yi BAĞIMSIZ rastgeleleştiriyordu (kare dağılım) — bu yanlıştı.
     * Burada tek bir açı+yarıçap seçip İKİSİNE BİRDEN uyguluyoruz (gerçek dairesel dağılım,
     * alanda düzgün dağılsın diye sqrt ile ölçekleniyor).
     */
    private fun jitterPoint(x: Int, y: Int, range: Int): Pair<Int, Int> {
        if (range <= 0) return x to y
        val angle = Math.random() * 2 * Math.PI
        val radius = range * Math.sqrt(Math.random())
        val dx = (radius * Math.cos(angle)).toInt()
        val dy = (radius * Math.sin(angle)).toInt()
        return (x + dx) to (y + dy)
    }

    override fun execute(action: Action) {
        when (action) {
            is Action.Tap -> repeat(action.repeat.coerceAtLeast(1)) {
                val (jx, jy) = jitterPoint(action.x, action.y, action.randomOffsetPx)
                dispatchTap(jx, jy, action.holdMs)
                Thread.sleep(action.holdMs + action.postDelayMs) // jestin kendi süresi + istenen ek gecikme
            }
            is Action.TapAtMatch -> { /* RuleEngine bunu somut bir Tap'e çevirip gönderir, buraya gelmemeli */ }
            is Action.TapAllMatches -> { /* RuleEngine bunu somut Tap'lere çevirip gönderir, buraya gelmemeli */ }
            is Action.TapRelative -> {
                val anchor = com.bigboss.app.engine.MatchLocationRegistry.get(action.anchorRuleId, action.maxAnchorAgeMs)
                if (anchor != null) {
                    repeat(action.repeat.coerceAtLeast(1)) {
                        val (jx, jy) = jitterPoint(anchor.first + action.offsetX, anchor.second + action.offsetY, action.randomOffsetPx)
                        dispatchTap(jx, jy, action.holdMs)
                        Thread.sleep(action.holdMs + action.postDelayMs)
                    }
                }
                // anchor henüz hiç bulunmadıysa (ya da kaydı çok eskiyse) sessizce hiçbir şey yapmaz — güvenli varsayılan
            }
            is Action.Swipe -> {
                val (jx1, jy1) = jitterPoint(action.x1, action.y1, action.randomOffsetPx)
                val (jx2, jy2) = jitterPoint(action.x2, action.y2, action.randomOffsetPx)
                dispatchSwipe(jx1, jy1, jx2, jy2, action.durationMs, action.holdStartMs, action.holdEndMs)
                Thread.sleep(action.holdStartMs + action.durationMs + action.holdEndMs + action.postDelayMs)
            }
            is Action.MultiPointSwipe -> {
                dispatchMultiPointSwipe(action)
                val move = (0 until (action.points.size - 1).coerceAtLeast(0)).sumOf { i ->
                    val a = action.points[i]; val b = action.points[i + 1]
                    segDurationFor(a.x, a.y, b.x, b.y, a.speed, action.segmentDurationMs)
                }
                val total = action.points.sumOf { it.holdMs } + move
                Thread.sleep(total + action.postDelayMs)
            }
            is Action.MultiFingerSwipe -> {
                dispatchMultiFingerSwipe(action)
                val longestPathMs = action.paths.maxOfOrNull { pts ->
                    val move = (0 until (pts.size - 1).coerceAtLeast(0)).sumOf { i ->
                        segDurationFor(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, pts[i].speed, action.segmentDurationMs)
                    }
                    pts.sumOf { it.holdMs } + move
                } ?: 0L
                Thread.sleep(longestPathMs + action.postDelayMs)
            }
            is Action.Wait -> Thread.sleep(action.ms) // basit sürüm; büyük projede coroutine delay tercih edilmeli
            is Action.Sequence -> action.steps.forEach { execute(it) }
            is Action.SetVariable -> when (action.mode) {
                "SET" -> com.bigboss.app.engine.VariableStore.set(action.name, action.delta)
                else -> com.bigboss.app.engine.VariableStore.increment(action.name, action.delta)
            }
            is Action.CallFunction -> { /* RuleEngine bunu kendisi yönetir, buraya gelmemeli */ }
            is Action.ReadTextToVariable -> { /* RuleEngine bunu frame ile kendisi çözer (resolveAndExecute), buraya gelmemeli */ }
            is Action.RunScript -> {
                if (action.language == "EMSCRIPT") {
                    val host = com.bigboss.app.engine.ScriptRuntime.emHost
                    if (host != null) {
                        val err = com.bigboss.app.emscript.EmScriptRunner.run(action.code, host)
                        if (err != null) android.util.Log.w("BigBossEMScript", err)
                    }
                } else {
                    com.bigboss.app.engine.ScriptRuntime.engine?.run(action.code)
                }
            }
            is Action.SystemAction -> {
                val globalAction = when (action.type) {
                    "BACK" -> GLOBAL_ACTION_BACK
                    "HOME" -> GLOBAL_ACTION_HOME
                    "RECENTS" -> GLOBAL_ACTION_RECENTS
                    "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
                    "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
                    else -> null
                }
                if (globalAction != null) performGlobalAction(globalAction)
            }
            Action.NoOp -> { /* hiçbir şey yapma */ }
        }
    }

    private fun dispatchTap(x: Int, y: Int, holdMs: Long = 50) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceAtLeast(1))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, null, null)
        if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("dispatchGesture REDDETTİ (Tap $x,$y) — sistem meşgul/hazır değil olabilir")
    }

    // Sıralı jest zinciri için tek adım: bir path + o path'in süresi.
    private data class StrokeStep(val path: Path, val duration: Long)

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long, holdStartMs: Long = 0, holdEndMs: Long = 0) {
        // Basit durum: hiç HOLD yoksa, TEK stroke'luk tek jest (hafif ve güvenilir).
        if (holdStartMs <= 0 && holdEndMs <= 0) {
            val path = linePath(x1, y1, x2, y2)
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
            val accepted = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("dispatchGesture REDDETTİ (Swipe basit $x1,$y1→$x2,$y2) — sistem meşgul/hazır değil olabilir")
            return
        }
        // HOLD var: başlangıçta bekle -> hareket -> bitişte bekle.
        // KRİTİK: Android'de continueStroke, aynı GestureDescription İÇİNDE stroke zincirlemek İÇİN
        // DEĞİLDİR; bir stroke'u AYRI (sonraki) bir jestte DEVAM ettirmek içindir. Bu yüzden her
        // adım ayrı bir jest olarak, bir önceki jestin onCompleted'ında zincirleniyor.
        val steps = mutableListOf<StrokeStep>()
        if (holdStartMs > 0) steps.add(StrokeStep(pointPath(x1, y1), holdStartMs))
        steps.add(StrokeStep(linePath(x1, y1, x2, y2), durationMs))
        if (holdEndMs > 0) steps.add(StrokeStep(pointPath(x2, y2), holdEndMs))
        dispatchStrokeSequence(steps, "Swipe+Hold ($x1,$y1→$x2,$y2 holdStart=$holdStartMs holdEnd=$holdEndMs)")
    }

    /**
     * Macrorify'daki "Swipe Path": TEK PARMAKLA art arda N noktadan geçen kaydırma.
     * HOLD yoksa TEK sürekli path (tek stroke, tek jest). HOLD varsa continueStroke zinciriyle
     * AYRI jestlere bölünür (her noktada durup bekleyip devam eder).
     */
    private fun dispatchMultiPointSwipe(action: Action.MultiPointSwipe) {
        val jit = action.points.map { Triple(jitterPoint(it.x, it.y, action.randomOffsetPx), it.holdMs, it.speed) }
        if (jit.size < 2) return
        // Her segmentin süresi KAYNAK noktanın speed'inden (piksel/12ms) hesaplanır — Macrorify'daki
        // "Speed" preseti artık GERÇEKTEN yürütmeyi etkiliyor (eskiden sabit segmentDurationMs kullanılıyordu).
        val segDurs = (0 until jit.size - 1).map { i ->
            val a = jit[i].first; val b = jit[i + 1].first
            segDurationFor(a.first, a.second, b.first, b.second, jit[i].third, action.segmentDurationMs)
        }
        val hasHold = jit.any { it.second > 0 }
        // Hold yok VE tüm segmentler aynı süre → tek sürekli stroke (en güvenilir yol).
        if (!hasHold && segDurs.distinct().size <= 1) {
            val stroke = continuousStrokeTotal(jit.map { it.first }, segDurs.sum()) ?: return
            val accepted = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("dispatchGesture REDDETTİ (MultiPointSwipe, ${jit.size} nokta) — sistem meşgul/hazır değil olabilir")
            return
        }
        // Hız değişken veya hold var → adım adım, her segment KENDİ süresiyle (continueStroke zinciri).
        val steps = mutableListOf<StrokeStep>()
        if (jit[0].second > 0) steps.add(StrokeStep(pointPath(jit[0].first.first, jit[0].first.second), jit[0].second))
        for (i in 1 until jit.size) {
            val prev = jit[i - 1].first; val cur = jit[i].first
            steps.add(StrokeStep(linePath(prev.first, prev.second, cur.first, cur.second), segDurs[i - 1]))
            if (jit[i].second > 0) steps.add(StrokeStep(pointPath(cur.first, cur.second), jit[i].second))
        }
        dispatchStrokeSequence(steps, "MultiPointSwipe (${jit.size} nokta, hız-duyarlı)")
    }

    /**
     * GERÇEK çoklu parmak (pinch/zoom): her parmak yolu AYRI bir sürekli stroke olur ve hepsi
     * TEK GestureDescription'a eklenir (eşzamanlı). NOT: çoklu-parmak yollarında nokta-başına HOLD
     * şu an desteklenmez (yalnız sürekli hareket) — pinch/zoom için gerekmez.
     */
    private fun dispatchMultiFingerSwipe(action: Action.MultiFingerSwipe) {
        val builder = GestureDescription.Builder()
        var anyStroke = false
        action.paths.forEach { pathPoints ->
            val pts = pathPoints.map { jitterPoint(it.x, it.y, action.randomOffsetPx) }
            if (pts.size >= 2) {
                // Parmak başına toplam süre, o parmağın noktalarının speed'lerinden toplanır (eşzamanlılık için tek stroke).
                val total = (0 until pts.size - 1).sumOf { i ->
                    segDurationFor(pts[i].first, pts[i].second, pts[i + 1].first, pts[i + 1].second, pathPoints[i].speed, action.segmentDurationMs)
                }
                val stroke = continuousStrokeTotal(pts, total)
                if (stroke != null) { builder.addStroke(stroke); anyStroke = true }
            }
        }
        if (anyStroke) {
            val accepted = dispatchGesture(builder.build(), null, null)
            if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("dispatchGesture REDDETTİ (MultiFingerSwipe, ${action.paths.size} parmak) — sistem meşgul/hazır değil olabilir")
        }
    }

    // ---- Ortak jest yardımcıları ----

    /** Tek noktada sabit (hold / long-press) path. */
    private fun pointPath(x: Int, y: Int): Path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }

    /** İki nokta arası düz çizgi path. */
    private fun linePath(x1: Int, y1: Int, x2: Int, y2: Int): Path =
        Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }

    /** N noktadan geçen TEK sürekli path'i tek bir stroke'a çevirir (HOLD yok). */
    private fun continuousStroke(points: List<Pair<Int, Int>>, segmentDurationMs: Long): GestureDescription.StrokeDescription? {
        if (points.isEmpty()) return null
        val path = Path().apply {
            moveTo(points[0].first.toFloat(), points[0].second.toFloat())
            for (i in 1 until points.size) lineTo(points[i].first.toFloat(), points[i].second.toFloat())
        }
        val total = ((points.size - 1).coerceAtLeast(1)) * segmentDurationMs
        return GestureDescription.StrokeDescription(path, 0, total.coerceAtLeast(1))
    }

    /** Verilen TOPLAM süreyle N noktadan geçen tek sürekli stroke (segment-başı değil, tek süre). */
    private fun continuousStrokeTotal(points: List<Pair<Int, Int>>, totalMs: Long): GestureDescription.StrokeDescription? {
        if (points.isEmpty()) return null
        val path = Path().apply {
            moveTo(points[0].first.toFloat(), points[0].second.toFloat())
            for (i in 1 until points.size) lineTo(points[i].first.toFloat(), points[i].second.toFloat())
        }
        return GestureDescription.StrokeDescription(path, 0, totalMs.coerceAtLeast(1))
    }

    /** Bir segmentin süresi: speed>0 ise mesafe/hız (piksel/12ms) formülünden, değilse fallback (ms). */
    private fun segDurationFor(x1: Int, y1: Int, x2: Int, y2: Int, speed: Int, fallbackMs: Long): Long {
        if (speed <= 0) return fallbackMs.coerceAtLeast(1)
        val dist = Math.hypot((x2 - x1).toDouble(), (y2 - y1).toDouble())
        return ((dist / speed) * 12.0).toLong().coerceIn(1L, 8000L)
    }

    /** HOLD'lu N noktalı yolu adım adım (hareket + o noktada bekleme) böler. */
    private fun stepsForHeldPath(pts: List<Pair<Pair<Int, Int>, Long>>, segmentDurationMs: Long): List<StrokeStep> {
        val steps = mutableListOf<StrokeStep>()
        val (p0, h0) = pts[0]
        if (h0 > 0) steps.add(StrokeStep(pointPath(p0.first, p0.second), h0))
        for (i in 1 until pts.size) {
            val prev = pts[i - 1].first
            val (cur, hold) = pts[i]
            steps.add(StrokeStep(linePath(prev.first, prev.second, cur.first, cur.second), segmentDurationMs))
            if (hold > 0) steps.add(StrokeStep(pointPath(cur.first, cur.second), hold))
        }
        return steps
    }

    /**
     * Adımları SIRAYLA gönderir: her adım bir öncekinin continueStroke DEVAMIDIR ve AYRI bir jest
     * olarak, önceki jestin onCompleted'ında tetiklenir (Android'in continueStroke için ZORUNLU
     * kıldığı "sonraki jestte devam" kuralı). Ateşle-unut: yürütücü toplam süreyi ayrıca uyur.
     */
    private fun canContinueStroke(): Boolean = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O

    private fun dispatchStrokeSequence(steps: List<StrokeStep>, label: String) {
        if (steps.isEmpty()) return

        // Android 7.0/7.1 (API 24-25) StrokeDescription/continueStroke zincirlemeyi desteklemez.
        // Her adımı AYRI bir jest olarak göndeririz; parmak arada kalksa da yolun tamamı en azından çalışır.
        if (!canContinueStroke()) {
            var index = 0
            fun next() {
                if (index >= steps.size) return
                val s = steps[index++]
                val dur = s.duration.coerceAtLeast(1)
                val stroke = GestureDescription.StrokeDescription(s.path, 0, dur)
                val cb = object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) { next() }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        com.bigboss.app.engine.ActionResultRegistry.recordActionError("$label — jest iptal edildi (Nougat adım ${index}/${steps.size})")
                    }
                }
                val accepted = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), cb, null)
                if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("$label — dispatchGesture reddetti (Nougat adım ${index}/${steps.size})")
            }
            next()
            return
        }

        fun step(i: Int, prev: GestureDescription.StrokeDescription?) {
            val willContinue = i < steps.size - 1
            val dur = steps[i].duration.coerceAtLeast(1)
            val stroke = prev?.continueStroke(steps[i].path, 0, dur, willContinue)
                ?: GestureDescription.StrokeDescription(steps[i].path, 0, dur, willContinue)
            val cb = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { if (willContinue) step(i + 1, stroke) }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    com.bigboss.app.engine.ActionResultRegistry.recordActionError("$label — jest iptal edildi (adım ${i + 1}/${steps.size})")
                }
            }
            val accepted = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), cb, null)
            if (!accepted) com.bigboss.app.engine.ActionResultRegistry.recordActionError("$label — dispatchGesture reddetti (adım ${i + 1}/${steps.size})")
        }
        step(0, null)
    }
}
