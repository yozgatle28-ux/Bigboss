package com.bigboss.app.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.databinding.ActivityPlayModeBinding
import com.bigboss.app.engine.RuleEngine
import com.bigboss.app.service.BigBossAccessibilityService
import com.bigboss.app.service.OverlayService
import com.bigboss.app.service.ScreenCaptureService
import com.bigboss.app.storage.FunctionStorage
import com.bigboss.app.storage.RuleDefinitionMapper
import com.bigboss.app.storage.RuleStorage

/**
 * PLAY MODE: sistemin GERÇEKTEN çalıştığı, hiçbir düzenleme/müdahale
 * imkanı olmayan ekran. Açılır açılmaz izin ister, botu çalışır hâlde
 * (paused = false) başlatır. Tek kontrol: durdurma.
 */
class PlayModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayModeBinding
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MediaProjectionManager::class.java)
        binding.btnStopPlay.setOnClickListener { stopAndReturn() }

        if (BigBossAccessibilityService.instance == null) {
            binding.tvPlayStatus.text = "⚠️ Erişilebilirlik servisi kapalı!\nAyarlar > Erişilebilirlik'ten BigBoss'u aç."
            return
        }

        if (ScreenCaptureService.ruleEngine != null && ScreenCaptureService.latestFrame != null) {
            // Zaten çalışıyor olabilir (örn. Edit Mode'dan geçiş) — motoru unpause et, overlay'i PLAY moduna al.
            startEngineUnpaused()
            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "PLAY")
            })
            finish()
        } else {
            requestScreenCapturePermission()
        }
    }

    private fun requestScreenCapturePermission() {
        binding.tvPlayStatus.text = "Ekran kaydı izni isteniyor..."
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_CODE_CAPTURE)
    }

    @Deprecated("Basitlik için kullanıldı.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && data != null) {
            val executor = BigBossAccessibilityService.instance
            if (executor == null) {
                binding.tvPlayStatus.text = "⚠️ Erişilebilirlik servisi kapalı!"
                return
            }
            // ÖNEMLİ: RuleEngine'e SABİT bir instance değil, her execute() çağrısında
            // GÜNCEL BigBossAccessibilityService.instance'a bakan bir sarmalayıcı veriyoruz —
            // servis herhangi bir sebeple yeniden bağlanırsa bile komutlar çalışmaya devam etsin.
            val liveExecutor = object : com.bigboss.app.engine.ActionExecutor {
                override fun execute(action: com.bigboss.app.engine.Action) {
                    BigBossAccessibilityService.instance?.execute(action)
                }
            }
            val ruleEngine = RuleEngine(liveExecutor)
            ruleEngine.setRules(com.bigboss.app.storage.EngineAssembler.buildRules(this))
            ruleEngine.setFunctionsProvider(com.bigboss.app.storage.EngineAssembler.buildFunctionsProvider(this))
            ScreenCaptureService.ruleEngine = ruleEngine

            com.bigboss.app.engine.ScriptRuntime.engine = com.bigboss.app.engine.ScriptEngine(
                executor = liveExecutor,
                frameProvider = { ScreenCaptureService.latestFrame },
                functionByName = { name ->
                    FunctionStorage.load(this).find { it.name == name }
                        ?.let { RuleDefinitionMapper.toRules(it.rules) } ?: emptyList()
                },
                runRuleList = { rulesToRun, frame -> ruleEngine.evaluateRulesOnce(rulesToRun, frame) },
                pausedProvider = { ruleEngine.paused },
                libraryLookup = { name -> com.bigboss.app.storage.LibraryStorage.load(this).find { it.name == name }?.templatePath },
                scriptLookup = { name -> com.bigboss.app.storage.ScriptStorage.load(this).find { it.name == name }?.code }
            )

            // EMScript host köprüsü — aynı motor bileşenlerini kullanır.
            com.bigboss.app.engine.ScriptRuntime.emHost = com.bigboss.app.service.AndroidEmHost(
                executor = liveExecutor,
                frameProvider = { ScreenCaptureService.latestFrame },
                libraryLookup = { name -> com.bigboss.app.storage.LibraryStorage.load(this).find { it.name == name }?.templatePath },
                pausedProvider = { ruleEngine.paused },
                logSink = { msg -> android.util.Log.i("BigBossEMScript", msg) },
                settingGet = { key -> com.bigboss.app.engine.VariableStore.getString(key) }
            )

            // BİRLEŞİK DEĞİŞKEN SİSTEMİ: kalıcı değişkenleri yükle + setVar'ı diske yaz + Reference çöz.
            com.bigboss.app.storage.EngineAssembler.setupVariableStore(this) { com.bigboss.app.engine.ScriptRuntime.engine }

            startService(Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_MODE, "PLAY")
            })
            val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(captureIntent)
            startEngineUnpaused()
            // Kritik: hemen kapanıyoruz — kullanıcı istediği uygulamaya geçebilir.
            finish()
        } else if (requestCode == REQUEST_CODE_CAPTURE) {
            binding.tvPlayStatus.text = "İzin verilmedi, PLAY MODE başlatılamadı."
        }
    }

    private fun startEngineUnpaused() {
        ScreenCaptureService.ruleEngine?.paused = false
        binding.tvPlayStatus.text = "▶️ ÇALIŞIYOR — sisteme müdahale kapalı"
    }

    private fun stopAndReturn() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        finish()
    }

    companion object {
        private const val REQUEST_CODE_CAPTURE = 51
    }
}
