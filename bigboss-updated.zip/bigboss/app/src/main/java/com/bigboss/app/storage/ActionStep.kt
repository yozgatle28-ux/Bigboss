package com.bigboss.app.storage

/**
 * "BAŞARILI OLUNCA" / "BULUNAMAZSA" sekmelerinde eklenen SIRALI
 * adımlardan biri. Bir RuleDefinition'ın `extraSteps` listesi, bu
 * adımların sırayla (tek seferde, art arda) çalıştırılmasını temsil eder.
 */
data class ActionStep(
    /** "TAP" | "SWIPE" | "WAIT" | "CALL_FUNCTION" | "SET_VARIABLE" | "RUN_SCRIPT" | "PLAY_RECORD" */
    var type: String,
    var x: Int = 0,
    var y: Int = 0,
    var x2: Int = 0,
    var y2: Int = 0,
    var waitMs: Long = 500,
    var repeat: Int = 1,
    var functionId: String? = null,
    /** "PLAY_RECORD" için: RecordStorage'daki hangi kaydın oynatılacağı. */
    var recordId: String? = null,
    var variableName: String = "",
    var variableDelta: Int = 1,
    var scriptId: String? = null,
    var scriptCode: String? = null,
    /** RUN_SCRIPT için dil: "EMSCRIPT" (tek motor). Eski kayıtlarda "JS" görülebilir (geriye dönük uyumluluk). */
    var scriptLanguage: String = "EMSCRIPT",
    /** TAP için: noktada kaç ms basılı tutulsun. */
    var holdMs: Long = 50,
    /** SWIPE için: başlangıç/bitiş noktalarında basılı bekleme (sürükle-bırak gibi jestler için). */
    var swipeHoldStartMs: Long = 0,
    var swipeHoldEndMs: Long = 0,
    /**
     * KÖK NEDEN DÜZELTMESİ (14 Temmuz — "swipe farklı pencerelerde farklı çalışıyor" raporu):
     * On Success/On Fail'deki ExtraAction editörü (showExtraSwipeEditor) bir hız presetinden
     * swipeDurationMs HESAPLIYORDU ama bu alan ActionStep'te HİÇ YOKTU — extraActionToStep bunu
     * sessizce ATIYORDU ve RuleDefinitionMapper.toActionStep süreyi HER ZAMAN sabit 300ms
     * kullanıyordu. Ana Akış'taki swipe ise kullanıcının ayarladığı gerçek süreyi kullanıyordu —
     * bu yüzden "aynı swipe aracı" pencereye göre FARKLI hızda/algoritmada çalışıyormuş gibi
     * görünüyordu. Artık bu alan taşınıyor ve toActionStep onu kullanıyor; tüm pencerelerdeki
     * basit (2 noktalı) swipe artık AYNI Action.Swipe çağrısını üretiyor.
     */
    var swipeDurationMs: Long = 300,
    /** İşlem tamamlandıktan sonra, sıradaki adıma geçmeden önce kaç ms beklensin. */
    var postDelayMs: Long = 0,
    /** "READ_TEXT" için: x,y,x2,y2 alanları BÖLGE (x,y,w,h) olarak kullanılır. Okunan metinden çıkarılan SAYI bulunamazsa bu kullanılır. */
    var readDefaultValue: Int = 0,
    var readWhitelist: String = "",
    var readBlacklist: String = ""
)
