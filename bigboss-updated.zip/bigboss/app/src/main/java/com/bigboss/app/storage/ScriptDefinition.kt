package com.bigboss.app.storage

/**
 * BigBoss'un kendi EMScript yorumlayıcısıyla çalışan kod parçası. Değişken,
 * if/else, döngü, fonksiyon — hepsi EMScript söz dizimiyle yazılabilir.
 * BigBoss'a özel köprü fonksiyonları (tap, swipe, findColor, vb.) için
 * README'deki "Kod Sistemi (Script)" bölümüne bak.
 *
 * KULLANICI İSTEĞİ (14 Temmuz): JavaScript (Rhino) motoru seçeneği arayüzden
 * kaldırıldı — sistem artık HER YERDE otomatik olarak EMScript kullanıyor.
 * `language` alanı SADECE geriye dönük uyumluluk için duruyor: daha önce "JS"
 * olarak kaydedilmiş eski scriptler hâlâ kendi motorlarıyla çalışmaya devam
 * eder (bkz. BigBossAccessibilityService.execute Action.RunScript), ama YENİ
 * hiçbir yerden "JS" seçilemez/kaydedilemez.
 */
data class ScriptDefinition(
    val id: String,
    var name: String,
    var code: String = "// Örnek:\nlog(\"Merhaba BigBoss\")\n",
    /** "EMSCRIPT" (tek motor). Eski kayıtlarda "JS" görülebilir (geriye dönük uyumluluk). */
    var language: String = "EMSCRIPT"
)
