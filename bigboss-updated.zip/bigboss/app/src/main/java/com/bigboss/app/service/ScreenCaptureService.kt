package com.bigboss.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import com.bigboss.app.R
import com.bigboss.app.engine.RuleEngine

/**
 * Ekranı periyodik olarak yakalayıp RuleEngine.onFrame(...) çağıran
 * ön plan (foreground) servisi. MediaProjection, kullanıcının bir kez
 * elle onayladığı resmi Android ekran kaydı iznini kullanır.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "bigboss_capture_channel"
        const val NOTIF_ID = 1001
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        // Basit bir singleton erişim; ileride dependency injection ile değiştirilebilir.
        var ruleEngine: RuleEngine? = null

        // Kural editörünün "donmuş ekran" olarak göstereceği en son frame.
        @Volatile var latestFrame: Bitmap? = null

        // HER yeni kare geldiğinde artan zaman damgası — overlay katmanı (kendi çerçevesini
        // gizleyip "kirlenmemiş" bir kare beklerken) "benim gizleme işlemimden SONRA yakalanan
        // bir kare geldi mi?" sorusunu buna bakarak cevaplar (bkz. captureCleanRegionCrop).
        @Volatile var frameTimestamp: Long = 0L
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var engineLoopThread: Thread? = null
    @Volatile private var engineLoopRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            startCapture(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, resultData)

        // Ekran çözünürlüğü, cihaz kaynaklarından alınır.
        val metrics: DisplayMetrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        // Görüntü YAKALAMA thread'i — SADECE bitmap üretir, başka hiçbir şey yapmaz.
        // ÖNEMLİ: kural değerlendirmesi/aksiyon çalıştırma BURADA YAPILMAZ — eskiden
        // burada yapılıyordu ve bir aksiyonun HOLD/DELAY'i (Thread.sleep) bu thread'i
        // kilitleyip YENİ GÖRÜNTÜ GELMESİNİ durduruyordu. "Tarama süresi 0 olsa bile
        // yavaş" şikayetinin gerçek sebebi buydu.
        val bgThread = android.os.HandlerThread("BigBossCaptureThread").apply { start() }
        val bgHandler = android.os.Handler(bgThread.looper)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "BigBossCapture",
            width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                latestFrame = imageToBitmap(image, width, height)
                frameTimestamp = System.currentTimeMillis()
            } finally {
                image.close()
            }
        }, bgHandler)

        startEngineLoop()
    }

    /**
     * Kural değerlendirme (ve aksiyon çalıştırma) için TAMAMEN AYRI, bağımsız bir
     * döngü thread'i. Her turda o an mevcut olan EN GÜNCEL görüntüyü işler.
     * Bir aksiyon HOLD/DELAY ile ne kadar beklerse beklesin, bu SADECE bir sonraki
     * DEĞERLENDİRME turunu geciktirir — ekran YAKALAMAYI asla durdurmaz. Bu sayede
     * "Bekleme süresi 0" gerçekten "art arda, mümkün olan en hızlı tarama" anlamına
     * geliyor artık.
     */
    private fun startEngineLoop() {
        engineLoopRunning = true
        engineLoopThread = Thread {
            while (engineLoopRunning) {
                val frame = latestFrame
                if (frame != null) {
                    try {
                        ruleEngine?.onFrame(frame)
                    } catch (e: Exception) {
                        // Bir kuralın hata vermesi tüm döngüyü durdurmasın.
                    }
                } else {
                    Thread.sleep(30)
                }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun imageToBitmap(image: android.media.Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        // ImageReader satırları hizalama (stride) İÇİN genelde gerçek genişlikten DAHA GENİŞ
        // ayrılmış olabilir — bu fazladan sütunlar TANIMSIZ/ÇÖP piksel içerir. Önceden bu ÇÖP
        // sütunlu geniş bitmap doğrudan `latestFrame` olarak paylaşılıyordu; ekranın sağ kenarına
        // yakın herhangi bir kırpma (kütüphaneye kaydetme dahil) bu çöp sütunları YAKALAYABİLİRDİ.
        // KÖK NEDEN DÜZELTMESİ: dolgu payı varsa, gerçek `width x height` alana HEMEN kırpıp o
        // padded ara bitmap'i geri dönmeden ÖNCE at — böylece uygulamanın GERİ KALANI (kırpma,
        // önizleme, kural motoru) HER ZAMAN tam olarak ekranla birebir eşleşen, çöpsüz bir kare görür.
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        if (paddedWidth == width) return padded
        val trimmed = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return trimmed
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "BigBoss Ekran Yakalama", NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BigBoss çalışıyor")
            .setContentText("Ekran izleniyor ve kurallar uygulanıyor")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()
    }

    override fun onDestroy() {
        engineLoopRunning = false
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        // HATA DÜZELTMESİ: son yakalanan büyük ekran bitmap'ine olan STATİK referansı bırak. Aksi halde
        // servis durduktan sonra bile bir tam ekran bitmap'i bellekte asılı kalıyordu (statik sızıntı).
        latestFrame = null
        super.onDestroy()
    }
}
