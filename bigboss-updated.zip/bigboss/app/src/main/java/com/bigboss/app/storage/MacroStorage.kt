package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * Tüm macro'ların ÜST BİLGİ listesini (macros.json) ve o an AKTİF olan macro'nun
 * id'sini (active_macro.txt) saklar. Aktif macro, Edit/Play Mode'un hangi macro
 * üzerinde çalıştığını belirler.
 */
object MacroStorage {

    private const val FILE_NAME = "macros.json"
    private const val ACTIVE_FILE = "active_macro.txt"
    private val gson = Gson()

    fun load(context: Context): MutableList<MacroDefinition> {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<MacroDefinition>>() {}.type
            gson.fromJson(file.readText(), type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, macros: List<MacroDefinition>) {
        File(context.filesDir, FILE_NAME).writeText(gson.toJson(macros))
    }

    fun upsert(context: Context, macro: MacroDefinition) {
        val macros = load(context)
        val idx = macros.indexOfFirst { it.id == macro.id }
        if (idx >= 0) macros[idx] = macro else macros.add(macro)
        save(context, macros)
    }

    fun find(context: Context, id: String): MacroDefinition? = load(context).find { it.id == id }

    /**
     * Bir macro'yu ve ONA AİT TÜM verileri (kurallar, fonksiyonlar, scriptler, kütüphane,
     * değişkenler, ayarlar, action grupları) siler.
     */
    fun delete(context: Context, id: String) {
        val macros = load(context)
        macros.removeAll { it.id == id }
        save(context, macros)
        // O macro'ya ait tüm namespace'li dosyaları temizle.
        MacroScope.deleteAllFor(context, id)
        // Silinen aktif macro ise aktifi değiştir.
        if (getActiveId(context) == id) {
            setActiveId(context, macros.firstOrNull()?.id ?: "")
        }
    }

    // ---- Aktif macro ----
    fun getActiveId(context: Context): String {
        val f = File(context.filesDir, ACTIVE_FILE)
        return if (f.exists()) f.readText().trim() else ""
    }

    fun setActiveId(context: Context, id: String) {
        File(context.filesDir, ACTIVE_FILE).writeText(id)
    }

    fun getActive(context: Context): MacroDefinition? {
        val id = getActiveId(context)
        if (id.isBlank()) return null
        return find(context, id)
    }

    /**
     * İlk açılış / eski sürümden geçiş. Hiç macro yoksa bir tane oluşturur ve
     * ESKİ tek-macro verisini (namespace'siz rules.json vb.) yeni macro'nun
     * namespace'ine taşır. Böylece güncelleme sonrası kullanıcı verisini kaybetmez.
     */
    fun ensureAtLeastOne(context: Context) {
        val macros = load(context)
        if (macros.isNotEmpty()) return

        val macro = MacroDefinition(java.util.UUID.randomUUID().toString(), "BigBoss")
        upsert(context, macro)
        setActiveId(context, macro.id)

        // Eski namespace'siz dosyaları bu macro'nun namespace'ine taşı (varsa).
        val legacyNames = listOf(
            "rules.json", "functions.json", "scripts.json", "settings.json",
            "library.json", "global_variables.json", "action_groups.json"
        )
        legacyNames.forEach { base ->
            val legacy = File(context.filesDir, base)
            if (legacy.exists()) {
                val dest = MacroScope.fileFor(context, macro.id, base)
                try { legacy.copyTo(dest, overwrite = true); legacy.delete() } catch (e: Exception) { /* yoksay */ }
            }
        }
    }
}

/**
 * Macro'ya göre AYRILMIŞ dosya yolları üretir. Her storage sınıfı artık
 * File(filesDir, FILE_NAME) yerine MacroScope.file(context, FILE_NAME) kullanır.
 * Böylece "rules.json" -> "m_<aktifMacroId>_rules.json" olur ve her macro'nun
 * kendi verisi izole kalır.
 *
 * Aktif macro yoksa (henüz hiç macro oluşturulmadıysa) "default" namespace'i
 * kullanılır — böylece eski tek-macro verisi kaybolmaz ve uygulama çökmeden çalışır.
 */
object MacroScope {

    private const val PREFIX = "m_"

    /** Aktif macro id (yoksa "default"). */
    private fun activeId(context: Context): String {
        val id = MacroStorage.getActiveId(context)
        return if (id.isBlank()) "default" else id
    }

    /** Namespace'li dosya. baseName örn "rules.json" -> "m_<id>_rules.json". */
    fun file(context: Context, baseName: String): File =
        File(context.filesDir, "$PREFIX${activeId(context)}_$baseName")

    /** Belirli bir macroId için namespace'li dosya (aktiften bağımsız). */
    fun fileFor(context: Context, macroId: String, baseName: String): File =
        File(context.filesDir, "$PREFIX${macroId}_$baseName")

    /** Bir macroId'ye ait TÜM namespace'li dosyaları siler (macro silinince). */
    fun deleteAllFor(context: Context, macroId: String) {
        val dir = context.filesDir
        val marker = "$PREFIX${macroId}_"
        dir.listFiles()?.forEach { f ->
            if (f.name.startsWith(marker)) f.delete()
        }
    }
}
