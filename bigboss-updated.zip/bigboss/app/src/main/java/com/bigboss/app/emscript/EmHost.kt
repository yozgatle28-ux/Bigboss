package com.bigboss.app.emscript

/**
 * Çoklu-nokta kaydırma için tek nokta: koordinat, noktadaki bekleme (ms) ve sonraki
 * segmente olan hız (piksel/12ms). Macrorify SwipePoint ile aynı semantik.
 */
data class SwipePathPoint(
    val x: Int,
    val y: Int,
    val holdMs: Long = 0,
    val speed: Int = 20
)

/**
 * EMScript host köprüsü — dil çekirdeğini gerçek cihaz işlemlerine bağlar.
 * SAF KOTLIN: Android tipleri (Bitmap, View) burada YOK, sadece soyut işlemler.
 * Android tarafı (AndroidEmHost) bunu gerçek motora (ActionExecutor, ImageMatcher,
 * ScreenCaptureService) bağlar. Test tarafı MockHost ile aynı arayüzü kullanır.
 *
 * Koordinatlar cihaz pikselidir. Tespit metotları timeout içinde döner.
 */
interface EmHost {
    /** Konsola/log'a yaz (Con.out). */
    fun log(message: String)

    /** Kullanıcıdan girdi al (Con.in). Desteklenmiyorsa boş string. */
    fun input(): String = ""

    /** Cihaz genişliği (piksel). */
    fun deviceWidth(): Int
    /** Cihaz yüksekliği (piksel). */
    fun deviceHeight(): Int

    /** Bir noktaya dokun (repeat kez, holdMs basılı). Edit Mode'da simüle edilmeyebilir. */
    fun tap(x: Int, y: Int, repeat: Int = 1, holdMs: Long = 50)

    /** İki nokta arası kaydır. */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 300)

    /** Çoklu-nokta kaydırma (parmak yerden kalkmadan tüm noktalardan geç). */
    fun swipePath(points: List<SwipePathPoint>, durationEachMs: Long = 300)

    /** Sistem eylemi: "BACK" | "HOME" | "RECENTS" | "NOTIFICATIONS" | "QUICK_SETTINGS". */
    fun system(action: String)

    /** Bir süre bekle (ms). */
    fun sleep(ms: Long)

    /**
     * Bir bölgede şablon görsel ara. timeout içinde tekrar dener.
     * Bulunursa MatchData, bulunamazsa null.
     * imageName: kütüphanedeki görsel adı (host çözer).
     */
    fun findImage(x: Int, y: Int, w: Int, h: Int, imageName: String, minScore: Float, timeoutMs: Long): MatchData?

    /**
     * Bir bölgede metin (OCR) ara. timeout içinde tekrar dener.
     * Bulunursa MatchData, bulunamazsa null.
     */
    fun findText(x: Int, y: Int, w: Int, h: Int, text: String, minScore: Float, timeoutMs: Long): MatchData?

    /** Bir bölgedeki metni oku (OCR). Bulunamazsa defaultValue. */
    fun readText(x: Int, y: Int, w: Int, h: Int, defaultValue: String): String

    /** Bir noktadaki rengi #RRGGBB olarak döndür. Frame yoksa "#000000". */
    fun colorAt(x: Int, y: Int): String

    /**
     * Bir bölgede belirli bir rengin olup olmadığını kontrol et (minScore eşleşme oranı).
     */
    fun findColor(x: Int, y: Int, w: Int, h: Int, colorHex: String, minScore: Float): Boolean

    /** true iken (Edit Mode) gerçek dokunuş simüle edilmez — script güvenliği. */
    fun isPaused(): Boolean = false

    /** Özel ayar diyaloğunu göster (Setting.show). Gösterildiyse true. */
    fun showSetting(): Boolean = false
    /** Bir ayar key'inin güncel değerini döndür (Setting.get). */
    fun getSetting(key: String): String = ""

    /**
     * Programatik ayar diyaloğunu göster (SettingBuilder.build().show()). Kullanıcı Kaydet'e
     * basarsa true, İptal/desteklenmiyorsa false. preview=true ise değerler yazılmaz (Dialog.preview()).
     */
    fun showSettingDialog(spec: EmSettingSpec, preview: Boolean = false): Boolean = false
    /** Bir ayar değerini (aynı isimli değişkeni) ayarla (Setting.set). */
    fun setSetting(key: String, value: String) {}
}

/**
 * Bir find/click operasyonunun sonucu (Macrorify Match). Host'tan bağımsız veri.
 * x,y = eşleşmenin orta noktası; region = eşleşme dikdörtgeni; score = skor 0..1.
 */
data class MatchData(
    val x: Int,
    val y: Int,
    val regionX: Int,
    val regionY: Int,
    val regionW: Int,
    val regionH: Int,
    val score: Double
)

/**
 * Programatik Setting/Dialog (SettingBuilder) için saf-Kotlin spec — Android tipleri içermez.
 * Android tarafı (AndroidEmHost/OverlayService) bunu SettingDefinition'a çevirip gerçek diyaloğu render eder.
 */
/** TabLayout tek sekmesi (doküman: tab(label, visibleIds, hiddenIds)). */
data class EmSettingTab(
    val label: String = "",
    /** Bu sekme seçiliyken GÖSTERİLECEK view id'leri. */
    val visibleIds: List<String> = emptyList(),
    /** Bu sekmede GİZLENECEK view id'leri. null => diğer TÜM view'ları gizle. */
    val hiddenIds: List<String>? = null
)

data class EmSettingViewSpec(
    /** "TEXTVIEW" | "EDITTEXT" | "CHECKBOX" | "RADIO" | "IMAGEPICKER" | "RECORDER" | "TABLAYOUT" */
    val type: String,
    val key: String = "",
    val label: String = "",
    val defaultValue: String = "",
    val hint: String = "",
    val helper: String = "",
    /** EditText giriş yöntemi: "TEXT" | "NUMBER" */
    val inputMethod: String = "TEXT",
    /** RADIO seçenek etiketleri. */
    val radioOptions: List<String> = emptyList(),
    /** Doküman view.id() — TabLayout visibleIds/hiddenIds bu id'leri hedefler. */
    val viewId: String = "",
    /** Sadece TABLAYOUT: id-tabanlı sekmeler. */
    val tabs: List<EmSettingTab> = emptyList(),
    val tabSelected: Int = 0,
    val tabSaveSelected: Boolean = false
)

data class EmSettingSpec(
    val title: String = "Ayarlar",
    val positiveText: String = "Kaydet",
    val negativeText: String = "İptal",
    val views: List<EmSettingViewSpec> = emptyList()
)
