package com.bigboss.app.engine

/**
 * Macrorify'ın GERÇEK mantığı: her Rule BAĞIMSIZDIR, aralarında sıra
 * YOKTUR. Koşul (condition) doğru olduğu her an, o an aksiyonu (action)
 * tetiklenir — "sıradaki kurala geçmek" diye bir şey yok. Görsel/renk
 * ekranda olduğu sürece tetiklenmeye devam eder, kaybolunca durur,
 * tekrar belirince tekrar tetiklenir.
 */
/**
 * KÖK NEDEN DÜZELTMESİ (kullanıcı raporu + Macrorify'ın resmi akış şeması/dokümantasyonu,
 * https://www.kok-emm.com/docs/image-detection/basic): motorun ESKİ tasarımı Macrorify'ın
 * GERÇEK "On Success / On Fail" mantığıyla UYUŞMUYORDU. Doğru mantık:
 *  1) Template, `Timeout` süresi BOYUNCA, `Scan Rate` hızında TEKRAR TEKRAR aranır.
 *  2) Bulunursa (herhangi bir taramada) → ANINDA "On Success" çalışır.
 *  3) Timeout dolana kadar HİÇ bulunamazsa → "On Fail" çalışır.
 *  4) `Loop` ayarına göre (None/Loop when success/Loop when fail/Loop always), On Success/
 *     On Fail SONRASI ya baştan (1)'e dönülür ya da kural tamamen durur.
 * Eskiden "On Fail" AYRI, TERS koşullu bir "gölge kural" olarak uygulanıyordu (Timeout'u HİÇ
 * beklemeden anında tetikleniyordu) — artık `onFailAction` BU kuralın bir PARÇASI.
 */
data class Rule(
    val id: String,
    val name: String,
    val condition: Condition,
    val thenAction: Action,
    /** Template bulunduğunda ("On Success") çalıştırılacak aksiyon dizisi zaten `thenAction`. */
    val onFailAction: Action? = null,
    /** "Wait Next": bu aksiyon tetiklendikten sonra tekrar tetiklenmeden önce en az kaç ms geçmeli. */
    val cooldownMs: Long = 100,
    val enabled: Boolean = true,
    /** true ise ters mantık: koşul KAYBOLUNCA (eşleşmeyince) tetiklenir ("Not Appear"). */
    val negate: Boolean = false,
    /** "NONE" | "ALWAYS" | "WHILE_SUCCESS" | "WHILE_FAIL" — Macrorify'daki "Loop": None/Loop
     *  when success/Loop when fail/Loop always ile BİREBİR karşılık gelir (bkz. RuleEngine). */
    val loopMode: String = "ALWAYS",
    /** Eşleşme bulunduktan SONRA, aksiyon çalışmadan önce beklenecek süre (ms). */
    val matchDelayMs: Long = 0,
    /**
     * Macrorify'daki "Timeout": Template'i aramak için MAKSİMUM süre (ms).
     *
     * TASARIM DÜZELTMESİ (kullanıcı onayıyla): "0 = sınırsız bekle, On Fail hiç tetiklenmesin"
     * eski davranışı, "On Fail çalışmıyor" şikayetini BAŞKA bir şekilde YENİDEN yaratıyordu —
     * kullanıcı On Fail adımları eklese bile Timeout girmeyi UNUTURSA hiç çalışmazlardı. Artık:
     *  - `scanTimeoutMs <= 0` (girilmemiş, VARSAYILAN): HER TARAMADA ANINDA karar verilir —
     *    bulundu → On Success, bulunamadı → On Fail, bekleme YOK.
     *  - `scanTimeoutMs > 0` (kullanıcı BİLİNÇLİ olarak girdiyse): bu süre BOYUNCA aramaya
     *    devam eder (Macrorify'ın "search until timeout" davranışı), süre dolup da
     *    bulunamazsa On Fail tetiklenir.
     */
    val scanTimeoutMs: Long = 0,
    /** Macrorify'daki "Scan Rate": bu kural saniyede en fazla kaç kere KONTROL edilsin (pil tasarrufu). 0 = sınırsız/en hızlı. */
    val scanRateHz: Float = 0f,
    /** "Otomatik Durdurma": art arda kaç BULUNAMADI'dan sonra bu kural kendini devre dışı bıraksın. 0 = sınırsız. */
    val maxConsecutiveFailures: Int = 0
)
