package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify'ın GERÇEK motor mantığı: PARALEL / REAKTİF, artık "Loop"
 * yaşam döngüsü de destekleniyor:
 *
 *  - NONE: kural bir kere denenir (başarılı olsun olmasın), sonra
 *    kendini devre dışı bırakır ("tarar ve durur").
 *  - ALWAYS: normal sürekli davranış — sonsuz döngü, hiç durmaz.
 *  - WHILE_SUCCESS: koşul doğru olana kadar bekler, doğru olunca BİR
 *    KERE tetiklenir ve kendini durdurur.
 *  - WHILE_FAIL: koşul doğru olduğu sürece tetiklenmeye devam eder;
 *    koşul YANLIŞA dönünce (kaybolunca) kendini durdurur.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    companion object {
        /** "Infinite Loop" için güvenlik üst sınırı — kullanıcı gerçekten sınırsız istese bile motor thread'i sonsuza kadar kilitlemesin diye. */
        private const val MAX_SAFE_INFINITE_LOOP_MS = 5 * 60_000L
    }
    private var rules: List<Rule> = emptyList()
    private var functionsProvider: (String) -> List<Rule> = { emptyList() }

    /** "NONE/WHILE_SUCCESS/WHILE_FAIL" ömrünü tamamlamış kural id'leri — bir daha kontrol edilmez. */
    private val completedRuleIds = mutableSetOf<String>()
    /**
     * KÖK NEDEN DÜZELTMESİ: eskiden "truthSince" (koşul NE ZAMANDAN BERİ sürekli doğru) adıyla,
     * YANLIŞ bir "hold/debounce" mantığı için kullanılıyordu. Macrorify'ın GERÇEK "Timeout"u
     * TERSİ: "bu deneme (arama) NE ZAMAN BAŞLADI" — süre `scanTimeoutMs`'i geçerse On Fail
     * tetiklenir. Bulununca (success) ya da bir deneme sonuçlanınca (Fail tetiklenince) SIFIRLANIR
     * — bir SONRAKİ deneme (loop varsa) BURADAN yeniden başlar.
     */
    private val attemptStartedAt = mutableMapOf<String, Long>()
    /** "Tarama Hızı" (Scan Rate) için: bu kural en son ne zaman KONTROL edildi (pil tasarrufu). */
    private val lastCheckedAt = mutableMapOf<String, Long>()
    /** "Otomatik Durdurma" (art arda BULUNAMADI) için: bu kural üst üste kaç kere bulunamadı. */
    private val consecutiveFailCount = mutableMapOf<String, Int>()

    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        rules = newRules
        completedRuleIds.clear()
        attemptStartedAt.clear()
        lastCheckedAt.clear()
        consecutiveFailCount.clear()
    }

    /** "Stop" butonu için: NONE/WHILE_SUCCESS/WHILE_FAIL kurallarının "bitti" durumunu sıfırlar — bir sonraki Play baştan başlar. */
    fun resetLoopState() {
        completedRuleIds.clear()
        attemptStartedAt.clear()
        lastCheckedAt.clear()
        consecutiveFailCount.clear()
        ActionResultRegistry.reset()
        MatchLocationRegistry.reset()
        RuleEvaluationRegistry.reset()
    }

    fun setFunctionsProvider(provider: (String) -> List<Rule>) {
        functionsProvider = provider
    }

    fun lastFiredAt(ruleId: String): Long? = ActionResultRegistry.lastFiredAt(ruleId)

    fun onFrame(frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rules) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    fun evaluateRulesOnce(rulesToRun: List<Rule>, frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rulesToRun) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    /**
     * KÖK NEDEN DÜZELTMESİ (kullanıcı raporu: "On Success ve On Fail düzgün çalışmıyor" +
     * Macrorify'ın resmi akış şeması: https://www.kok-emm.com/docs/image-detection/basic):
     *
     * DOĞRU MANTIK: "Template bulunamazsa, TÜM işlem Timeout dolana kadar TEKRARLANIR. Süre
     * dolunca On Fail çalışır." Yani:
     *  1) Her uygun karede (Scan Rate'e göre) koşul kontrol edilir.
     *  2) BULUNURSA → ANINDA (bekleme YOK) On Success tetiklenir.
     *  3) BULUNAMAZSA → bu "deneme" ne zaman BAŞLADI'ya bakılır; Timeout'u henüz AŞMADIYSA
     *     hiçbir şey yapılmaz, bir SONRAKİ uygun karede TEKRAR denenir (arama devam eder).
     *     Timeout AŞILDIYSA On Fail tetiklenir.
     *  4) On Success/On Fail SONRASI, `loopMode`'a göre (Macrorify "Loop"):
     *     - NONE: kural tamamen durur (bir daha ASLA kontrol edilmez).
     *     - WHILE_SUCCESS ("Loop when success"): success olunca YENİDEN dener (deneme sıfırlanır);
     *       fail olunca DURUR.
     *     - WHILE_FAIL ("Loop when fail"): fail olunca YENİDEN dener; success olunca DURUR.
     *     - ALWAYS ("Loop always", varsayılan): SONUÇ NE OLURSA OLSUN her zaman yeniden dener.
     */
    private fun evaluateAndMaybeFire(rule: Rule, frame: Bitmap, now: Long) {
        if (rule.id in completedRuleIds) return

        // "Tarama Hızı" (Scan Rate): pil tasarrufu için bu kuralı saniyede en fazla N kere
        // KONTROL ediyoruz — 0 ise sınırsız (mevcut en hızlı davranış, önceki gibi).
        if (rule.scanRateHz > 0f) {
            val minIntervalMs = (1000f / rule.scanRateHz).toLong()
            val lastChecked = lastCheckedAt[rule.id]
            if (lastChecked != null && now - lastChecked < minIntervalMs) return
            lastCheckedAt[rule.id] = now
        }

        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        // "Relative Coordinates" (Locatable Detection) için: bu kuralın koşulu HAM olarak
        // (negate/cooldown'dan bağımsız) doğru bulunduysa, BULUNDUĞU KONUMU kaydet — başka
        // kurallar bunu "anchor" (referans nokta) olarak kullanabilsin diye.
        if (conditionMatched) {
            try {
                rule.condition.matchLocation(frame)?.let { (mx, my) -> MatchLocationRegistry.record(rule.id, mx, my) }
            } catch (e: Exception) {
                // Konum kaydı başarısız olsa bile ana değerlendirme akışı etkilenmesin.
            }
        }
        val success = if (rule.negate) !conditionMatched else conditionMatched
        // Canlı Test ekranı için: bu karedeki DEĞERLENDİRME sonucunu (ateşlenip ateşlenmediğinden
        // bağımsız) kaydet — OverlayService ekrandaki alanın çerçevesini buna göre boyar.
        RuleEvaluationRegistry.record(rule.id, success)

        if (success) {
            // BULUNDU — Macrorify'da ANINDA tetiklenir, "hold" (bekleme) YOK. Wait Next
            // (cooldown) SADECE art arda çok hızlı tetiklenmeyi önler, arama süresiyle ilgisi yok.
            attemptStartedAt.remove(rule.id) // bir sonraki deneme için sıfırla
            consecutiveFailCount[rule.id] = 0
            val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
            if (now - last < rule.cooldownMs) return
            fireWithDelay(rule, rule.thenAction, frame, now)
            applyLoopDecision(rule, wasSuccess = true)
            return
        }

        // BULUNAMADI. "Otomatik Durdurma": art arda çok fazla BULUNAMADI'dan sonra kendini durdurur.
        if (rule.maxConsecutiveFailures > 0) {
            val count = (consecutiveFailCount[rule.id] ?: 0) + 1
            consecutiveFailCount[rule.id] = count
            if (count >= rule.maxConsecutiveFailures) {
                completedRuleIds.add(rule.id)
                return
            }
        }

        /**
         * TASARIM DÜZELTMESİ (kullanıcı onayıyla): "Timeout girilmemişse (0), On Fail HİÇ
         * tetiklenmesin, sonsuza kadar beklesin" eski davranışı, tam da şikayet edilen "On Fail
         * çalışmıyor" durumunu BAŞKA bir şekilde YENİDEN yaratıyordu — kullanıcı On Fail adımları
         * eklese bile Timeout girmeyi UNUTURSA, o adımlar HİÇBİR ZAMAN çalışmazdı. Artık TERSİ:
         * Timeout girilmemişse (0 ya da negatif), HER TARAMADA ANINDA karar verilir — bulundu →
         * On Success, bulunamadı → On Fail (bekleme YOK). Timeout SADECE kullanıcı BİLİNÇLİ
         * olarak "biraz bekleyip birkaç kez dene" istediğinde devreye giren İSTEĞE BAĞLI bir ek.
         */
        if (rule.scanTimeoutMs <= 0) {
            attemptStartedAt.remove(rule.id)
            val onFailNow = rule.onFailAction
            if (onFailNow != null) {
                val lastNow = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - lastNow >= rule.cooldownMs) {
                    fireWithDelay(rule, onFailNow, frame, now)
                }
            }
            applyLoopDecision(rule, wasSuccess = false)
            return
        }

        val startedAt = attemptStartedAt.getOrPut(rule.id) { now }
        if (now - startedAt < rule.scanTimeoutMs) return // Timeout henüz DOLMADI — aramaya devam

        // Timeout DOLDU, hâlâ bulunamadı — On Fail tetiklenir (tanımlıysa).
        attemptStartedAt.remove(rule.id) // bir sonraki deneme için sıfırla
        val onFail = rule.onFailAction
        if (onFail != null) {
            val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
            if (now - last >= rule.cooldownMs) {
                fireWithDelay(rule, onFail, frame, now)
            }
        }
        applyLoopDecision(rule, wasSuccess = false)
    }

    /**
     * Macrorify'daki "Loop" (None/Loop when success/Loop when fail/Loop always) — bir On Success/
     * On Fail SONRASI ne olacağına karar verir.
     *
     * ÖNEMLİ: motor-içi anahtar isimleri ("WHILE_SUCCESS"/"WHILE_FAIL") UI'daki etiketlerle
     * TERS eşleşir — bu, ÖNCEKİ bir turda kayıtlı veriyle GERİYE DÖNÜK UYUMLULUĞU BOZMAMAK için
     * BİLİNÇLİ olarak korunan, YERLEŞİK bir kural (bkz. Loop sekmesi UI kodu, satır ~5507):
     *  - "WHILE_SUCCESS" anahtarı = UI'da "Loop when fail" (BAŞARISIZ olduğu SÜRECE tekrarlar,
     *    İLK BAŞARILI olunca durur).
     *  - "WHILE_FAIL" anahtarı = UI'da "Loop when success" (BAŞARILI olduğu SÜRECE tekrarlar,
     *    İLK BAŞARISIZ olunca durur).
     */
    private fun applyLoopDecision(rule: Rule, wasSuccess: Boolean) {
        when (rule.loopMode) {
            "NONE" -> completedRuleIds.add(rule.id) // Tek seferlik — bir daha ASLA kontrol edilmez.
            "WHILE_SUCCESS" -> if (wasSuccess) completedRuleIds.add(rule.id) // "Loop when fail": success olunca dur.
            "WHILE_FAIL" -> if (!wasSuccess) completedRuleIds.add(rule.id) // "Loop when success": fail olunca dur.
            else -> { /* "ALWAYS" ("Loop always"): sonuç ne olursa olsun devam — hiçbir şey yapma. */ }
        }
    }

    private fun fireWithDelay(rule: Rule, action: Action, frame: Bitmap, now: Long) {
        ActionResultRegistry.markFired(rule.id)
        if (rule.matchDelayMs > 0) Thread.sleep(rule.matchDelayMs)
        fireAction(rule, action, frame, now)
    }

    private fun fireAction(rule: Rule, action: Action, frame: Bitmap, now: Long) {
        val callAction = extractCallFunction(action)
        if (callAction != null) {
            if (action is Action.Sequence) {
                action.steps.filter { it !is Action.CallFunction }.forEach { resolveAndExecute(rule, it, frame) }
            }
            val funcRules = functionsProvider(callAction.functionId)
            if (callAction.infiniteLoop) {
                // GÜVENLİK: gerçekten sınırsız bir döngü motor thread'ini sonsuza kadar kilitleyip
                // uygulamayı tamamen tepkisiz bırakabilir. Kullanıcı "sınırsız" dese bile (timeLimitMs=0),
                // motor kendi güvenlik üst sınırını (5 dakika) uygular — Macrorify'da da bu risk var,
                // biz sadece donmayı önlemek için ek bir çıpa koyuyoruz.
                // HATA DÜZELTMESİ: bu döngü hiç bekleme koymadan sürekli dönüyordu, motor
                // thread'ini %100 CPU'ya kilitleyip pili tüketiyor ve cihazı ısıtıyordu.
                // Kural değerlendirmesi zaten her karede tekrar tetiklenecek şekilde
                // tasarlandığından, aralara küçük bir bekleme koymak davranışı bozmadan
                // CPU'yu serbest bırakır.
                val effectiveLimitMs = if (callAction.timeLimitMs > 0) callAction.timeLimitMs else MAX_SAFE_INFINITE_LOOP_MS
                val loopStart = System.currentTimeMillis()
                while (System.currentTimeMillis() - loopStart < effectiveLimitMs) {
                    for (funcRule in funcRules) {
                        if (!funcRule.enabled) continue
                        evaluateAndMaybeFire(funcRule, frame, now)
                    }
                    Thread.sleep(16L) // ~60 kontrol/saniye üst sınırı, busy-loop'u önler
                }
            } else {
                repeat(callAction.repeat.coerceAtLeast(1)) {
                    for (funcRule in funcRules) {
                        if (!funcRule.enabled) continue
                        evaluateAndMaybeFire(funcRule, frame, now)
                    }
                }
            }
        } else {
            resolveAndExecute(rule, action, frame)
        }
    }

    /**
     * KULLANICI RAPORU: bir swipe'ın hold süresini 0'dan 300'e çıkarınca "sistem artık
     * çalışmıyor" (test/Play Mode bir daha tepki vermiyor). `continueStroke` API kullanımını
     * Android'in KENDİ resmi test paterniyle karşılaştırdım — birebir doğru, bir API-kullanım
     * hatası DEĞİL. Kesin bir çökme noktası bulamadım, ama kök neden NE OLURSA OLSUN motoru
     * korumak için: bu fonksiyon artık TÜM gövdeyi try-catch içine alıyor — TEK bir aksiyonun
     * (örn. Android'in gesture API'sinin nadir bir cihazda/durumda fırlattığı beklenmedik bir
     * exception) YAKALANMAMIŞ hâlde motorun ANA DÖNGÜSÜNE sızıp TÜM sistemi durdurmasını
     * engelliyor — hata sadece o TEK karede loglanıp yutuluyor, motor bir SONRAKİ karede
     * NORMAL çalışmaya devam ediyor.
     */
    private fun resolveAndExecute(rule: Rule, action: Action, frame: Bitmap) {
        try {
            when (action) {
                is Action.TapAtMatch -> {
                    val loc = rule.condition.matchLocation(frame)
                    if (loc != null) executor.execute(Action.Tap(loc.first, loc.second, action.repeat, action.holdMs, action.postDelayMs, action.randomOffsetPx))
                }
                is Action.TapAllMatches -> {
                    val locs = rule.condition.matchLocations(frame)
                    locs.forEach { (mx, my) -> executor.execute(Action.Tap(mx, my, action.repeat, action.holdMs, action.postDelayMs, action.randomOffsetPx)) }
                }
                is Action.ReadTextToVariable -> {
                    val region = com.bigboss.app.model.Region(action.regionX, action.regionY, action.regionW, action.regionH)
                    val text = TextMatcher.readText(frame, region, action.whitelist, action.blacklist)
                    val number = text?.let { Regex("-?\\d+").find(it)?.value?.toIntOrNull() } ?: action.defaultValue
                    VariableStore.set(action.variableName, number)
                }
                is Action.Sequence -> action.steps.forEach { resolveAndExecute(rule, it, frame) }
                else -> executor.execute(action)
            }
        } catch (e: Exception) {
            android.util.Log.e("BigBossRuleEngine", "Aksiyon çalıştırılırken hata (kural: ${rule.id}): ${e.message}", e)
            ActionResultRegistry.recordActionError("${rule.id.take(8)}: ${e.javaClass.simpleName} — ${e.message}")
        }
    }

    private fun extractCallFunction(action: Action): Action.CallFunction? = when (action) {
        is Action.CallFunction -> action
        is Action.Sequence -> action.steps.filterIsInstance<Action.CallFunction>().firstOrNull()
        else -> null
    }
}
