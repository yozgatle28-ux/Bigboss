package com.bigboss.app.emscript

/**
 * EMScript çalışma-zamanı değerleri ve ortam (scope) tanımları.
 *
 * Değer eşlemesi (Kotlin karşılıkları):
 *  - number  -> Double
 *  - string  -> String
 *  - bool    -> Boolean
 *  - null    -> null
 *  - array   -> EmArray (değiştirilebilir liste sarmalayıcı; .size, .push, indeksleme)
 *  - function-> EmCallable (kullanıcı fonksiyonu, lambda, native köprü, sınıf metodu)
 *  - object  -> EmInstance (sınıf örneği)
 *  - class   -> EmClass (sınıf tanımı; static metotlar + yapıcı)
 */

/** Çağrılabilir her şey (fonksiyon, lambda, native köprü, metot). */
interface EmCallable {
    val arity: Int   // -1 = değişken sayıda argüman
    fun call(interpreter: Interpreter, args: List<Any?>): Any?
    fun name(): String = "<fn>"
}

/** Dizi — EMScript'te tek yerleşik veri yapısı. .size, .push(x), indeksleme. */
class EmArray(val elements: MutableList<Any?> = mutableListOf()) {
    val size: Int get() = elements.size
    fun push(v: Any?) { elements.add(v) }
    fun get(i: Int): Any? = elements.getOrNull(i)
    fun set(i: Int, v: Any?) {
        while (elements.size <= i) elements.add(null)
        elements[i] = v
    }
    override fun toString(): String = "[" + elements.joinToString(", ") { Interpreter.stringify(it) } + "]"
}

/** Değişkenleri tutan ortam (scope). Zincirleme: iç scope dışı görebilir. */
class Environment(val enclosing: Environment? = null) {
    private val values = HashMap<String, Any?>()

    fun define(name: String, value: Any?) { values[name] = value }

    fun get(name: Token): Any? {
        if (values.containsKey(name.lexeme)) return values[name.lexeme]
        if (enclosing != null) return enclosing.get(name)
        throw EmScriptError("Tanımsız değişken '${name.lexeme}'", name.line)
    }

    fun getByName(name: String): Any? {
        if (values.containsKey(name)) return values[name]
        if (enclosing != null) return enclosing.getByName(name)
        return null
    }

    fun has(name: String): Boolean =
        values.containsKey(name) || (enclosing?.has(name) ?: false)

    fun assign(name: Token, value: Any?) {
        if (values.containsKey(name.lexeme)) { values[name.lexeme] = value; return }
        if (enclosing != null) { enclosing.assign(name, value); return }
        throw EmScriptError("Tanımsız değişken '${name.lexeme}' (atama)", name.line)
    }
}

/** Sınıf tanımı. */
class EmClass(
    val emName: String,
    val initParams: List<Token>?,
    val initBody: List<Stmt>,
    val methods: Map<String, EmFunction>,
    val staticMethods: Map<String, EmFunction>,
    val closure: Environment
) : EmCallable {
    override val arity: Int get() = initParams?.size ?: 0
    override fun name() = emName

    override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
        val instance = EmInstance(this)
        // init'i çalıştır (varsa)
        if (initParams != null) {
            val env = Environment(closure)
            env.define("this", instance)
            for (i in initParams.indices) {
                env.define(initParams[i].lexeme, args.getOrNull(i))
            }
            interpreter.executeBlock(initBody, env)
        }
        return instance
    }

    fun findStatic(name: String): EmFunction? = staticMethods[name]
}

/** Sınıf örneği (nesne). Alanlar dinamik (this.x = ...). */
class EmInstance(val klass: EmClass) {
    val fields = HashMap<String, Any?>()

    fun get(name: String): Any? {
        if (fields.containsKey(name)) return fields[name]
        val method = klass.methods[name]
        if (method != null) return method.bind(this)
        throw EmScriptError("'${klass.emName}' nesnesinde '$name' yok")
    }

    fun set(name: String, value: Any?) { fields[name] = value }
    override fun toString(): String = "<${klass.emName} nesnesi>"
}
