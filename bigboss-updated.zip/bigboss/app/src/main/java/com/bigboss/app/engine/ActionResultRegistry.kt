package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Macrorify'daki "Action Result" koşulunun temeli: bir kuralın en son
 * ne zaman tetiklendiğini tutar. Böylece "B kuralı, A kuralı yakın
 * zamanda tetiklendiyse çalışsın" gibi SIRA gerektiren senaryolar,
 * paralel/reaktif motorda da mümkün olur — gerçek bir "sıra" olmadan.
 */
object ActionResultRegistry {
    private val lastFiredAt = ConcurrentHashMap<String, Long>()

    /** "Otomatik Durdurma" güvenlik ağı için: HERHANGİ bir kuralın en son ne zaman tetiklendiği (global). */
    @Volatile private var lastAnyFiredAt: Long = System.currentTimeMillis()

    fun markFired(ruleId: String) {
        val now = System.currentTimeMillis()
        lastFiredAt[ruleId] = now
        lastAnyFiredAt = now
    }

    fun firedWithin(ruleId: String, withinMs: Long): Boolean {
        val t = lastFiredAt[ruleId] ?: return false
        return System.currentTimeMillis() - t <= withinMs
    }

    fun lastFiredAt(ruleId: String): Long? = lastFiredAt[ruleId]

    /** Şu andan itibaren HERHANGİ bir kuralın en son tetiklenmesinden bu yana geçen süre (ms). */
    fun msSinceAnyFire(): Long = System.currentTimeMillis() - lastAnyFiredAt

    /** "Play" başlarken/durdurulunca çağrılır — sayaç sıfırdan başlasın diye. */
    fun markAliveNow() { lastAnyFiredAt = System.currentTimeMillis() }

    fun reset() {
        lastFiredAt.clear()
        lastAnyFiredAt = System.currentTimeMillis()
    }
}
