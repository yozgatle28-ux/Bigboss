package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** "scripts.json" içinde tüm Script'leri saklar. */
object ScriptStorage {

    private const val FILE_NAME = "scripts.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<ScriptDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<ScriptDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, scripts: List<ScriptDefinition>) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(scripts))
    }

    fun upsert(context: Context, script: ScriptDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == script.id }
        if (idx >= 0) all[idx] = script else all.add(script)
        save(context, all)
    }

    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    fun moveUp(context: Context, id: String) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == id }
        if (idx > 0) { val tmp = all[idx - 1]; all[idx - 1] = all[idx]; all[idx] = tmp; save(context, all) }
    }

    fun moveDown(context: Context, id: String) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == id }
        if (idx in 0 until all.size - 1) { val tmp = all[idx + 1]; all[idx + 1] = all[idx]; all[idx] = tmp; save(context, all) }
    }
}
