package com.bigboss.app.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "Resources" kırpma aracının birebir kopyası: solda kontrol paneli
 * (X/Y/W/H + döndür/sıfırla/iptal/onay), sağda ekran/görsel üzerinde turkuaz çerçeve.
 * Çerçeve sürüklenebilir, sağ-alt üçgen tutamakla boyutlandırılabilir; koordinatlar
 * gerçek zamanlı senkronize.
 *
 * Hem ekrandan kütüphaneye görsel ekleme (ScreenCapture) hem de kütüphanedeki
 * mevcut görseli yeniden kırpma (LibraryBitmap) için aynı araç kullanılır.
 */
class MacrorifyCropTool(
    private val context: Context,
    private val windowManager: WindowManager,
    private val maxW: Int,
    private val maxH: Int,
    private val initialRect: Rect,
    private val backgroundBitmap: android.graphics.Bitmap? = null,
    private val onDone: (Rect) -> Unit,
    private val onCancel: () -> Unit
) {

    private val density = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private var rootView: FrameLayout? = null
    private var frameView: CropFrameView? = null
    private var panelView: LinearLayout? = null
    private var etX: EditText? = null
    private var etY: EditText? = null
    private var etW: EditText? = null
    private var etH: EditText? = null
    private var suppressSync = false

    // Çerçevenin ekrandaki (GÖRÜNTÜLEME) konumu/boyutu — piksel piksel EKRANA çizilen değerler.
    private var frameX = 0f
    private var frameY = 0f
    private var frameW = 0f
    private var frameH = 0f

    /**
     * KRİTİK DÜZELTME (kullanıcı raporu: "kütüphanedeki resimleri kırpma özelliği çalışmıyor"):
     * Kütüphaneden bir görsel yeniden kırpılırken (`backgroundBitmap` DOLU), o görsel genelde
     * KÜÇÜK (örn. 100×100px) ama `FIT_CENTER` ile TÜM ekranı kaplayacak şekilde BÜYÜTÜLEREK
     * gösteriliyordu — ama çerçevenin KENDİSİ hâlâ `maxW`/`maxH`'yi (görselin HAM, KÜÇÜK piksel
     * boyutu) sınır olarak kullanıyordu. Sonuç: ekranda kocaman büyütülmüş bir resim görünürken,
     * kırpma çerçevesi bunun üzerinde SADECE 100×100 piksellik (yani ekranın küçük bir köşesinde,
     * resimle HİÇ örtüşmeyen) bir alanda sıkışıp kalıyordu — kullanıcı gördüğü resmi
     * KIRPAMIYORDU. Artık bir `displayScale` hesaplanıp GÖRÜNTÜLENEN resim boyutu İLE çerçevenin
     * sınırları AYNI ölçeğe getiriliyor; ekrana gösterilen HER ŞEY "görüntüleme uzayında", sadece
     * kullanıcıya gösterilen X/Y/Genişlik/Yükseklik alanları VE sonuç `onDone(rect)` çağrısı
     * "gerçek" (orijinal bitmap pikseli) uzayına çevriliyor.
     */
    private var displayScale = 1f
    private var imageOffsetX = 0f
    private var imageOffsetY = 0f
    private var dispMaxW = 0f
    private var dispMaxH = 0f

    private val panelWidth = (160 * density).toInt()
    private val panelMargin = (12 * density).toInt()
    private val minFrameSize = (24 * density).toInt()
    private val triangleSize = (22 * density)

    /** Overlay'i ekrana ekler. */
    fun show() {
        if (rootView != null) return

        val metrics = context.resources.displayMetrics
        if (backgroundBitmap != null) {
            // KÜÇÜK bir görseli (kütüphane öğesi) EKRANDA rahatça düzenlenebilecek bir boyuta
            // BÜYÜT — panelin sağında kalan alana, en/boy oranını KORUYARAK sığdır.
            val availW = (metrics.widthPixels - panelWidth - panelMargin * 3).coerceAtLeast(1)
            val availH = (metrics.heightPixels - panelMargin * 2).coerceAtLeast(1)
            displayScale = min(availW.toFloat() / maxW, availH.toFloat() / maxH).coerceAtLeast(0.01f)
            imageOffsetX = (panelWidth + panelMargin * 2).toFloat()
            imageOffsetY = ((metrics.heightPixels - maxH * displayScale) / 2f).coerceAtLeast(panelMargin.toFloat())
        } else {
            // Ekrandan canlı kırpma: arka plan zaten GERÇEK ekranın kendisi (saydam overlay) —
            // hiçbir büyütme/küçültme yok, 1:1 piksel eşlemesi.
            displayScale = 1f
            imageOffsetX = 0f
            imageOffsetY = 0f
        }
        dispMaxW = maxW * displayScale
        dispMaxH = maxH * displayScale

        val root = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            if (backgroundBitmap != null) {
                setBackgroundColor(Color.BLACK)
            } else {
                setBackgroundColor(Color.parseColor("#22000000")) // hafif karartma, arka planı görünür tutar
            }
        }
        rootView = root

        backgroundBitmap?.let { bmp ->
            val bg = android.widget.ImageView(context).apply {
                scaleType = android.widget.ImageView.ScaleType.FIT_XY
                setImageBitmap(bmp)
            }
            root.addView(bg, FrameLayout.LayoutParams(
                (maxW * displayScale).toInt().coerceAtLeast(1),
                (maxH * displayScale).toInt().coerceAtLeast(1)
            ).apply {
                leftMargin = imageOffsetX.toInt()
                topMargin = imageOffsetY.toInt()
            })
        }

        val frame = CropFrameView(context).apply {
            layoutParams = FrameLayout.LayoutParams(0, 0)
        }
        frameView = frame
        root.addView(frame)

        val panel = buildControlPanel()
        panelView = panel
        val pParams = FrameLayout.LayoutParams(panelWidth, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = panelMargin
            topMargin = panelMargin
        }
        panelParams = pParams
        root.addView(panel, pParams)

        val rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(root, rootParams)

        // Başlangıç konumunu uygula
        setFrameRect(initialRect, animate = false)
    }

    /** Overlay'i kaldırır. */
    fun dismiss() {
        rootView?.let { windowManager.removeView(it) }
        rootView = null
        frameView = null
        panelView = null
        panelParams = null
    }

    private var panelParams: FrameLayout.LayoutParams? = null
    private var panelDownRawX = 0f
    private var panelDownRawY = 0f
    private var panelStartLeft = 0
    private var panelStartTop = 0

    private fun buildControlPanel(): LinearLayout {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F7F7F9"))
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
        }
        val stroke = GradientDrawable().apply {
            setColor(Color.parseColor("#F7F7F9"))
            setStroke((1 * density).toInt(), Color.parseColor("#DDDDDD"))
            cornerRadius = 6f * density
        }
        panel.background = stroke

        /**
         * KULLANICI İSTEĞİ: "kırmızı çerçeve ile işaretlediğim kısmı [kontrol paneli] ekranda
         * istediğim yere taşıyabilmeliyim." Panel eskiden SABİT (sol-üst köşede) duruyordu —
         * artık bu "Kırp" başlığı bir SÜRÜKLEME TUTAMACI: alanlara/butonlara DOKUNMADAN,
         * SADECE başlıktan tutup panelin TAMAMINI ekranda istediğin yere taşıyabiliyorsun.
         */
        val title = TextView(context).apply {
            text = "⠿ Kırp"
            textSize = 14f
            setTextColor(Color.parseColor("#333333"))
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (8 * density).toInt())
            isClickable = true
            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        panelDownRawX = event.rawX; panelDownRawY = event.rawY
                        val p = panelParams
                        panelStartLeft = p?.leftMargin ?: 0
                        panelStartTop = p?.topMargin ?: 0
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - panelDownRawX).toInt()
                        val dy = (event.rawY - panelDownRawY).toInt()
                        val metrics = context.resources.displayMetrics
                        val p = panelParams
                        if (p != null) {
                            val panelH = panelView?.height ?: 0
                            p.leftMargin = (panelStartLeft + dx).coerceIn(0, max(0, metrics.widthPixels - panelWidth))
                            p.topMargin = (panelStartTop + dy).coerceIn(0, max(0, metrics.heightPixels - panelH))
                            panelView?.layoutParams = p
                            panelView?.requestLayout()
                        }
                        true
                    }
                    else -> true
                }
            }
        }
        panel.addView(title)

        fun fieldRow(hint1: String, hint2: String): Pair<EditText, EditText> {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            val e1 = EditText(context).apply {
                this.hint = hint1
                textSize = 12f
                setTextColor(Color.parseColor("#333333"))
                setHintTextColor(Color.parseColor("#999999"))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                background = fieldBg()
            }
            val e2 = EditText(context).apply {
                this.hint = hint2
                textSize = 12f
                setTextColor(Color.parseColor("#333333"))
                setHintTextColor(Color.parseColor("#999999"))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = (6 * density).toInt()
                }
                setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                background = fieldBg()
            }
            row.addView(e1); row.addView(e2)
            panel.addView(row)
            return e1 to e2
        }

        val (xField, yField) = fieldRow("X", "Y")
        etX = xField; etY = yField
        val (wField, hField) = fieldRow("Genişlik", "Yükseklik")
        etW = wField; etH = hField

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { syncFrameFromFields() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        etX?.addTextChangedListener(watcher)
        etY?.addTextChangedListener(watcher)
        etW?.addTextChangedListener(watcher)
        etH?.addTextChangedListener(watcher)

        val btnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, (12 * density).toInt(), 0, 0)
        }
        btnRow.addView(textBtn("↻", Color.parseColor("#2196F3")) { rotateFrame() })
        btnRow.addView(textBtn("▭", Color.parseColor("#2196F3")) { resetFrame() })
        btnRow.addView(textBtn("✕", Color.parseColor("#E53935")) { dismiss(); onCancel() })
        btnRow.addView(textBtn("✓", Color.parseColor("#43A047")) { confirm() })
        panel.addView(btnRow)

        return panel
    }

    private fun fieldBg(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.WHITE)
        setStroke((1 * density).toInt(), Color.parseColor("#DDDDDD"))
        cornerRadius = 4f * density
    }

    private fun textBtn(symbol: String, tint: Int, onClick: () -> Unit): TextView {
        val size = (36 * density).toInt()
        return TextView(context).apply {
            text = symbol
            textSize = 20f
            setTextColor(tint)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(size, size)
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    /** Çerçeveyi verilen (GERÇEK/orijinal piksel uzayındaki) Rect'e göre konumlandırır. */
    private fun setFrameRect(rect: Rect, animate: Boolean) {
        // Gelen rect HER ZAMAN "gerçek" (orijinal bitmap) piksel uzayında — GÖRÜNTÜLEME
        // uzayına (displayScale ile) çevirip öyle uyguluyoruz.
        val logX = rect.left.toFloat().coerceIn(0f, max(0f, (maxW - minFrameSize / displayScale).toFloat()))
        val logY = rect.top.toFloat().coerceIn(0f, max(0f, (maxH - minFrameSize / displayScale).toFloat()))
        val logW = rect.width().toFloat().coerceIn((minFrameSize / displayScale), maxW.toFloat() - logX)
        val logH = rect.height().toFloat().coerceIn((minFrameSize / displayScale), maxH.toFloat() - logY)
        applyFrame(logX * displayScale, logY * displayScale, logW * displayScale, logH * displayScale)
        syncFieldsFromFrame()
    }

    private fun applyFrame(x: Float, y: Float, w: Float, h: Float) {
        frameX = x; frameY = y; frameW = w; frameH = h
        frameView?.let { fv ->
            fv.layoutParams = FrameLayout.LayoutParams(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)).apply {
                leftMargin = (x + imageOffsetX).toInt()
                topMargin = (y + imageOffsetY).toInt()
            }
            fv.requestLayout()
        }
    }

    /** GÖRÜNTÜLEME uzayındaki (frameX/Y/W/H) değerleri "gerçek" piksel uzayına çevirip alanlara yazar. */
    private fun syncFieldsFromFrame() {
        if (suppressSync) return
        suppressSync = true
        etX?.setText((frameX / displayScale).toInt().toString())
        etY?.setText((frameY / displayScale).toInt().toString())
        etW?.setText((frameW / displayScale).toInt().toString())
        etH?.setText((frameH / displayScale).toInt().toString())
        suppressSync = false
    }

    /** Alanlardaki "gerçek" piksel değerlerini okuyup GÖRÜNTÜLEME uzayına çevirerek uygular. */
    private fun syncFrameFromFields() {
        if (suppressSync) return
        val x = etX?.text?.toString()?.toIntOrNull() ?: return
        val y = etY?.text?.toString()?.toIntOrNull() ?: return
        val w = etW?.text?.toString()?.toIntOrNull() ?: return
        val h = etH?.text?.toString()?.toIntOrNull() ?: return
        if (w <= 0 || h <= 0) return
        setFrameRect(Rect(x, y, x + w, y + h), animate = false)
    }

    private fun rotateFrame() {
        // Çerçeveyi 90° döndür: genişlik/yükseklik takas; sağ-alt ve sol-üst konumlarını koru
        val newW = frameH
        val newH = frameW
        var newX = frameX
        var newY = frameY
        if (newX + newW > dispMaxW) newX = (dispMaxW - newW).coerceAtLeast(0f)
        if (newY + newH > dispMaxH) newY = (dispMaxH - newH).coerceAtLeast(0f)
        applyFrame(newX, newY, newW, newH)
        syncFieldsFromFrame()
    }

    private fun resetFrame() {
        setFrameRect(Rect(0, 0, maxW, maxH), animate = false)
    }

    private fun confirm() {
        // GÖRÜNTÜLEME uzayındaki çerçeveyi "gerçek" (orijinal bitmap) piksel uzayına çevirip döner.
        val logX = (frameX / displayScale).toInt()
        val logY = (frameY / displayScale).toInt()
        val logW = (frameW / displayScale).toInt()
        val logH = (frameH / displayScale).toInt()
        val rect = Rect(logX, logY, logX + logW, logY + logH)
        dismiss()
        onDone(rect)
    }

    /** Turkuaz border + sağ-alt üçgen boyutlandırma tutamağı. */
    private inner class CropFrameView(ctx: Context) : View(ctx) {
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4") // Macrorify turkuazı
            style = Paint.Style.STROKE
            strokeWidth = 3f * density
        }
        private val trianglePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4")
            style = Paint.Style.FILL
        }
        private val triangleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * density
        }

        private var dragMode = DragMode.NONE
        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0f
        private var startY = 0f
        private var startW = 0f
        private var startH = 0f

        init {
            isClickable = true
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX; downRawY = event.rawY
                        startX = frameX; startY = frameY; startW = frameW; startH = frameH
                        dragMode = if (isInTriangle(event.x, event.y)) DragMode.RESIZE else DragMode.MOVE
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        when (dragMode) {
                            DragMode.MOVE -> {
                                val nx = (startX + dx).coerceIn(0f, max(0f, dispMaxW - frameW))
                                val ny = (startY + dy).coerceIn(0f, max(0f, dispMaxH - frameH))
                                applyFrame(nx, ny, frameW, frameH)
                            }
                            DragMode.RESIZE -> {
                                val newW = (startW + dx).coerceIn(minFrameSize.toFloat(), dispMaxW - startX)
                                val newH = (startH + dy).coerceIn(minFrameSize.toFloat(), dispMaxH - startY)
                                applyFrame(startX, startY, newW, newH)
                            }
                            else -> {}
                        }
                        syncFieldsFromFrame()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragMode = DragMode.NONE
                }
                true
            }
        }

        private fun isInTriangle(x: Float, y: Float): Boolean {
            // Sağ-alt köşede eşkenar üçgen / dik üçgen bölge
            return x >= width - triangleSize && y >= height - triangleSize
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val inset = borderPaint.strokeWidth / 2f
            canvas.drawRect(inset, inset, w - inset, h - inset, borderPaint)

            // Sağ-alt üçgen tutamak
            val path = Path().apply {
                moveTo(w, h - triangleSize)
                lineTo(w - triangleSize, h)
                lineTo(w, h)
                close()
            }
            canvas.drawPath(path, trianglePaint)
            canvas.drawLine(w, h - triangleSize, w - triangleSize, h, triangleStroke)
        }
    }

    private enum class DragMode { NONE, MOVE, RESIZE }
}
