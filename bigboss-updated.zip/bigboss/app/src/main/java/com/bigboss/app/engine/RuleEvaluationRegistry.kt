package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * "Canlı Test" (Live Test) ekranı için: her karede bir kuralın koşulunun NEGATE UYGULANMIŞ
 * ("success" — kullanıcının ekranda görmek istediği gerçek sonuç, ham conditionMatched değil)
 * sonucunu ve NE ZAMAN değerlendirildiğini tutar. OverlayService, test oturumu sırasında bunu
 * poll edip ekrandaki tarama alanlarının çerçevesini yeşil (başarılı)/kırmızı (başarısız) boyar.
 *
 * Neden ayrı bir registry (ActionResultRegistry/MatchLocationRegistry'ye ek olarak): onlar
 * "ne zaman ateşlendi" / "nerede bulundu" tutar, ama "bu karede sonuç ne oldu" (ateşlenmese
 * bile, örn. cooldown/timeout nedeniyle) bilgisini AYRI tutmak gerekiyor — canlı geri bildirim
 * kuralın ATEŞLENMESİNİ değil, o anki DEĞERLENDİRME sonucunu yansıtmalı.
 */
object RuleEvaluationRegistry {
    private data class Entry(val success: Boolean, val timestamp: Long)

    private val results = ConcurrentHashMap<String, Entry>()

    fun record(ruleId: String, success: Boolean) {
        results[ruleId] = Entry(success, System.currentTimeMillis())
    }

    /**
     * maxAgeMs içinde bir değerlendirme varsa son sonucu (true/false) döner; hiç
     * değerlendirilmediyse ya da kayıt çok eskiyse (kural artık taranmıyor/scanRateHz'e göre
     * sırası gelmedi) null döner — "henüz bilinmiyor" (nötr) durumu ayırt edilebilsin diye.
     */
    fun get(ruleId: String, maxAgeMs: Long = 2500L): Boolean? {
        val e = results[ruleId] ?: return null
        if (System.currentTimeMillis() - e.timestamp > maxAgeMs) return null
        return e.success
    }

    /** Yeni bir test oturumu/Play başlarken çağrılır — önceki oturumun izleri kalmasın. */
    fun reset() = results.clear()
}
