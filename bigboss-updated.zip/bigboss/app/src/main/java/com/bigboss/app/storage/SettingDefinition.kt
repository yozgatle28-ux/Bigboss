package com.bigboss.app.storage

/**
 * Macrorify "Setting Builder" — botu KULLANAN kişinin çalışma anında parametre
 * değiştirebileceği ÖZEL bir ayar arayüzü. Diyalog, "view" denen bileşenlerden oluşur.
 *
 * ÇEKİRDEK MANTIK ("The Key"): TextView DIŞINDAKİ her view'ın bir `key`'i vardır.
 * Kullanıcı "Kaydet"e basınca, her key ile AYNI isimde bir DEĞİŞKEN (birleşik
 * VariableStore) oluşturulur/güncellenir. Böylece kullanıcının girdiği değer
 * makronun her yerinde {key} olarak kullanılabilir. key, değişken isimlendirme
 * kurallarına uymak zorundadır (^[A-Za-z_][A-Za-z0-9_]*$).
 */

/** Tek bir görsel bileşen (view). type'a göre bazı alanlar kullanılır. */
data class SettingViewDef(
    val id: String,
    /** "TEXTVIEW" | "EDITTEXT" | "CHECKBOX" | "RADIO" | "IMAGEPICKER" | "RECORDER" | "TABLAYOUT" */
    var type: String = "EDITTEXT",
    /**
     * Bu view'ın değişken adı. TextView için kullanılmaz (o sadece etiket gösterir).
     * Kaydet'te bu isimde değişken oluşturulur/güncellenir.
     */
    var key: String = "",
    /** TextView: gösterilecek metin. Diğerlerinde: alanın üst etiketi/başlığı. */
    var label: String = "",
    /** EditText: varsayılan metin. CheckBox: "true"/"false". Radio: seçili index (metin). */
    var defaultValue: String = "",
    /** EditText: kutu içi ipucu (hint). */
    var hint: String = "",
    /** EditText/CheckBox/Radio: alanın altındaki yardımcı açıklama (helper). */
    var helper: String = "",
    /** EditText giriş yöntemi: "TEXT" | "NUMBER" */
    var inputMethod: String = "TEXT",
    /** RADIO için seçenek etiketleri. TABLAYOUT için: sekme isimleri (aynı liste alanı yeniden kullanılıyor). */
    var radioOptions: MutableList<String> = mutableListOf("Seçenek 0", "Seçenek 1"),
    /**
     * Macrorify'daki "Tab Layout": bu view, listede kendinden ÖNCEKİ en yakın TABLAYOUT
     * view'ının hangi sekmesinde gösterilsin (0 tabanlı). -1 = sekmesiz (her zaman görünür —
     * henüz hiç TABLAYOUT eklenmemişse ya da bu view bir TABLAYOUT'un ÖNÜNDEYSE bu geçerli).
     */
    var tabIndex: Int = -1
)

/**
 * Tüm özel ayar diyaloğu. Macrorify'da tek bir "Setting" vardır; biz de tek bir
 * kayıtlı tanım tutuyoruz (settings.json). İçinde sıralı view listesi + başlangıçta
 * otomatik gösterilsin mi bayrağı bulunur.
 */
data class SettingDefinition(
    var title: String = "Ayarlar",
    var views: MutableList<SettingViewDef> = mutableListOf(),
    /** true ise Play Mode başlarken diyalog otomatik gösterilir ("Show at start up"). */
    var showAtStartup: Boolean = false
)
