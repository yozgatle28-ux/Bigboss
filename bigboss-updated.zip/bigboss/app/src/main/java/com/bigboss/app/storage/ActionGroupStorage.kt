package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** "action_groups.json" içinde tüm Action Group'ları saklar. */
object ActionGroupStorage {

    private const val FILE_NAME = "action_groups.json"
    private val gson = Gson()

    fun load(context: Context): MutableList<ActionGroupDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<ActionGroupDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, groups: List<ActionGroupDefinition>) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(groups))
    }

    fun upsert(context: Context, group: ActionGroupDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == group.id }
        if (idx >= 0) all[idx] = group else all.add(group)
        save(context, all)
    }

    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    fun upsertRuleInGroup(context: Context, groupId: String, rule: RuleDefinition) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        val idx = group.rules.indexOfFirst { it.id == rule.id }
        if (idx >= 0) group.rules[idx] = rule else group.rules.add(rule)
        save(context, all)
    }

    fun deleteRuleFromGroup(context: Context, groupId: String, ruleId: String) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        group.rules.removeAll { it.id == ruleId }
        save(context, all)
    }
}
