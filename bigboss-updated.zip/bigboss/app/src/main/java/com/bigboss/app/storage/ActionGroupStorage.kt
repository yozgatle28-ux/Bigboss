package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** "action_groups.json" içinde tüm Action Group'ları saklar. */
object ActionGroupStorage {

    private const val FILE_NAME = "action_groups.json"
    private val gson = Gson()

    @Synchronized
    fun load(context: Context): MutableList<ActionGroupDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val json = file.readText()
            val type = object : TypeToken<MutableList<ActionGroupDefinition>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    @Synchronized
    fun save(context: Context, groups: List<ActionGroupDefinition>) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(groups))
    }

    @Synchronized
    fun upsert(context: Context, group: ActionGroupDefinition) {
        val all = load(context)
        val idx = all.indexOfFirst { it.id == group.id }
        if (idx >= 0) all[idx] = group else all.add(group)
        save(context, all)
    }

    @Synchronized
    fun delete(context: Context, id: String) {
        val all = load(context)
        all.removeAll { it.id == id }
        save(context, all)
    }

    @Synchronized
    fun upsertRuleInGroup(context: Context, groupId: String, rule: RuleDefinition) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        val idx = group.rules.indexOfFirst { it.id == rule.id }
        if (idx >= 0) group.rules[idx] = rule else group.rules.add(rule)
        save(context, all)
    }

    @Synchronized
    fun deleteRuleFromGroup(context: Context, groupId: String, ruleId: String) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        group.rules.removeAll { it.id == ruleId }
        save(context, all)
    }

    /**
     * KULLANICI İSTEĞİ: Ana Akış/Fonksiyon'daki ortak araç çubuğu (Yukarı/Aşağı Taşı) Grup'a
     * da uygulanabilsin diye eklendi — `FunctionStorage.moveRuleUp/Down` ile BİREBİR AYNI
     * desen, sadece grup İÇİNDEKİ kuralların sırasını değiştirir.
     */
    @Synchronized
    fun moveRuleUp(context: Context, groupId: String, ruleId: String) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        val idx = group.rules.indexOfFirst { it.id == ruleId }
        if (idx > 0) { val tmp = group.rules[idx - 1]; group.rules[idx - 1] = group.rules[idx]; group.rules[idx] = tmp; save(context, all) }
    }

    @Synchronized
    fun moveRuleDown(context: Context, groupId: String, ruleId: String) {
        val all = load(context)
        val group = all.find { it.id == groupId } ?: return
        val idx = group.rules.indexOfFirst { it.id == ruleId }
        if (idx in 0 until group.rules.size - 1) { val tmp = group.rules[idx + 1]; group.rules[idx + 1] = group.rules[idx]; group.rules[idx] = tmp; save(context, all) }
    }
}
