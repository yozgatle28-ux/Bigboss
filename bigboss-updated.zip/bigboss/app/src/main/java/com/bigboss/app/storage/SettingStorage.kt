package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import java.io.File
import java.util.UUID

/** "settings.json" içinde tek bir özel ayar (Setting Builder) tanımını saklar. */
object SettingStorage {

    private const val FILE_NAME = "settings.json"
    private val gson = Gson()

    fun load(context: Context): SettingDefinition {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return SettingDefinition()
        return try {
            gson.fromJson(file.readText(), SettingDefinition::class.java) ?: SettingDefinition()
        } catch (e: Exception) {
            SettingDefinition()
        }
    }

    fun save(context: Context, def: SettingDefinition) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(def))
    }

    /** Diyalogda hiç view var mı (gösterilmeye değer mi)? */
    fun hasViews(context: Context): Boolean = load(context).views.isNotEmpty()

    /**
     * Kullanıcı "Kaydet"e bastığında çağrılır: her view'ın (TextView hariç) SON değeri
     * `values` haritasında gelir (key -> girilen değer). Bu değerleri hem kalıcı
     * değişken deposuna (GlobalVariableStorage) hem de canlı çalışma-zamanı deposuna
     * (VariableStore) yazar — böylece makronun her yerinde {key} olarak kullanılabilir.
     *
     * Ayrıca girilen defaultValue'ları tanımın kendisine de yazar (tekrar açınca aynı
     * değerlerin gelmesi için — Macrorify'daki "kaydedilir" davranışı).
     */
    fun applyValues(context: Context, values: Map<String, String>) {
        // 1) Kalıcı değişkenlere yaz (varsa güncelle, yoksa oluştur).
        val vars = GlobalVariableStorage.load(context)
        values.forEach { (key, value) ->
            val existing = vars.find { it.name == key }
            if (existing != null) {
                existing.textValue = value
                GlobalVariableStorage.upsert(context, existing)
            } else {
                GlobalVariableStorage.upsert(
                    context,
                    GlobalVariableDefinition(UUID.randomUUID().toString(), key, type = "STRING", textValue = value)
                )
            }
        }
        // 2) Canlı çalışma-zamanı deposuna da yaz (anında etki).
        values.forEach { (key, value) ->
            com.bigboss.app.engine.VariableStore.setRaw(key, value, "STRING")
        }
        // 3) Girilen değerleri tanımın defaultValue'suna işle (tekrar açınca gelsin).
        val def = load(context)
        def.views.forEach { v ->
            if (v.type != "TEXTVIEW" && values.containsKey(v.key)) {
                v.defaultValue = values[v.key] ?: v.defaultValue
            }
        }
        save(context, def)
    }
}
