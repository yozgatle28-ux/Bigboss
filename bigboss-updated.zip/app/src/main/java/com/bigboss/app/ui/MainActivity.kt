package com.bigboss.app.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bigboss.app.storage.MacroDefinition
import com.bigboss.app.storage.MacroStorage
import java.io.File
import java.util.UUID

/**
 * Ana ekran — Macrorify tarzı ÇOKLU macro listesi. Her macro bir kart:
 * ikon + isim + versiyon + EDIT/PLAY butonları. Sağ altta "+" ile yeni macro
 * sihirbazı (isim -> yön -> ikon). Bir karttan Edit/Play seçince o macro AKTİF olur.
 */
class MainActivity : AppCompatActivity() {

    private val accent = Color.parseColor("#7C4DFF")
    private val bgDark = Color.parseColor("#121212")
    private val surface = Color.parseColor("#1E1E1E")
    private val textPrimary = Color.parseColor("#F0F0F0")
    private val textSecondary = Color.parseColor("#AAAAAA")
    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MacroStorage.ensureAtLeastOne(this) // ilk açılış / eski veriden geçiş
        setContentView(buildRoot())
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList() // Edit/Play'den dönünce güncel kalsın
    }

    // ==================== Kök düzen ====================

    private fun buildRoot(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(bgDark) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(MATCH, MATCH)
        }

        // Üst başlık çubuğu
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(accent)
            setPadding(dp(20), dp(18), dp(20), dp(18))
            addView(TextView(this@MainActivity).apply {
                text = "BigBoss"
                setTextColor(Color.WHITE)
                textSize = 22f
                setTypeface(null, Typeface.BOLD)
            })
        })

        // Macro listesi (kaydırılabilir)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(90))
        }
        col.addView(ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, 0, 1f)
            addView(listContainer)
        })

        root.addView(col)

        // Sağ altta "+" FAB
        root.addView(TextView(this).apply {
            text = "+"
            setTextColor(Color.WHITE)
            textSize = 30f
            gravity = Gravity.CENTER
            background = roundBg(accent, dp(28))
            val lp = FrameLayout.LayoutParams(dp(56), dp(56))
            lp.gravity = Gravity.BOTTOM or Gravity.END
            lp.setMargins(0, 0, dp(24), dp(24))
            layoutParams = lp
            setOnClickListener { startCreateWizard() }
        })

        return root
    }

    // ==================== Liste ====================

    private fun refreshList() {
        listContainer.removeAllViews()
        val macros = MacroStorage.load(this).sortedByDescending { it.createdAt }

        if (macros.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "Henüz macro yok.\n\nSağ alttaki + ile ilk macronu oluştur."
                setTextColor(textSecondary)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(80), dp(24), dp(24))
            })
            return
        }

        macros.forEach { macro -> listContainer.addView(macroCard(macro)) }
    }

    private fun macroCard(macro: MacroDefinition): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(surface, dp(12))
            setPadding(dp(16), dp(16), dp(16), dp(12))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(0, 0, 0, dp(12))
            layoutParams = lp
        }

        // Üst satır: ikon + isim/versiyon
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topRow.addView(ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(Color.parseColor("#2A2A2A"), dp(8))
            val bmp = if (macro.iconPath.isNotBlank() && File(macro.iconPath).exists())
                BitmapFactory.decodeFile(macro.iconPath) else null
            if (bmp != null) setImageBitmap(bmp) else setImageResource(com.bigboss.app.R.drawable.app_logo)
        })
        topRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            addView(TextView(this@MainActivity).apply {
                text = macro.name
                setTextColor(textPrimary)
                textSize = 17f
                setTypeface(null, Typeface.BOLD)
            })
            addView(TextView(this@MainActivity).apply {
                val orient = if (macro.orientation == "LANDSCAPE") "Yatay" else "Dikey"
                text = "$orient · ${macro.width}x${macro.height} · v${macro.version}"
                setTextColor(textSecondary)
                textSize = 12f
            })
        })
        card.addView(topRow)

        // Alt satır: EDIT / PLAY / uc-nokta
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        btnRow.addView(textButton("EDIT MODE") { openMode(macro, edit = true) })
        btnRow.addView(textButton("PLAY MODE") { openMode(macro, edit = false) })
        btnRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) // esneme
        btnRow.addView(textButton("\u22EE") { showMacroOptions(macro) })
        card.addView(btnRow)

        return card
    }

    // ==================== Mod açma (aktif macro'yu ayarla) ====================

    private fun openMode(macro: MacroDefinition, edit: Boolean) {
        MacroStorage.setActiveId(this, macro.id)
        startActivity(Intent(this, if (edit) EditModeActivity::class.java else PlayModeActivity::class.java))
    }

    private fun showMacroOptions(macro: MacroDefinition) {
        val options = arrayOf("Yeniden adlandir", "Sil")
        AlertDialog.Builder(this)
            .setTitle(macro.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> renameMacro(macro)
                    1 -> confirmDelete(macro)
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun renameMacro(macro: MacroDefinition) {
        val input = EditText(this).apply { setText(macro.name) }
        AlertDialog.Builder(this)
            .setTitle("Yeniden adlandir")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                macro.name = input.text.toString().ifBlank { macro.name }
                MacroStorage.upsert(this, macro)
                refreshList()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun confirmDelete(macro: MacroDefinition) {
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage("'${macro.name}' ve TÜM verisi (kurallar, fonksiyonlar, scriptler, kütüphane) silinsin mi? Bu geri alinamaz.")
            .setPositiveButton("Sil") { _, _ ->
                MacroStorage.delete(this, macro.id)
                refreshList()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    // ==================== Oluşturma sihirbazı (isim -> yön -> ikon) ====================

    private fun startCreateWizard() {
        val draft = MacroDefinition(UUID.randomUUID().toString(), "")
        wizardName(draft)
    }

    private fun wizardName(draft: MacroDefinition) {
        val input = EditText(this).apply { hint = "Macro adi"; setText(draft.name) }
        AlertDialog.Builder(this)
            .setTitle("Yeni Macro")
            .setView(input)
            .setPositiveButton("İleri") { _, _ ->
                draft.name = input.text.toString().ifBlank { "İsimsiz Macro" }
                wizardOrientation(draft)
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun wizardOrientation(draft: MacroDefinition) {
        // Cihazın gerçek çözünürlüğünü referans al
        val dm = resources.displayMetrics
        val realW = dm.widthPixels
        val realH = dm.heightPixels
        val portrait = minOf(realW, realH) to maxOf(realW, realH)
        val landscape = maxOf(realW, realH) to minOf(realW, realH)

        val radioGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL; setPadding(dp(24), dp(8), dp(24), dp(8)) }
        val rbPortrait = RadioButton(this).apply { text = "Dikey (Portrait) — ${portrait.first}x${portrait.second}"; id = 1 }
        val rbLandscape = RadioButton(this).apply { text = "Yatay (Landscape) — ${landscape.first}x${landscape.second}"; id = 2 }
        radioGroup.addView(rbPortrait); radioGroup.addView(rbLandscape)
        if (draft.orientation == "LANDSCAPE") rbLandscape.isChecked = true else rbPortrait.isChecked = true

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "Bu macronun tasarlandigi yön. Farkli cihazlara doğru ölçeklenmesi için kritik."
                setPadding(dp(24), dp(12), dp(24), 0); textSize = 13f
            })
            addView(radioGroup)
        }

        AlertDialog.Builder(this)
            .setTitle("Yön (Orientation)")
            .setView(box)
            .setPositiveButton("İleri") { _, _ ->
                if (radioGroup.checkedRadioButtonId == 2) {
                    draft.orientation = "LANDSCAPE"; draft.width = landscape.first; draft.height = landscape.second
                } else {
                    draft.orientation = "PORTRAIT"; draft.width = portrait.first; draft.height = portrait.second
                }
                wizardIcon(draft)
            }
            .setNegativeButton("Geri") { _, _ -> wizardName(draft) }
            .show()
    }

    private fun wizardIcon(draft: MacroDefinition) {
        // İkon opsiyonel — şimdilik varsayılan kullanılır (galeri seçimi ileride).
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(16), dp(24), dp(8))
            addView(ImageView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
                setImageResource(com.bigboss.app.R.drawable.app_logo)
                background = roundBg(Color.parseColor("#2A2A2A"), dp(8))
            })
            addView(TextView(this@MainActivity).apply {
                text = "Bu adim opsiyonel — estetik amaçli. Şimdi 'Bitir'e basabilirsin."
                setPadding(0, dp(14), 0, 0); textSize = 13f; gravity = Gravity.CENTER
            })
        }
        AlertDialog.Builder(this)
            .setTitle("İkon")
            .setView(box)
            .setPositiveButton("Bitir") { _, _ -> finishCreate(draft) }
            .setNegativeButton("Geri") { _, _ -> wizardOrientation(draft) }
            .show()
    }

    private fun finishCreate(draft: MacroDefinition) {
        MacroStorage.upsert(this, draft)
        MacroStorage.setActiveId(this, draft.id) // yeni macro aktif olsun
        refreshList()
        Toast.makeText(this, "'${draft.name}' oluşturuldu", Toast.LENGTH_SHORT).show()
    }

    // ==================== yardımcılar ====================

    private fun textButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(accent)
        textSize = 14f
        setTypeface(null, Typeface.BOLD)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun roundBg(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    companion object {
        private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        private const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    }
}
