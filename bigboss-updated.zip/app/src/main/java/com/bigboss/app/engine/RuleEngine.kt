package com.bigboss.app.engine

import android.graphics.Bitmap
import android.util.Log

interface ActionExecutor {
    fun execute(action: Action)
}

/**
 * Macrorify'ın GERÇEK motor mantığı: PARALEL / REAKTİF, artık "Loop"
 * yaşam döngüsü de destekleniyor:
 *
 *  - NONE: kural bir kere denenir (başarılı olsun olmasın), sonra
 *    kendini devre dışı bırakır ("tarar ve durur").
 *  - ALWAYS: normal sürekli davranış — sonsuz döngü, hiç durmaz.
 *  - WHILE_SUCCESS: koşul doğru olana kadar bekler, doğru olunca BİR
 *    KERE tetiklenir ve kendini durdurur.
 *  - WHILE_FAIL: koşul doğru olduğu sürece tetiklenmeye devam eder;
 *    koşul YANLIŞA dönünce (kaybolunca) kendini durdurur.
 */
class RuleEngine(
    private val executor: ActionExecutor
) {
    companion object {
        /** "Infinite Loop" için güvenlik üst sınırı — kullanıcı gerçekten sınırsız istese bile motor thread'i sonsuza kadar kilitlemesin diye. */
        private const val MAX_SAFE_INFINITE_LOOP_MS = 5 * 60_000L
    }
    private var rules: List<Rule> = emptyList()
    private var functionsProvider: (String) -> List<Rule> = { emptyList() }

    /** "NONE/WHILE_SUCCESS/WHILE_FAIL" ömrünü tamamlamış kural id'leri — bir daha kontrol edilmez. */
    private val completedRuleIds = mutableSetOf<String>()
    /** WHILE_FAIL için: bu kural en az bir kez başarılı oldu mu (kaybolma anını tespit etmek için). */
    private val everSucceededIds = mutableSetOf<String>()
    /** "Tarama Süresi" (Timeout) için: koşul SÜREKLİ doğru kalmaya ne zaman başladı. */
    private val truthSince = mutableMapOf<String, Long>()
    /** "Tarama Hızı" (Scan Rate) için: bu kural en son ne zaman KONTROL edildi (pil tasarrufu). */
    private val lastCheckedAt = mutableMapOf<String, Long>()
    /** "Otomatik Durdurma" (art arda BULUNAMADI) için: bu kural üst üste kaç kere bulunamadı. */
    private val consecutiveFailCount = mutableMapOf<String, Int>()

    @Volatile var paused: Boolean = true

    fun setRules(newRules: List<Rule>) {
        rules = newRules
        completedRuleIds.clear()
        everSucceededIds.clear()
        truthSince.clear()
        lastCheckedAt.clear()
        consecutiveFailCount.clear()
    }

    /** "Stop" butonu için: NONE/WHILE_SUCCESS/WHILE_FAIL kurallarının "bitti" durumunu sıfırlar — bir sonraki Play baştan başlar. */
    fun resetLoopState() {
        completedRuleIds.clear()
        everSucceededIds.clear()
        truthSince.clear()
        lastCheckedAt.clear()
        consecutiveFailCount.clear()
        ActionResultRegistry.reset()
        MatchLocationRegistry.reset()
    }

    fun setFunctionsProvider(provider: (String) -> List<Rule>) {
        functionsProvider = provider
    }

    fun lastFiredAt(ruleId: String): Long? = ActionResultRegistry.lastFiredAt(ruleId)

    fun onFrame(frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rules) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    fun evaluateRulesOnce(rulesToRun: List<Rule>, frame: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        for (rule in rulesToRun) {
            if (!rule.enabled) continue
            evaluateAndMaybeFire(rule, frame, now)
        }
    }

    private fun evaluateAndMaybeFire(rule: Rule, frame: Bitmap, now: Long) {
        if (rule.id in completedRuleIds) return

        // "Tarama Hızı" (Scan Rate): pil tasarrufu için bu kuralı saniyede en fazla N kere
        // KONTROL ediyoruz — 0 ise sınırsız (mevcut en hızlı davranış, önceki gibi).
        if (rule.scanRateHz > 0f) {
            val minIntervalMs = (1000f / rule.scanRateHz).toLong()
            val lastChecked = lastCheckedAt[rule.id]
            if (lastChecked != null && now - lastChecked < minIntervalMs) return
            lastCheckedAt[rule.id] = now
        }

        val conditionMatched = try {
            rule.condition.evaluate(frame)
        } catch (e: Exception) {
            Log.e("RuleEngine", "Koşul değerlendirme hatası: ${rule.id}", e)
            false
        }
        // "Relative Coordinates" (Locatable Detection) için: bu kuralın koşulu HAM olarak
        // (negate/cooldown'dan bağımsız) doğru bulunduysa, BULUNDUĞU KONUMU kaydet — başka
        // kurallar bunu "anchor" (referans nokta) olarak kullanabilsin diye.
        if (conditionMatched) {
            try {
                rule.condition.matchLocation(frame)?.let { (mx, my) -> MatchLocationRegistry.record(rule.id, mx, my) }
            } catch (e: Exception) {
                // Konum kaydı başarısız olsa bile ana değerlendirme akışı etkilenmesin.
            }
        }
        val success = if (rule.negate) !conditionMatched else conditionMatched

        // "Otomatik Durdurma" (art arda BULUNAMADI): sadece GERÇEKTEN kontrol edilen turlarda sayılır
        // (Tarama Hızı ile sınırlıysa, ardı ardına gelen saniyeler anlamına gelir — ham kare değil).
        if (rule.maxConsecutiveFailures > 0) {
            if (success) {
                consecutiveFailCount[rule.id] = 0
            } else {
                val count = (consecutiveFailCount[rule.id] ?: 0) + 1
                consecutiveFailCount[rule.id] = count
                if (count >= rule.maxConsecutiveFailures) {
                    completedRuleIds.add(rule.id) // art arda çok fazla bulunamadı, kendini durdur
                    return
                }
            }
        }

        // "Tarama Süresi" (Timeout): success olsa bile, en az bu kadar SÜREKLİ (kesintisiz) doğru
        // kalmadıkça "ateşlenmeye hazır" sayılmaz — kısa titreşim/yanlış pozitifleri eler.
        if (!success) truthSince.remove(rule.id)
        val readyToFire = if (success && rule.scanTimeoutMs > 0) {
            val since = truthSince.getOrPut(rule.id) { now }
            now - since >= rule.scanTimeoutMs
        } else success

        when (rule.loopMode) {
            "NONE" -> {
                // NONE zaten TEK bir denemede karar veriyor, süre boyunca beklemek onun mantığıyla çelişir.
                if (success) fireWithDelay(rule, frame, now)
                completedRuleIds.add(rule.id) // ne olursa olsun tek seferlik
                return
            }
            "WHILE_SUCCESS" -> {
                if (!readyToFire) return
                val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - last < rule.cooldownMs) return
                fireWithDelay(rule, frame, now)
                completedRuleIds.add(rule.id) // yakaladı, bir kere ateşle, bitir
                return
            }
            "WHILE_FAIL" -> {
                if (success) {
                    everSucceededIds.add(rule.id)
                } else if (rule.id in everSucceededIds) {
                    completedRuleIds.add(rule.id) // daha önce vardı, şimdi kayboldu -> bitir
                    return
                }
                if (!readyToFire) return
                val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - last < rule.cooldownMs) return
                fireWithDelay(rule, frame, now)
                return
            }
            else -> { // "ALWAYS" (varsayılan, sürekli)
                if (!readyToFire) return
                val last = ActionResultRegistry.lastFiredAt(rule.id) ?: 0L
                if (now - last < rule.cooldownMs) return
                fireWithDelay(rule, frame, now)
            }
        }
    }

    private fun fireWithDelay(rule: Rule, frame: Bitmap, now: Long) {
        ActionResultRegistry.markFired(rule.id)
        if (rule.matchDelayMs > 0) Thread.sleep(rule.matchDelayMs)
        fireAction(rule, rule.thenAction, frame, now)
    }

    private fun fireAction(rule: Rule, action: Action, frame: Bitmap, now: Long) {
        val callAction = extractCallFunction(action)
        if (callAction != null) {
            if (action is Action.Sequence) {
                action.steps.filter { it !is Action.CallFunction }.forEach { resolveAndExecute(rule, it, frame) }
            }
            val funcRules = functionsProvider(callAction.functionId)
            if (callAction.infiniteLoop) {
                // GÜVENLİK: gerçekten sınırsız bir döngü motor thread'ini sonsuza kadar kilitleyip
                // uygulamayı tamamen tepkisiz bırakabilir. Kullanıcı "sınırsız" dese bile (timeLimitMs=0),
                // motor kendi güvenlik üst sınırını (5 dakika) uygular — Macrorify'da da bu risk var,
                // biz sadece donmayı önlemek için ek bir çıpa koyuyoruz.
                // HATA DÜZELTMESİ: bu döngü hiç bekleme koymadan sürekli dönüyordu, motor
                // thread'ini %100 CPU'ya kilitleyip pili tüketiyor ve cihazı ısıtıyordu.
                // Kural değerlendirmesi zaten her karede tekrar tetiklenecek şekilde
                // tasarlandığından, aralara küçük bir bekleme koymak davranışı bozmadan
                // CPU'yu serbest bırakır.
                val effectiveLimitMs = if (callAction.timeLimitMs > 0) callAction.timeLimitMs else MAX_SAFE_INFINITE_LOOP_MS
                val loopStart = System.currentTimeMillis()
                while (System.currentTimeMillis() - loopStart < effectiveLimitMs) {
                    for (funcRule in funcRules) {
                        if (!funcRule.enabled) continue
                        evaluateAndMaybeFire(funcRule, frame, now)
                    }
                    Thread.sleep(16L) // ~60 kontrol/saniye üst sınırı, busy-loop'u önler
                }
            } else {
                repeat(callAction.repeat.coerceAtLeast(1)) {
                    for (funcRule in funcRules) {
                        if (!funcRule.enabled) continue
                        evaluateAndMaybeFire(funcRule, frame, now)
                    }
                }
            }
        } else {
            resolveAndExecute(rule, action, frame)
        }
    }

    /**
     * KULLANICI RAPORU: bir swipe'ın hold süresini 0'dan 300'e çıkarınca "sistem artık
     * çalışmıyor" (test/Play Mode bir daha tepki vermiyor). `continueStroke` API kullanımını
     * Android'in KENDİ resmi test paterniyle karşılaştırdım — birebir doğru, bir API-kullanım
     * hatası DEĞİL. Kesin bir çökme noktası bulamadım, ama kök neden NE OLURSA OLSUN motoru
     * korumak için: bu fonksiyon artık TÜM gövdeyi try-catch içine alıyor — TEK bir aksiyonun
     * (örn. Android'in gesture API'sinin nadir bir cihazda/durumda fırlattığı beklenmedik bir
     * exception) YAKALANMAMIŞ hâlde motorun ANA DÖNGÜSÜNE sızıp TÜM sistemi durdurmasını
     * engelliyor — hata sadece o TEK karede loglanıp yutuluyor, motor bir SONRAKİ karede
     * NORMAL çalışmaya devam ediyor.
     */
    private fun resolveAndExecute(rule: Rule, action: Action, frame: Bitmap) {
        try {
            when (action) {
                is Action.TapAtMatch -> {
                    val loc = rule.condition.matchLocation(frame)
                    if (loc != null) executor.execute(Action.Tap(loc.first, loc.second, action.repeat, action.holdMs, action.postDelayMs, action.randomOffsetPx))
                }
                is Action.TapAllMatches -> {
                    val locs = rule.condition.matchLocations(frame)
                    locs.forEach { (mx, my) -> executor.execute(Action.Tap(mx, my, action.repeat, action.holdMs, action.postDelayMs, action.randomOffsetPx)) }
                }
                is Action.ReadTextToVariable -> {
                    val region = com.bigboss.app.model.Region(action.regionX, action.regionY, action.regionW, action.regionH)
                    val text = TextMatcher.readText(frame, region, action.whitelist, action.blacklist)
                    val number = text?.let { Regex("-?\\d+").find(it)?.value?.toIntOrNull() } ?: action.defaultValue
                    VariableStore.set(action.variableName, number)
                }
                is Action.Sequence -> action.steps.forEach { resolveAndExecute(rule, it, frame) }
                else -> executor.execute(action)
            }
        } catch (e: Exception) {
            android.util.Log.e("BigBossRuleEngine", "Aksiyon çalıştırılırken hata (kural: ${rule.id}): ${e.message}", e)
            ActionResultRegistry.recordActionError("${rule.id.take(8)}: ${e.javaClass.simpleName} — ${e.message}")
        }
    }

    private fun extractCallFunction(action: Action): Action.CallFunction? = when (action) {
        is Action.CallFunction -> action
        is Action.Sequence -> action.steps.filterIsInstance<Action.CallFunction>().firstOrNull()
        else -> null
    }
}
