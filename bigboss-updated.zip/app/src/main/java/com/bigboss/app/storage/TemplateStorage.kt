package com.bigboss.app.storage

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Kural editöründe "Resim Ara" seçildiğinde, kullanıcının çizdiği bölgeden
 * kırpılan görüntüyü diske kaydeder. Kaydedilen dosya yolu RuleDefinition
 * içinde templatePath olarak saklanır.
 */
object TemplateStorage {

    @Synchronized
    fun save(context: Context, bitmap: Bitmap): String {
        val dir = File(context.filesDir, "templates").apply { mkdirs() }
        val file = File(dir, "${UUID.randomUUID()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file.absolutePath
    }

    @Synchronized
    fun delete(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            File(path).delete()
        } catch (_: Exception) {
        }
    }
}
