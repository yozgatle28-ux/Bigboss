package com.bigboss.app.emscript

/**
 * EMScript kodunu tek çağrıyla çalıştıran kolaylık katmanı.
 * Lexer -> Parser -> Interpreter zincirini kurar, host API'sini enjekte eder,
 * ve hataları yakalayıp okunaklı mesaja çevirir.
 *
 * Saf Kotlin: EmHost dışarıdan verilir (Android tarafı AndroidEmHost'u geçer,
 * test tarafı MockHost'u). Bu sayede runner'ın kendisi de izole test edilebilir.
 */
object EmScriptRunner {

    /**
     * Bir EMScript kodunu çalıştırır.
     * @param code    EMScript kaynak kodu
     * @param host    cihaz köprüsü
     * @param maxSteps sonsuz döngü koruması (0=kapalı). Varsayılan makul bir üst sınır.
     * @return null başarılıysa; hata mesajı başarısızsa.
     */
    fun run(code: String, host: EmHost, maxSteps: Long = 50_000_000): String? {
        return try {
            val tokens = Lexer(code).scanTokens()
            val statements = Parser(tokens).parse()
            val interpreter = Interpreter()
            interpreter.maxSteps = maxSteps
            EmStdLib.install(interpreter, host)
            interpreter.interpret(statements)
            null
        } catch (e: EmScriptError) {
            "EMScript hatası: ${e.message}"
        } catch (e: Interpreter.ReturnSignal) {
            null // en üst düzeyde return — zararsız
        } catch (e: Interpreter.BreakSignal) {
            "EMScript hatası: 'break' döngü dışında kullanılamaz"
        } catch (e: Interpreter.ContinueSignal) {
            "EMScript hatası: 'continue' döngü dışında kullanılamaz"
        } catch (e: StackOverflowError) {
            "EMScript hatası: çok derin özyineleme (stack overflow)"
        } catch (e: Exception) {
            "EMScript beklenmeyen hata: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    /**
     * Sadece söz dizimini kontrol eder (çalıştırmadan). Kod editöründe "doğrula" için.
     * @return null geçerliyse; hata mesajı geçersizse.
     */
    fun validate(code: String): String? {
        return try {
            val tokens = Lexer(code).scanTokens()
            Parser(tokens).parse()
            null
        } catch (e: EmScriptError) {
            e.message
        } catch (e: Exception) {
            e.message ?: "Bilinmeyen söz dizimi hatası"
        }
    }
}
