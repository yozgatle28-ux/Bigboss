package com.bigboss.app.emscript

/**
 * EMScript Lexer (tokenizer): kaynak metni token dizisine çevirir.
 * Yorumlar (// ...), boşluklar atlanır. String'lerde \n \t \" \\ kaçışları desteklenir.
 */
class Lexer(private val source: String) {

    private val tokens = mutableListOf<Token>()
    private var start = 0
    private var current = 0
    private var line = 1

    private val keywords = mapOf(
        "var" to TokenType.VAR, "fun" to TokenType.FUN, "class" to TokenType.CLASS,
        "if" to TokenType.IF, "else" to TokenType.ELSE, "for" to TokenType.FOR,
        "while" to TokenType.WHILE, "do" to TokenType.DO, "return" to TokenType.RETURN,
        "break" to TokenType.BREAK, "continue" to TokenType.CONTINUE,
        "new" to TokenType.NEW, "static" to TokenType.STATIC, "init" to TokenType.INIT,
        "this" to TokenType.THIS, "true" to TokenType.TRUE, "false" to TokenType.FALSE,
        "null" to TokenType.NULL
    )

    fun scanTokens(): List<Token> {
        while (!isAtEnd()) {
            start = current
            scanToken()
        }
        tokens.add(Token(TokenType.EOF, "", null, line))
        return tokens
    }

    private fun scanToken() {
        val c = advance()
        when (c) {
            '(' -> add(TokenType.LPAREN)
            ')' -> add(TokenType.RPAREN)
            '{' -> add(TokenType.LBRACE)
            '}' -> add(TokenType.RBRACE)
            '[' -> add(TokenType.LBRACKET)
            ']' -> add(TokenType.RBRACKET)
            ',' -> add(TokenType.COMMA)
            '.' -> add(TokenType.DOT)
            ';' -> add(TokenType.SEMICOLON)
            ':' -> add(TokenType.COLON)
            '?' -> add(TokenType.QUESTION)
            '+' -> add(if (match('=')) TokenType.PLUS_ASSIGN else TokenType.PLUS)
            '-' -> add(if (match('=')) TokenType.MINUS_ASSIGN else TokenType.MINUS)
            '*' -> add(if (match('=')) TokenType.STAR_ASSIGN else TokenType.STAR)
            '%' -> add(TokenType.PERCENT)
            '/' -> {
                if (match('/')) {
                    // satır yorumu
                    while (peek() != '\n' && !isAtEnd()) advance()
                } else if (match('*')) {
                    // blok yorumu
                    blockComment()
                } else if (match('=')) {
                    add(TokenType.SLASH_ASSIGN)
                } else {
                    add(TokenType.SLASH)
                }
            }
            '!' -> add(if (match('=')) TokenType.NEQ else TokenType.NOT)
            '=' -> add(if (match('=')) TokenType.EQ else if (match('>')) TokenType.ARROW else TokenType.ASSIGN)
            '<' -> add(if (match('=')) TokenType.LE else TokenType.LT)
            '>' -> add(if (match('=')) TokenType.GE else TokenType.GT)
            '&' -> if (match('&')) add(TokenType.AND) else throw EmScriptError("Beklenmeyen '&' (belki '&&'?)", line)
            '|' -> if (match('|')) add(TokenType.OR) else throw EmScriptError("Beklenmeyen '|' (belki '||'?)", line)
            ' ', '\r', '\t' -> {}
            '\n' -> line++
            '"' -> string('"')
            '\'' -> string('\'')
            else -> {
                if (c.isDigit()) number()
                else if (isAlpha(c)) identifier()
                else throw EmScriptError("Beklenmeyen karakter: '$c'", line)
            }
        }
    }

    private fun blockComment() {
        // iç içe blok yorumu desteklenmez; ilk */ ile kapanır
        while (!isAtEnd()) {
            if (peek() == '*' && peekNext() == '/') { advance(); advance(); return }
            if (peek() == '\n') line++
            advance()
        }
        throw EmScriptError("Kapanmamış blok yorumu (*/)", line)
    }

    private fun string(quote: Char) {
        val sb = StringBuilder()
        while (peek() != quote && !isAtEnd()) {
            val ch = peek()
            if (ch == '\n') line++
            if (ch == '\\') {
                advance() // ters eğik çizgiyi tüket
                val esc = advance()
                when (esc) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    'r' -> sb.append('\r')
                    '"' -> sb.append('"')
                    '\'' -> sb.append('\'')
                    '\\' -> sb.append('\\')
                    else -> sb.append(esc)
                }
            } else {
                sb.append(advance())
            }
        }
        if (isAtEnd()) throw EmScriptError("Kapanmamış metin (string)", line)
        advance() // kapanış tırnağı
        tokens.add(Token(TokenType.STRING, sb.toString(), sb.toString(), line))
    }

    private fun number() {
        while (peek().isDigit()) advance()
        if (peek() == '.' && peekNext().isDigit()) {
            advance()
            while (peek().isDigit()) advance()
        }
        val text = source.substring(start, current)
        tokens.add(Token(TokenType.NUMBER, text, text.toDouble(), line))
    }

    private fun identifier() {
        while (isAlphaNumeric(peek())) advance()
        val text = source.substring(start, current)
        val type = keywords[text] ?: TokenType.IDENTIFIER
        add(type)
    }

    // ---- yardımcılar ----
    private fun isAtEnd() = current >= source.length
    private fun advance() = source[current++]
    private fun peek() = if (isAtEnd()) '\u0000' else source[current]
    private fun peekNext() = if (current + 1 >= source.length) '\u0000' else source[current + 1]
    private fun match(expected: Char): Boolean {
        if (isAtEnd() || source[current] != expected) return false
        current++
        return true
    }
    private fun isAlpha(c: Char) = c.isLetter() || c == '_'
    private fun isAlphaNumeric(c: Char) = isAlpha(c) || c.isDigit()
    private fun add(type: TokenType) {
        tokens.add(Token(type, source.substring(start, current), null, line))
    }
}
