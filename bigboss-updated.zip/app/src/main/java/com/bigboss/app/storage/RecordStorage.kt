package com.bigboss.app.storage

import android.content.Context
import com.bigboss.app.engine.Action
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * Kayıtları (RecordDefinition) macro'ya göre ayrılmış olarak saklar (MacroScope).
 * Ayrıca bir kaydı, mevcut motorun çalıştırabileceği bir Action listesine çevirir
 * (Play Record için ayrı bir oynatma altyapısına gerek kalmaz).
 */
object RecordStorage {

    private const val FILE_NAME = "records.json"
    private val gson = Gson()

    @Synchronized
    fun load(context: Context): MutableList<RecordDefinition> {
        val file = MacroScope.file(context, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<RecordDefinition>>() {}.type
            gson.fromJson(file.readText(), type) ?: mutableListOf()
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    @Synchronized
    fun save(context: Context, records: List<RecordDefinition>) {
        MacroScope.file(context, FILE_NAME).writeText(gson.toJson(records))
    }

    @Synchronized
    fun upsert(context: Context, record: RecordDefinition) {
        val records = load(context)
        val idx = records.indexOfFirst { it.id == record.id }
        if (idx >= 0) records[idx] = record else records.add(record)
        save(context, records)
    }

    @Synchronized
    fun find(context: Context, id: String): RecordDefinition? = load(context).find { it.id == id }
    @Synchronized
    fun findByName(context: Context, name: String): RecordDefinition? = load(context).find { it.name == name }

    @Synchronized
    fun delete(context: Context, id: String) {
        val records = load(context)
        records.removeAll { it.id == id }
        save(context, records)
    }

    /**
     * Bir kaydı, mevcut motorun çalıştırabileceği Action listesine çevirir.
     * Olaylar arası bekleme (startOffsetMs farkı) Action.Wait ile korunur, böylece
     * kaydın orijinal zamanlaması oynatmada da geçerli olur.
     */
    @Synchronized
    fun toActions(record: RecordDefinition): List<Action> {
        val actions = mutableListOf<Action>()
        var lastEnd = 0L
        record.events.sortedBy { it.startOffsetMs }.forEach { e ->
            // Bir önceki olayın bitişinden bu olayın başlangıcına kadar bekle
            val gap = e.startOffsetMs - lastEnd
            if (gap > 0) actions.add(Action.Wait(gap))
            when (e.type) {
                "SWIPE" -> actions.add(Action.Swipe(e.x, e.y, e.x2, e.y2, e.durationMs.coerceAtLeast(1)))
                else -> actions.add(Action.Tap(e.x, e.y, 1, e.durationMs.coerceAtLeast(1)))
            }
            lastEnd = e.startOffsetMs + e.durationMs
        }
        return actions
    }
}
