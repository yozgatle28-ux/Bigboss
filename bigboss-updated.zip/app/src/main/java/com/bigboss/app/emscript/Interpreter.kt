package com.bigboss.app.emscript

/** Kullanıcı tanımlı fonksiyon / lambda / metot. closure ile tanımlandığı scope'u taşır. */
class EmFunction(
    private val declName: String,
    private val params: List<Token>,
    private val body: List<Stmt>,
    private val exprBody: Expr?,   // lambda tek-ifade gövdesi (varsa)
    private val closure: Environment,
    private val boundThis: EmInstance? = null
) : EmCallable {
    override val arity: Int get() = params.size
    override fun name() = declName

    /** Metodu bir örneğe bağlar (this'i sabitler). */
    fun bind(instance: EmInstance): EmFunction =
        EmFunction(declName, params, body, exprBody, closure, instance)

    override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
        val env = Environment(closure)
        if (boundThis != null) env.define("this", boundThis)
        for (i in params.indices) env.define(params[i].lexeme, args.getOrNull(i))
        // lambda tek ifade gövdesi
        if (exprBody != null) return interpreter.evaluatePublic(exprBody, env)
        return try {
            interpreter.executeBlock(body, env)
            null
        } catch (r: Interpreter.ReturnSignal) {
            r.value
        }
    }
}

/**
 * EMScript Interpreter — AST'yi tree-walking ile çalıştırır.
 * Host köprüsü: native fonksiyonlar (tap, swipe, find, Con.out...) dışarıdan `globals`'a
 * define edilir. Böylece dil çekirdeği Android'den bağımsızdır ve izole test edilebilir.
 */
class Interpreter {

    val globals = Environment()
    private var environment = globals

    /** return sinyali (Kotlin exception ile akış kontrolü). */
    class ReturnSignal(val value: Any?) : RuntimeException(null, null, false, false)
    /** break/continue sinyalleri. */
    class BreakSignal : RuntimeException(null, null, false, false)
    class ContinueSignal : RuntimeException(null, null, false, false)

    /** Sonsuz döngü koruması: adım sayacı. 0 = kapalı. */
    var maxSteps: Long = 0
    private var steps: Long = 0

    fun interpret(statements: List<Stmt>) {
        steps = 0
        for (s in statements) execute(s)
    }

    /** Tek bir ifadeyi değerlendirip sonucu döndürür (REFERENCE değişkenleri / tek satır için). */
    fun evalExpression(statements: List<Stmt>): Any? {
        steps = 0
        var last: Any? = null
        for (s in statements) {
            last = if (s is Stmt.Expression) evaluate(s.expr) else { execute(s); null }
        }
        return last
    }

    // ==================== Deyim çalıştırma ====================

    private fun execute(stmt: Stmt) {
        tick()
        when (stmt) {
            is Stmt.Var -> environment.define(stmt.name.lexeme, stmt.initializer?.let { evaluate(it) })
            is Stmt.Expression -> evaluate(stmt.expr)
            is Stmt.Block -> executeBlock(stmt.statements, Environment(environment))
            is Stmt.If -> {
                if (truthy(evaluate(stmt.cond))) execute(stmt.thenB)
                else stmt.elseB?.let { execute(it) }
            }
            is Stmt.While -> {
                while (truthy(evaluate(stmt.cond))) {
                    try { execute(stmt.body) }
                    catch (b: BreakSignal) { break }
                    catch (c: ContinueSignal) { /* devam */ }
                    tick()
                }
            }
            is Stmt.DoWhile -> {
                do {
                    try { execute(stmt.body) }
                    catch (b: BreakSignal) { break }
                    catch (c: ContinueSignal) { }
                    tick()
                } while (truthy(evaluate(stmt.cond)))
            }
            is Stmt.For -> {
                val prev = environment
                environment = Environment(environment)
                try {
                    stmt.init?.let { execute(it) }
                    while (stmt.cond?.let { truthy(evaluate(it)) } != false) {
                        try { execute(stmt.body) }
                        catch (b: BreakSignal) { break }
                        catch (c: ContinueSignal) { }
                        stmt.step?.let { evaluate(it) }
                        tick()
                    }
                } finally { environment = prev }
            }
            is Stmt.ForEach -> {
                val iterable = evaluate(stmt.iterable)
                val list: List<Any?> = when (iterable) {
                    is EmArray -> iterable.elements.toList()
                    is String -> iterable.map { it.toString() }
                    else -> throw EmScriptError("foreach yalnızca dizi/metin üzerinde çalışır", stmt.varName.line)
                }
                val prev = environment
                environment = Environment(environment)
                try {
                    for (item in list) {
                        environment.define(stmt.varName.lexeme, item)
                        try { execute(stmt.body) }
                        catch (b: BreakSignal) { break }
                        catch (c: ContinueSignal) { }
                        tick()
                    }
                } finally { environment = prev }
            }
            is Stmt.Function -> {
                val fn = EmFunction(stmt.name.lexeme, stmt.params, stmt.body, null, environment)
                environment.define(stmt.name.lexeme, fn)
            }
            is Stmt.Return -> throw ReturnSignal(stmt.value?.let { evaluate(it) })
            is Stmt.Break -> throw BreakSignal()
            is Stmt.Continue -> throw ContinueSignal()
            is Stmt.Class -> {
                val methods = stmt.methods.associate { m ->
                    m.name.lexeme to EmFunction(m.name.lexeme, m.params, m.body, null, environment)
                }
                val statics = stmt.staticMethods.associate { m ->
                    m.name.lexeme to EmFunction(m.name.lexeme, m.params, m.body, null, environment)
                }
                val klass = EmClass(stmt.name.lexeme, stmt.initParams, stmt.initBody, methods, statics, environment)
                environment.define(stmt.name.lexeme, klass)
            }
        }
    }

    fun executeBlock(statements: List<Stmt>, env: Environment) {
        val previous = environment
        environment = env
        try {
            for (s in statements) execute(s)
        } finally {
            environment = previous
        }
    }

    // ==================== İfade değerlendirme ====================

    fun evaluatePublic(expr: Expr, env: Environment): Any? {
        val prev = environment
        environment = env
        try { return evaluate(expr) } finally { environment = prev }
    }

    private fun evaluate(expr: Expr): Any? {
        tick()
        return when (expr) {
            is Expr.Literal -> expr.value
            is Expr.Variable -> environment.get(expr.name)
            is Expr.This -> environment.getByName("this")
                ?: throw EmScriptError("'this' yalnızca metot içinde geçerli", expr.keyword.line)
            is Expr.ArrayLiteral -> EmArray(expr.elements.map { evaluate(it) }.toMutableList())
            is Expr.Assign -> evalAssign(expr)
            is Expr.Unary -> evalUnary(expr)
            is Expr.Binary -> evalBinary(expr)
            is Expr.Logical -> evalLogical(expr)
            is Expr.Ternary -> if (truthy(evaluate(expr.cond))) evaluate(expr.thenE) else evaluate(expr.elseE)
            is Expr.Get -> evalGet(expr)
            is Expr.Index -> evalIndex(expr)
            is Expr.Call -> evalCall(expr)
            is Expr.New -> evalNew(expr)
            is Expr.Lambda -> EmFunction("<lambda>", expr.params, expr.body, expr.exprBody, environment)
        }
    }

    private fun evalAssign(expr: Expr.Assign): Any? {
        val newValue = evaluate(expr.value)
        return when (val target = expr.target) {
            is Expr.Variable -> {
                val v = applyCompound(expr.op, { environment.get(target.name) }, newValue)
                environment.assign(target.name, v)
                v
            }
            is Expr.Get -> {
                val obj = evaluate(target.obj)
                if (obj !is EmInstance) throw EmScriptError("Yalnızca nesne alanına atanabilir", target.name.line)
                val v = applyCompound(expr.op, { obj.get(target.name.lexeme) }, newValue)
                obj.set(target.name.lexeme, v)
                v
            }
            is Expr.Index -> {
                val obj = evaluate(target.obj)
                if (obj is EmMap) {
                    val key = evaluate(target.index)
                    val v = applyCompound(expr.op, { obj.map[key] }, newValue)
                    obj.map[key] = v
                    return v
                }
                val idx = toInt(evaluate(target.index))
                if (obj !is EmArray) throw EmScriptError("Yalnızca dizi/map'e indeksle atanabilir", target.bracket.line)
                val v = applyCompound(expr.op, { obj.get(idx) }, newValue)
                obj.set(idx, v)
                v
            }
            else -> throw EmScriptError("Geçersiz atama hedefi")
        }
    }

    /** += -= *= /= için mevcut değerle birleştir; = için doğrudan yeni değer. */
    private fun applyCompound(op: Token, current: () -> Any?, rhs: Any?): Any? {
        return when (op.type) {
            TokenType.ASSIGN -> rhs
            TokenType.PLUS_ASSIGN -> plus(current(), rhs, op)
            TokenType.MINUS_ASSIGN -> arith(current(), rhs, op) { a, b -> a - b }
            TokenType.STAR_ASSIGN -> arith(current(), rhs, op) { a, b -> a * b }
            TokenType.SLASH_ASSIGN -> arith(current(), rhs, op) { a, b -> a / b }
            else -> rhs
        }
    }

    private fun evalUnary(expr: Expr.Unary): Any? {
        val right = evaluate(expr.right)
        return when (expr.op.type) {
            TokenType.MINUS -> -toNum(right, expr.op)
            TokenType.NOT -> !truthy(right)
            else -> throw EmScriptError("Bilinmeyen tekli işleç ${expr.op.lexeme}", expr.op.line)
        }
    }

    private fun evalLogical(expr: Expr.Logical): Any? {
        val left = evaluate(expr.left)
        if (expr.op.type == TokenType.OR) {
            if (truthy(left)) return left
        } else { // AND
            if (!truthy(left)) return left
        }
        return evaluate(expr.right)
    }

    private fun evalBinary(expr: Expr.Binary): Any? {
        val left = evaluate(expr.left)
        val right = evaluate(expr.right)
        return when (expr.op.type) {
            TokenType.PLUS -> plus(left, right, expr.op)
            TokenType.MINUS -> arith(left, right, expr.op) { a, b -> a - b }
            TokenType.STAR -> arith(left, right, expr.op) { a, b -> a * b }
            TokenType.SLASH -> arith(left, right, expr.op) { a, b -> a / b }
            TokenType.PERCENT -> arith(left, right, expr.op) { a, b -> a % b }
            TokenType.GT -> toNum(left, expr.op) > toNum(right, expr.op)
            TokenType.GE -> toNum(left, expr.op) >= toNum(right, expr.op)
            TokenType.LT -> toNum(left, expr.op) < toNum(right, expr.op)
            TokenType.LE -> toNum(left, expr.op) <= toNum(right, expr.op)
            TokenType.EQ -> isEqual(left, right)
            TokenType.NEQ -> !isEqual(left, right)
            else -> throw EmScriptError("Bilinmeyen işleç ${expr.op.lexeme}", expr.op.line)
        }
    }

    private fun evalGet(expr: Expr.Get): Any? {
        val obj = evaluate(expr.obj)
        val nameStr = expr.name.lexeme
        return when (obj) {
            is EmInstance -> obj.get(nameStr)
            is EmArray -> arrayMember(obj, nameStr, expr.name.line)
            is String -> stringMember(obj, nameStr, expr.name.line)
            is EmMap -> mapMember(obj, nameStr, expr.name.line)
            is EmClass -> obj.findStatic(nameStr)
                ?: throw EmScriptError("'${obj.emName}' sınıfında static '$nameStr' yok", expr.name.line)
            is EmHostObject -> obj.get(nameStr)
                ?: throw EmScriptError("'$nameStr' bulunamadı", expr.name.line)
            else -> throw EmScriptError("'$nameStr' erişilemez (nesne değil)", expr.name.line)
        }
    }

    private fun evalIndex(expr: Expr.Index): Any? {
        val obj = evaluate(expr.obj)
        if (obj is EmMap) return obj.map[evaluate(expr.index)]
        val idx = toInt(evaluate(expr.index))
        return when (obj) {
            is EmArray -> obj.get(idx)
            is String -> if (idx in obj.indices) obj[idx].toString() else ""
            else -> throw EmScriptError("İndekslenemez (dizi/metin/map değil)", expr.bracket.line)
        }
    }

    private fun evalCall(expr: Expr.Call): Any? {
        val callee = evaluate(expr.callee)
        val args = expr.args.map { evaluate(it) }
        if (callee !is EmCallable) throw EmScriptError("Çağrılabilir değil: ${stringify(callee)}", expr.paren.line)
        if (callee.arity != -1 && args.size != callee.arity) {
            // Esnek: eksik argümanları null, fazlasını yok say (dinamik dil davranışı)
        }
        return callee.call(this, args)
    }

    private fun evalNew(expr: Expr.New): Any? {
        val klass = environment.getByName(expr.className.lexeme)
            ?: throw EmScriptError("Bilinmeyen sınıf '${expr.className.lexeme}'", expr.className.line)
        if (klass !is EmClass) throw EmScriptError("'${expr.className.lexeme}' bir sınıf değil", expr.className.line)
        val args = expr.args.map { evaluate(it) }
        return klass.call(this, args)
    }

    // ==================== yardımcı native metot üreticisi ====================

    private fun nativeMethod(arity: Int, fn: (List<Any?>) -> Any?): EmCallable =
        object : EmCallable {
            override val arity = arity
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = fn(args)
        }

    // ==================== String instance metotları (doküman: Str, Java String sarmalayıcı) ====================
    private fun stringMember(s: String, name: String, line: Int): Any? = when (name) {
        "size", "length" -> s.length.toDouble()  // BigBoss: özellik olarak da erişilir
        "charAt" -> nativeMethod(1) { a -> val i = toInt(a.getOrNull(0)); if (i in s.indices) s[i].toString() else "" }
        "compare" -> nativeMethod(1) { a -> s.compareTo(stringify(a.getOrNull(0))).toDouble() }
        "concat" -> nativeMethod(1) { a -> s + stringify(a.getOrNull(0)) }
        "contains" -> nativeMethod(1) { a -> s.contains(stringify(a.getOrNull(0))) }
        "endsWith" -> nativeMethod(1) { a -> s.endsWith(stringify(a.getOrNull(0))) }
        "startsWith" -> nativeMethod(1) { a -> s.startsWith(stringify(a.getOrNull(0))) }
        "indexOf" -> nativeMethod(1) { a -> s.indexOf(stringify(a.getOrNull(0))).toDouble() }
        "lastIndexOf" -> nativeMethod(1) { a -> s.lastIndexOf(stringify(a.getOrNull(0))).toDouble() }
        "matches" -> nativeMethod(1) { a -> try { Regex(stringify(a.getOrNull(0))).matches(s) } catch (e: Exception) { false } }
        "replace" -> nativeMethod(2) { a -> s.replace(stringify(a.getOrNull(0)), stringify(a.getOrNull(1))) }
        "replaceAll" -> nativeMethod(2) { a -> try { s.replace(Regex(stringify(a.getOrNull(0))), stringify(a.getOrNull(1))) } catch (e: Exception) { s } }
        "replaceFirst" -> nativeMethod(2) { a -> try { s.replaceFirst(Regex(stringify(a.getOrNull(0))), stringify(a.getOrNull(1))) } catch (e: Exception) { s } }
        "split" -> nativeMethod(1) { a -> EmArray(s.split(Regex(stringify(a.getOrNull(0)))).map { it as Any? }.toMutableList()) }
        "subString", "substring" -> nativeMethod(-1) { a ->
            val b = toInt(a.getOrNull(0)).coerceIn(0, s.length)
            val e = if (a.size > 1) toInt(a.getOrNull(1)).coerceIn(b, s.length) else s.length
            s.substring(b, e)
        }
        "toLowerCase" -> nativeMethod(0) { s.lowercase() }
        "toUpperCase" -> nativeMethod(0) { s.uppercase() }
        "trim" -> nativeMethod(0) { s.trim() }
        "toArray" -> nativeMethod(0) { EmArray(s.map { it.toString() as Any? }.toMutableList()) }
        else -> throw EmScriptError("Metinde '$name' yok", line)
    }

    // ==================== Array instance metotları ====================
    private fun arrayMember(arr: EmArray, name: String, line: Int): Any? = when (name) {
        "size", "length" -> arr.size.toDouble()
        "push" -> nativeMethod(1) { a -> arr.push(a.getOrNull(0)); arr.size.toDouble() }
        "pop" -> nativeMethod(0) { if (arr.elements.isEmpty()) null else arr.elements.removeAt(arr.elements.size - 1) }
        "shift" -> nativeMethod(0) { if (arr.elements.isEmpty()) null else arr.elements.removeAt(0) }
        "unshift" -> nativeMethod(1) { a -> arr.elements.add(0, a.getOrNull(0)); arr.size.toDouble() }
        "get" -> nativeMethod(1) { a -> arr.get(toInt(a.getOrNull(0))) }
        "set" -> nativeMethod(2) { a -> arr.set(toInt(a.getOrNull(0)), a.getOrNull(1)); null }
        "insertAt" -> nativeMethod(2) { a -> val i = toInt(a.getOrNull(0)).coerceIn(0, arr.size); arr.elements.add(i, a.getOrNull(1)); arr.size.toDouble() }
        "insertRange" -> nativeMethod(2) { a -> val i = toInt(a.getOrNull(0)).coerceIn(0, arr.size); val els = (a.getOrNull(1) as? EmArray)?.elements ?: mutableListOf(); arr.elements.addAll(i, els); arr.size.toDouble() }
        "removeAt" -> nativeMethod(1) { a -> val i = toInt(a.getOrNull(0)); if (i in arr.elements.indices) arr.elements.removeAt(i); arr.size.toDouble() }
        "removeRange" -> nativeMethod(2) { a -> val b = toInt(a.getOrNull(0)).coerceIn(0, arr.size); val e = toInt(a.getOrNull(1)).coerceIn(b, arr.size); repeat(e - b) { arr.elements.removeAt(b) }; arr.size.toDouble() }
        "slice", "sub" -> nativeMethod(-1) { a -> val b = toInt(a.getOrNull(0)).coerceIn(0, arr.size); val e = if (a.size > 1) toInt(a.getOrNull(1)).coerceIn(b, arr.size) else arr.size; EmArray(arr.elements.subList(b, e).toMutableList()) }
        "concat" -> nativeMethod(1) { a -> val els = (a.getOrNull(0) as? EmArray)?.elements ?: mutableListOf(); EmArray((arr.elements + els).toMutableList()) }
        "clear" -> nativeMethod(0) { arr.elements.clear(); 0.0 }
        "clone" -> nativeMethod(0) { EmArray(arr.elements.toMutableList()) }
        "indexOf" -> nativeMethod(1) { a -> arr.elements.indexOfFirst { isEqual(it, a.getOrNull(0)) }.toDouble() }
        "lastIndexOf" -> nativeMethod(1) { a -> arr.elements.indexOfLast { isEqual(it, a.getOrNull(0)) }.toDouble() }
        "has", "contains" -> nativeMethod(1) { a -> arr.elements.any { isEqual(it, a.getOrNull(0)) } }
        "isEmpty" -> nativeMethod(0) { arr.elements.isEmpty() }
        "first" -> nativeMethod(0) { arr.elements.firstOrNull() }
        "last" -> nativeMethod(0) { arr.elements.lastOrNull() }
        "join" -> nativeMethod(-1) { a -> val sep = if (a.isEmpty()) "," else stringify(a.getOrNull(0)); arr.elements.joinToString(sep) { stringify(it) } }
        "reverse" -> nativeMethod(0) { arr.elements.reverse(); arr }
        "fill" -> nativeMethod(1) { a -> val v = a.getOrNull(0); for (i in arr.elements.indices) arr.elements[i] = v; arr }
        "uniq" -> nativeMethod(0) { val seen = ArrayList<Any?>(); for (e in arr.elements) if (seen.none { isEqual(it, e) }) seen.add(e); EmArray(seen) }
        // NOT: Tüm callback tabanlı metotlar snapshot (toList) üzerinde çalışır; callback içinde
        // aynı dizinin mutasyonu (push/removeAt/set) ConcurrentModificationException üretmesin diye.
        "sort" -> nativeMethod(-1) { a ->
            val cmp = a.getOrNull(0) as? EmCallable
            val snap = arr.elements.toMutableList()
            if (cmp != null) snap.sortWith { x, y -> val d = (cmp.call(this, listOf(x, y)) as? Double) ?: 0.0; if (d < 0) -1 else if (d > 0) 1 else 0 }
            else snap.sortWith { x, y -> if (x is Double && y is Double) x.compareTo(y) else stringify(x).compareTo(stringify(y)) }
            arr.elements.clear(); arr.elements.addAll(snap); arr
        }
        "map" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod arr; EmArray(arr.elements.toList().map { f.call(this, listOf(it)) }.toMutableList()) }
        "filter" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod arr; EmArray(arr.elements.toList().filter { truthy(f.call(this, listOf(it))) }.toMutableList()) }
        "each", "forEach" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod null; arr.elements.toList().forEach { f.call(this, listOf(it)) }; null }
        "find" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod null; arr.elements.toList().firstOrNull { truthy(f.call(this, listOf(it))) } }
        "findIndex" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod -1.0; arr.elements.toList().indexOfFirst { truthy(f.call(this, listOf(it))) }.toDouble() }
        "findLast" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod null; arr.elements.toList().lastOrNull { truthy(f.call(this, listOf(it))) } }
        "findLastIndex" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod -1.0; arr.elements.toList().indexOfLast { truthy(f.call(this, listOf(it))) }.toDouble() }
        "all" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod true; arr.elements.toList().all { truthy(f.call(this, listOf(it))) } }
        "any" -> nativeMethod(1) { a -> val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod false; arr.elements.toList().any { truthy(f.call(this, listOf(it))) } }
        "reduce" -> nativeMethod(-1) { a ->
            val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod null
            val snap = arr.elements.toList()
            var acc: Any?; var start: Int
            if (a.size < 2) { if (snap.isEmpty()) return@nativeMethod null; acc = snap[0]; start = 1 } else { acc = a.getOrNull(1); start = 0 }
            for (i in start until snap.size) acc = f.call(this, listOf(acc, snap[i]))
            acc
        }
        "reduceRight" -> nativeMethod(-1) { a ->
            val f = a.getOrNull(0) as? EmCallable ?: return@nativeMethod null
            val snap = arr.elements.toList()
            var acc: Any?; var start: Int
            if (a.size < 2) { if (snap.isEmpty()) return@nativeMethod null; acc = snap.last(); start = snap.size - 2 } else { acc = a.getOrNull(1); start = snap.size - 1 }
            var i = start
            while (i >= 0) { acc = f.call(this, listOf(acc, snap[i])); i-- }
            acc
        }
        else -> throw EmScriptError("Dizide '$name' yok", line)
    }

    // ==================== Map instance metotları ====================
    private fun mapMember(m: EmMap, name: String, line: Int): Any? = when (name) {
        "put" -> nativeMethod(2) { a -> val k = a.getOrNull(0); val prev = m.map[k]; m.map[k] = a.getOrNull(1); prev }
        "get" -> nativeMethod(1) { a -> m.map[a.getOrNull(0)] }
        "remove" -> nativeMethod(1) { a -> m.map.remove(a.getOrNull(0)) }
        "containsKey" -> nativeMethod(1) { a -> m.map.containsKey(a.getOrNull(0)) }
        "containsValue" -> nativeMethod(1) { a -> m.map.containsValue(a.getOrNull(0)) }
        "putIfAbsent" -> nativeMethod(2) { a -> val k = a.getOrNull(0); if (!m.map.containsKey(k)) { m.map[k] = a.getOrNull(1); null } else m.map[k] }
        "replace" -> nativeMethod(2) { a -> val k = a.getOrNull(0); if (m.map.containsKey(k)) { val p = m.map[k]; m.map[k] = a.getOrNull(1); p } else null }
        "putAll" -> nativeMethod(1) { a -> (a.getOrNull(0) as? EmMap)?.let { m.map.putAll(it.map) }; null }
        "size" -> nativeMethod(0) { m.map.size.toDouble() }
        "isEmpty" -> nativeMethod(0) { m.map.isEmpty() }
        "clear" -> nativeMethod(0) { m.map.clear(); null }
        "keys" -> nativeMethod(0) { EmArray(m.map.keys.toMutableList()) }
        "values" -> nativeMethod(0) { EmArray(m.map.values.toMutableList()) }
        "entries" -> nativeMethod(0) { EmArray(m.map.entries.map { EmArray(mutableListOf(it.key, it.value)) as Any? }.toMutableList()) }
        else -> throw EmScriptError("Map'te '$name' yok", line)
    }

    // ==================== operatör yardımcıları ====================

    private fun plus(a: Any?, b: Any?, op: Token): Any? {
        // Sayı + Sayı = toplama; herhangi biri string ise metin birleştirme (JS/EMScript davranışı)
        if (a is Double && b is Double) return a + b
        if (a is String || b is String) return stringify(a) + stringify(b)
        if (a is Double && b is Double) return a + b
        throw EmScriptError("'+' için uyumsuz tipler: ${typeName(a)} + ${typeName(b)}", op.line)
    }

    private inline fun arith(a: Any?, b: Any?, op: Token, f: (Double, Double) -> Double): Double {
        return f(toNum(a, op), toNum(b, op))
    }

    private fun isEqual(a: Any?, b: Any?): Boolean {
        if (a == null && b == null) return true
        if (a == null || b == null) return false
        return a == b
    }

    // ==================== dönüşümler ====================

    private fun truthy(v: Any?): Boolean = when (v) {
        null -> false
        is Boolean -> v
        is Double -> v != 0.0
        is String -> v.isNotEmpty()
        else -> true // nesne/dizi/fonksiyon -> doğru (JS truthy)
    }

    private fun toNum(v: Any?, op: Token): Double = when (v) {
        is Double -> v
        is Boolean -> if (v) 1.0 else 0.0
        is String -> v.toDoubleOrNull() ?: throw EmScriptError("Sayı bekleniyordu, metin geldi: \"$v\"", op.line)
        null -> 0.0
        else -> throw EmScriptError("Sayı bekleniyordu: ${typeName(v)}", op.line)
    }

    private fun toInt(v: Any?): Int = when (v) {
        is Double -> v.toInt()
        is Boolean -> if (v) 1 else 0
        is String -> v.toDoubleOrNull()?.toInt() ?: 0
        else -> 0
    }

    private fun typeName(v: Any?): String = when (v) {
        null -> "null"; is Double -> "number"; is Boolean -> "bool"; is String -> "string"
        is EmArray -> "array"; is EmMap -> "map"; is EmCallable -> "function"; is EmInstance -> "object"; else -> "value"
    }

    private fun tick() {
        if (maxSteps > 0) {
            steps++
            if (steps > maxSteps) throw EmScriptError("Adım sınırı aşıldı ($maxSteps) — muhtemel sonsuz döngü")
        }
    }

    companion object {
        /** Bir EMScript değerini kullanıcıya gösterilecek metne çevirir. */
        fun stringify(v: Any?): String = when (v) {
            null -> "null"
            is Double -> if (v == Math.floor(v) && !v.isInfinite()) v.toLong().toString() else v.toString()
            is Boolean -> v.toString()
            else -> v.toString()
        }
    }
}

/**
 * Host tarafından sağlanan "nesne benzeri" köprü (örn. Con, Region, Setting).
 * get(name) ile alan/metot döndürür — native fonksiyonlar ya da alt nesneler.
 */
interface EmHostObject {
    fun get(name: String): Any?
}
