package com.bigboss.app.emscript

/**
 * EMScript Soyut Sözdizimi Ağacı (AST). Parser bunları üretir, Interpreter gezer.
 * İki ana grup: İfadeler (Expr, bir değer üretir) ve Deyimler (Stmt, bir eylem yapar).
 */

sealed class Expr {
    /** number/string/bool/null sabiti. */
    data class Literal(val value: Any?) : Expr()
    /** Değişken okuma: x */
    data class Variable(val name: Token) : Expr()
    /** Atama: x = deger  ya da  hedef.alan = deger  ya da  dizi[i] = deger */
    data class Assign(val target: Expr, val op: Token, val value: Expr) : Expr()
    /** İkili işlem: a + b, a < b, a && b, ... */
    data class Binary(val left: Expr, val op: Token, val right: Expr) : Expr()
    /** Tekli işlem: -a, !a */
    data class Unary(val op: Token, val right: Expr) : Expr()
    /** Mantıksal (kısa devre): a && b, a || b */
    data class Logical(val left: Expr, val op: Token, val right: Expr) : Expr()
    /** Üçlü: cond ? a : b */
    data class Ternary(val cond: Expr, val thenE: Expr, val elseE: Expr) : Expr()
    /** Çağrı: f(a, b) */
    data class Call(val callee: Expr, val paren: Token, val args: List<Expr>) : Expr()
    /** Alan erişimi: nesne.alan */
    data class Get(val obj: Expr, val name: Token) : Expr()
    /** İndeks erişimi: dizi[i] */
    data class Index(val obj: Expr, val index: Expr, val bracket: Token) : Expr()
    /** Dizi sabiti: [a, b, c] */
    data class ArrayLiteral(val elements: List<Expr>) : Expr()
    /** this */
    data class This(val keyword: Token) : Expr()
    /** new ClassName(args) */
    data class New(val className: Token, val args: List<Expr>) : Expr()
    /** Lambda: (a, b) => govde  ya da  a => ifade */
    data class Lambda(val params: List<Token>, val body: List<Stmt>, val exprBody: Expr?) : Expr()
}

sealed class Stmt {
    /** var isim = deger */
    data class Var(val name: Token, val initializer: Expr?) : Stmt()
    /** İfade deyimi (örn. f()) */
    data class Expression(val expr: Expr) : Stmt()
    /** { ... } blok */
    data class Block(val statements: List<Stmt>) : Stmt()
    /** if (cond) then else elseB */
    data class If(val cond: Expr, val thenB: Stmt, val elseB: Stmt?) : Stmt()
    /** while (cond) body */
    data class While(val cond: Expr, val body: Stmt) : Stmt()
    /** do body while (cond) */
    data class DoWhile(val body: Stmt, val cond: Expr) : Stmt()
    /** for (init; cond; step) body */
    data class For(val init: Stmt?, val cond: Expr?, val step: Expr?, val body: Stmt) : Stmt()
    /** for (var item : iterable) body */
    data class ForEach(val varName: Token, val iterable: Expr, val body: Stmt) : Stmt()
    /** fun isim(params) { body } */
    data class Function(val name: Token, val params: List<Token>, val body: List<Stmt>) : Stmt()
    /** return deger */
    data class Return(val keyword: Token, val value: Expr?) : Stmt()
    /** break */
    data class Break(val keyword: Token) : Stmt()
    /** continue */
    data class Continue(val keyword: Token) : Stmt()
    /** class isim { ... } */
    data class Class(
        val name: Token,
        val initParams: List<Token>?,      // init(...) parametreleri (yoksa null)
        val initBody: List<Stmt>,          // init gövdesi
        val methods: List<Function>,       // örnek metotları
        val staticMethods: List<Function>, // static metotlar
        val fields: List<Token>            // bildirilen alan adları (belgeleme amaçlı)
    ) : Stmt()
}
