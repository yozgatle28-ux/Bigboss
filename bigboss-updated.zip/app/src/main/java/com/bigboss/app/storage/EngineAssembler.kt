package com.bigboss.app.storage

import android.content.Context
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Rule

/**
 * Motoru (RuleEngine) her yerde AYNI şekilde kurmak için merkezi yer.
 * Ana Akış kurallarının yanına, her etkin Action Group için bir
 * "kapı kuralı" (gate rule) ekler — bu kural sadece kapı koşulunu
 * kontrol eder, doğruysa grubun içindeki taramaları (Fonksiyon çağırma
 * mekanizmasıyla) tetikler. Kapı yanlışsa, gruptaki taramalar HİÇ
 * kontrol edilmez — performans kazancı burada.
 */
object EngineAssembler {

    /** Region Scaling için GÜNCEL cihaz çözünürlüğü — ScreenCaptureService de aynı kaynaktan (resources.displayMetrics) çözünürlük belirliyor, tutarlı. */
    private fun currentScreenSize(context: Context): Pair<Int, Int> {
        val metrics = context.resources.displayMetrics
        return metrics.widthPixels to metrics.heightPixels
    }

    fun buildRules(context: Context): List<Rule> {
        val (curW, curH) = currentScreenSize(context)
        val mainRules = RuleDefinitionMapper.toRules(RuleStorage.load(context), context, curW, curH)
        val groups = ActionGroupStorage.load(context).filter { it.enabled && it.gate != null }
        val gateRules = groups.map { group ->
            val gateDef = RuleDefinition(
                id = "group-gate-${group.id}",
                name = "📦 ${group.name}",
                alternatives = mutableListOf(group.gate!!),
                timeoutMs = group.gateCooldownMs
            )
            Rule(
                id = gateDef.id,
                name = gateDef.name,
                condition = RuleDefinitionMapper.toCondition(gateDef, curW, curH),
                thenAction = Action.CallFunction(group.id, group.gateRepeat.coerceAtLeast(1), group.gateInfiniteLoop, group.gateTimeLimitMs),
                cooldownMs = group.gateCooldownMs,
                enabled = true,
                negate = false,
                loopMode = "ALWAYS"
            )
        }
        return mainRules + gateRules
    }

    /** Function çağırma mekanizmasını, hem Fonksiyonlar hem Action Group'lar için ortak kullanır. */
    fun buildFunctionsProvider(context: Context): (String) -> List<Rule> = { id ->
        val (curW, curH) = currentScreenSize(context)
        FunctionStorage.load(context).find { it.id == id }?.let { RuleDefinitionMapper.toRules(it.rules, context, curW, curH) }
            ?: ActionGroupStorage.load(context).find { it.id == id }?.let { RuleDefinitionMapper.toRules(it.rules, context, curW, curH) }
            ?: emptyList()
    }

    /** Botu çalıştıran RuleEngine'e en güncel kural+fonksiyon listesini yükler. */
    fun refresh(context: Context) {
        val engine = com.bigboss.app.service.ScreenCaptureService.ruleEngine ?: return
        engine.setRules(buildRules(context))
        engine.setFunctionsProvider(buildFunctionsProvider(context))
    }

    /**
     * BİRLEŞİK DEĞİŞKEN SİSTEMİ kurulumu. Edit/PlayMode başlarken bir kez çağrılır:
     *  1) Kalıcı değişkenleri (JSON) çalışma-zamanı VariableStore'a yükler.
     *  2) setVar/Set Variable ile değişen değerlerin diske de yazılması için persister kurar.
     *  3) REFERENCE tipli değişkenlerin ifadelerini script motorunda değerlendiren köprüyü kurar.
     * scriptEngineProvider, o an kurulu ScriptEngine'i döndürür (Reference değerlendirmesi için).
     */
    fun setupVariableStore(context: Context, scriptEngineProvider: () -> com.bigboss.app.engine.ScriptEngine?) {
        val store = com.bigboss.app.engine.VariableStore
        // 1) Kalıcı değişkenleri belleğe yükle (devre dışı olanları atla).
        val persisted = GlobalVariableStorage.load(context)
            .filter { !it.disabled }
            .map { Triple(it.name, it.raw(), it.type) }
        store.resetAll()
        store.loadInitial(persisted)
        // 2) Çalışma-zamanı değişikliklerini diske yaz (aynı isim varsa güncelle, yoksa NUMBER olarak ekle).
        store.persister = { name, textValue ->
            val all = GlobalVariableStorage.load(context)
            val existing = all.find { it.name == name }
            if (existing != null) {
                existing.textValue = textValue
                GlobalVariableStorage.upsert(context, existing)
            } else {
                GlobalVariableStorage.upsert(
                    context,
                    GlobalVariableDefinition(java.util.UUID.randomUUID().toString(), name, type = "NUMBER", textValue = textValue)
                )
            }
        }
        // 3) REFERENCE ifadelerini script motorunda değerlendir (sonucu metin olarak döndür).
        store.resolveReference = { expr ->
            val eng = scriptEngineProvider()
            if (eng == null) null
            else try { eng.evaluateExpression(expr) } catch (e: Exception) { null }
        }
    }
}
