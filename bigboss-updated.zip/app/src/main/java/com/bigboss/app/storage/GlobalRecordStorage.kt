package com.bigboss.app.storage

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * `RecordStorage`'ın (LOCAL — `MacroScope` ile aktif macro'ya özel) GLOBAL karşılığı.
 * Birden fazla macro yaparken, TÜM macrolarda ortak kullanılabilecek kayıtlar (Play Record).
 */
object GlobalRecordStorage {

    private const val FILE_NAME = "global_records.json"
    private val gson = Gson()

    @Synchronized
    fun load(context: Context): MutableList<RecordDefinition> {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<RecordDefinition>>() {}.type
            gson.fromJson(file.readText(), type) ?: mutableListOf()
        } catch (e: Exception) {
            StorageSafety.backupCorrupt(file, e)
            mutableListOf()
        }
    }

    @Synchronized
    fun save(context: Context, records: List<RecordDefinition>) {
        File(context.filesDir, FILE_NAME).writeText(gson.toJson(records))
    }

    @Synchronized
    fun upsert(context: Context, record: RecordDefinition) {
        val records = load(context)
        val idx = records.indexOfFirst { it.id == record.id }
        if (idx >= 0) records[idx] = record else records.add(record)
        save(context, records)
    }

    @Synchronized
    fun delete(context: Context, id: String) {
        val records = load(context)
        records.removeAll { it.id == id }
        save(context, records)
    }
}
