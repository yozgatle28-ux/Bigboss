package com.bigboss.app.service

import android.graphics.Bitmap
import android.graphics.Color
import com.bigboss.app.emscript.EmHost
import com.bigboss.app.emscript.MatchData
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.ActionExecutor
import com.bigboss.app.engine.ImageMatcher
import com.bigboss.app.engine.TextMatcher
import com.bigboss.app.model.Region

/**
 * EMScript host köprüsünün ANDROID tarafı. Saf-Kotlin EmHost arayüzünü BigBoss'un
 * gerçek motoruna bağlar: ActionExecutor (dokunma/kaydırma), ImageMatcher (görsel),
 * TextMatcher (OCR), ve frameProvider (ScreenCaptureService.latestFrame).
 *
 * Bu sınıf Android tiplerini (Bitmap) kullandığı için cihazda çalışır; izole test edilemez.
 * Ama tüm KARAR mantığı (find döngüsü, koordinat, dönüşüm) saf-Kotlin EmStdLib'te ve
 * mock host ile test edildi — burada sadece gerçek motora "kablolama" var.
 *
 * @param executor         gerçek dokunma/kaydırma yürütücüsü
 * @param frameProvider    en güncel ekran görüntüsü (yoksa null)
 * @param libraryLookup    kütüphane görsel adı -> dosya yolu (findImage("isim") için)
 * @param pausedProvider   true iken (Edit Mode) gerçek dokunuş simüle edilmez
 * @param logSink          Con.out çıktısını uygulamaya iletir
 * @param settingShow      Setting.show() -> diyaloğu göster (gösterildiyse true)
 * @param settingGet       Setting.get(key) -> değer
 */
class AndroidEmHost(
    private val executor: ActionExecutor,
    private val frameProvider: () -> Bitmap?,
    private val libraryLookup: (String) -> String? = { null },
    private val pausedProvider: () -> Boolean = { false },
    private val logSink: (String) -> Unit = {},
    private val settingShow: () -> Boolean = { false },
    private val settingGet: (String) -> String = { "" },
    private val settingSet: (String, String) -> Unit = { _, _ -> }
) : EmHost {

    /** OverlayService tarafından kurulur: programatik ayar diyaloğunu (SettingBuilder.build().show()) UI thread'de gösterip Kaydet/İptal'e kadar bloke bekler. Kurulmazsa false döner. */
    var settingDialogRequester: ((com.bigboss.app.emscript.EmSettingSpec, Boolean) -> Boolean)? = null

    override fun log(message: String) = logSink(message)

    override fun deviceWidth(): Int = frameProvider()?.width ?: 1080
    override fun deviceHeight(): Int = frameProvider()?.height ?: 1920

    override fun tap(x: Int, y: Int, repeat: Int, holdMs: Long) {
        executor.execute(Action.Tap(x, y, repeat.coerceAtLeast(1), holdMs))
    }

    override fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long) {
        executor.execute(Action.Swipe(x1, y1, x2, y2, durationMs))
    }

    override fun swipePath(points: List<Triple<Int, Int, Long>>, durationEachMs: Long) {
        val defs = points.map { Action.SwipePointDef(it.first, it.second, it.third) }
        executor.execute(Action.MultiPointSwipe(defs, durationEachMs))
    }

    override fun system(action: String) {
        executor.execute(Action.SystemAction(action))
    }

    override fun sleep(ms: Long) {
        if (ms > 0) try { Thread.sleep(ms) } catch (e: InterruptedException) { Thread.currentThread().interrupt() }
    }

    override fun findImage(x: Int, y: Int, w: Int, h: Int, imageName: String, minScore: Float, timeoutMs: Long): MatchData? {
        val region = Region(x, y, w, h)
        val path = libraryLookup(imageName) ?: imageName
        return withTimeout(timeoutMs) {
            val frame = frameProvider() ?: return@withTimeout null
            val result = ImageMatcher.bestLocation(frame, region, path, 8) ?: return@withTimeout null
            val (score, loc) = result
            if (score < minScore) return@withTimeout null
            // loc = şablon merkezi (cihaz pikseli). Eşleşme bölgesini yaklaşık kur.
            MatchData(loc.first, loc.second, loc.first - w / 2, loc.second - h / 2, w, h, score.toDouble())
        }
    }

    override fun findText(x: Int, y: Int, w: Int, h: Int, text: String, minScore: Float, timeoutMs: Long): MatchData? {
        val region = Region(x, y, w, h)
        return withTimeout(timeoutMs) {
            val frame = frameProvider() ?: return@withTimeout null
            val score = TextMatcher.contains(frame, region, text, false, "", "")
            if (score < minScore) return@withTimeout null
            // OCR konum vermez; bölge merkezini kullan.
            MatchData(region.centerX, region.centerY, x, y, w, h, score.toDouble())
        }
    }

    override fun readText(x: Int, y: Int, w: Int, h: Int, defaultValue: String): String {
        val frame = frameProvider() ?: return defaultValue
        return TextMatcher.readText(frame, Region(x, y, w, h), "", "") ?: defaultValue
    }

    override fun colorAt(x: Int, y: Int): String {
        val frame = frameProvider() ?: return "#000000"
        if (x < 0 || y < 0 || x >= frame.width || y >= frame.height) return "#000000"
        val c = frame.getPixel(x, y)
        return String.format("#%02X%02X%02X", Color.red(c), Color.green(c), Color.blue(c))
    }

    override fun findColor(x: Int, y: Int, w: Int, h: Int, colorHex: String, minScore: Float): Boolean {
        val frame = frameProvider() ?: return false
        val target = try { Color.parseColor(colorHex) } catch (e: Exception) { return false }
        return com.bigboss.app.engine.Condition.ColorInRegion(Region(x, y, w, h), target, minScore).evaluate(frame)
    }

    override fun isPaused(): Boolean = pausedProvider()

    override fun showSetting(): Boolean = settingShow()
    override fun getSetting(key: String): String = settingGet(key)
    override fun showSettingDialog(spec: com.bigboss.app.emscript.EmSettingSpec, preview: Boolean): Boolean =
        settingDialogRequester?.invoke(spec, preview) ?: false
    override fun setSetting(key: String, value: String) = settingSet(key, value)

    /**
     * Bir find işlemini timeout dolana kadar (ya da bulununca) tekrar dener.
     * timeout<=0 ise tek deneme. Denemeler arası kısa uyku.
     */
    private inline fun <T> withTimeout(timeoutMs: Long, block: () -> T?): T? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            if (pausedProvider()) return null
            val result = block()
            if (result != null) return result
            if (timeoutMs <= 0 || System.currentTimeMillis() >= deadline) return null
            try { Thread.sleep(200) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); return null }
        }
    }
}
