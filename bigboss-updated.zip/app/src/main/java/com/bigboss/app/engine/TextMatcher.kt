package com.bigboss.app.engine

import android.graphics.Bitmap
import com.bigboss.app.model.Region
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Macrorify'daki "Text Recognition" özelliğinin karşılığı: bir bölgede
 * belirli bir kelime/metnin geçip geçmediğini ML Kit'in cihaz-üstü OCR'ı
 * ile arar. İnternet gerekmez (Google Play Services üzerinden bir kere
 * model indirildikten sonra), ama cihazda Play Services olması gerekir.
 *
 * TOLERANS: OCR bazen harfleri yanlış okuyabilir (örn. "0" yerine "O").
 * Bu yüzden artık TAM eşleşme yerine BENZERLİK ORANI (0.0-1.0) döndürüyor
 * — Min Skor ile ne kadar toleranslı olacağını sen ayarlıyorsun.
 *
 * ÖNEMLİ: Bu fonksiyon bloklayan (senkron) bir çağrı yapar
 * (Tasks.await), bu yüzden ANA THREAD'DE ÇAĞRILMAMALI. ScreenCaptureService
 * artık frame'leri arka plan thread'inde işliyor, orada güvenlidir.
 */
object TextMatcher {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Macrorify'daki "Text Reader": bölgeyi OKUYUP ham metni döner (bir DEĞİŞKENE yazmak için) — eşleşme değil, okuma. */
    fun readText(frame: Bitmap, region: Region, whitelist: String = "", blacklist: String = ""): String? {
        val cropped = safeCrop(frame, region) ?: return null
        return try {
            val image = InputImage.fromBitmap(cropped, 0)
            val result = Tasks.await(recognizer.process(image), 3, TimeUnit.SECONDS)
            applyCorrections(result.text, whitelist, blacklist).trim()
        } catch (e: Exception) {
            null
        }
    }

    fun contains(
        frame: Bitmap, region: Region, expectedText: String,
        caseSensitive: Boolean = false, whitelist: String = "", blacklist: String = ""
    ): Float {
        if (expectedText.isBlank()) return 0f
        val cropped = safeCrop(frame, region) ?: return 0f
        return try {
            val image = InputImage.fromBitmap(cropped, 0)
            val result = Tasks.await(recognizer.process(image), 3, TimeUnit.SECONDS)
            val cleaned = applyCorrections(result.text, whitelist, blacklist)
            similarityScore(cleaned, expectedText, caseSensitive)
        } catch (e: Exception) {
            0f
        }
    }

    /** Macrorify'daki Whitelist/Blacklist: OCR'ın "1"/"l" veya "0"/"o" gibi karıştırdığı karakterleri temizler. */
    private fun applyCorrections(text: String, whitelist: String, blacklist: String): String {
        var result = text
        if (whitelist.isNotEmpty()) {
            val allowed = whitelist.toSet()
            result = result.filter { it.isWhitespace() || it in allowed }
        }
        if (blacklist.isNotEmpty()) {
            val disallowed = blacklist.toSet()
            result = result.filter { it !in disallowed }
        }
        return result
    }

    /**
     * Tanınan metin içinde, aranan metne EN YAKIN parçayı bulup benzerlik
     * oranı (0.0-1.0) döner. Tam eşleşme 1.0, hiç alakasız 0.0'a yakın.
     * Min Skor (tolerans) ile karşılaştırılarak kullanılır.
     */
    fun similarityScore(recognizedRaw: String, expectedRaw: String, caseSensitive: Boolean = false): Float {
        val recognized = normalize(recognizedRaw, caseSensitive)
        val expected = normalize(expectedRaw, caseSensitive)
        if (expected.isEmpty()) return 0f
        if (recognized.contains(expected)) return 1f // hızlı yol: tam eşleşme zaten var

        if (recognized.length <= expected.length) {
            return similarity(recognized, expected)
        }
        // Kayan pencere: aranan metinle aynı uzunlukta parçaları tarayıp en iyi benzerliği bul
        var best = 0f
        val len = expected.length
        var i = 0
        while (i + len <= recognized.length) {
            val window = recognized.substring(i, i + len)
            val score = similarity(window, expected)
            if (score > best) best = score
            if (best >= 0.999f) break
            i++
        }
        return best
    }

    private fun normalize(text: String, caseSensitive: Boolean = false): String {
        val trimmed = text.replace(Regex("\\s+"), " ").trim()
        return if (caseSensitive) trimmed else trimmed.lowercase()
    }

    private fun similarity(a: String, b: String): Float {
        if (a.isEmpty() && b.isEmpty()) return 1f
        val dist = levenshtein(a, b)
        val maxLen = max(a.length, b.length).coerceAtLeast(1)
        return (1f - dist.toFloat() / maxLen).coerceIn(0f, 1f)
    }

    /** Klasik düzenleme mesafesi (Levenshtein) — kaç harf ekleme/silme/değiştirme gerektiği. */
    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) dp[i - 1][j - 1]
                else 1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
            }
        }
        return dp[a.length][b.length]
    }

    private fun safeCrop(frame: Bitmap, region: Region): Bitmap? {
        val x = region.x.coerceIn(0, frame.width - 1)
        val y = region.y.coerceIn(0, frame.height - 1)
        val w = region.width.coerceAtMost(frame.width - x)
        val h = region.height.coerceAtMost(frame.height - y)
        if (w <= 0 || h <= 0) return null
        return Bitmap.createBitmap(frame, x, y, w, h)
    }
}
