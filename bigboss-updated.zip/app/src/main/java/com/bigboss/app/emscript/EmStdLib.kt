package com.bigboss.app.emscript

/**
 * EMScript standart kütüphanesini (host API) bir Interpreter'a kurar.
 * Macrorify referansına göre: Con, Point, SwipePoint, Region, Match + düz fonksiyonlar
 * (tap, swipe, click, wait, back, home...). Tüm gerçek işler EmHost'a devredilir.
 *
 * Nesneler EmHostObject (get ile üye döndürür) veya native EmCallable olarak kurulur.
 */
object EmStdLib {

    fun install(interpreter: Interpreter, host: EmHost) {
        val g = interpreter.globals

        // ---- native fonksiyon yardımcısı ----
        fun fn(arity: Int, f: (List<Any?>) -> Any?): EmCallable = object : EmCallable {
            override val arity = arity
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = f(args)
        }
        fun numArg(a: List<Any?>, i: Int, def: Int = 0): Int =
            (a.getOrNull(i) as? Double)?.toInt() ?: (a.getOrNull(i) as? String)?.toDoubleOrNull()?.toInt() ?: def
        fun longArg(a: List<Any?>, i: Int, def: Long = 0): Long =
            (a.getOrNull(i) as? Double)?.toLong() ?: def
        fun strArg(a: List<Any?>, i: Int, def: String = ""): String =
            a.getOrNull(i)?.let { Interpreter.stringify(it) } ?: def
        fun floatArg(a: List<Any?>, i: Int, def: Float): Float =
            (a.getOrNull(i) as? Double)?.toFloat() ?: def

        // ==================== Con ====================
        g.define("Con", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "out" -> fn(-1) { a -> host.log(a.joinToString(" ") { Interpreter.stringify(it) }); null }
                "in" -> fn(0) { host.input() }
                else -> null
            }
        })
        // düz log da olsun (geriye dönük)
        g.define("log", fn(-1) { a -> host.log(a.joinToString(" ") { Interpreter.stringify(it) }); null })

        // ==================== Point ====================
        // Point(x, y) -> EmHostObject (getX/getY/offset/noScale)
        // Ayrıca static Point.scale(x, y, edges=0): dokümantasyonda vardı ama HİÇ implemente edilmemişti;
        // scriptte çağrılınca "üye bulunamadı" hatası veriyordu. EMScript makro/cihaz çözünürlük ayrımı
        // tutmadığından ölçekleme KİMLİK (identity) olarak uygulanır — koordinatlar zaten cihaz pikseli
        // kabul edilir (RuleDefinitionMapper'daki "çözünürlük verilmezse ölçekleme yok" ile tutarlı).
        g.define("Point", object : EmHostObject, EmCallable {
            override val arity = 2
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = pointObject(numArg(args, 0), numArg(args, 1))
            override fun get(name: String): Any? = when (name) {
                "scale" -> fn(-1) { a -> pointObject(numArg(a, 0), numArg(a, 1)) }
                else -> null
            }
        })

        // ==================== SwipePoint ====================
        // SwipePoint(x, y, hold=0) veya SwipePoint(point, hold=0)
        g.define("SwipePoint", fn(-1) { a ->
            val first = a.getOrNull(0)
            if (first is EmHostObject) {
                val px = (first.get("__x") as? Double)?.toInt() ?: 0
                val py = (first.get("__y") as? Double)?.toInt() ?: 0
                swipePointObject(px, py, longArg(a, 1))
            } else {
                swipePointObject(numArg(a, 0), numArg(a, 1), longArg(a, 2))
            }
        })

        // ==================== Region ====================
        // Region(x, y, w, h) veya Region() = cihaz boyutu
        g.define("Region", object : EmHostObject, EmCallable {
            override val arity = -1
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                val x = numArg(args, 0); val y = numArg(args, 1)
                val w = numArg(args, 2, host.deviceWidth()); val h = numArg(args, 3, host.deviceHeight())
                return regionObject(host, x, y, w, h)
            }
            // Static: Region.deviceReg(), Region.macroReg(), Region.highlightOff()
            override fun get(name: String): Any? = when (name) {
                "deviceReg" -> fn(-1) { regionObject(host, 0, 0, host.deviceWidth(), host.deviceHeight()) }
                "macroReg" -> fn(-1) { regionObject(host, 0, 0, host.deviceWidth(), host.deviceHeight()) }
                // static Region.scale(x, y, w, h, edges=0): dokümanda vardı ama eksikti (identity ölçekleme).
                "scale" -> fn(-1) { a -> regionObject(host, numArg(a, 0), numArg(a, 1), numArg(a, 2, host.deviceWidth()), numArg(a, 3, host.deviceHeight())) }
                "highlightOff" -> fn(0) { null }
                "LEFT" -> 1.0; "TOP" -> 2.0; "RIGHT" -> 4.0; "BOTTOM" -> 8.0
                else -> null
            }
        })

        // ==================== Düz fonksiyonlar ====================
        g.define("tap", fn(-1) { a -> if (!host.isPaused()) host.tap(numArg(a, 0), numArg(a, 1), numArg(a, 2, 1).coerceAtLeast(1), longArg(a, 3, 50)); null })
        g.define("click", fn(-1) { a ->
            // click(point) veya click(x, y)
            val first = a.getOrNull(0)
            if (first is EmHostObject) {
                val px = (first.get("__x") as? Double)?.toInt() ?: 0
                val py = (first.get("__y") as? Double)?.toInt() ?: 0
                if (!host.isPaused()) host.tap(px, py, 1, 50)
            } else {
                if (!host.isPaused()) host.tap(numArg(a, 0), numArg(a, 1), 1, 50)
            }
            null
        })
        g.define("swipe", fn(-1) { a ->
            val first = a.getOrNull(0)
            if (first is EmArray) {
                // swipe(path) — SwipePoint dizisi
                val pts = first.elements.mapNotNull { el ->
                    if (el is EmHostObject) {
                        val px = (el.get("__x") as? Double)?.toInt() ?: return@mapNotNull null
                        val py = (el.get("__y") as? Double)?.toInt() ?: return@mapNotNull null
                        val hold = (el.get("__hold") as? Double)?.toLong() ?: 0L
                        Triple(px, py, hold)
                    } else null
                }
                if (!host.isPaused() && pts.size >= 2) host.swipePath(pts)
            } else {
                if (!host.isPaused()) host.swipe(numArg(a, 0), numArg(a, 1), numArg(a, 2), numArg(a, 3), longArg(a, 4, 300))
            }
            null
        })
        g.define("wait", fn(1) { a -> host.sleep(longArg(a, 0)); null })
        g.define("sleep", fn(1) { a -> host.sleep(longArg(a, 0)); null })
        g.define("back", fn(0) { if (!host.isPaused()) host.system("BACK"); null })
        g.define("home", fn(0) { if (!host.isPaused()) host.system("HOME"); null })
        g.define("recents", fn(0) { if (!host.isPaused()) host.system("RECENTS"); null })
        g.define("colorAt", fn(2) { a -> host.colorAt(numArg(a, 0), numArg(a, 1)) })
        g.define("randomInt", fn(2) { a ->
            val lo = numArg(a, 0); val hi = numArg(a, 1)
            if (hi > lo) (lo + (Math.random() * (hi - lo + 1)).toInt()).toDouble() else lo.toDouble()
        })

        // ==================== Setting ====================
        g.define("Setting", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "get" -> fn(1) { a -> host.getSetting(strArg(a, 0)) }
                "show" -> fn(0) { host.showSetting() }
                else -> null
            }
        })
    }

    // -------- Point host nesnesi --------
    private fun pointObject(px: Int, py: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__x" -> px.toDouble()   // dahili (swipe/click nesneden okusun)
            "__y" -> py.toDouble()
            "getX" -> callable0 { px.toDouble() }
            "getY" -> callable0 { py.toDouble() }
            "offset" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val dx = (args.getOrNull(0) as? Double)?.toInt() ?: 0
                    val dy = (args.getOrNull(1) as? Double)?.toInt() ?: 0
                    return pointObject(px + dx, py + dy)
                }
            }
            "noScale" -> callable0 { pointObject(px, py) }
            else -> null
        }
    }

    // -------- SwipePoint host nesnesi --------
    private fun swipePointObject(px: Int, py: Int, hold: Long): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__x" -> px.toDouble()
            "__y" -> py.toDouble()
            "__hold" -> hold.toDouble()
            "getX" -> callable0 { px.toDouble() }
            "getY" -> callable0 { py.toDouble() }
            else -> null
        }
    }

    // -------- Match host nesnesi --------
    private fun matchObject(host: EmHost, m: MatchData): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "getScore" -> callable0 { m.score }
            "getPoint" -> callable0 { pointObject(m.x, m.y) }
            "getRegion" -> callable0 { regionObject(host, m.regionX, m.regionY, m.regionW, m.regionH) }
            "click" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    if (!host.isPaused()) host.tap(m.x, m.y, 1, 50); return null
                }
            }
            else -> null
        }
    }

    // -------- Region host nesnesi --------
    private fun regionObject(host: EmHost, rx: Int, ry: Int, rw: Int, rh: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "getX" -> callable0 { rx.toDouble() }
            "getY" -> callable0 { ry.toDouble() }
            "getW" -> callable0 { rw.toDouble() }
            "getH" -> callable0 { rh.toDouble() }
            "getMiddlePoint" -> callable0 { pointObject(rx + rw / 2, ry + rh / 2) }
            // Dönüşümler (yeni Region döner) — percent varsayılan 0.5
            // Not: left/right/top/bottom o kenardan `p` keser. middle/horizontal/vertical
            // İKİ kenardan keser, bu yüzden toplam küçülme `p` olsun diye her kenara `p/2`.
            "middle" -> callableP { p -> val h = p / 2; shrink(host, rx, ry, rw, rh, h, h, h, h) }
            "left" -> callableP { p -> shrink(host, rx, ry, rw, rh, 0.0, 0.0, p, 0.0) }
            "right" -> callableP { p -> shrink(host, rx, ry, rw, rh, p, 0.0, 0.0, 0.0) }
            "top" -> callableP { p -> shrink(host, rx, ry, rw, rh, 0.0, 0.0, 0.0, p) }
            "bottom" -> callableP { p -> shrink(host, rx, ry, rw, rh, 0.0, p, 0.0, 0.0) }
            "horizontal" -> callableP { p -> val h = p / 2; shrink(host, rx, ry, rw, rh, h, 0.0, h, 0.0) }
            "vertical" -> callableP { p -> val h = p / 2; shrink(host, rx, ry, rw, rh, 0.0, h, 0.0, h) }
            "offset" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val dx = (args.getOrNull(0) as? Double)?.toInt() ?: 0
                    val dy = (args.getOrNull(1) as? Double)?.toInt() ?: 0
                    val nw = (args.getOrNull(2) as? Double)?.toInt() ?: rw
                    val nh = (args.getOrNull(3) as? Double)?.toInt() ?: rh
                    return regionObject(host, rx + dx, ry + dy, nw, nh)
                }
            }
            "noScale" -> callable0 { regionObject(host, rx, ry, rw, rh) }
            "setX" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, (args.getOrNull(0) as? Double)?.toInt() ?: rx, ry, rw, rh) }
            "setY" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, (args.getOrNull(0) as? Double)?.toInt() ?: ry, rw, rh) }
            "setW" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, ry, (args.getOrNull(0) as? Double)?.toInt() ?: rw, rh) }
            "setH" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, ry, rw, (args.getOrNull(0) as? Double)?.toInt() ?: rh) }
            // Tespit
            "find" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val img = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val m = host.findImage(rx, ry, rw, rh, img, 0.8f, timeout) ?: return null
                    return matchObject(host, m)
                }
            }
            "findAll" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val names = (args.getOrNull(0) as? EmArray)?.elements?.map { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val results = names.mapNotNull { host.findImage(rx, ry, rw, rh, it, 0.8f, timeout) }
                    if (results.size != names.size) return null
                    return EmArray(results.map { matchObject(host, it) as Any? }.toMutableList())
                }
            }
            "findAny" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val names = (args.getOrNull(0) as? EmArray)?.elements?.map { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val results = names.map { host.findImage(rx, ry, rw, rh, it, 0.8f, timeout) }
                    if (results.all { it == null }) return null
                    return EmArray(results.map { if (it != null) matchObject(host, it) as Any? else null }.toMutableList())
                }
            }
            "click" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val img = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val m = host.findImage(rx, ry, rw, rh, img, 0.8f, timeout) ?: return null
                    if (!host.isPaused()) host.tap(m.x, m.y, 1, 50)
                    return matchObject(host, m)
                }
            }
            "findText" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val text = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val m = host.findText(rx, ry, rw, rh, text, 0.8f, timeout) ?: return null
                    return matchObject(host, m)
                }
            }
            "clickText" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val text = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val timeout = (args.getOrNull(1) as? Double)?.toLong() ?: 0L
                    val m = host.findText(rx, ry, rw, rh, text, 0.8f, timeout) ?: return null
                    if (!host.isPaused()) host.tap(m.x, m.y, 1, 50)
                    return matchObject(host, m)
                }
            }
            "read" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? =
                    host.readText(rx, ry, rw, rh, "")
            }
            "readAsString" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val def = args.getOrNull(1)?.let { Interpreter.stringify(it) } ?: ""
                    return host.readText(rx, ry, rw, rh, def)
                }
            }
            "readAsNumber" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val s = host.readText(rx, ry, rw, rh, "")
                    return s.filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: 0.0
                }
            }
            "findColor" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val hex = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: "#000000"
                    val minScore = (args.getOrNull(1) as? Double)?.toFloat() ?: 0.9f
                    return host.findColor(rx, ry, rw, rh, hex, minScore)
                }
            }
            "highlight" -> callable0 { null }
            "highlightOff" -> callable0 { null }
            else -> null
        }
    }

    // -------- yardımcı: bölge küçültme (percent) --------
    private fun shrink(host: EmHost, x: Int, y: Int, w: Int, h: Int, padL: Double, padB: Double, padR: Double, padT: Double): EmHostObject {
        val nx = x + (w * padL).toInt()
        val ny = y + (h * padT).toInt()
        val nw = (w * (1 - padL - padR)).toInt().coerceAtLeast(1)
        val nh = (h * (1 - padT - padB)).toInt().coerceAtLeast(1)
        return regionObject(host, nx, ny, nw, nh)
    }

    // -------- native fonksiyon kısayolları --------
    private fun callable0(f: () -> Any?): EmCallable = object : EmCallable {
        override val arity = 0
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? = f()
    }
    private fun callableP(f: (Double) -> Any?): EmCallable = object : EmCallable {
        override val arity = -1
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
            val p = (args.getOrNull(0) as? Double) ?: 0.5
            return f(p)
        }
    }
}
