package com.bigboss.app.emscript

/**
 * EMScript standart kütüphanesini (host API) bir Interpreter'a kurar.
 * Macrorify referansına göre: Con, Point, SwipePoint, Region, Match + düz fonksiyonlar
 * (tap, swipe, click, wait, back, home...). Tüm gerçek işler EmHost'a devredilir.
 *
 * Nesneler EmHostObject (get ile üye döndürür) veya native EmCallable olarak kurulur.
 */
object EmStdLib {

    fun install(interpreter: Interpreter, host: EmHost) {
        val g = interpreter.globals

        // ---- native fonksiyon yardımcısı ----
        fun fn(arity: Int, f: (List<Any?>) -> Any?): EmCallable = object : EmCallable {
            override val arity = arity
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = f(args)
        }
        fun numArg(a: List<Any?>, i: Int, def: Int = 0): Int =
            (a.getOrNull(i) as? Double)?.toInt() ?: (a.getOrNull(i) as? String)?.toDoubleOrNull()?.toInt() ?: def
        fun longArg(a: List<Any?>, i: Int, def: Long = 0): Long =
            (a.getOrNull(i) as? Double)?.toLong() ?: def
        fun strArg(a: List<Any?>, i: Int, def: String = ""): String =
            a.getOrNull(i)?.let { Interpreter.stringify(it) } ?: def
        fun floatArg(a: List<Any?>, i: Int, def: Float): Float =
            (a.getOrNull(i) as? Double)?.toFloat() ?: def
        fun dbl(a: List<Any?>, i: Int, def: Double = 0.0): Double =
            (a.getOrNull(i) as? Double) ?: (a.getOrNull(i) as? String)?.toDoubleOrNull() ?: def

        // ==================== Con ====================
        g.define("Con", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "out" -> fn(-1) { a -> host.log(a.joinToString(" ") { Interpreter.stringify(it) }); null }
                "in" -> fn(0) { host.input() }
                else -> null
            }
        })
        // düz log da olsun (geriye dönük)
        g.define("log", fn(-1) { a -> host.log(a.joinToString(" ") { Interpreter.stringify(it) }); null })

        // ==================== Point ====================
        // Point(x, y) -> EmHostObject (getX/getY/offset/noScale)
        // Ayrıca static Point.scale(x, y, edges=0): dokümantasyonda vardı ama HİÇ implemente edilmemişti;
        // scriptte çağrılınca "üye bulunamadı" hatası veriyordu. EMScript makro/cihaz çözünürlük ayrımı
        // tutmadığından ölçekleme KİMLİK (identity) olarak uygulanır — koordinatlar zaten cihaz pikseli
        // kabul edilir (RuleDefinitionMapper'daki "çözünürlük verilmezse ölçekleme yok" ile tutarlı).
        g.define("Point", object : EmHostObject, EmCallable {
            override val arity = 2
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? = pointObject(numArg(args, 0), numArg(args, 1))
            override fun get(name: String): Any? = when (name) {
                "scale" -> fn(-1) { a -> pointObject(numArg(a, 0), numArg(a, 1)) }
                else -> null
            }
        })

        // ==================== SwipePoint ====================
        // Doküman: SwipePoint(point, hold=0, speed=20). Ek olarak SwipePoint(x, y, hold, speed) de desteklenir.
        g.define("SwipePoint", fn(-1) { a ->
            val first = a.getOrNull(0)
            if (first is EmHostObject) {
                val px = (first.get("__x") as? Double)?.toInt() ?: 0
                val py = (first.get("__y") as? Double)?.toInt() ?: 0
                swipePointObject(px, py, longArg(a, 1), longArg(a, 2, 20))
            } else {
                swipePointObject(numArg(a, 0), numArg(a, 1), longArg(a, 2), longArg(a, 3, 20))
            }
        })

        // ==================== Region ====================
        // Region(x, y, w, h) veya Region() = cihaz boyutu
        g.define("Region", object : EmHostObject, EmCallable {
            override val arity = -1
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                val x = numArg(args, 0); val y = numArg(args, 1)
                val w = numArg(args, 2, host.deviceWidth()); val h = numArg(args, 3, host.deviceHeight())
                return regionObject(host, x, y, w, h)
            }
            // Static: Region.deviceReg(), Region.macroReg(), Region.highlightOff()
            override fun get(name: String): Any? = when (name) {
                "deviceReg" -> fn(-1) { regionObject(host, 0, 0, host.deviceWidth(), host.deviceHeight()) }
                "macroReg" -> fn(-1) { regionObject(host, 0, 0, host.deviceWidth(), host.deviceHeight()) }
                // static Region.scale(x, y, w, h, edges=0): dokümanda vardı ama eksikti (identity ölçekleme).
                "scale" -> fn(-1) { a -> regionObject(host, numArg(a, 0), numArg(a, 1), numArg(a, 2, host.deviceWidth()), numArg(a, 3, host.deviceHeight())) }
                "highlightOff" -> fn(0) { null }
                "LEFT" -> 1.0; "TOP" -> 2.0; "RIGHT" -> 4.0; "BOTTOM" -> 8.0
                else -> null
            }
        })

        // ==================== Düz fonksiyonlar ====================
        g.define("tap", fn(-1) { a -> if (!host.isPaused()) host.tap(numArg(a, 0), numArg(a, 1), numArg(a, 2, 1).coerceAtLeast(1), longArg(a, 3, 50)); null })
        g.define("click", fn(-1) { a ->
            // click(point[, CParam]) veya click(x, y[, CParam])
            val first = a.getOrNull(0)
            if (first is EmHostObject && first.get("__x") != null) {
                val px = (first.get("__x") as? Double)?.toInt() ?: 0
                val py = (first.get("__y") as? Double)?.toInt() ?: 0
                performClick(host, px, py, a.getOrNull(1))
            } else {
                performClick(host, numArg(a, 0), numArg(a, 1), a.getOrNull(2))
            }
            null
        })
        g.define("swipe", fn(-1) { a ->
            val first = a.getOrNull(0)
            if (first is EmArray) {
                // swipe(path) — SwipePoint dizisi
                val pts = first.elements.mapNotNull { el ->
                    if (el is EmHostObject) {
                        val px = (el.get("__x") as? Double)?.toInt() ?: return@mapNotNull null
                        val py = (el.get("__y") as? Double)?.toInt() ?: return@mapNotNull null
                        val hold = (el.get("__hold") as? Double)?.toLong() ?: 0L
                        Triple(px, py, hold)
                    } else null
                }
                if (!host.isPaused() && pts.size >= 2) host.swipePath(pts)
            } else {
                if (!host.isPaused()) host.swipe(numArg(a, 0), numArg(a, 1), numArg(a, 2), numArg(a, 3), longArg(a, 4, 300))
            }
            null
        })
        g.define("wait", fn(1) { a -> host.sleep(longArg(a, 0)); null })
        g.define("sleep", fn(1) { a -> host.sleep(longArg(a, 0)); null })
        g.define("back", fn(0) { if (!host.isPaused()) host.system("BACK"); null })
        g.define("home", fn(0) { if (!host.isPaused()) host.system("HOME"); null })
        g.define("recents", fn(0) { if (!host.isPaused()) host.system("RECENTS"); null })
        g.define("colorAt", fn(2) { a -> host.colorAt(numArg(a, 0), numArg(a, 1)) })
        g.define("randomInt", fn(2) { a ->
            val lo = numArg(a, 0); val hi = numArg(a, 1)
            if (hi > lo) (lo + (Math.random() * (hi - lo + 1)).toInt()).toDouble() else lo.toDouble()
        })

        // ==================== Setting + UI Builder (SettingBuilder / view'lar / Dialog) ====================
        // Setting.setDialog(dialog) ile atanan diyalog Setting.show() ile gösterilebilir.
        var pendingSettingSpec: EmSettingSpec? = null
        g.define("Setting", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                // get(key[, default]) — değer yoksa default (verilmişse) döner; "true"/"false"/sayı otomatik tür dönüşümü.
                "get" -> fn(-1) { a ->
                    val raw = host.getSetting(strArg(a, 0))
                    if (raw.isEmpty() && a.size > 1) a.getOrNull(1) else coerceSettingValue(raw)
                }
                "set" -> fn(2) { a -> host.setSetting(strArg(a, 0), a.getOrNull(1)?.let { Interpreter.stringify(it) } ?: ""); null }
                "setDialog" -> fn(1) { a -> pendingSettingSpec = (a.getOrNull(0) as? EmHostObject)?.get("__dialogSpec") as? EmSettingSpec; null }
                "builder" -> fn(0) { settingBuilderObject(host, SettingBuilderState()) }
                "show" -> fn(0) {
                    val spec = pendingSettingSpec
                    if (spec != null) { if (host.showSettingDialog(spec, false)) 1.0 else null } else host.showSetting()
                }
                else -> null
            }
        })
        // ==================== UI Builder view yapıcıları (doküman: Setting Builder views) ====================
        g.define("TextView", fn(-1) { a -> settingViewObject("TEXTVIEW", "", a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: "", "", "", "", "TEXT", emptyList()) })
        val editTextCtor = fn(-1) { a ->
            val text = a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: ""
            val im = (a.getOrNull(1) as? Double)?.toInt() ?: 0
            val hint = a.getOrNull(2)?.let { Interpreter.stringify(it) } ?: ""
            val helper = a.getOrNull(3)?.let { Interpreter.stringify(it) } ?: ""
            // hint hem üst etiket hem kutu-içi ipucu olarak kullanılır (doküman: "floats above when focused").
            settingViewObject("EDITTEXT", "", hint, text, hint, helper, if (im == 1) "NUMBER" else "TEXT", emptyList())
        }
        g.define("EditText", editTextCtor)
        val checkBoxCtor = fn(-1) { a ->
            val checked = (a.getOrNull(0) as? Boolean) ?: false
            settingViewObject("CHECKBOX", "", a.getOrNull(1)?.let { Interpreter.stringify(it) } ?: "", if (checked) "true" else "false", "", "", "TEXT", emptyList())
        }
        g.define("Checkbox", checkBoxCtor)
        g.define("CheckBox", checkBoxCtor)
        g.define("RadioGroup", fn(-1) { a ->
            val radios = when (val r = a.getOrNull(0)) {
                is EmArray -> r.elements.map { Interpreter.stringify(it) }
                null -> emptyList()
                else -> listOf(Interpreter.stringify(r))
            }
            val selected = (a.getOrNull(1) as? Double)?.toInt() ?: 0
            settingViewObject("RADIO", "", "", selected.toString(), "", "", "TEXT", radios)
        })
        g.define("ImagePicker", fn(-1) { a ->
            settingViewObject("IMAGEPICKER", "", a.getOrNull(1)?.let { Interpreter.stringify(it) } ?: "", a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: "", "", "", "TEXT", emptyList())
        })
        // Recorder(name=null, label=null) — kayıt seçici. defaultValue=name (kayıt adı/id), label=üst etiket.
        g.define("Recorder", fn(-1) { a ->
            settingViewObject("RECORDER", "", a.getOrNull(1)?.let { Interpreter.stringify(it) } ?: "", a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: "", "", "", "TEXT", emptyList())
        })
        // TabLayout() — sekmeler view'ları id ile göster/gizler: .tab(label, visibleIds, hiddenIds), .select(i), .saveSelected(b), .id(x).
        g.define("TabLayout", fn(-1) { tabLayoutObject(TabLayoutState()) })

        // ==================== Math (saf; host gerektirmez, dokümanda vardı ama HİÇ implemente edilmemişti) ====================
        g.define("Math", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "PI" -> Math.PI
                "E" -> Math.E
                "sin" -> fn(1) { a -> Math.sin(dbl(a, 0)) }
                "cos" -> fn(1) { a -> Math.cos(dbl(a, 0)) }
                "tan" -> fn(1) { a -> Math.tan(dbl(a, 0)) }
                "asin" -> fn(1) { a -> Math.asin(dbl(a, 0)) }
                "acos" -> fn(1) { a -> Math.acos(dbl(a, 0)) }
                "atan" -> fn(1) { a -> Math.atan(dbl(a, 0)) }
                "atan2" -> fn(2) { a -> Math.atan2(dbl(a, 0), dbl(a, 1)) }
                "sqrt" -> fn(1) { a -> Math.sqrt(dbl(a, 0)) }
                "cbrt" -> fn(1) { a -> Math.cbrt(dbl(a, 0)) }
                "hypot" -> fn(2) { a -> Math.hypot(dbl(a, 0), dbl(a, 1)) }
                "ceil" -> fn(1) { a -> Math.ceil(dbl(a, 0)) }
                "floor" -> fn(1) { a -> Math.floor(dbl(a, 0)) }
                "round" -> fn(1) { a -> Math.round(dbl(a, 0)).toDouble() }
                "exp" -> fn(1) { a -> Math.exp(dbl(a, 0)) }
                "pow" -> fn(2) { a -> Math.pow(dbl(a, 0), dbl(a, 1)) }
                "log" -> fn(1) { a -> Math.log(dbl(a, 0)) }
                "log10" -> fn(1) { a -> Math.log10(dbl(a, 0)) }
                "log1p" -> fn(1) { a -> Math.log1p(dbl(a, 0)) }
                "abs" -> fn(1) { a -> Math.abs(dbl(a, 0)) }
                "max" -> fn(2) { a -> Math.max(dbl(a, 0), dbl(a, 1)) }
                "min" -> fn(2) { a -> Math.min(dbl(a, 0), dbl(a, 1)) }
                "random" -> fn(0) { Math.random() }
                "randomRange" -> fn(2) { a -> val lo = dbl(a, 0); val hi = dbl(a, 1); lo + Math.random() * (hi - lo) }
                "toDegrees" -> fn(1) { a -> Math.toDegrees(dbl(a, 0)) }
                "toRadians" -> fn(1) { a -> Math.toRadians(dbl(a, 0)) }
                else -> null
            }
        })

        // ==================== Num ====================
        g.define("Num", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                // parse(value, default=null): sayıya çevir; olmazsa default (yoksa null)
                "parse" -> fn(-1) { a ->
                    when (val v = a.getOrNull(0)) {
                        is Double -> v
                        is String -> v.toDoubleOrNull() ?: (a.getOrNull(1) as? Double)
                        else -> a.getOrNull(1) as? Double
                    }
                }
                else -> null
            }
        })

        // ==================== Str (statik yardımcılar; instance metotlar interpreter'da) ====================
        g.define("Str", object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "join" -> fn(-1) { a ->
                    val delim = strArg(a, 0)
                    val rest = a.drop(1)
                    val items = if (rest.size == 1 && rest[0] is EmArray) (rest[0] as EmArray).elements else rest
                    items.joinToString(delim) { Interpreter.stringify(it) }
                }
                "format" -> fn(-1) { a ->
                    val fmt = strArg(a, 0)
                    // EMScript sayıları Double; %d gibi format için tam sayıları Long'a çevir.
                    val rest = a.drop(1).map { if (it is Double && it == Math.floor(it) && !it.isInfinite()) it.toLong() else it }.toTypedArray()
                    try { String.format(fmt, *rest) } catch (e: Exception) { fmt }
                }
                "lockMatch" -> fn(2) { a -> similarity(strArg(a, 0), strArg(a, 1)) }
                else -> null
            }
        })

        // ==================== Map ====================
        // Doküman: var map = Map(); map.put(k, v); map.get(k). İndeksleme map[k] de desteklenir.
        g.define("Map", fn(0) { EmMap() })

        // ==================== Param nesneleri (FParam / TParam / CParam) ====================
        // Hem yapıcı (FParam(...)) hem statik (FParam.timeout(x)) hem de kopya-yapıcı (FParam(param)) desteklenir.
        g.define("FParam", object : EmCallable, EmHostObject {
            override val arity = -1
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                val first = args.getOrNull(0)
                if (first is EmHostObject && first.get("__mScore") != null && first.get("__scale") == null) {
                    return fparamObject(
                        (first.get("__timeout") as? Double)?.toLong() ?: 0L,
                        (first.get("__sRate") as? Double)?.toInt() ?: 3,
                        (first.get("__mScore") as? Double) ?: 0.7,
                        (first.get("__method") as? Double)?.toInt() ?: 0
                    )
                }
                return fparamObject(longArg(args, 0, 0), numArg(args, 1, 3), dbl(args, 2, 0.7), numArg(args, 3, 0))
            }
            override fun get(name: String): Any? = when (name) {
                "timeout" -> fn(1) { a -> fparamObject(longArg(a, 0, 0), 3, 0.7, 0) }
                "sRate" -> fn(1) { a -> fparamObject(0, numArg(a, 0, 3), 0.7, 0) }
                "mScore" -> fn(1) { a -> fparamObject(0, 3, dbl(a, 0, 0.7), 0) }
                "method" -> fn(1) { a -> fparamObject(0, 3, 0.7, numArg(a, 0, 0)) }
                "CCOEFF" -> 0.0; "CCORR" -> 1.0; "SQDIFF" -> 2.0
                else -> null
            }
        })
        g.define("TParam", object : EmCallable, EmHostObject {
            override val arity = -1
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                val first = args.getOrNull(0)
                if (first is EmHostObject && first.get("__scale") != null) {
                    return tparamObject(
                        (first.get("__timeout") as? Double)?.toLong() ?: 0L,
                        (first.get("__sRate") as? Double)?.toInt() ?: 3,
                        (first.get("__mScore") as? Double) ?: 0.7,
                        (first.get("__scale") as? Double) ?: 1.0,
                        (first.get("__mode") as? Double)?.toInt() ?: 0,
                        first.get("__whitelist") as? String,
                        first.get("__blacklist") as? String,
                        first.get("__case") as? Boolean ?: false
                    )
                }
                return tparamObject(longArg(args, 0, 0), numArg(args, 1, 3), dbl(args, 2, 0.7), dbl(args, 3, 1.0), numArg(args, 4, 0), args.getOrNull(5) as? String, args.getOrNull(6) as? String, args.getOrNull(7) as? Boolean ?: false)
            }
            override fun get(name: String): Any? = when (name) {
                "timeout" -> fn(1) { a -> tparamObject(longArg(a, 0, 0), 3, 0.7, 1.0, 0, null, null, false) }
                "sRate" -> fn(1) { a -> tparamObject(0, numArg(a, 0, 3), 0.7, 1.0, 0, null, null, false) }
                "mScore" -> fn(1) { a -> tparamObject(0, 3, dbl(a, 0, 0.7), 1.0, 0, null, null, false) }
                "WORD" -> 0.0; "LINE" -> 1.0; "PARAGRAPH" -> 2.0
                else -> null
            }
        })
        g.define("CParam", object : EmCallable, EmHostObject {
            override val arity = -1
            override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                val first = args.getOrNull(0)
                if (first is EmHostObject && first.get("__repeat") != null) {
                    return cparamObject(
                        (first.get("__repeat") as? Double)?.toInt() ?: 1,
                        (first.get("__hold") as? Double)?.toLong() ?: 0L,
                        (first.get("__delay") as? Double)?.toLong() ?: 0L,
                        (first.get("__waitNext") as? Double)?.toLong() ?: 100L,
                        (first.get("__random") as? Double)?.toInt() ?: 0
                    )
                }
                return cparamObject(numArg(args, 0, 1), longArg(args, 1, 0), longArg(args, 2, 0), longArg(args, 3, 100), numArg(args, 4, 0))
            }
            override fun get(name: String): Any? = when (name) {
                "repeat" -> fn(1) { a -> cparamObject(numArg(a, 0, 1), 0, 0, 100, 0) }
                "hold" -> fn(1) { a -> cparamObject(1, longArg(a, 0, 0), 0, 100, 0) }
                "delay" -> fn(1) { a -> cparamObject(1, 0, longArg(a, 0, 0), 100, 0) }
                "waitNext" -> fn(1) { a -> cparamObject(1, 0, 0, longArg(a, 0, 100), 0) }
                "random" -> fn(1) { a -> cparamObject(1, 0, 0, 100, numArg(a, 0, 0)) }
                else -> null
            }
        })
    }

    // -------- Point host nesnesi --------
    private fun pointObject(px: Int, py: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__x" -> px.toDouble()   // dahili (swipe/click nesneden okusun)
            "__y" -> py.toDouble()
            "getX" -> callable0 { px.toDouble() }
            "getY" -> callable0 { py.toDouble() }
            "offset" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val dx = (args.getOrNull(0) as? Double)?.toInt() ?: 0
                    val dy = (args.getOrNull(1) as? Double)?.toInt() ?: 0
                    return pointObject(px + dx, py + dy)
                }
            }
            "noScale" -> callable0 { pointObject(px, py) }
            else -> null
        }
    }

    // -------- SwipePoint host nesnesi --------
    private fun swipePointObject(px: Int, py: Int, hold: Long, speed: Long = 20): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__x" -> px.toDouble()
            "__y" -> py.toDouble()
            "__hold" -> hold.toDouble()
            "__speed" -> speed.toDouble()
            "getX" -> callable0 { px.toDouble() }
            "getY" -> callable0 { py.toDouble() }
            "getHold" -> callable0 { hold.toDouble() }    // doküman: SwipePoint.getHold()
            "getSpeed" -> callable0 { speed.toDouble() }  // doküman: SwipePoint.getSpeed()
            else -> null
        }
    }

    // -------- Param nesneleri için object-level yardımcılar --------
    private fun nativeFn(arity: Int, f: (List<Any?>) -> Any?): EmCallable = object : EmCallable {
        override val arity = arity
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? = f(args)
    }
    private fun dnum(v: Any?, def: Double): Double = (v as? Double) ?: def

    // FParam(timeout=0, sRate=3, mScore=0.7, method=0) — bul parametreleri (doküman). Fluent metotlar yeni kopya döner.
    private fun fparamObject(timeout: Long, sRate: Int, mScore: Double, method: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__timeout" -> timeout.toDouble()
            "__sRate" -> sRate.toDouble()
            "__mScore" -> mScore
            "__method" -> method.toDouble()
            "timeout" -> nativeFn(1) { a -> fparamObject(dnum(a.getOrNull(0), timeout.toDouble()).toLong(), sRate, mScore, method) }
            "sRate" -> nativeFn(1) { a -> fparamObject(timeout, dnum(a.getOrNull(0), sRate.toDouble()).toInt(), mScore, method) }
            "mScore" -> nativeFn(1) { a -> fparamObject(timeout, sRate, dnum(a.getOrNull(0), mScore), method) }
            "method" -> nativeFn(1) { a -> fparamObject(timeout, sRate, mScore, dnum(a.getOrNull(0), method.toDouble()).toInt()) }
            else -> null
        }
    }

    // TParam(timeout=0, sRate=3, mScore=0.7, scale=1, mode=0, whitelist=null, blacklist=null, case=false)
    private fun tparamObject(timeout: Long, sRate: Int, mScore: Double, scale: Double, mode: Int, whitelist: String?, blacklist: String?, caseSensitive: Boolean): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__timeout" -> timeout.toDouble()
            "__sRate" -> sRate.toDouble()
            "__mScore" -> mScore
            "__scale" -> scale
            "__mode" -> mode.toDouble()
            "__whitelist" -> whitelist
            "__blacklist" -> blacklist
            "__case" -> caseSensitive
            "timeout" -> nativeFn(1) { a -> tparamObject(dnum(a.getOrNull(0), timeout.toDouble()).toLong(), sRate, mScore, scale, mode, whitelist, blacklist, caseSensitive) }
            "sRate" -> nativeFn(1) { a -> tparamObject(timeout, dnum(a.getOrNull(0), sRate.toDouble()).toInt(), mScore, scale, mode, whitelist, blacklist, caseSensitive) }
            "mScore" -> nativeFn(1) { a -> tparamObject(timeout, sRate, dnum(a.getOrNull(0), mScore), scale, mode, whitelist, blacklist, caseSensitive) }
            else -> null
        }
    }

    // CParam(repeat=1, hold=0, delay=0, waitNext=100, random=0) — tıklama parametreleri
    private fun cparamObject(repeat: Int, hold: Long, delay: Long, waitNext: Long, random: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__repeat" -> repeat.toDouble()
            "__hold" -> hold.toDouble()
            "__delay" -> delay.toDouble()
            "__waitNext" -> waitNext.toDouble()
            "__random" -> random.toDouble()
            "repeat" -> nativeFn(1) { a -> cparamObject(dnum(a.getOrNull(0), repeat.toDouble()).toInt(), hold, delay, waitNext, random) }
            "hold" -> nativeFn(1) { a -> cparamObject(repeat, dnum(a.getOrNull(0), hold.toDouble()).toLong(), delay, waitNext, random) }
            "delay" -> nativeFn(1) { a -> cparamObject(repeat, hold, dnum(a.getOrNull(0), delay.toDouble()).toLong(), waitNext, random) }
            "waitNext" -> nativeFn(1) { a -> cparamObject(repeat, hold, delay, dnum(a.getOrNull(0), waitNext.toDouble()).toLong(), random) }
            "random" -> nativeFn(1) { a -> cparamObject(repeat, hold, delay, waitNext, dnum(a.getOrNull(0), random.toDouble()).toInt()) }
            else -> null
        }
    }

    // find/findText/click için: arg number ise (eşik 0.8 korunur, timeout=arg); FParam/TParam ise (mScore, timeout).
    private fun findScoreTimeout(arg: Any?): Pair<Float, Long> = when {
        arg is EmHostObject && arg.get("__mScore") != null ->
            ((arg.get("__mScore") as? Double)?.toFloat() ?: 0.8f) to ((arg.get("__timeout") as? Double)?.toLong() ?: 0L)
        arg is Double -> 0.8f to arg.toLong()
        else -> 0.8f to 0L
    }

    // Tıklamayı CParam'a göre uygular. cp number ise repeat sayısıdır; yoksa tek tıklama (hold 50ms — eski davranış).
    private fun performClick(host: EmHost, x: Int, y: Int, cp: Any?) {
        if (host.isPaused()) return
        var times = 1; var hold = 50L; var delay = 0L; var waitNext = 0L; var random = 0
        if (cp is EmHostObject && cp.get("__repeat") != null) {
            times = (cp.get("__repeat") as? Double)?.toInt() ?: 1
            hold = (cp.get("__hold") as? Double)?.toLong() ?: 0L
            delay = (cp.get("__delay") as? Double)?.toLong() ?: 0L
            waitNext = (cp.get("__waitNext") as? Double)?.toLong() ?: 100L
            random = (cp.get("__random") as? Double)?.toInt() ?: 0
        } else if (cp is Double) {
            times = cp.toInt()
        }
        if (delay > 0) host.sleep(delay)
        repeat(times.coerceAtLeast(1)) {
            val jx = if (random > 0) x + (Math.random() * (2 * random + 1)).toInt() - random else x
            val jy = if (random > 0) y + (Math.random() * (2 * random + 1)).toInt() - random else y
            host.tap(jx, jy, 1, hold)
        }
        if (waitNext > 0) host.sleep(waitNext)
    }

    // -------- Match host nesnesi --------
    // -------- UI Builder (SettingBuilder / view / Dialog) yardımcıları --------
    private class SettingBuilderState {
        var title: String = "Ayarlar"
        var positive: String = "Kaydet"
        var negative: String = "İptal"
        val views: MutableList<EmSettingViewSpec> = mutableListOf()
    }

    private class TabLayoutState {
        var viewId: String = ""
        var selected: Int = 0
        var saveSelected: Boolean = false
        val tabs: MutableList<EmSettingTab> = mutableListOf()
    }

    private fun idList(v: Any?): List<String> = when (v) {
        is EmArray -> v.elements.map { Interpreter.stringify(it) }
        null -> emptyList()
        else -> listOf(Interpreter.stringify(v))
    }

    // TabLayout() -> zincirlenebilir; tab()/select()/saveSelected()/id() aynı nesneyi döner.
    private fun tabLayoutObject(st: TabLayoutState): EmHostObject {
        lateinit var self: EmHostObject
        self = object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "__viewType" -> "TABLAYOUT"
                "__viewId" -> st.viewId
                "__tabs" -> st.tabs.toList()
                "__tabSelected" -> st.selected
                "__tabSaveSelected" -> st.saveSelected
                "id" -> nativeFn(1) { a -> a.getOrNull(0)?.let { st.viewId = Interpreter.stringify(it) }; self }
                "tab" -> nativeFn(-1) { a ->
                    val label = a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: ""
                    val visible = idList(a.getOrNull(1))
                    val hidden = if (a.size > 2) idList(a.getOrNull(2)) else null  // 3. arg yoksa: diğer TÜM view'ları gizle
                    st.tabs.add(EmSettingTab(label, visible, hidden))
                    self
                }
                "select" -> nativeFn(1) { a -> st.selected = (a.getOrNull(0) as? Double)?.toInt() ?: st.selected; self }
                "saveSelected" -> nativeFn(1) { a -> st.saveSelected = (a.getOrNull(0) as? Boolean) ?: true; self }
                else -> null
            }
        }
        return self
    }

    // Bir view host-nesnesi. __view* alanları + fluent id()/text()/name()/label(). SettingBuilder.add ile key atanır.
    private fun settingViewObject(type: String, key: String, label: String, defaultValue: String, hint: String, helper: String, inputMethod: String, radioOptions: List<String>, viewId: String = ""): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__viewType" -> type
            "__key" -> key
            "__viewId" -> viewId
            "__label" -> label
            "__default" -> defaultValue
            "__hint" -> hint
            "__helper" -> helper
            "__input" -> inputMethod
            "__radios" -> radioOptions
            // Doküman: .id() bir tanımlayıcı atar (TabLayout görünürlüğü bunu hedefler); .add(key,...) değişken adını atar.
            "id" -> nativeFn(1) { a -> settingViewObject(type, key, label, defaultValue, hint, helper, inputMethod, radioOptions, a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: viewId) }
            "text" -> nativeFn(1) { a -> settingViewObject(type, key, a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: label, defaultValue, hint, helper, inputMethod, radioOptions, viewId) }
            "label" -> nativeFn(1) { a -> settingViewObject(type, key, a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: label, defaultValue, hint, helper, inputMethod, radioOptions, viewId) }
            "name" -> nativeFn(1) { a -> settingViewObject(type, key, label, a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: defaultValue, hint, helper, inputMethod, radioOptions, viewId) }
            else -> null
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun viewSpecFrom(v: EmHostObject, key: String): EmSettingViewSpec {
        val type = v.get("__viewType") as? String ?: "EDITTEXT"
        val vkey = if (key.isNotBlank()) key else (v.get("__key") as? String ?: "")
        val radios = (v.get("__radios") as? List<String>) ?: emptyList()
        val tabs = (v.get("__tabs") as? List<EmSettingTab>) ?: emptyList()
        return EmSettingViewSpec(
            type = type,
            key = vkey,
            label = v.get("__label") as? String ?: "",
            defaultValue = v.get("__default") as? String ?: "",
            hint = v.get("__hint") as? String ?: "",
            helper = v.get("__helper") as? String ?: "",
            inputMethod = v.get("__input") as? String ?: "TEXT",
            radioOptions = radios,
            viewId = v.get("__viewId") as? String ?: "",
            tabs = tabs,
            tabSelected = (v.get("__tabSelected") as? Int) ?: 0,
            tabSaveSelected = (v.get("__tabSaveSelected") as? Boolean) ?: false
        )
    }

    // Setting.builder() -> zincirlenebilir builder. Metotlar aynı builder'ı döner; build() Dialog verir.
    private fun settingBuilderObject(host: EmHost, st: SettingBuilderState): EmHostObject {
        lateinit var self: EmHostObject
        self = object : EmHostObject {
            override fun get(name: String): Any? = when (name) {
                "add" -> nativeFn(2) { a ->
                    val key = a.getOrNull(0)?.let { Interpreter.stringify(it) } ?: ""
                    val v = a.getOrNull(1)
                    if (v is EmHostObject && v.get("__viewType") != null) st.views.add(viewSpecFrom(v, key))
                    self
                }
                "setTitle" -> nativeFn(1) { a -> a.getOrNull(0)?.let { st.title = Interpreter.stringify(it) }; self }
                "setPositiveButton" -> nativeFn(1) { a -> a.getOrNull(0)?.let { st.positive = Interpreter.stringify(it) }; self }
                "setNegativeButton" -> nativeFn(1) { a -> a.getOrNull(0)?.let { st.negative = Interpreter.stringify(it) }; self }
                "group" -> nativeFn(-1) { self }       // doküman: görsel gruplama; mevcut render düz akışta gösterir
                "groupEnd" -> nativeFn(-1) { self }
                "build" -> nativeFn(-1) { dialogObject(host, EmSettingSpec(st.title, st.positive, st.negative, st.views.toList())) }
                else -> null
            }
        }
        return self
    }

    // build() sonucu Dialog: show() -> Kaydet ise 1, İptal ise null. preview() önizleme (Kaydet etkisiz).
    private fun dialogObject(host: EmHost, spec: EmSettingSpec): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "__dialogSpec" -> spec
            "show" -> nativeFn(-1) { if (host.showSettingDialog(spec, false)) 1.0 else null }
            "preview" -> nativeFn(-1) { if (host.showSettingDialog(spec, true)) 1.0 else null }
            else -> null
        }
    }

    // Setting.get: string değeri olası tür (boolean/number) olarak yorumla; değilse string bırak.
    private fun coerceSettingValue(raw: String): Any? = when {
        raw == "true" -> true
        raw == "false" -> false
        else -> raw.toDoubleOrNull() ?: raw
    }

    private fun matchObject(host: EmHost, m: MatchData): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "getScore" -> callable0 { m.score }
            "getPoint" -> callable0 { pointObject(m.x, m.y) }
            "getRegion" -> callable0 { regionObject(host, m.regionX, m.regionY, m.regionW, m.regionH) }
            "click" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    performClick(host, m.x, m.y, args.getOrNull(0)); return null
                }
            }
            else -> null
        }
    }

    // -------- Region host nesnesi --------
    private fun regionObject(host: EmHost, rx: Int, ry: Int, rw: Int, rh: Int): EmHostObject = object : EmHostObject {
        override fun get(name: String): Any? = when (name) {
            "getX" -> callable0 { rx.toDouble() }
            "getY" -> callable0 { ry.toDouble() }
            "getW" -> callable0 { rw.toDouble() }
            "getH" -> callable0 { rh.toDouble() }
            "getMiddlePoint" -> callable0 { pointObject(rx + rw / 2, ry + rh / 2) }
            // Dönüşümler (yeni Region döner) — percent varsayılan 0.5. padPercent(padL,padT,padR,padB).
            // DOKÜMAN semantiği: X(p) => "o kenara doğru p kadar küçült" = KARŞI kenardan p kesilir,
            // böylece adı geçen kenar (X) tarafındaki (1-p) oran KORUNUR:
            //   left  => sağdan keser (sol korunur)   right  => soldan keser (sağ korunur)
            //   top   => alttan keser (üst korunur)    bottom => üstten keser (alt korunur)
            // HATA DÜZELTMESİ: top/bottom önceden TERS çalışıyordu (top alt yarıyı, bottom üst yarıyı
            // döndürüyordu). left/right doğruyken top/bottom argümanları takas edilmişti; artık düzeltildi.
            "middle" -> callableP { p -> val h = p / 2; padPercent(host, rx, ry, rw, rh, h, h, h, h) }
            "left" -> callableP { p -> padPercent(host, rx, ry, rw, rh, 0.0, 0.0, p, 0.0) }
            "right" -> callableP { p -> padPercent(host, rx, ry, rw, rh, p, 0.0, 0.0, 0.0) }
            "top" -> callableP { p -> padPercent(host, rx, ry, rw, rh, 0.0, 0.0, 0.0, p) }
            "bottom" -> callableP { p -> padPercent(host, rx, ry, rw, rh, 0.0, p, 0.0, 0.0) }
            "horizontal" -> callableP { p -> val h = p / 2; padPercent(host, rx, ry, rw, rh, h, 0.0, h, 0.0) }
            "vertical" -> callableP { p -> val h = p / 2; padPercent(host, rx, ry, rw, rh, 0.0, h, 0.0, h) }
            // pad(padLeft%, padTop%=0, padRight%=0, padBottom%=0): pozitif küçültür, negatif genişletir
            "pad" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    fun d(i: Int) = (args.getOrNull(i) as? Double) ?: 0.0
                    return padPercent(host, rx, ry, rw, rh, d(0), d(1), d(2), d(3))
                }
            }
            // Piksel tabanlı kırpmalar (doküman: leftPixel/topPixel/rightPixel/bottomPixel/...)
            "leftPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, 0, 0, px, 0) }
            "rightPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, px, 0, 0, 0) }
            "topPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, 0, 0, 0, px) }
            "bottomPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, 0, px, 0, 0) }
            "horizontalPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, px / 2, 0, px / 2, 0) }
            "verticalPixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, 0, px / 2, 0, px / 2) }
            "middlePixel" -> callablePx { px -> padPixel(host, rx, ry, rw, rh, px / 2, px / 2, px / 2, px / 2) }
            "offset" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val dx = (args.getOrNull(0) as? Double)?.toInt() ?: 0
                    val dy = (args.getOrNull(1) as? Double)?.toInt() ?: 0
                    val nw = (args.getOrNull(2) as? Double)?.toInt() ?: rw
                    val nh = (args.getOrNull(3) as? Double)?.toInt() ?: rh
                    return regionObject(host, rx + dx, ry + dy, nw, nh)
                }
            }
            "noScale" -> callable0 { regionObject(host, rx, ry, rw, rh) }
            "setX" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, (args.getOrNull(0) as? Double)?.toInt() ?: rx, ry, rw, rh) }
            "setY" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, (args.getOrNull(0) as? Double)?.toInt() ?: ry, rw, rh) }
            "setW" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, ry, (args.getOrNull(0) as? Double)?.toInt() ?: rw, rh) }
            "setH" -> object : EmCallable { override val arity = 1
                override fun call(interpreter: Interpreter, args: List<Any?>) = regionObject(host, rx, ry, rw, (args.getOrNull(0) as? Double)?.toInt() ?: rh) }
            // Tespit — 2. argüman timeout (number) VEYA param nesnesi (FParam/TParam) olabilir.
            // Param verilirse mScore (eşik) ve timeout host'a iletilir. Sadece number verilirse
            // eski 0.8 eşik korunur. NOT: FParam.sRate/method ve TParam.scale/mode/whitelist/
            // blacklist/case param'da saklanır ama mevcut OCR/eşleme host'u yalnızca mScore+timeout kullanır.
            "find" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val img = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val m = host.findImage(rx, ry, rw, rh, img, score, timeout) ?: return null
                    return matchObject(host, m)
                }
            }
            "findAll" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val names = (args.getOrNull(0) as? EmArray)?.elements?.map { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val results = names.mapNotNull { host.findImage(rx, ry, rw, rh, it, score, timeout) }
                    if (results.size != names.size) return null
                    return EmArray(results.map { matchObject(host, it) as Any? }.toMutableList())
                }
            }
            "findAny" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val names = (args.getOrNull(0) as? EmArray)?.elements?.map { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val results = names.map { host.findImage(rx, ry, rw, rh, it, score, timeout) }
                    if (results.all { it == null }) return null
                    return EmArray(results.map { if (it != null) matchObject(host, it) as Any? else null }.toMutableList())
                }
            }
            // click(image, timeout|FParam, repeat|CParam)
            "click" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val img = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val m = host.findImage(rx, ry, rw, rh, img, score, timeout) ?: return null
                    performClick(host, m.x, m.y, args.getOrNull(2))
                    return matchObject(host, m)
                }
            }
            "findText" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val text = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val m = host.findText(rx, ry, rw, rh, text, score, timeout) ?: return null
                    return matchObject(host, m)
                }
            }
            "clickText" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val text = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: return null
                    val (score, timeout) = findScoreTimeout(args.getOrNull(1))
                    val m = host.findText(rx, ry, rw, rh, text, score, timeout) ?: return null
                    performClick(host, m.x, m.y, args.getOrNull(2))
                    return matchObject(host, m)
                }
            }
            "read" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? =
                    host.readText(rx, ry, rw, rh, "")
            }
            "readAsString" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val def = args.getOrNull(1)?.let { Interpreter.stringify(it) } ?: ""
                    return host.readText(rx, ry, rw, rh, def)
                }
            }
            "readAsNumber" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val s = host.readText(rx, ry, rw, rh, "")
                    return s.filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: 0.0
                }
            }
            "findColor" -> object : EmCallable {
                override val arity = -1
                override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
                    val hex = args.getOrNull(0)?.let { Interpreter.stringify(it) } ?: "#000000"
                    val minScore = (args.getOrNull(1) as? Double)?.toFloat() ?: 0.9f
                    return host.findColor(rx, ry, rw, rh, hex, minScore)
                }
            }
            "highlight" -> callable0 { null }
            "highlightOff" -> callable0 { null }
            else -> null
        }
    }

    // -------- yardımcı: bölge küçültme --------
    // Parametre sırası NET: SOL, ÜST, SAĞ, ALT (padL, padT, padR, padB). Pozitif küçültür, negatif genişletir.
    private fun padPercent(host: EmHost, x: Int, y: Int, w: Int, h: Int, padL: Double, padT: Double, padR: Double, padB: Double): EmHostObject {
        val nx = x + (w * padL).toInt()
        val ny = y + (h * padT).toInt()
        val nw = (w * (1 - padL - padR)).toInt().coerceAtLeast(1)
        val nh = (h * (1 - padT - padB)).toInt().coerceAtLeast(1)
        return regionObject(host, nx, ny, nw, nh)
    }
    private fun padPixel(host: EmHost, x: Int, y: Int, w: Int, h: Int, padL: Int, padT: Int, padR: Int, padB: Int): EmHostObject {
        val nx = x + padL
        val ny = y + padT
        val nw = (w - padL - padR).coerceAtLeast(1)
        val nh = (h - padT - padB).coerceAtLeast(1)
        return regionObject(host, nx, ny, nw, nh)
    }

    // -------- native fonksiyon kısayolları --------
    private fun callable0(f: () -> Any?): EmCallable = object : EmCallable {
        override val arity = 0
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? = f()
    }
    private fun callableP(f: (Double) -> Any?): EmCallable = object : EmCallable {
        override val arity = -1
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
            val p = (args.getOrNull(0) as? Double) ?: 0.5
            return f(p)
        }
    }
    private fun callablePx(f: (Int) -> Any?): EmCallable = object : EmCallable {
        override val arity = -1
        override fun call(interpreter: Interpreter, args: List<Any?>): Any? {
            val px = (args.getOrNull(0) as? Double)?.toInt() ?: 0
            return f(px)
        }
    }

    // -------- Str.lockMatch: iki metin arası benzerlik 0..1 (Levenshtein tabanlı) --------
    private fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        val maxLen = maxOf(a.length, b.length)
        if (maxLen == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / maxLen
    }
    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + minOf(prev, dp[j], dp[j - 1])
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
