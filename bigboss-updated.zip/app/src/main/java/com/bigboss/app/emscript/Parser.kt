package com.bigboss.app.emscript

/**
 * EMScript Parser (recursive descent). Token dizisini AST'ye çevirir.
 * Dilbilgisi Macrorify EMScript'e göre: var/fun/class, if/else, for/while/do-while,
 * foreach, ternary, lambda, dizi, üye/indeks erişimi, new.
 *
 * İfade öncelik sırası (düşükten yükseğe):
 *   assignment -> ternary -> or -> and -> equality -> comparison ->
 *   term(+ -) -> factor(* / %) -> unary(! -) -> call/get/index -> primary
 */
class Parser(private val tokens: List<Token>) {

    private var current = 0

    fun parse(): List<Stmt> {
        val statements = mutableListOf<Stmt>()
        while (!isAtEnd()) {
            if (match(TokenType.SEMICOLON)) continue // boş deyimleri atla
            statements.add(declaration())
        }
        return statements
    }

    // ==================== Deyimler ====================

    private fun declaration(): Stmt {
        if (match(TokenType.VAR)) return varDeclaration()
        if (check(TokenType.FUN) && checkNext(TokenType.IDENTIFIER)) {
            advance() // fun
            return functionDeclaration()
        }
        if (match(TokenType.CLASS)) return classDeclaration()
        return statement()
    }

    private fun varDeclaration(): Stmt {
        val name = consume(TokenType.IDENTIFIER, "Değişken adı bekleniyordu")
        var initializer: Expr? = null
        if (match(TokenType.ASSIGN)) initializer = expression()
        matchSemicolon()
        return Stmt.Var(name, initializer)
    }

    private fun functionDeclaration(): Stmt.Function {
        val name = consume(TokenType.IDENTIFIER, "Fonksiyon adı bekleniyordu")
        consume(TokenType.LPAREN, "Fonksiyon adından sonra '(' bekleniyordu")
        val params = parseParams()
        consume(TokenType.LBRACE, "Fonksiyon gövdesi için '{' bekleniyordu")
        val body = block()
        return Stmt.Function(name, params, body)
    }

    private fun parseParams(): List<Token> {
        val params = mutableListOf<Token>()
        if (!check(TokenType.RPAREN)) {
            do {
                params.add(consume(TokenType.IDENTIFIER, "Parametre adı bekleniyordu"))
            } while (match(TokenType.COMMA))
        }
        consume(TokenType.RPAREN, "Parametrelerden sonra ')' bekleniyordu")
        return params
    }

    private fun classDeclaration(): Stmt {
        val name = consume(TokenType.IDENTIFIER, "Sınıf adı bekleniyordu")
        consume(TokenType.LBRACE, "Sınıf gövdesi için '{' bekleniyordu")

        var initParams: List<Token>? = null
        var initBody: List<Stmt> = emptyList()
        val methods = mutableListOf<Stmt.Function>()
        val staticMethods = mutableListOf<Stmt.Function>()
        val fields = mutableListOf<Token>()

        while (!check(TokenType.RBRACE) && !isAtEnd()) {
            when {
                match(TokenType.INIT) -> {
                    consume(TokenType.LPAREN, "init için '(' bekleniyordu")
                    initParams = parseParams()
                    consume(TokenType.LBRACE, "init gövdesi için '{' bekleniyordu")
                    initBody = block()
                }
                match(TokenType.STATIC) -> {
                    // static add(a,b) { }
                    staticMethods.add(methodDeclaration())
                }
                check(TokenType.IDENTIFIER) && checkNext(TokenType.LPAREN) -> {
                    // metot: name(...) { }
                    methods.add(methodDeclaration())
                }
                check(TokenType.IDENTIFIER) -> {
                    // alan bildirimi: sadece isim (belgeleme; init içinde this.x ile atanır)
                    fields.add(advance())
                    matchSemicolon()
                }
                else -> throw error(peek(), "Sınıf gövdesinde beklenmeyen öğe")
            }
        }
        consume(TokenType.RBRACE, "Sınıf gövdesi için '}' bekleniyordu")
        return Stmt.Class(name, initParams, initBody, methods, staticMethods, fields)
    }

    /** Sınıf içi metot: name(params) { body }  (fun anahtar kelimesi olmadan) */
    private fun methodDeclaration(): Stmt.Function {
        val name = consume(TokenType.IDENTIFIER, "Metot adı bekleniyordu")
        consume(TokenType.LPAREN, "Metot adından sonra '(' bekleniyordu")
        val params = parseParams()
        consume(TokenType.LBRACE, "Metot gövdesi için '{' bekleniyordu")
        val body = block()
        return Stmt.Function(name, params, body)
    }

    private fun statement(): Stmt {
        if (match(TokenType.IF)) return ifStatement()
        if (match(TokenType.WHILE)) return whileStatement()
        if (match(TokenType.DO)) return doWhileStatement()
        if (match(TokenType.FOR)) return forStatement()
        if (match(TokenType.RETURN)) return returnStatement()
        if (match(TokenType.BREAK)) { val kw = previous(); matchSemicolon(); return Stmt.Break(kw) }
        if (match(TokenType.CONTINUE)) { val kw = previous(); matchSemicolon(); return Stmt.Continue(kw) }
        if (match(TokenType.LBRACE)) return Stmt.Block(block())
        return expressionStatement()
    }

    private fun ifStatement(): Stmt {
        consume(TokenType.LPAREN, "if'ten sonra '(' bekleniyordu")
        val cond = expression()
        consume(TokenType.RPAREN, "if koşulundan sonra ')' bekleniyordu")
        val thenB = statement()
        var elseB: Stmt? = null
        if (match(TokenType.ELSE)) elseB = statement()
        return Stmt.If(cond, thenB, elseB)
    }

    private fun whileStatement(): Stmt {
        consume(TokenType.LPAREN, "while'dan sonra '(' bekleniyordu")
        val cond = expression()
        consume(TokenType.RPAREN, "while koşulundan sonra ')' bekleniyordu")
        val body = statement()
        return Stmt.While(cond, body)
    }

    private fun doWhileStatement(): Stmt {
        val body = statement()
        consume(TokenType.WHILE, "do gövdesinden sonra 'while' bekleniyordu")
        consume(TokenType.LPAREN, "while'dan sonra '(' bekleniyordu")
        val cond = expression()
        consume(TokenType.RPAREN, "while koşulundan sonra ')' bekleniyordu")
        matchSemicolon()
        return Stmt.DoWhile(body, cond)
    }

    private fun forStatement(): Stmt {
        consume(TokenType.LPAREN, "for'dan sonra '(' bekleniyordu")

        // foreach mi? for (var x : iterable)
        // Bunu anlamak için: VAR IDENTIFIER COLON  desenine bak
        if (check(TokenType.VAR) && checkNext(TokenType.IDENTIFIER) && checkNextNext(TokenType.COLON)) {
            advance() // var
            val varName = advance() // identifier
            advance() // :
            val iterable = expression()
            consume(TokenType.RPAREN, "foreach'ten sonra ')' bekleniyordu")
            val body = statement()
            return Stmt.ForEach(varName, iterable, body)
        }

        // klasik for (init; cond; step)
        val init: Stmt? = when {
            match(TokenType.SEMICOLON) -> null
            match(TokenType.VAR) -> varDeclaration()
            else -> expressionStatement()
        }
        var cond: Expr? = null
        if (!check(TokenType.SEMICOLON)) cond = expression()
        consume(TokenType.SEMICOLON, "for koşulundan sonra ';' bekleniyordu")
        var step: Expr? = null
        if (!check(TokenType.RPAREN)) step = expression()
        consume(TokenType.RPAREN, "for başlığından sonra ')' bekleniyordu")
        val body = statement()
        return Stmt.For(init, cond, step, body)
    }

    private fun returnStatement(): Stmt {
        val keyword = previous()
        var value: Expr? = null
        if (!check(TokenType.SEMICOLON) && !check(TokenType.RBRACE) && !isAtEnd() && !startsNewStatement()) {
            value = expression()
        }
        matchSemicolon()
        return Stmt.Return(keyword, value)
    }

    /** return'den sonra değer mi var yoksa yeni deyim mi başlıyor — kaba kontrol. */
    private fun startsNewStatement(): Boolean {
        // return tek başına bir satırdaysa değer yoktur; ama EMScript'te ; opsiyonel.
        // Güvenli taraf: sadece açık deyim başlatıcı anahtar kelimeler için true dön.
        return check(TokenType.RETURN) || check(TokenType.IF) || check(TokenType.WHILE) ||
               check(TokenType.FOR) || check(TokenType.VAR) || check(TokenType.FUN) ||
               check(TokenType.CLASS) || check(TokenType.DO)
    }

    private fun expressionStatement(): Stmt {
        val expr = expression()
        matchSemicolon()
        return Stmt.Expression(expr)
    }

    private fun block(): List<Stmt> {
        val statements = mutableListOf<Stmt>()
        while (!check(TokenType.RBRACE) && !isAtEnd()) {
            if (match(TokenType.SEMICOLON)) continue // boş deyimleri atla
            statements.add(declaration())
        }
        consume(TokenType.RBRACE, "Blok için '}' bekleniyordu")
        return statements
    }

    // ==================== İfadeler ====================

    private fun expression(): Expr = assignment()

    private fun assignment(): Expr {
        val expr = ternary()
        if (check(TokenType.ASSIGN) || check(TokenType.PLUS_ASSIGN) || check(TokenType.MINUS_ASSIGN) ||
            check(TokenType.STAR_ASSIGN) || check(TokenType.SLASH_ASSIGN)) {
            val op = advance()
            val value = assignment()
            if (expr is Expr.Variable || expr is Expr.Get || expr is Expr.Index) {
                return Expr.Assign(expr, op, value)
            }
            throw error(op, "Geçersiz atama hedefi")
        }
        return expr
    }

    private fun ternary(): Expr {
        var expr = or()
        if (match(TokenType.QUESTION)) {
            val thenE = expression()
            consume(TokenType.COLON, "Üçlü ifadede ':' bekleniyordu")
            val elseE = expression()
            expr = Expr.Ternary(expr, thenE, elseE)
        }
        return expr
    }

    private fun or(): Expr {
        var expr = and()
        while (match(TokenType.OR)) {
            val op = previous()
            val right = and()
            expr = Expr.Logical(expr, op, right)
        }
        return expr
    }

    private fun and(): Expr {
        var expr = equality()
        while (match(TokenType.AND)) {
            val op = previous()
            val right = equality()
            expr = Expr.Logical(expr, op, right)
        }
        return expr
    }

    private fun equality(): Expr {
        var expr = comparison()
        while (check(TokenType.EQ) || check(TokenType.NEQ)) {
            val op = advance()
            val right = comparison()
            expr = Expr.Binary(expr, op, right)
        }
        return expr
    }

    private fun comparison(): Expr {
        var expr = term()
        while (check(TokenType.LT) || check(TokenType.GT) || check(TokenType.LE) || check(TokenType.GE)) {
            val op = advance()
            val right = term()
            expr = Expr.Binary(expr, op, right)
        }
        return expr
    }

    private fun term(): Expr {
        var expr = factor()
        while (check(TokenType.PLUS) || check(TokenType.MINUS)) {
            val op = advance()
            val right = factor()
            expr = Expr.Binary(expr, op, right)
        }
        return expr
    }

    private fun factor(): Expr {
        var expr = unary()
        while (check(TokenType.STAR) || check(TokenType.SLASH) || check(TokenType.PERCENT)) {
            val op = advance()
            val right = unary()
            expr = Expr.Binary(expr, op, right)
        }
        return expr
    }

    private fun unary(): Expr {
        if (check(TokenType.NOT) || check(TokenType.MINUS)) {
            val op = advance()
            val right = unary()
            return Expr.Unary(op, right)
        }
        return callChain()
    }

    /** Çağrı zinciri: primary sonrası ()/./[ ] tekrarları. */
    private fun callChain(): Expr {
        var expr = primary()
        while (true) {
            expr = when {
                match(TokenType.LPAREN) -> finishCall(expr)
                match(TokenType.DOT) -> {
                    val name = consume(TokenType.IDENTIFIER, "'.' sonrası alan adı bekleniyordu")
                    Expr.Get(expr, name)
                }
                match(TokenType.LBRACKET) -> {
                    val index = expression()
                    val bracket = consume(TokenType.RBRACKET, "İndeksten sonra ']' bekleniyordu")
                    Expr.Index(expr, index, bracket)
                }
                else -> return expr
            }
        }
    }

    private fun finishCall(callee: Expr): Expr {
        val args = mutableListOf<Expr>()
        if (!check(TokenType.RPAREN)) {
            do {
                args.add(expression())
            } while (match(TokenType.COMMA))
        }
        val paren = consume(TokenType.RPAREN, "Argümanlardan sonra ')' bekleniyordu")
        return Expr.Call(callee, paren, args)
    }

    private fun primary(): Expr {
        if (match(TokenType.TRUE)) return Expr.Literal(true)
        if (match(TokenType.FALSE)) return Expr.Literal(false)
        if (match(TokenType.NULL)) return Expr.Literal(null)
        if (match(TokenType.NUMBER)) return Expr.Literal(previous().literal)
        if (match(TokenType.STRING)) return Expr.Literal(previous().literal)
        if (match(TokenType.THIS)) return Expr.This(previous())
        if (match(TokenType.NEW)) {
            val className = consume(TokenType.IDENTIFIER, "new'den sonra sınıf adı bekleniyordu")
            consume(TokenType.LPAREN, "Sınıf adından sonra '(' bekleniyordu")
            val args = mutableListOf<Expr>()
            if (!check(TokenType.RPAREN)) {
                do { args.add(expression()) } while (match(TokenType.COMMA))
            }
            consume(TokenType.RPAREN, "new argümanlarından sonra ')' bekleniyordu")
            return Expr.New(className, args)
        }
        if (match(TokenType.LBRACKET)) {
            // dizi literali
            val elements = mutableListOf<Expr>()
            if (!check(TokenType.RBRACKET)) {
                do { elements.add(expression()) } while (match(TokenType.COMMA))
            }
            consume(TokenType.RBRACKET, "Dizi için ']' bekleniyordu")
            return Expr.ArrayLiteral(elements)
        }
        if (match(TokenType.FUN)) {
            // anonim fonksiyon: fun (a,b) { } veya fun (a,b) => expr
            return lambdaAfterFun()
        }
        if (check(TokenType.IDENTIFIER)) {
            // lambda kısa yolu: x => ...  (tek parametreli)
            if (checkNext(TokenType.ARROW)) {
                val param = advance() // identifier
                advance() // =>
                return lambdaBody(listOf(param))
            }
            return Expr.Variable(advance())
        }
        if (match(TokenType.LPAREN)) {
            // ya gruplama ya da lambda: (a, b) => ...
            // İleriye bakıp lambda mı diye kontrol et
            if (looksLikeLambdaParams()) {
                val params = parseParams() // RPAREN'ı tüketir
                consume(TokenType.ARROW, "Lambda için '=>' bekleniyordu")
                return lambdaBody(params)
            }
            val expr = expression()
            consume(TokenType.RPAREN, "İfadeden sonra ')' bekleniyordu")
            return expr
        }
        throw error(peek(), "İfade bekleniyordu")
    }

    /** '(' zaten tüketildi; sonrasının 'params) =>' olup olmadığını geçici olarak tara. */
    private fun looksLikeLambdaParams(): Boolean {
        val save = current
        // boş param: ) =>
        if (check(TokenType.RPAREN) && checkNext(TokenType.ARROW)) return true
        // param listesi: IDENTIFIER (, IDENTIFIER)* ) =>
        var ok = check(TokenType.IDENTIFIER)
        if (ok) {
            var i = current
            // taklit ilerleme (gerçek current'ı bozmadan)
            fun typeAt(idx: Int) = if (idx < tokens.size) tokens[idx].type else TokenType.EOF
            var idx = i
            if (typeAt(idx) != TokenType.IDENTIFIER) { return false }
            idx++
            while (typeAt(idx) == TokenType.COMMA) {
                idx++
                if (typeAt(idx) != TokenType.IDENTIFIER) { ok = false; break }
                idx++
            }
            if (ok) ok = typeAt(idx) == TokenType.RPAREN && typeAt(idx + 1) == TokenType.ARROW
        }
        current = save
        return ok
    }

    private fun lambdaAfterFun(): Expr {
        consume(TokenType.LPAREN, "Anonim fonksiyon için '(' bekleniyordu")
        val params = parseParams()
        if (match(TokenType.ARROW)) return lambdaBody(params)
        consume(TokenType.LBRACE, "Fonksiyon gövdesi için '{' bekleniyordu")
        val body = block()
        return Expr.Lambda(params, body, null)
    }

    /** '=>' sonrası: ya { blok } ya da tek ifade. */
    private fun lambdaBody(params: List<Token>): Expr {
        if (match(TokenType.LBRACE)) {
            val body = block()
            return Expr.Lambda(params, body, null)
        }
        val expr = expression()
        return Expr.Lambda(params, emptyList(), expr)
    }

    // ==================== yardımcılar ====================

    private fun matchSemicolon() { while (match(TokenType.SEMICOLON)) { /* opsiyonel ; */ } }

    private fun match(type: TokenType): Boolean {
        if (check(type)) { advance(); return true }
        return false
    }

    private fun check(type: TokenType) = !isAtEnd() && peek().type == type
    private fun checkNext(type: TokenType): Boolean {
        if (current + 1 >= tokens.size) return false
        return tokens[current + 1].type == type
    }
    private fun checkNextNext(type: TokenType): Boolean {
        if (current + 2 >= tokens.size) return false
        return tokens[current + 2].type == type
    }

    private fun advance(): Token {
        if (!isAtEnd()) current++
        return previous()
    }
    private fun isAtEnd() = peek().type == TokenType.EOF
    private fun peek() = tokens[current]
    private fun previous() = tokens[current - 1]

    private fun consume(type: TokenType, message: String): Token {
        if (check(type)) return advance()
        throw error(peek(), message)
    }

    private fun error(token: Token, message: String): EmScriptError {
        val where = if (token.type == TokenType.EOF) "dosya sonunda" else "'${token.lexeme}' yakınında"
        return EmScriptError("$message ($where)", token.line)
    }
}
