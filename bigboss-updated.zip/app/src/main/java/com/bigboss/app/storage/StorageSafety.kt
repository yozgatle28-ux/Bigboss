package com.bigboss.app.storage

import android.util.Log
import java.io.File

/**
 * HATA DÜZELTMESİ: Önceden, bir depolama dosyası (rules.json, library.json, vb.) herhangi bir
 * sebeple (yarım kalmış yazma, bozuk karakter, uygulama güncellemesi sonrası şema uyuşmazlığı)
 * JSON olarak okunamadığında, `load()` sessizce BOŞ bir liste döndürüyordu. Kullanıcı arayüzü bu
 * boş listeyi normal karşılayıp herhangi bir `save()` çağrısında (örneğin tek bir kural eklerken)
 * dosyanın üzerine BOŞ içerik yazıyordu — yani kullanıcının TÜM kuralları/kütüphanesi kalıcı
 * olarak siliniyordu, üstelik kullanıcıya hiçbir uyarı gösterilmeden.
 *
 * Artık bir dosya okunamadığında, üzerine hiçbir şey yazılmadan önce `.corrupt-<timestamp>`
 * uzantılı bir YEDEK olarak kopyalanıyor ve hata logcat'e yazılıyor. Böylece veri fiziksel
 * olarak diskte kalmaya devam ediyor ve gerekirse elle geri yüklenebiliyor.
 */
internal object StorageSafety {
    private const val TAG = "BigBossStorage"

    fun backupCorrupt(file: File, e: Exception) {
        Log.e(TAG, "${file.name} okunamadı, veri kaybını önlemek için dosya yedekleniyor: ${e.message}", e)
        try {
            val backup = File(file.parentFile, "${file.name}.corrupt-${System.currentTimeMillis()}")
            file.copyTo(backup, overwrite = true)
        } catch (backupError: Exception) {
            Log.e(TAG, "Bozuk dosya yedeklenemedi: ${file.name}", backupError)
        }
    }
}
