package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * BİRLEŞİK DEĞİŞKEN DEPOSU (Macrorify'daki "Variables"). Artık TEK sistem:
 *  - Oyun-içi sayaçlar (eskiden buradaydı) VE
 *  - Kalıcı ayar değişkenleri (eskiden GlobalVariableStorage'daydı)
 * aynı çalışma-zamanı deposunda birleşir. Değerler METİN (String) olarak tutulur,
 * böylece Number + String + Reference üç tip de aynı depoda yaşayabilir.
 *
 * KALICILIK: Motor katmanı Context'e erişemez. Bunun yerine dışarıdan (Edit/PlayMode)
 * bir `persister` ve `initialLoader` verilir:
 *   - initialLoader: uygulama başlarken kalıcı değişkenleri (JSON'dan) yükler.
 *   - persister: set() çağrıldığında değeri kalıcı depoya yazar (name -> textValue).
 * Böylece bir script setVar("altin", 500) dediğinde hem bellekte hem diskte güncellenir.
 *
 * REFERENCE tipi: değeri bir ifadedir (örn. getVar("a")+5). resolveReference callback'i
 * ile script motorunda değerlendirilir. Ayarlanmazsa ham metin döner.
 */
object VariableStore {
    /** name -> ham metin değer (Number: "10", String: "merhaba", Reference: "getVar(\"a\")+5") */
    private val vars = ConcurrentHashMap<String, String>()
    /** name -> tip ("NUMBER" | "STRING" | "REFERENCE"). Bilinmiyorsa NUMBER varsayılır. */
    private val types = ConcurrentHashMap<String, String>()

    /** set() olduğunda kalıcı depoya yazan köprü (Edit/PlayMode kurar). */
    @Volatile var persister: ((name: String, textValue: String) -> Unit)? = null
    /** Bir REFERENCE ifadesini değerlendiren köprü (script motoru). Sonuç metin olarak döner. */
    @Volatile var resolveReference: ((expr: String) -> String?)? = null

    /** Uygulama başlarken kalıcı değişkenleri belleğe yükler (name, textValue, type). */
    fun loadInitial(entries: List<Triple<String, String, String>>) {
        entries.forEach { (name, textValue, type) ->
            vars[name] = textValue
            types[name] = type
        }
    }

    // ---- Sayısal erişim (geriye dönük: eski get/set/increment Int imzaları korunur) ----

    /** Değişkenin SAYISAL değeri. Reference ise önce değerlendirilir. Sayı değilse 0. */
    fun get(name: String): Int = getNumber(name)

    fun getNumber(name: String): Int {
        val resolved = resolvedRaw(name) ?: return 0
        return resolved.trim().toDoubleOrNull()?.toInt() ?: 0
    }

    fun set(name: String, value: Int) { setRaw(name, value.toString(), "NUMBER") }

    fun increment(name: String, delta: Int) { setRaw(name, (getNumber(name) + delta).toString(), "NUMBER") }

    // ---- Metin erişim ----

    /** Değişkenin METİN değeri. Reference ise değerlendirilmiş sonucu. */
    fun getString(name: String): String = resolvedRaw(name) ?: ""

    fun setString(name: String, value: String) { setRaw(name, value, "STRING") }

    // ---- Ham erişim + tip ----

    /** Ham (değerlendirilmemiş) metin. Reference için ifadenin kendisi. Yoksa null. */
    fun getRaw(name: String): String? = vars[name]

    fun getType(name: String): String = types[name] ?: "NUMBER"

    /** Değeri ve (opsiyonel) tipi ayarlar, kalıcı depoya da yazar. */
    fun setRaw(name: String, textValue: String, type: String? = null) {
        vars[name] = textValue
        if (type != null) types[name] = type
        persister?.invoke(name, textValue)
    }

    /** REFERENCE ise ifadeyi değerlendirip sonucu, değilse ham değeri döner. */
    private fun resolvedRaw(name: String): String? {
        val rawVal = vars[name] ?: return null
        return if (getType(name) == "REFERENCE") {
            resolveReference?.invoke(rawVal) ?: rawVal
        } else rawVal
    }

    fun getAll(): Map<String, String> = vars.toMap()
    fun reset(name: String) { setRaw(name, "0", "NUMBER") }
    fun resetAll() { vars.clear(); types.clear() }
}
