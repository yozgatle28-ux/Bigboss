package com.bigboss.app.engine

/**
 * Macrorify'daki "Region Scaling" (Basic → Region Scaling) mantığının BigBoss karşılığı.
 *
 * Bir kural OLUŞTURULDUĞU ekranın çözünürlüğünde (baseW x baseH) kaydedilir (bölge X/Y/W/H,
 * dokunma noktaları hep bu çözünürlüğe göredir). Farklı bir cihazda (ya da aynı cihazda farklı
 * bir çözünürlükte, örn. yeniden kurulum sonrası) ÇALIŞTIRILDIĞINDA, bu yardımcı sınıf
 * koordinatları GÜNCEL çözünürlüğe (curW x curH) ölçekler.
 *
 * 3 mod (Macrorify dokümanındaki tanımlara sadık kalınarak, kendi yorumumuzla):
 *  - FIXED   : Tek bir orana (en küçük eksen oranı) göre, EN-BOY ORANINI BOZMADAN, ekranın
 *              MERKEZİNDEN sabitlenerek ölçeklenir. "Ortadaki elemanlar için" — en-boy oranı
 *              değişse bile öğe görsel olarak bozulmadan (gerilmeden) ekranın ortasında kalır.
 *  - DYNAMIC : X ve Y ekseni BAĞIMSIZ oranlarla (yüzde olarak) ölçeklenir, sol-üstten
 *              (0,0) itibaren. "Kenara hizalı elemanlar için" — ekranın kenarına göre yüzdesi
 *              korunur ama en-boy oranı değişirse öğe gerilebilir (distortion kabul edilir).
 *  - STICKY  : FIXED gibi en-boy oranını bozmadan ölçekler ama seçilen KENAR(LAR)DAN sabit bir
 *              boşluk (margin) korunacak şekilde konumlandırır (örn. sağ-üst köşedeki bir buton,
 *              ekran genişlese bile hep sağ-üstte aynı boşlukla kalır). Kenar seçilmemiş bir
 *              eksende sol-üstten (0,0) itibaren normal ölçekleme uygulanır.
 *
 * NOT: Ölçekleme, kural İNŞA edilirken (RuleDefinitionMapper, ScriptEngine'deki değişken
 * çözümlemesiyle AYNI noktada) BİR KERE uygulanır. Bu, mimariyle tutarlıdır ama şu anlama gelir:
 * Play Mode ÇALIŞIRKEN ekran döndürülürse (yönlendirme değişirse), kurallar bir sonraki
 * yeniden-kuruluma (kural düzenleme, ya da Play Mode'u yeniden başlatma) kadar YENİ çözünürlüğe
 * göre tekrar ölçeklenmez. Macrorify de benzer bir modele sahiptir; kabul edilebilir bir sınırlama.
 */
object RegionScaler {
    const val EDGE_LEFT = 1
    const val EDGE_TOP = 2
    const val EDGE_RIGHT = 4
    const val EDGE_BOTTOM = 8

    data class ScaledRegion(val x: Int, val y: Int, val width: Int, val height: Int)
    data class ScaledPoint(val x: Int, val y: Int)

    /**
     * Bir dikdörtgeni (bölge) base çözünürlükten güncel çözünürlüğe ölçekler.
     * baseW/baseH/curW/curH <= 0 İSE, ya da base==current İSE, HİÇBİR ŞEY değiştirmez —
     * eski kurallar (ölçekleme bilgisi olmayan) ve tek-cihaz kullanımı için %100 uyumluluk.
     */
    fun scaleRegion(
        x: Int, y: Int, width: Int, height: Int,
        baseW: Int, baseH: Int, curW: Int, curH: Int,
        mode: String, stickyEdges: Int
    ): ScaledRegion {
        if (baseW <= 0 || baseH <= 0 || curW <= 0 || curH <= 0) return ScaledRegion(x, y, width, height)
        if (baseW == curW && baseH == curH) return ScaledRegion(x, y, width, height)

        val scaleX = curW.toFloat() / baseW.toFloat()
        val scaleY = curH.toFloat() / baseH.toFloat()

        return when (mode) {
            "DYNAMIC" -> ScaledRegion(
                x = (x * scaleX).toInt(),
                y = (y * scaleY).toInt(),
                width = (width * scaleX).toInt().coerceAtLeast(1),
                height = (height * scaleY).toInt().coerceAtLeast(1)
            )
            "STICKY" -> scaleSticky(x, y, width, height, minOf(scaleX, scaleY), baseW, baseH, curW, curH, stickyEdges)
            else -> { // "FIXED" (varsayılan): tek orana göre, en-boy oranını bozmadan, MERKEZDEN ölçekle
                val scale = minOf(scaleX, scaleY)
                ScaledRegion(
                    x = ((x - baseW / 2f) * scale + curW / 2f).toInt(),
                    y = ((y - baseH / 2f) * scale + curH / 2f).toInt(),
                    width = (width * scale).toInt().coerceAtLeast(1),
                    height = (height * scale).toInt().coerceAtLeast(1)
                )
            }
        }
    }

    private fun scaleSticky(
        x: Int, y: Int, width: Int, height: Int, scale: Float,
        baseW: Int, baseH: Int, curW: Int, curH: Int, stickyEdges: Int
    ): ScaledRegion {
        var newW = (width * scale).toInt().coerceAtLeast(1)
        var newH = (height * scale).toInt().coerceAtLeast(1)
        var newX = (x * scale).toInt() // varsayılan: sol kenardan (0,0) itibaren ölçekle
        var newY = (y * scale).toInt() // varsayılan: üst kenardan (0,0) itibaren ölçekle

        val stickyLeft = stickyEdges and EDGE_LEFT != 0
        val stickyRight = stickyEdges and EDGE_RIGHT != 0
        val stickyTop = stickyEdges and EDGE_TOP != 0
        val stickyBottom = stickyEdges and EDGE_BOTTOM != 0

        if (stickyRight) {
            val rightMarginScaled = ((baseW - (x + width)) * scale).toInt()
            newX = if (stickyLeft) {
                // hem sol hem sağ sabit: iki kenar arası GERÇEKTEN esner (genişlik yeniden hesaplanır)
                newW = (curW - newX - rightMarginScaled).coerceAtLeast(1)
                newX
            } else {
                curW - rightMarginScaled - newW
            }
        }
        if (stickyBottom) {
            val bottomMarginScaled = ((baseH - (y + height)) * scale).toInt()
            newY = if (stickyTop) {
                newH = (curH - newY - bottomMarginScaled).coerceAtLeast(1)
                newY
            } else {
                curH - bottomMarginScaled - newH
            }
        }
        return ScaledRegion(newX, newY, newW, newH)
    }

    /** Tek bir NOKTA (dokunma/kaydırma koordinatı) için aynı mantık — 1x1'lik bir bölge gibi ölçeklenir. */
    fun scalePoint(
        x: Int, y: Int,
        baseW: Int, baseH: Int, curW: Int, curH: Int,
        mode: String, stickyEdges: Int
    ): ScaledPoint {
        val r = scaleRegion(x, y, 1, 1, baseW, baseH, curW, curH, mode, stickyEdges)
        return ScaledPoint(r.x, r.y)
    }

    /**
     * Bir OFFSET/DELTA değeri (nokta farkı, örn. Relative Coordinates'daki offsetX/Y) için
     * ölçekleme. Bir "kenar"ı yoktur, bu yüzden her zaman basit oransal (DYNAMIC tarzı) ölçeklenir.
     */
    fun scaleDeltaX(dx: Int, baseW: Int, curW: Int): Int {
        if (baseW <= 0 || curW <= 0 || baseW == curW) return dx
        return (dx * (curW.toFloat() / baseW.toFloat())).toInt()
    }

    fun scaleDeltaY(dy: Int, baseH: Int, curH: Int): Int {
        if (baseH <= 0 || curH <= 0 || baseH == curH) return dy
        return (dy * (curH.toFloat() / baseH.toFloat())).toInt()
    }
}
