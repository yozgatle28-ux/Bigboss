package com.bigboss.app.storage

/**
 * Macrorify'daki "Swipe Point": bir kaydırma/gesture yolundaki tek bir nokta.
 * Her noktanın kendi bekleme süresi (hold), sonraki noktaya geçiş hızı (speed)
 * ve ölçekleme türü (scale) vardır.
 */
data class SwipePointData(
    var x: Int = 0,
    var y: Int = 0,
    /** Bu noktada parmağın basılı bekleyeceği süre (ms). */
    var holdMs: Long = 0,
    /** Sonraki noktaya geçiş hızı — Macrorify birimi: piksel / 12ms. Büyük = hızlı. */
    var speed: Int = 20,
    /** "FIXED" (orantılı ölçekle) | "STICKY" (kenara sabitle) — farklı cihazlara uyarlama. */
    var scale: String = "FIXED",
    /** Opsiyonel: koordinat yerine değişken/ifade (💡). Boşsa x/y kullanılır. */
    var xVarName: String? = null,
    var yVarName: String? = null,
    var holdVarName: String? = null,
    var speedVarName: String? = null
)
