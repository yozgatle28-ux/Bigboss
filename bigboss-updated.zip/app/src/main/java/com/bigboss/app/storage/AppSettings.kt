package com.bigboss.app.storage

import android.content.Context

/** Basit, kalıcı uygulama ayarları (SharedPreferences tabanlı). */
object AppSettings {
    private const val PREFS = "bigboss_settings"
    private const val KEY_AUTO_STOP_MINUTES = "auto_stop_minutes"
    private const val KEY_DARK_MODE = "dark_mode"

    /** "Otomatik Durdurma": kaç dakika boyunca HİÇBİR kural tetiklenmezse makro otomatik dursun. 0 = kapalı. */
    fun getAutoStopMinutes(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_AUTO_STOP_MINUTES, 0)

    fun setAutoStopMinutes(context: Context, minutes: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_AUTO_STOP_MINUTES, minutes).apply()
    }

    /** Panel/ekranların Karanlık mı Aydınlık mı görüneceği. */
    fun isDarkMode(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DARK_MODE, false)

    fun setDarkMode(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }
}
