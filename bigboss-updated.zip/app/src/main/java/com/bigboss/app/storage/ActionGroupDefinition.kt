package com.bigboss.app.storage

/**
 * "Action Group": performans optimizasyonu için. Bir GATE (kapı) koşulu
 * (örn. bir simge) ve o kapı doğru olduğunda çalışan bir tarama listesi.
 * Kapı koşulu ekranda YOKSA, içindeki taramalar HİÇ kontrol edilmez —
 * böylece 50 taramayı 2 gruba (25+25) ayırıp gereksiz sistemi yormadan
 * çalıştırabilirsin.
 */
data class ActionGroupDefinition(
    val id: String,
    var name: String,
    var enabled: Boolean = true,
    /** Grubun "kapı" koşulu — bu ekranda bulunmadıkça içindeki taramalar kontrol edilmez. */
    var gate: ConditionAlt? = null,
    /** Kapı en fazla ne sıklıkla kontrol edilsin (ms). */
    var gateCooldownMs: Long = 300,
    /** Kapı bulununca, gruptaki taramalar kaç kere art arda çalışsın ("döngü sayısı"). gateInfiniteLoop true ise bu yok sayılır. */
    var gateRepeat: Int = 1,
    /** Macrorify'daki "Infinite Loop": true ise gateRepeat yok sayılır, kapı koşulu doğru olduğu sürece SONSUZA kadar tekrarlar. */
    var gateInfiniteLoop: Boolean = false,
    /** "Time Limit": Infinite Loop açıkken, bu süre (ms) aşılınca döngü otomatik durur. 0 = sınırsız (gerçekten sonsuz). */
    var gateTimeLimitMs: Long = 0,
    /** Kapı bulununca sırayla taranacak/çalışacak kurallar. */
    var rules: MutableList<RuleDefinition> = mutableListOf()
)
