package com.bigboss.app.storage

import android.content.Context
import com.bigboss.app.engine.Action
import com.bigboss.app.engine.Condition
import com.bigboss.app.engine.RegionScaler
import com.bigboss.app.engine.Rule
import com.bigboss.app.model.Region

/**
 * Editörden gelen düz RuleDefinition listesini, RuleEngine'in anladığı
 * Rule/Condition/Action nesnelerine çevirir.
 *
 * REGION SCALING (Macrorify "Fixed/Dynamic/Sticky"): her RuleDefinition, OLUŞTURULDUĞU ekranın
 * çözünürlüğünü (baseScreenW/H) taşır. Bu Mapper, kural İNŞA edilirken (curW/curH — GÜNCEL cihaz
 * çözünürlüğü verildiyse) bölge/nokta koordinatlarını [RegionScaler] ile bir KERE ölçekler —
 * tıpkı değişken çözümlemesi (resolve()) gibi BUILD-TIME bir işlem. curW/curH verilmezse (0,0
 * varsayılan) hiçbir ölçekleme uygulanmaz — eski çağıranlar (Context'siz/çözünürlüksüz) ve eski
 * kurallar (baseScreenW=0) için %100 geriye dönük uyumluluk korunur.
 *
 * RELATIVE COORDINATES (Macrorify "Locatable Detection"): bir ConditionAlt/RuleDefinition'ın
 * relativeAnchorRuleId alanı doluysa, bölge/nokta SABİT değil, o ID'li kuralın SON bulunduğu
 * konuma (MatchLocationRegistry, RUNTIME'da RuleEngine tarafından doldurulur) göre HER FRAME
 * yeniden hesaplanır — bu yüzden bu kısım build-time'da ÇÖZÜLEMEZ, Condition.RelativeTo /
 * Action.TapRelative nesneleri olarak motora taşınır.
 */
object RuleDefinitionMapper {

    private fun toSingleCondition(
        alt: ConditionAlt,
        baseW: Int, baseH: Int, curW: Int, curH: Int, scaleMode: String, stickyEdges: Int
    ): Condition {
        val scaled = RegionScaler.scaleRegion(
            alt.x, alt.y, alt.width.coerceAtLeast(1), alt.height.coerceAtLeast(1),
            baseW, baseH, curW, curH, scaleMode, stickyEdges
        )
        val region = Region(scaled.x, scaled.y, scaled.width.coerceAtLeast(1), scaled.height.coerceAtLeast(1))
        val minScoreFraction = alt.minScore.coerceIn(0, 100) / 100f
        val base: Condition = when (alt.conditionKind) {
            "IMAGE" -> Condition.ImageInRegion(region, alt.templatePath ?: "", minScoreFraction)
            "TEXT" -> Condition.TextInRegion(region, alt.expectedText ?: "", minScoreFraction, alt.textCaseSensitive, alt.textWhitelist, alt.textBlacklist)
            // Macrorify "Conditional" tipleri — ekran taramasından bağımsız mantıksal koşullar:
            "VARIABLE" -> Condition.VariableCompare(alt.variableName, alt.variableOp, alt.compareValue)
            "CUSTOM" -> Condition.Script(alt.customCode)
            else -> Condition.ColorInRegion(region, alt.color, minScoreFraction)
        }

        // Macrorify "Relative Coordinates" (Locatable Detection): bölgesi olan koşul tipleri
        // (COLOR/IMAGE/TEXT) için, bir anchor kural seçildiyse Condition.RelativeTo ile sarmalanır.
        val anchorId = alt.relativeAnchorRuleId
        if (anchorId.isNullOrBlank() || alt.conditionKind !in setOf("COLOR", "IMAGE", "TEXT")) return base

        val offX = RegionScaler.scaleDeltaX(alt.relativeOffsetX, baseW, curW)
        val offY = RegionScaler.scaleDeltaY(alt.relativeOffsetY, baseH, curH)
        val resizeW = alt.relativeResizeW?.let { RegionScaler.scaleDeltaX(it, baseW, curW).coerceAtLeast(1) }
        val resizeH = alt.relativeResizeH?.let { RegionScaler.scaleDeltaY(it, baseH, curH).coerceAtLeast(1) }
        return Condition.RelativeTo(anchorId, offX, offY, resizeW, resizeH, alt.relativeMaxAnchorAgeMs, base)
    }

    fun toCondition(def: RuleDefinition, curW: Int = 0, curH: Int = 0): Condition {
        if (def.alternatives.isEmpty()) return Condition.Always // koşulsuz adım (sadece dokunma/kaydırma gibi)
        val baseW = def.baseScreenW; val baseH = def.baseScreenH
        val mode = def.regionScaleMode; val edges = def.regionStickyEdges
        val altList = def.alternatives
        val mainCondition: Condition = if (altList.size == 1) {
            toSingleCondition(altList[0], baseW, baseH, curW, curH, mode, edges)
        } else {
            val logic = try { Condition.GroupLogic.valueOf(def.alternativesLogic) } catch (e: Exception) { Condition.GroupLogic.ONE_SUCCESS }
            Condition.Group(altList.map { toSingleCondition(it, baseW, baseH, curW, curH, mode, edges) }, logic)
        }

        val extraGates = mutableListOf<Condition>()
        val variableName = def.requireVariableName
        if (!variableName.isNullOrBlank()) {
            extraGates.add(Condition.VariableCompare(variableName, def.requireVariableOp, def.requireVariableValue))
        }
        if (def.randomChancePercent in 0..99) {
            extraGates.add(Condition.Random(def.randomChancePercent))
        }

        return if (extraGates.isEmpty()) mainCondition
        else Condition.Group(listOf(mainCondition) + extraGates, Condition.GroupLogic.ALL_SUCCESS)
    }

    /**
     * Bir alan bir değişkene bağlıysa GÜNCEL sayısal değerini, değilse sabit değeri döner.
     * Birleşik değişken sistemi: önce çalışma-zamanı VariableStore'a (setVar/Set Variable ile
     * güncellenen canlı değer), o yoksa kalıcı GlobalVariableStorage'a bakar.
     */
    private fun resolve(context: Context?, varName: String?, fallback: Long): Long {
        if (varName.isNullOrBlank()) return fallback
        // Ampul menüsü alana "{isim}" yazmış olabilir → süslü parantezleri soy.
        val name = Regex("^\\{([A-Za-z_][A-Za-z0-9_]*)\\}$").find(varName.trim())?.groupValues?.get(1) ?: varName
        // 1) Çalışma zamanı deposu (en güncel — script/aksiyonlarla değişmiş olabilir)
        if (com.bigboss.app.engine.VariableStore.getRaw(name) != null) {
            return com.bigboss.app.engine.VariableStore.getNumber(name).toLong()
        }
        // 2) Kalıcı depo (Context varsa)
        if (context != null) {
            com.bigboss.app.storage.GlobalVariableStorage.valueOf(context, name)?.let { return it }
        }
        // 3) Düz sayı olabilir (ampul "Forever" → "-1" yazmış olabilir)
        varName.trim().toLongOrNull()?.let { return it }
        return fallback
    }

    private fun toActionStep(
        step: com.bigboss.app.storage.ActionStep, context: Context?,
        baseW: Int = 0, baseH: Int = 0, curW: Int = 0, curH: Int = 0, mode: String = "FIXED", edges: Int = 0
    ): Action {
        fun sp(x: Int, y: Int) = RegionScaler.scalePoint(x, y, baseW, baseH, curW, curH, mode, edges)
        return when (step.type) {
            "TAP" -> sp(step.x, step.y).let { Action.Tap(it.x, it.y, step.repeat.coerceAtLeast(1), step.holdMs.coerceAtLeast(1), step.postDelayMs) }
            "SWIPE" -> {
                val a = sp(step.x, step.y); val b = sp(step.x2, step.y2)
                // KÖK NEDEN DÜZELTMESİ: süre artık HER ZAMAN 300ms'e sabitlenmiyor — step'in
                // KENDİ swipeDurationMs'i (On Success/On Fail editöründeki hız presetiyle
                // ayarlanan GERÇEK değer) kullanılıyor. Böylece bu yoldan eklenen swipe, Ana
                // Akış'taki swipe ile AYNI algoritmayı (Action.Swipe → dispatchSwipe) birebir
                // aynı parametrelerle çalıştırır.
                Action.Swipe(a.x, a.y, b.x, b.y, step.swipeDurationMs.coerceAtLeast(1), step.swipeHoldStartMs, step.swipeHoldEndMs, step.postDelayMs)
            }
            "WAIT" -> Action.Wait(step.waitMs)
            "PLAY_RECORD" -> {
                val record = context?.let { com.bigboss.app.storage.RecordStorage.find(it, step.recordId ?: "") }
                if (record != null) Action.Sequence(com.bigboss.app.storage.RecordStorage.toActions(record)) else Action.NoOp
            }
            "CALL_FUNCTION" -> Action.CallFunction(step.functionId ?: "", step.repeat.coerceAtLeast(1))
            "SET_VARIABLE" -> Action.SetVariable(step.variableName, step.variableDelta)
            "RUN_SCRIPT" -> Action.RunScript(step.scriptCode ?: "", step.scriptLanguage)
            "SYSTEM_BACK" -> Action.SystemAction("BACK")
            "SYSTEM_HOME" -> Action.SystemAction("HOME")
            "SYSTEM_RECENTS" -> Action.SystemAction("RECENTS")
            "SYSTEM_NOTIFICATIONS" -> Action.SystemAction("NOTIFICATIONS")
            "SYSTEM_QUICK_SETTINGS" -> Action.SystemAction("QUICK_SETTINGS")
            "READ_TEXT" -> {
                // NOT: burada x,y,x2,y2 bir BÖLGE (x,y,genişlik,yükseklik) olarak kullanılır — iki nokta değil.
                val r = RegionScaler.scaleRegion(step.x, step.y, step.x2.coerceAtLeast(1), step.y2.coerceAtLeast(1), baseW, baseH, curW, curH, mode, edges)
                Action.ReadTextToVariable(r.x, r.y, r.width, r.height, step.variableName, step.readDefaultValue, step.readWhitelist, step.readBlacklist)
            }
            else -> Action.NoOp
        }
    }

    fun toAction(def: RuleDefinition, context: Context? = null, curW: Int = 0, curH: Int = 0): Action {
        val baseW = def.baseScreenW; val baseH = def.baseScreenH
        val mode = def.regionScaleMode; val edges = def.regionStickyEdges

        val effectiveHold = resolve(context, def.actionHoldVarName, def.actionHoldMs).coerceAtLeast(1)
        val effectivePostDelay = resolve(context, def.actionPostDelayVarName, def.actionPostDelayMs).coerceAtLeast(0)
        val effectiveSwipeHoldStart = resolve(context, def.swipeHoldStartVarName, def.swipeHoldStartMs).coerceAtLeast(0)
        val effectiveSwipeHoldEnd = resolve(context, def.swipeHoldEndVarName, def.swipeHoldEndMs).coerceAtLeast(0)
        // Macrorify "her input alanında değişken" — repeat/randomize/duration/koordinat da bağlanabilir:
        val effectiveRepeat = resolve(context, def.actionRepeatVarName, def.actionRepeatCount.toLong()).toInt().coerceAtLeast(1)
        val effectiveRandom = resolve(context, def.randomOffsetVarName, def.randomOffsetPx.toLong()).toInt().coerceAtLeast(0)
        val effectiveDuration = resolve(context, def.swipeDurationVarName, def.swipeDurationMs)
        val rawX = resolve(context, def.actionXVarName, def.actionX.toLong()).toInt()
        val rawY = resolve(context, def.actionYVarName, def.actionY.toLong()).toInt()
        val rawX2 = resolve(context, def.actionX2VarName, def.actionX2.toLong()).toInt()
        val rawY2 = resolve(context, def.actionY2VarName, def.actionY2.toLong()).toInt()
        // Region Scaling: dokunma/kaydırma NOKTALARI da base->current çözünürlüğe göre ölçeklenir.
        val p1 = RegionScaler.scalePoint(rawX, rawY, baseW, baseH, curW, curH, mode, edges)
        val p2 = RegionScaler.scalePoint(rawX2, rawY2, baseW, baseH, curW, curH, mode, edges)
        val effX = p1.x; val effY = p1.y
        val effX2 = p2.x; val effY2 = p2.y

        val baseAction: Action = when (def.actionType) {
            "SWIPE" -> if (def.swipeExtraFingerPaths.isNotEmpty()) {
                // GERÇEK çoklu parmak: 1. parmağın yolu (swipePathPoints VARSA o, yoksa basit 2 nokta) +
                // swipeExtraFingerPaths'teki TÜM diğer parmaklar, hepsi ölçeklenerek birleştirilir.
                val primaryPath: List<Action.SwipePointDef> = if (def.swipePathPoints.size >= 2) {
                    def.swipePathPoints.map {
                        val sp = RegionScaler.scalePoint(it.x, it.y, baseW, baseH, curW, curH, mode, edges)
                        Action.SwipePointDef(sp.x, sp.y, it.holdMs, it.speed)
                    }
                } else {
                    // Basit 2-nokta primary parmağı multi-finger'da birlikte hareket ederken
                    // kullanıcının seçtiği swipeDurationMs'yi KORUMAK için speed'i tersine çözüyoruz.
                    // Yoksa varsayılan 20 ile hız çok farklı segment süreleri oluştururdu.
                    val dist = kotlin.math.hypot((effX2 - effX).toDouble(), (effY2 - effY).toDouble())
                    val primarySpeed = if (effectiveDuration > 0 && dist > 0) {
                        ((dist * 12.0) / effectiveDuration).toInt().coerceIn(1, 1000)
                    } else 20
                    listOf(
                        Action.SwipePointDef(effX, effY, effectiveSwipeHoldStart, primarySpeed),
                        Action.SwipePointDef(effX2, effY2, effectiveSwipeHoldEnd, primarySpeed)
                    )
                }
                val extraPaths = def.swipeExtraFingerPaths.map { finger ->
                    finger.map {
                        val sp = RegionScaler.scalePoint(it.x, it.y, baseW, baseH, curW, curH, mode, edges)
                        Action.SwipePointDef(sp.x, sp.y, it.holdMs, it.speed)
                    }
                }
                Action.MultiFingerSwipe(
                    paths = listOf(primaryPath) + extraPaths,
                    segmentDurationMs = effectiveDuration,
                    postDelayMs = effectivePostDelay,
                    randomOffsetPx = effectiveRandom
                )
            } else if (def.swipePathPoints.size > 2) {
                Action.MultiPointSwipe(
                    points = def.swipePathPoints.map {
                        val sp = RegionScaler.scalePoint(it.x, it.y, baseW, baseH, curW, curH, mode, edges)
                        Action.SwipePointDef(sp.x, sp.y, it.holdMs, it.speed)
                    },
                    segmentDurationMs = effectiveDuration,
                    postDelayMs = effectivePostDelay,
                    randomOffsetPx = effectiveRandom
                )
            } else Action.Swipe(
                x1 = effX, y1 = effY,
                x2 = effX2, y2 = effY2,
                durationMs = effectiveDuration,
                holdStartMs = effectiveSwipeHoldStart,
                holdEndMs = effectiveSwipeHoldEnd,
                postDelayMs = effectivePostDelay,
                randomOffsetPx = effectiveRandom
            )
            // "Koşulsuz Bekle" (Macrorify "Wait"): artık gerçekten bekliyor (eskiden NoOp'tu — hiçbir şey yapmazdı).
            "WAIT" -> Action.Wait(effectivePostDelay.coerceAtLeast(0))
            "SYSTEM_BACK" -> Action.SystemAction("BACK")
            "SYSTEM_HOME" -> Action.SystemAction("HOME")
            "SYSTEM_RECENTS" -> Action.SystemAction("RECENTS")
            "SYSTEM_NOTIFICATIONS" -> Action.SystemAction("NOTIFICATIONS")
            "SYSTEM_QUICK_SETTINGS" -> Action.SystemAction("QUICK_SETTINGS")
            "CALL_FUNCTION" -> Action.CallFunction(def.callFunctionId ?: "", def.callFunctionRepeat.coerceAtLeast(1))
            // Macrorify "Set Variable" (bağımsız üst-düzey adım): gerçek iş, AŞAĞIDAKİ mevcut
            // "incrementVariableName" mekanizmasından (steps.add ile HER actionType'a eklenen ortak
            // etki) geliyor — burada sadece etiket/placeholder olarak NoOp döner, çift eklemeyi önler.
            "SET_VARIABLE" -> Action.NoOp
            // Macrorify "Play Record" (bağımsız üst-düzey adım): seçili kaydı Action dizisine çevirip sırayla çalıştırır.
            "PLAY_RECORD" -> {
                val record = context?.let { com.bigboss.app.storage.RecordStorage.find(it, def.playRecordId ?: "") }
                if (record != null) Action.Sequence(com.bigboss.app.storage.RecordStorage.toActions(record)) else Action.NoOp
            }
            // Macrorify "Text Reader" (bağımsız üst-düzey adım): actionX/Y/X2/Y2 burada BÖLGE (x,y,genişlik,yükseklik) olarak kullanılır.
            "READ_TEXT" -> {
                val r = RegionScaler.scaleRegion(def.actionX, def.actionY, def.actionX2.coerceAtLeast(1), def.actionY2.coerceAtLeast(1), baseW, baseH, curW, curH, mode, edges)
                Action.ReadTextToVariable(r.x, r.y, r.width, r.height, def.readTextVariableName ?: "", def.readTextDefaultValue, def.readTextWhitelist, def.readTextBlacklist)
            }
            // Macrorify "Code" (bağımsız üst-düzey adım): kütüphaneye kaydetmeden, doğrudan gömülü kod.
            "RUN_SCRIPT" -> Action.RunScript(def.runScriptCode ?: "", def.runScriptLanguage)
            // ACTION sekmesindeki "Wait till appear/vanish" modları: birincil aksiyon YOK (tıklamaz).
            // Koşul sağlanınca (appear = bulundu, vanish = negate ile bulunamadı) onSuccess yine çalışır.
            "NONE" -> Action.NoOp
            else -> {
                val anchorId = def.actionRelativeAnchorRuleId
                if (def.tapAtMatchLocation && def.tapAllMatches) {
                    Action.TapAllMatches(effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
                } else if (def.tapAtMatchLocation) {
                    Action.TapAtMatch(effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
                } else if (!anchorId.isNullOrBlank()) {
                    // Macrorify "Relative Coordinates" aksiyon tarafı: sabit nokta yerine başka
                    // bir kuralın son bulunduğu konum + offset'e dokun.
                    val offX = RegionScaler.scaleDeltaX(def.actionRelativeOffsetX, baseW, curW)
                    val offY = RegionScaler.scaleDeltaY(def.actionRelativeOffsetY, baseH, curH)
                    Action.TapRelative(anchorId, offX, offY, effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
                } else {
                    Action.Tap(effX, effY, effectiveRepeat, effectiveHold, effectivePostDelay, effectiveRandom)
                }
            }
        }

        val steps = mutableListOf(baseAction)
        val varName = def.incrementVariableName
        if (!varName.isNullOrBlank()) steps.add(Action.SetVariable(varName, def.incrementVariableDelta, def.incrementVariableMode))
        def.extraSteps.forEach { steps.add(toActionStep(it, context, baseW, baseH, curW, curH, mode, edges)) }

        return if (steps.size == 1) steps[0] else Action.Sequence(steps)
    }

    fun toRule(def: RuleDefinition, context: Context? = null, curW: Int = 0, curH: Int = 0): Rule {
        // 💡 Ampul: Timeout/Scan Rate/Wait Next/Delay bir değişkene bağlıysa sabit değer yerine onun güncel değerini kullan.
        val effectiveScanTimeout = resolve(context, def.scanTimeoutVarName, def.scanTimeoutMs)
        val effectiveScanRateHz = if (def.scanRateVarName.isNullOrBlank()) def.scanRateHz
            else resolve(context, def.scanRateVarName, (def.scanRateHz * 10).toLong()) / 10f
        val effectiveCooldown = resolve(context, def.cooldownVarName, def.timeoutMs)
        val effectiveMatchDelay = resolve(context, def.matchDelayVarName, def.matchDelayMs)
        return Rule(
            id = def.id,
            name = def.name,
            condition = toCondition(def, curW, curH),
            thenAction = toAction(def, context, curW, curH),
            cooldownMs = if (effectiveCooldown < 0) 0 else effectiveCooldown,
            enabled = def.enabled,
            negate = def.negateCondition,
            loopMode = def.loopMode,
            matchDelayMs = effectiveMatchDelay,
            scanTimeoutMs = effectiveScanTimeout,
            scanRateHz = effectiveScanRateHz,
            maxConsecutiveFailures = def.maxConsecutiveFailures
        )
    }

    /** Sadece etkin (enabled) kuralları, tanımlandıkları sırayla Rule'a çevirir. */
    fun toRules(definitions: List<RuleDefinition>, context: Context? = null, curW: Int = 0, curH: Int = 0): List<Rule> =
        definitions.filter { it.enabled }.map { toRule(it, context, curW, curH) }
}
