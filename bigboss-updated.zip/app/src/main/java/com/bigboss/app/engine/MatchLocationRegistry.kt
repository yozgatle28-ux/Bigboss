package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Macrorify'daki "Relative Coordinates" (Locatable Detection) için: bir kuralın koşulu
 * EN SON DOĞRU bulunduğunda, BULUNDUĞU KONUMU (eşleşmenin merkez noktası) burada saklar.
 * Başka bir kural/aksiyon, bu konumu "anchor" (referans nokta) olarak kullanıp ondan
 * OFFSET alarak kendi bölgesini/dokunuşunu buna göre KONUMLANDIRABİLİR — kaydırılan bir
 * listede öğe pozisyonu sürekli değiştiğinde (fiyat, satın-al butonu gibi) ZORUNLU bir
 * mekanizma, çünkü sabit koordinat işe yaramaz.
 *
 * NOT: Sadece "konum döndüren" koşullar (ColorInRegion, ImageInRegion — Condition.matchLocation
 * override eden tipler) burada kayıt bırakır. TextInRegion (OCR) henüz konum döndürmüyor (motor
 * sınırlaması, README'de dürüstçe belirtilmiştir) — bu yüzden metin bazlı kurallar ANCHOR olarak
 * kullanılamaz; böyle bir kurala bağlanan bir Relative koşulu/aksiyonu hep "anchor yok" (null)
 * bulur ve tetiklenmez.
 */
object MatchLocationRegistry {
    private data class Entry(val x: Int, val y: Int, val timestamp: Long)

    private val locations = ConcurrentHashMap<String, Entry>()

    /** Bir kuralın koşulu DOĞRU bulunduğunda (negate/cooldown'dan BAĞIMSIZ — ham sonuç) çağrılır. */
    fun record(ruleId: String, x: Int, y: Int) {
        locations[ruleId] = Entry(x, y, System.currentTimeMillis())
    }

    /** maxAgeMs içinde kaydedilmiş bir konum varsa (x to y) döner, yoksa (hiç bulunmadı ya da çok eski) null. */
    fun get(ruleId: String, maxAgeMs: Long): Pair<Int, Int>? {
        val e = locations[ruleId] ?: return null
        val age = System.currentTimeMillis() - e.timestamp
        if (age > maxAgeMs) return null
        return e.x to e.y
    }

    /** "Stop" butonu / Play Mode yeniden başlatma için: tüm konum geçmişini temizler. */
    fun reset() = locations.clear()
}
