package com.bigboss.app.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Macrorify'daki "Resources" kırpma aracının birebir kopyası: solda kontrol paneli
 * (X/Y/W/H + döndür/sıfırla/iptal/onay), sağda ekran/görsel üzerinde turkuaz çerçeve.
 * Çerçeve sürüklenebilir, sağ-alt üçgen tutamakla boyutlandırılabilir; koordinatlar
 * gerçek zamanlı senkronize.
 *
 * Hem ekrandan kütüphaneye görsel ekleme (ScreenCapture) hem de kütüphanedeki
 * mevcut görseli yeniden kırpma (LibraryBitmap) için aynı araç kullanılır.
 */
class MacrorifyCropTool(
    private val context: Context,
    private val windowManager: WindowManager,
    private val maxW: Int,
    private val maxH: Int,
    private val initialRect: Rect,
    private val backgroundBitmap: android.graphics.Bitmap? = null,
    private val onDone: (Rect) -> Unit,
    private val onCancel: () -> Unit
) {

    private val density = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private var rootView: FrameLayout? = null
    private var frameView: CropFrameView? = null
    private var panelView: LinearLayout? = null
    private var etX: EditText? = null
    private var etY: EditText? = null
    private var etW: EditText? = null
    private var etH: EditText? = null
    private var suppressSync = false

    private var frameX = 0f
    private var frameY = 0f
    private var frameW = 0f
    private var frameH = 0f

    private val panelWidth = (160 * density).toInt()
    private val panelMargin = (12 * density).toInt()
    private val minFrameSize = (24 * density).toInt()
    private val triangleSize = (22 * density)

    /** Overlay'i ekrana ekler. */
    fun show() {
        if (rootView != null) return

        val root = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            if (backgroundBitmap != null) {
                setBackgroundColor(Color.BLACK)
            } else {
                setBackgroundColor(Color.parseColor("#22000000")) // hafif karartma, arka planı görünür tutar
            }
        }
        rootView = root

        backgroundBitmap?.let { bmp ->
            val bg = android.widget.ImageView(context).apply {
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                setImageBitmap(bmp)
            }
            root.addView(bg)
        }

        val frame = CropFrameView(context).apply {
            layoutParams = FrameLayout.LayoutParams(0, 0)
        }
        frameView = frame
        root.addView(frame)

        val panel = buildControlPanel()
        panelView = panel
        root.addView(panel, FrameLayout.LayoutParams(panelWidth, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = panelMargin
            topMargin = panelMargin
        })

        val rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(root, rootParams)

        // Başlangıç konumunu uygula
        setFrameRect(initialRect, animate = false)
    }

    /** Overlay'i kaldırır. */
    fun dismiss() {
        rootView?.let { windowManager.removeView(it) }
        rootView = null
        frameView = null
        panelView = null
    }

    private fun buildControlPanel(): LinearLayout {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F7F7F9"))
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
        }
        val stroke = GradientDrawable().apply {
            setColor(Color.parseColor("#F7F7F9"))
            setStroke((1 * density).toInt(), Color.parseColor("#DDDDDD"))
            cornerRadius = 6f * density
        }
        panel.background = stroke

        val title = TextView(context).apply {
            text = "Kırp"
            textSize = 14f
            setTextColor(Color.parseColor("#333333"))
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        panel.addView(title)

        fun fieldRow(hint1: String, hint2: String): Pair<EditText, EditText> {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            val e1 = EditText(context).apply {
                this.hint = hint1
                textSize = 12f
                setTextColor(Color.parseColor("#333333"))
                setHintTextColor(Color.parseColor("#999999"))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                background = fieldBg()
            }
            val e2 = EditText(context).apply {
                this.hint = hint2
                textSize = 12f
                setTextColor(Color.parseColor("#333333"))
                setHintTextColor(Color.parseColor("#999999"))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = (6 * density).toInt()
                }
                setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                background = fieldBg()
            }
            row.addView(e1); row.addView(e2)
            panel.addView(row)
            return e1 to e2
        }

        val (xField, yField) = fieldRow("X", "Y")
        etX = xField; etY = yField
        val (wField, hField) = fieldRow("Genişlik", "Yükseklik")
        etW = wField; etH = hField

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { syncFrameFromFields() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        etX?.addTextChangedListener(watcher)
        etY?.addTextChangedListener(watcher)
        etW?.addTextChangedListener(watcher)
        etH?.addTextChangedListener(watcher)

        val btnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, (12 * density).toInt(), 0, 0)
        }
        btnRow.addView(textBtn("↻", Color.parseColor("#2196F3")) { rotateFrame() })
        btnRow.addView(textBtn("▭", Color.parseColor("#2196F3")) { resetFrame() })
        btnRow.addView(textBtn("✕", Color.parseColor("#E53935")) { dismiss(); onCancel() })
        btnRow.addView(textBtn("✓", Color.parseColor("#43A047")) { confirm() })
        panel.addView(btnRow)

        return panel
    }

    private fun fieldBg(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.WHITE)
        setStroke((1 * density).toInt(), Color.parseColor("#DDDDDD"))
        cornerRadius = 4f * density
    }

    private fun textBtn(symbol: String, tint: Int, onClick: () -> Unit): TextView {
        val size = (36 * density).toInt()
        return TextView(context).apply {
            text = symbol
            textSize = 20f
            setTextColor(tint)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(size, size)
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    /** Çerçeveyi verilen Rect'e göre konumlandırır. */
    private fun setFrameRect(rect: Rect, animate: Boolean) {
        val x = rect.left.toFloat().coerceIn(0f, max(0f, (maxW - minFrameSize).toFloat()))
        val y = rect.top.toFloat().coerceIn(0f, max(0f, (maxH - minFrameSize).toFloat()))
        val w = rect.width().toFloat().coerceIn(minFrameSize.toFloat(), maxW.toFloat() - x)
        val h = rect.height().toFloat().coerceIn(minFrameSize.toFloat(), maxH.toFloat() - y)
        applyFrame(x, y, w, h)
        syncFieldsFromFrame()
    }

    private fun applyFrame(x: Float, y: Float, w: Float, h: Float) {
        frameX = x; frameY = y; frameW = w; frameH = h
        frameView?.let { fv ->
            fv.layoutParams = FrameLayout.LayoutParams(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)).apply {
                leftMargin = x.toInt()
                topMargin = y.toInt()
            }
            fv.requestLayout()
        }
    }

    private fun syncFieldsFromFrame() {
        if (suppressSync) return
        suppressSync = true
        etX?.setText(frameX.toInt().toString())
        etY?.setText(frameY.toInt().toString())
        etW?.setText(frameW.toInt().toString())
        etH?.setText(frameH.toInt().toString())
        suppressSync = false
    }

    private fun syncFrameFromFields() {
        if (suppressSync) return
        val x = etX?.text?.toString()?.toIntOrNull() ?: return
        val y = etY?.text?.toString()?.toIntOrNull() ?: return
        val w = etW?.text?.toString()?.toIntOrNull() ?: return
        val h = etH?.text?.toString()?.toIntOrNull() ?: return
        if (w <= 0 || h <= 0) return
        setFrameRect(Rect(x, y, x + w, y + h), animate = false)
    }

    private fun rotateFrame() {
        // Çerçeveyi 90° döndür: genişlik/yükseklik takas; sağ-alt ve sol-üst konumlarını koru
        val newW = frameH
        val newH = frameW
        var newX = frameX
        var newY = frameY
        if (newX + newW > maxW) newX = (maxW - newW).coerceAtLeast(0f)
        if (newY + newH > maxH) newY = (maxH - newH).coerceAtLeast(0f)
        applyFrame(newX, newY, newW, newH)
        syncFieldsFromFrame()
    }

    private fun resetFrame() {
        setFrameRect(Rect(0, 0, maxW, maxH), animate = false)
    }

    private fun confirm() {
        val rect = Rect(frameX.toInt(), frameY.toInt(), (frameX + frameW).toInt(), (frameY + frameH).toInt())
        dismiss()
        onDone(rect)
    }

    /** Turkuaz border + sağ-alt üçgen boyutlandırma tutamağı. */
    private inner class CropFrameView(ctx: Context) : View(ctx) {
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4") // Macrorify turkuazı
            style = Paint.Style.STROKE
            strokeWidth = 3f * density
        }
        private val trianglePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4")
            style = Paint.Style.FILL
        }
        private val triangleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00BCD4")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * density
        }

        private var dragMode = DragMode.NONE
        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0f
        private var startY = 0f
        private var startW = 0f
        private var startH = 0f

        init {
            isClickable = true
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX; downRawY = event.rawY
                        startX = frameX; startY = frameY; startW = frameW; startH = frameH
                        dragMode = if (isInTriangle(event.x, event.y)) DragMode.RESIZE else DragMode.MOVE
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        when (dragMode) {
                            DragMode.MOVE -> {
                                val nx = (startX + dx).coerceIn(0f, max(0f, maxW - frameW))
                                val ny = (startY + dy).coerceIn(0f, max(0f, maxH - frameH))
                                applyFrame(nx, ny, frameW, frameH)
                            }
                            DragMode.RESIZE -> {
                                val newW = (startW + dx).coerceIn(minFrameSize.toFloat(), maxW - startX)
                                val newH = (startH + dy).coerceIn(minFrameSize.toFloat(), maxH - startY)
                                applyFrame(startX, startY, newW, newH)
                            }
                            else -> {}
                        }
                        syncFieldsFromFrame()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragMode = DragMode.NONE
                }
                true
            }
        }

        private fun isInTriangle(x: Float, y: Float): Boolean {
            // Sağ-alt köşede eşkenar üçgen / dik üçgen bölge
            return x >= width - triangleSize && y >= height - triangleSize
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val inset = borderPaint.strokeWidth / 2f
            canvas.drawRect(inset, inset, w - inset, h - inset, borderPaint)

            // Sağ-alt üçgen tutamak
            val path = Path().apply {
                moveTo(w, h - triangleSize)
                lineTo(w - triangleSize, h)
                lineTo(w, h)
                close()
            }
            canvas.drawPath(path, trianglePaint)
            canvas.drawLine(w, h - triangleSize, w - triangleSize, h, triangleStroke)
        }
    }

    private enum class DragMode { NONE, MOVE, RESIZE }
}
