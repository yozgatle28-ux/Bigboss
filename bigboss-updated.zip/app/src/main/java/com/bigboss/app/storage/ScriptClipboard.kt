package com.bigboss.app.storage

/** "Functions" sayfasındaki Kopyala/Kes/Yapıştır için — FunctionClipboard'ın Script (Code) karşılığı. */
object ScriptClipboard {
    private var copied: ScriptDefinition? = null

    fun copy(script: ScriptDefinition) {
        copied = script.copy()
    }

    fun hasContent(): Boolean = copied != null
    fun peekName(): String? = copied?.name

    fun pasteAsNew(): ScriptDefinition? {
        val src = copied ?: return null
        return src.copy(id = java.util.UUID.randomUUID().toString())
    }
}
