package com.bigboss.app.storage

/**
 * Bir "macro" (iş) — Macrorify'daki her bir otomasyon projesi. Artık uygulama
 * ÇOKLU macro destekliyor; her macro'nun kendi kuralları, fonksiyonları, scriptleri,
 * kütüphanesi, değişkenleri ve ayarları var (MacroScope ile dosya adı macroId'ye göre
 * ayrılır). Bu sınıf yalnızca macro'nun ÜST BİLGİSİNİ (metadata) tutar.
 */
data class MacroDefinition(
    val id: String,
    var name: String,
    /** "PORTRAIT" | "LANDSCAPE" — makronun tasarlandığı yön (ölçekleme için kritik). */
    var orientation: String = "PORTRAIT",
    /** Makronun tasarlandığı referans çözünürlük (ölçekleme temeli). */
    var width: Int = 1080,
    var height: Int = 1920,
    /** Opsiyonel ikon dosya yolu (kullanıcı seçerse). Boşsa varsayılan ikon. */
    var iconPath: String = "",
    /** Oluşturulma zamanı (sıralama için). */
    val createdAt: Long = System.currentTimeMillis(),
    /** Uygulama versiyonu etiketi (kartta gösterilir, Macrorify'daki "1.0.0" gibi). */
    var version: String = "1.0.0"
)
