package com.bigboss.app.engine

/**
 * ScriptEngine, Context'e ihtiyaç duyduğu için (Function/VariableStore
 * köprüleri) Condition/Action seviyesinde doğrudan oluşturulamıyor.
 * Bunun yerine EditModeActivity/PlayModeActivity botu başlatırken bir
 * ScriptEngine kurup buraya atıyor; Condition.Script gibi sınıflar
 * buradan erişiyor.
 */
object ScriptRuntime {
    var engine: ScriptEngine? = null

    /**
     * EMScript motoru için host köprüsü (AndroidEmHost). Edit/PlayMode botu kurarken
     * ScriptEngine'in yanında bunu da atar. Action.RunScript EMScript ise buradan çalışır.
     * Tip: com.bigboss.app.emscript.EmHost (Any olarak tutulur ki engine paketi
     * emscript paketine bağımlı olmasın — kullanım yerinde cast edilir).
     */
    var emHost: com.bigboss.app.emscript.EmHost? = null
}
