package com.bigboss.app.storage

/**
 * BİRLEŞİK DEĞİŞKEN (Macrorify'daki "Variable"). Artık TEK bir değişken kavramı var:
 * hem kalıcı ayar sabitleri (eski "🔢 Değişkenler") hem de oyun-içi sayaçlar (eski
 * script VariableStore) aynı yerde tutulur. Herhangi bir input alanına {isim} ile
 * gömülebilir ("her yerde kullanılabilir").
 *
 * Macrorify'ın 3 tipi:
 *  - NUMBER: sayısal parametre (örn. count = 0). textValue bir tam sayı metnidir.
 *  - STRING: metin parametresi (örn. mesaj = "merhaba").
 *  - REFERENCE: bir İFADE (örn. getVar("a") + 5). Okunduğunda script motorunda
 *    değerlendirilir — dinamik/hesaplanan değer.
 *
 * İsimlendirme kuralı (Macrorify): sadece a-z A-Z 0-9 ve _ ; sayıyla başlayamaz.
 * Konvansiyon camelCase (topRegion, middlePoint).
 *
 * NOT: Geriye dönük uyumluluk — eski JSON'larda sadece `value: Long` alanı vardı.
 * Gson eski dosyaları okurken `type`/`textValue`/`disabled` alanlarını varsayılanla
 * doldurur; `migrated()` ile eski `value` yeni `textValue`'ya taşınır.
 */
data class GlobalVariableDefinition(
    val id: String,
    var name: String,
    /** GERİYE DÖNÜK: eski sürümdeki sayısal değer. Yeni sürümde textValue kullanılır; bu sadece göç için tutulur. */
    var value: Long = 0,
    /** "NUMBER" | "STRING" | "REFERENCE" */
    var type: String = "NUMBER",
    /** Değişkenin değeri — tüm tipler METİN olarak saklanır (Number için "10", String için "merhaba", Reference için ifade). */
    var textValue: String? = null,
    /** true ise değişken devre dışı (Macrorify'daki "Disable"). */
    var disabled: Boolean = false
) {
    /** Eski JSON'dan yüklendiyse (textValue null) eski sayısal `value`'yu textValue'ya taşır. */
    fun migrated(): GlobalVariableDefinition {
        if (textValue == null) textValue = value.toString()
        return this
    }

    /** Bu değişkenin ham metin değeri (Reference ise ifadenin kendisi). */
    fun raw(): String = textValue ?: value.toString()
}
