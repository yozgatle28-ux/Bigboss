package com.bigboss.app.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Macrorify'daki "Action Result" koşulunun temeli: bir kuralın en son
 * ne zaman tetiklendiğini tutar. Böylece "B kuralı, A kuralı yakın
 * zamanda tetiklendiyse çalışsın" gibi SIRA gerektiren senaryolar,
 * paralel/reaktif motorda da mümkün olur — gerçek bir "sıra" olmadan.
 */
object ActionResultRegistry {
    private val lastFiredAt = ConcurrentHashMap<String, Long>()

    /** "Otomatik Durdurma" güvenlik ağı için: HERHANGİ bir kuralın en son ne zaman tetiklendiği (global). */
    @Volatile private var lastAnyFiredAt: Long = System.currentTimeMillis()

    fun markFired(ruleId: String) {
        val now = System.currentTimeMillis()
        lastFiredAt[ruleId] = now
        lastAnyFiredAt = now
    }

    fun firedWithin(ruleId: String, withinMs: Long): Boolean {
        val t = lastFiredAt[ruleId] ?: return false
        return System.currentTimeMillis() - t <= withinMs
    }

    fun lastFiredAt(ruleId: String): Long? = lastFiredAt[ruleId]

    /** Şu andan itibaren HERHANGİ bir kuralın en son tetiklenmesinden bu yana geçen süre (ms). */
    fun msSinceAnyFire(): Long = System.currentTimeMillis() - lastAnyFiredAt

    /** "Play" başlarken/durdurulunca çağrılır — sayaç sıfırdan başlasın diye. */
    fun markAliveNow() { lastAnyFiredAt = System.currentTimeMillis() }

    fun reset() {
        lastFiredAt.clear()
        lastAnyFiredAt = System.currentTimeMillis()
    }

    /**
     * KULLANICI RAPORU: bir swipe'ın hold'unu 0'dan bir değere değiştirince test/Play Mode
     * "çalışmıyor" gibi görünüyor — ama `resolveAndExecute`'un try-catch'i (Log.e ile) bir
     * hatayı YAKALIYORSA bunu SESSİZCE yutuyordu, kullanıcı GÖRMÜYORDU. Artık SON hata burada
     * (UI'ın DA erişebileceği paylaşılan bir nesnede) tutuluyor — OverlayService bunu
     * KONTROL EDİP bir Toast olarak gösterebiliyor, "motor aslında bir hata alıyor mu yoksa
     * gerçekten hiçbir şey mi olmuyor" sorusuna KESİN bir cevap veriyor.
     */
    @Volatile var lastActionError: String? = null
        private set
    fun recordActionError(msg: String) { lastActionError = msg }
    fun consumeLastActionError(): String? { val m = lastActionError; lastActionError = null; return m }
}
