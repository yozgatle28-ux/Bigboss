package com.bigboss.app.emscript

/**
 * EMScript token tipleri. Macrorify'ın EMScript dilinin sözdizimine göre:
 * C-tarzı, dinamik tipli. var/fun/class/if/else/for/while/do/return/break/continue,
 * ternary (?:), foreach (for x : arr), lambda (=>), dizi, nesne/sınıf.
 */
enum class TokenType {
    // Literaller
    NUMBER, STRING, IDENTIFIER,
    // Anahtar kelimeler
    VAR, FUN, CLASS, IF, ELSE, FOR, WHILE, DO, RETURN, BREAK, CONTINUE,
    NEW, STATIC, INIT, THIS, TRUE, FALSE, NULL,
    // Operatörler ve noktalama
    PLUS, MINUS, STAR, SLASH, PERCENT,
    ASSIGN,                 // =
    PLUS_ASSIGN, MINUS_ASSIGN, STAR_ASSIGN, SLASH_ASSIGN, // += -= *= /=
    EQ, NEQ, LT, GT, LE, GE,   // == != < > <= >=
    AND, OR, NOT,           // && || !
    QUESTION, COLON,        // ? :
    ARROW,                  // => (lambda)
    DOT, COMMA, SEMICOLON,
    LPAREN, RPAREN,         // ( )
    LBRACE, RBRACE,         // { }
    LBRACKET, RBRACKET,     // [ ]
    // Son
    EOF
}

/**
 * Tek bir token. line: hata mesajları için satır numarası.
 * literal: NUMBER için Double, STRING için String, diğerlerinde null.
 */
data class Token(
    val type: TokenType,
    val lexeme: String,
    val literal: Any? = null,
    val line: Int = 1
) {
    override fun toString(): String = "$type('$lexeme')"
}

/** EMScript çalışma/ayrıştırma hatası — satır bilgisiyle. */
class EmScriptError(message: String, val line: Int = -1) : RuntimeException(
    if (line >= 0) "Satır $line: $message" else message
)
