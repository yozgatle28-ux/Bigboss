package com.bigboss.app.storage

/**
 * Kaydedilmiş bir jest dizisi (Macrorify "Record"). Kullanıcının ekranda yaptığı
 * gerçek dokunuş/kaydırma hareketleri, ZAMAN DAMGALARIYLA yakalanıp burada saklanır.
 * Oynatılırken (Play Record) olaylar aynı zamanlamayla yeniden yapılır.
 *
 * Bu sürüm TEK PARMAK kaydını destekler (dokunuş + kaydırma). Çok-parmak (10 parmağa
 * kadar eşzamanlı jest) sonraki sürümde eklenecek.
 */
data class RecordDefinition(
    val id: String,
    var name: String,
    /** Kayıttaki olaylar (zaman sırasına göre). */
    var events: MutableList<RecordEvent> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Kayıttaki tek bir olay. İki tip:
 *  - "TAP": (x,y) noktasına dokunuş; durationMs = basılı kalma süresi.
 *  - "SWIPE": (x,y) -> (x2,y2) kaydırma; durationMs = kaydırma süresi.
 * startOffsetMs: kaydın başından bu olaya kadar geçen süre (zamanlamayı korur).
 */
data class RecordEvent(
    var type: String = "TAP",   // "TAP" | "SWIPE"
    var x: Int = 0,
    var y: Int = 0,
    var x2: Int = 0,
    var y2: Int = 0,
    var durationMs: Long = 50,
    /** Kaydın başlangıcından bu olayın başladığı ana kadar geçen ms (bekleme hesabı için). */
    var startOffsetMs: Long = 0
)
